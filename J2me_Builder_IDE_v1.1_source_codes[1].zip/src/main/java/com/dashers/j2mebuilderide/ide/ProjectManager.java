package com.dashers.j2mebuilderide.ide;

import java.io.File;
import java.io.IOException;
import java.util.Vector;

import com.dashers.j2mebuilderide.compiler.Compiler;
import com.dashers.j2mebuilderide.compiler.CompileError;

/**
 * Android port of the original J2ME/MIDP ProjectManager.java.
 *
 * Every method name and signature is unchanged from the original so that
 * calling code (Activities, or blocks in Sketchware Pro calling into this
 * as a custom Java class) doesn't need to change at all -- only the
 * storage layer underneath changed, from JSR-75 FileConnection/
 * FileSystemRegistry to plain java.io.File.
 *
 * A few things that don't translate 1:1 from MIDP and are handled
 * differently here, on purpose:
 *  - There's no FileSystemRegistry/drive-letter concept on Android, so
 *    getWritableRoot() and the mkdirIfMissing() segment-walking dance
 *    (which existed specifically to work around JSR-75's mkdir() only
 *    creating one path segment at a time on Symbian) are no longer
 *    needed -- java.io.File.mkdirs() already creates a full missing
 *    directory chain in one call. They're kept here (see below) only
 *    as thin wrappers so any caller still referencing them keeps working,
 *    but they now just delegate to File.mkdirs().
 *  - hasFilePermission() on Android should really be backed by a runtime
 *    permission check (READ_EXTERNAL_STORAGE / WRITE_EXTERNAL_STORAGE, or
 *    Storage Access Framework grants on Android 10+/scoped storage) --
 *    that check has to happen in your Activity, since it needs a
 *    Context/Activity to request permissions. What's here is a plain
 *    "can I actually open this path" probe, same behavioral contract as
 *    the original (returns false rather than throwing), but it will not
 *    proactively prompt the user -- do that in the Activity before
 *    calling into ProjectManager.
 */
public class ProjectManager {

    public final String projectsRoot;

    public ProjectManager(String projectsRoot) {
        this.projectsRoot = projectsRoot;
    }

    // ---------------- project list ----------------

    public void ensureRoot() throws IOException {
        try {
            mkdirIfMissing(projectsRoot);
        } catch (SecurityException se) {
            // If we can't create the root, try an alternative location
            throw new IOException("Cannot access file system: " + se.getMessage());
        }
    }

    public Vector listProjectNames() {
        Vector names = new Vector();
        try {
            if (!hasFilePermission(projectsRoot)) {
                return names;
            }

            File dir = new File(projectsRoot);
            if (dir.exists() && dir.isDirectory()) {
                File[] entries = dir.listFiles();
                if (entries != null) {
                    for (int i = 0; i < entries.length; i++) {
                        if (entries[i].isDirectory()) {
                            names.addElement(entries[i].getName());
                        }
                    }
                }
            }
        } catch (SecurityException se) {
            // Handle security exception gracefully
            System.err.println("Security exception when listing projects: " + se.getMessage());
            // Return empty list
        }
        return names;
    }

    /**
     * Check if we have read permission for a given path. On Android this
     * is a plain existence/readability probe -- it does NOT request
     * runtime storage permissions or Storage Access Framework grants.
     * Request those in your Activity (ActivityCompat.requestPermissions /
     * the SAF document-tree picker) before your app ever gets here; this
     * method just confirms the path is actually reachable given whatever
     * permissions the app already has.
     */
    private boolean hasFilePermission(String path) {
        try {
            File f = new File(path);
            // A path that doesn't exist yet isn't a permission failure --
            // callers like ensureRoot()/createProject() expect to create
            // it. Only treat this as "no permission" if the path exists
            // but genuinely can't be read (e.g. blocked by scoped storage).
            return !f.exists() || f.canRead();
        } catch (SecurityException se) {
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * NOT reliable on Android -- kept only for source-level parity with
     * the original J2ME API surface. It was originally written assuming
     * System.getProperty("user.home") behaves like a desktop JVM (falling
     * back to a sensible default when null); on Android this property
     * commonly returns "/" (the filesystem root) instead of null, which
     * silently produces an unwritable path like "/JCompiler/projects/" --
     * a location only the OS itself can write to, no matter what storage
     * permissions the app has been granted. That bug is exactly what
     * produced a real "Could not create directory: /JCompiler/projects/"
     * failure on-device even after the user granted storage permission
     * and manually created folders elsewhere -- the app was never even
     * looking at the user's storage in that case.
     *
     * Always call this with a real Context-derived path instead --
     * Context.getExternalFilesDir(null) (needs no runtime permission on
     * any Android version) or a user-picked Storage Access Framework
     * folder -- see JCompilerBridge.init(Context), which does this
     * correctly and is what Sketchware Pro blocks should actually call.
     */
    public static String getWritableRoot() {
        String dir = System.getProperty("user.home");
        if (dir == null || dir.length() == 0 || dir.equals("/")) dir = "/sdcard/JCompiler";
        if (!dir.endsWith("/")) dir = dir + "/";
        return dir;
    }

    public Project createProject(String name) throws IOException {
        return createProject(name, true);
    }

    /** writeStub=false creates the folders only (no default-package <name>.java), for
     *  callers that write their own, package-aware main source file. */
    public Project createProject(String name, boolean writeStub) throws IOException {
        Project p = new Project();
        p.folderName = name;
        p.rootUrl = projectsRoot + name + "/";
        p.mainClass = name;

        try {
            mkdirIfMissing(p.rootUrl);
            mkdirIfMissing(p.srcUrl());
            mkdirIfMissing(p.resUrl());
            mkdirIfMissing(p.binUrl());

            p.save();

            if (!writeStub) return p;

            String stub =
                "import javax.microedition.midlet.MIDlet;\n" +
                "import javax.microedition.lcdui.Display;\n" +
                "import javax.microedition.lcdui.Form;\n" +
                "\n" +
                "public class " + name + " extends MIDlet {\n" +
                "    Display display;\n" +
                "    Form form;\n" +
                "\n" +
                "    public " + name + "() {\n" +
                "        display = Display.getDisplay(this);\n" +
                "        form = new Form(\"" + name + "\");\n" +
                "        form.append(\"Hello, world!\");\n" +
                "    }\n" +
                "\n" +
                "    protected void startApp() {\n" +
                "        display.setCurrent(form);\n" +
                "    }\n" +
                "\n" +
                "    protected void pauseApp() {\n" +
                "    }\n" +
                "\n" +
                "    protected void destroyApp(boolean unconditional) {\n" +
                "    }\n" +
                "}\n";
            Project.writeWholeFile(p.srcUrl() + name + ".java", stub.getBytes("UTF-8"));

            return p;
        } catch (SecurityException se) {
            throw new IOException("Cannot create project due to security restrictions: " + se.getMessage());
        }
    }

    public Project openProject(String name) throws IOException {
        Project p = new Project();
        p.folderName = name;
        p.rootUrl = projectsRoot + name + "/";

        try {
            p.load();
            return p;
        } catch (SecurityException se) {
            throw new IOException("Cannot open project due to security restrictions: " + se.getMessage());
        }
    }

    public void deleteProject(String name) throws IOException {
        try {
            deleteRecursive(projectsRoot + name + "/");
        } catch (SecurityException se) {
            throw new IOException("Cannot delete project due to security restrictions: " + se.getMessage());
        }
    }

    // ---------------- packaging ----------------
    // Unchanged from the original except for the package/import rename --
    // this whole section only ever went through Project.readWholeFile/
    // writeWholeFile and the Compiler/ZipWriter/ManifestBuilder classes,
    // none of which touch FileConnection directly.

    public static class PackageResult {
        public boolean ok;
        public String message;
        public int jarBytes;
        public int classCount;
    }

    public PackageResult packageProject(Project p) { return packageProject(p, null); }

    /** Packages the project; when 'pre' (the result of a compile that just ran) is given it is reused instead of compiling again. */
    public PackageResult packageProject(Project p, Compiler.ProjectResult pre) {
        PackageResult result = new PackageResult();

        try {
            if (!hasFilePermission(p.rootUrl)) {
                result.ok = false;
                result.message = "Cannot access project directory. Please grant file permissions.";
                return result;
            }
        } catch (Exception e) {
            result.ok = false;
            result.message = "Permission error: " + e.getMessage();
            return result;
        }

        Vector sourceNames = listSourceFiles(p);
        if (sourceNames.size() == 0) {
            result.ok = false;
            result.message = "No .java files in src/ to compile.";
            return result;
        }

        Compiler.ProjectFile[] files = new Compiler.ProjectFile[sourceNames.size()];
        StringBuffer errors = new StringBuffer();
        for (int i = 0; i < sourceNames.size(); i++) {
            String fileName = (String) sourceNames.elementAt(i);
            Compiler.ProjectFile pf = new Compiler.ProjectFile();
            pf.fileName = fileName;
            try {
                byte[] srcBytes = Project.readWholeFile(p.srcUrl() + fileName);
                pf.source = (srcBytes != null) ? new String(srcBytes, "UTF-8") : "";
            } catch (IOException ioe) {
                errors.append(fileName).append(": ").append(ioe.getMessage()).append('\n');
                pf.source = "";
            } catch (SecurityException se) {
                errors.append(fileName).append(": permission denied\n");
                pf.source = "";
            }
            files[i] = pf;
        }
        if (errors.length() > 0) {
            result.ok = false;
            result.message = "Package aborted -- could not read source:\n" + errors;
            return result;
        }

        ZipWriter zip = new ZipWriter();
        int compiledCount = 0;
        boolean mainClassFound = false;
        StringBuffer warnings = new StringBuffer();
        String obfNote = null;

        try {
            java.util.Hashtable srcMap = new java.util.Hashtable();
            for (int fi = 0; fi < files.length; fi++) srcMap.put(files[fi].fileName, files[fi].source);
            Compiler.ProjectResult unit;
            if (pre != null) {
                unit = pre;
            } else if (com.dashers.j2mebuilderide.compiler.EcjCompiler.isInitialized()) {
                Libraries.prepare(p, srcMap);
                File[] a = Libraries.jars(p, false);
                File[] b = Libraries.jars(p, true);
                File[] all = new File[a.length + b.length];
                System.arraycopy(a, 0, all, 0, a.length);
                System.arraycopy(b, 0, all, a.length, b.length);
                unit = com.dashers.j2mebuilderide.compiler.EcjCompiler.compileProject(files, all);
            } else {
                Libraries.prepare(p, srcMap);
                unit = Compiler.compileProject(files);
            }
            String[] entryNames = new String[unit.classBytes.length];
            byte[][] entryBytes = new byte[unit.classBytes.length][];
            for (int ci = 0; ci < unit.classBytes.length; ci++) {
                String className = unit.names[ci];
                byte[] classBytes = unit.classBytes[ci];
                try {
                    Project.writeWholeFile(p.binUrl() + className + ".class", classBytes);
                } catch (SecurityException se) {
                    result.ok = false;
                    result.message = "Permission denied when writing class files: " + se.getMessage();
                    return result;
                }
                entryNames[ci] = className.replace('.', '/');
                entryBytes[ci] = classBytes;
                compiledCount++;
                if (className.equals(p.mainClass) || className.equals(p.packageName.length() > 0 ? p.packageName + "." + p.mainClass : p.mainClass)) mainClassFound = true;
            }

            // optional obfuscation of what goes INTO the jar (bin/ keeps the readable classes);
            // any failure falls back to the plain classes
            if (p.obfuscation > 0 && entryNames.length > 0) {
                try {
                    Obfuscator.Result o = Obfuscator.run(entryNames, entryBytes, p.packageName.length() > 0 ? p.packageName + "." + p.mainClass : p.mainClass, p.obfuscation, unit.privateMembers);
                    entryNames = o.names;
                    entryBytes = o.classes;
                    obfNote = "obfuscated (level " + p.obfuscation + "): " + o.classesRenamed + " class"
                            + (o.classesRenamed == 1 ? "" : "es")
                            + (o.membersRenamed > 0 ? ", " + o.membersRenamed + " member"
                                    + (o.membersRenamed == 1 ? "" : "s") : "")
                            + " renamed (mapping.txt)";
                    try {
                        Project.writeWholeFile(p.rootUrl + "mapping.txt", o.mapping.getBytes("UTF-8"));
                    } catch (Exception e) {
                        warnings.append("warning: could not write mapping.txt (").append(e).append(")\n");
                    }
                } catch (Throwable t) {
                    warnings.append("warning: obfuscation skipped, jar left readable (").append(t).append(")\n");
                }
            }
            for (int ci = 0; ci < entryNames.length; ci++) {
                zip.addEntry(entryNames[ci] + ".class", entryBytes[ci]);
            }
        } catch (CompileError ce) {
            String fileName = (ce.fileName != null) ? ce.fileName : "(unknown file)";
            String source = sourceForFile(files, ce.fileName);
            errors.append(fileName).append(" line ").append(ce.line)
                  .append(": ").append(ce.getMessage());
            String snippet = (source != null) ? CompileError.sourceLine(source, ce.line) : "";
            if (snippet.length() > 0) {
                errors.append("\n    > ").append(snippet);
            }
            if (ce.hint != null) {
                errors.append("\n    hint: ").append(ce.hint);
            }
            errors.append('\n');
        } catch (RuntimeException re) {
            errors.append("internal error: ").append(re).append('\n');
        } catch (IOException ioe) {
            errors.append("could not write class file: ").append(ioe.getMessage()).append('\n');
        }

        if (errors.length() > 0) {
            result.ok = false;
            result.message = "Package aborted -- fix these first:\n" + errors;
            return result;
        }
        if (!mainClassFound) {
            result.ok = false;
            result.message = "MIDlet-1 main class \"" + (p.packageName.length() > 0 ? p.packageName + "." + p.mainClass : p.mainClass)
                    + "\" (see Properties) was not among the compiled classes.";
            return result;
        }

        // ---- bundle res/ into the jar, preserving subfolder structure ----
        Vector resourceRelPaths = listResourceFiles(p);
        int resourceCount = 0;
        for (int i = 0; i < resourceRelPaths.size(); i++) {
            String relPath = (String) resourceRelPaths.elementAt(i);
            try {
                byte[] data = Project.readWholeFile(p.resUrl() + relPath);
                if (data == null) {
                    warnings.append("warning: could not read res/").append(relPath).append('\n');
                    continue;
                }
                zip.addEntry(relPath, data);
                resourceCount++;
            } catch (IOException ioe) {
                warnings.append("warning: could not read res/").append(relPath)
                        .append(": ").append(ioe.getMessage()).append('\n');
            } catch (SecurityException se) {
                warnings.append("warning: permission denied reading res/").append(relPath).append('\n');
            }
        }

        // ---- user library jars (lib/*.jar) are packed into the MIDlet JAR ----
        int libEntries = Libraries.embedInto(zip, p, warnings);

        String resolvedIcon = resolveIcon(p, resourceRelPaths, warnings);

        try {
            zip.addEntry("META-INF/MANIFEST.MF", ManifestBuilder.buildManifest(p, resolvedIcon).getBytes("UTF-8"));
            byte[] jarBytes = zip.toByteArray();

            try {
                Project.writeWholeFile(p.jarUrl(), jarBytes);
            } catch (SecurityException se) {
                result.ok = false;
                result.message = "Permission denied when writing JAR file: " + se.getMessage();
                return result;
            }

            String jad = ManifestBuilder.buildJad(p, jarBytes.length, resolvedIcon);
            try {
                Project.writeWholeFile(p.jadUrl(), jad.getBytes("UTF-8"));
            } catch (SecurityException se) {
                result.ok = false;
                result.message = "Permission denied when writing JAD file: " + se.getMessage();
                return result;
            }

            result.ok = true;
            result.jarBytes = jarBytes.length;
            result.classCount = compiledCount;
            result.message = p.folderName + ".jar (" + jarBytes.length + " bytes, "
                    + compiledCount + " class" + (compiledCount == 1 ? "" : "es")
                    + (resourceCount > 0 ? ", " + resourceCount + " resource"
                            + (resourceCount == 1 ? "" : "s") : "")
                    + ")\n" + p.folderName + ".jad written"
                    + (libEntries > 0 ? "\nlibraries: " + libEntries + " file" + (libEntries == 1 ? "" : "s") + " packed from lib/" : "")
                    + (resolvedIcon.length() > 0 ? "\nicon: " + resolvedIcon : "")
                    + (obfNote != null ? "\n" + obfNote : "")
                    + "\nsaved in project folder"
                    + (warnings.length() > 0 ? "\n" + warnings : "");
        } catch (IOException ioe) {
            result.ok = false;
            result.message = "Could not write jar/jad: " + ioe.getMessage();
        } catch (SecurityException se) {
            result.ok = false;
            result.message = "Permission denied: " + se.getMessage();
        }
        return result;
    }

    private static String resolveIcon(Project p, Vector resourceRelPaths, StringBuffer warnings) {
        String configured = (p.icon != null) ? p.icon.trim() : "";
        if (configured.length() > 0) {
            for (int i = 0; i < resourceRelPaths.size(); i++) {
                String rp = (String) resourceRelPaths.elementAt(i);
                if (rp.equals(configured)) {
                    if (MimeTypes.isPng(rp)) return rp;
                    warnings.append("warning: icon \"").append(configured)
                            .append("\" is not a PNG (JSR-118 requires PNG icons) -- omitted\n");
                    return "";
                }
            }
            warnings.append("warning: configured icon \"").append(configured)
                    .append("\" not found in res/ -- omitted\n");
            return "";
        }
        for (int i = 0; i < resourceRelPaths.size(); i++) {
            String rp = (String) resourceRelPaths.elementAt(i);
            if (rp.equalsIgnoreCase("icon.png")) return rp;
        }
        return "";
    }

    private static String sourceForFile(Compiler.ProjectFile[] files, String fileName) {
        if (fileName == null) return null;
        for (int i = 0; i < files.length; i++) {
            if (fileName.equals(files[i].fileName)) return files[i].source;
        }
        return null;
    }

    public Vector listSourceFiles(Project p) {
        Vector names = new Vector();
        try {
            if (!hasFilePermission(p.srcUrl())) {
                return names;
            }
            File dir = new File(p.srcUrl());
            if (dir.exists() && dir.isDirectory()) {
                File[] entries = dir.listFiles();
                if (entries != null) {
                    collectJavaFiles(entries, dir, names);
                }
            }
        } catch (SecurityException se) {
            // Permission denied
        }
        return names;
    }

    private void collectJavaFiles(File[] entries, File base, Vector names) {
        if (entries == null) return;
        for (int i = 0; i < entries.length; i++) {
            File f = entries[i];
            if (f.isDirectory()) {
                collectJavaFiles(f.listFiles(), base, names);
            } else if (f.getName().endsWith(".java")) {
                String abs = f.getAbsolutePath().replace('\\', '/');
                String root = base.getAbsolutePath().replace('\\', '/');
                String rel = abs.startsWith(root + "/") ? abs.substring(root.length() + 1) : f.getName();
                names.addElement(rel);
            }
        }
    }

    /** Flat listing of bin/ -- compiled output mirrors src/ one class file
     *  per top-level class, so unlike res/ this never needs to recurse. */
    public Vector listBinFiles(Project p) {
        Vector names = new Vector();
        try {
            if (!hasFilePermission(p.binUrl())) {
                return names;
            }
            File dir = new File(p.binUrl());
            if (dir.exists() && dir.isDirectory()) {
                File[] entries = dir.listFiles();
                if (entries != null) {
                    for (int i = 0; i < entries.length; i++) {
                        String name = entries[i].getName();
                        if (!entries[i].isDirectory() && name.endsWith(".class")) {
                            names.addElement(name);
                        }
                    }
                }
            }
        } catch (SecurityException se) {
            // Permission denied
        }
        return names;
    }

    public Vector listResourceFiles(Project p) {
        Vector paths = new Vector();
        try {
            collectResourceFiles(p.resUrl(), "", paths);
        } catch (SecurityException se) {
            // Permission denied
        }
        return paths;
    }

    private void collectResourceFiles(String dirPath, String relPrefix, Vector outRelPaths) {
        File dir = new File(dirPath);
        if (!dir.exists() || !dir.isDirectory()) return;
        File[] entries = dir.listFiles();
        if (entries == null) return;
        for (int i = 0; i < entries.length; i++) {
            String name = entries[i].getName();
            if (entries[i].isDirectory()) {
                collectResourceFiles(dirPath + name + "/", relPrefix + name + "/", outRelPaths);
            } else {
                outRelPaths.addElement(relPrefix + name);
            }
        }
    }

    // ---------------- filesystem helpers ----------------

    /**
     * Creates the directory at path, creating any missing parent
     * directories along the way. On Android this is just File.mkdirs() --
     * unlike JSR-75's FileConnection.mkdir() (which could only create one
     * path segment at a time, see the original J2ME ProjectManager's
     * comment on this method), java.io.File.mkdirs() already creates the
     * full missing chain in one call, so the segment-walking workaround
     * that used to live here isn't needed anymore.
     */
    private static void mkdirIfMissing(String path) throws IOException {
        File dir = new File(path);
        if (dir.exists()) {
            if (!dir.isDirectory()) {
                throw new IOException("Path exists and is not a directory: " + path);
            }
            return;
        }
        try {
            if (!dir.mkdirs() && !dir.exists()) {
                throw new IOException("Could not create directory: " + path);
            }
        } catch (SecurityException se) {
            throw new IOException("Permission denied to create directory: " + path
                    + " (" + se.getMessage() + ")");
        }
    }

    private static void deleteRecursive(String path) throws IOException {
        File f = new File(path);
        if (!f.exists()) return;
        if (f.isDirectory()) {
            File[] children = f.listFiles();
            if (children != null) {
                for (int i = 0; i < children.length; i++) {
                    deleteRecursive(children[i].getPath());
                }
            }
        }
        if (!f.delete()) {
            throw new IOException("Could not delete: " + path);
        }
    }
}
