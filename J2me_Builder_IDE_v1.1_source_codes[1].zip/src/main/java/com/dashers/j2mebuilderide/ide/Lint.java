package com.dashers.j2mebuilderide.ide;

import java.util.HashSet;
import java.util.Vector;

/**
 * Cheap source checks that produce build WARNINGS (the compiler itself only
 * ever reports hard errors). Everything works on a copy of the source with
 * comments and string/char literals blanked out, so words inside them never
 * count as code.
 */
public final class Lint {
    private Lint() {}

    public static final class Warning {
        public String file;
        public int line;
        public String message;

        public String toString() {
            return file + ":" + line + "  " + message;
        }
    }

    public static Vector check(String fileName, String source) {
        Vector out = new Vector();
        if (source == null || source.length() == 0 || source.length() > 400000) return out;
        String code = blank(source);
        String[] lines = split(code);

        // ---- imports ----
        HashSet seen = new HashSet();
        Vector importNames = new Vector();   // simple names
        Vector importLines = new Vector();   // Integer
        Vector importFull = new Vector();
        for (int i = 0; i < lines.length; i++) {
            String t = lines[i].trim();
            if (!t.startsWith("import ") || !t.endsWith(";")) continue;
            String full = t.substring(7, t.length() - 1).trim();
            if (full.startsWith("static ")) full = full.substring(7).trim();
            if (seen.contains(full)) {
                add(out, fileName, i + 1, "duplicate import " + full);
                continue;
            }
            seen.add(full);
            if (full.endsWith(".*")) continue;
            int dot = full.lastIndexOf('.');
            importNames.addElement(dot < 0 ? full : full.substring(dot + 1));
            importLines.addElement(new Integer(i + 1));
            importFull.addElement(full);
        }

        if (importNames.size() > 0) {
            HashSet used = identifiers(lines);
            for (int k = 0; k < importNames.size(); k++) {
                if (!used.contains(importNames.elementAt(k))) {
                    add(out, fileName, ((Integer) importLines.elementAt(k)).intValue(),
                        "unused import " + importFull.elementAt(k));
                }
            }
        }

        // ---- empty catch ----
        int from = 0;
        while (true) {
            int c = code.indexOf("catch", from);
            if (c < 0) break;
            from = c + 5;
            int p = skipWs(code, from);
            if (p >= code.length() || code.charAt(p) != '(') continue;
            int close = code.indexOf(')', p);
            if (close < 0) continue;
            int q = skipWs(code, close + 1);
            if (q >= code.length() || code.charAt(q) != '{') continue;
            int r = skipWs(code, q + 1);
            if (r < code.length() && code.charAt(r) == '}') {
                add(out, fileName, lineOf(code, c), "empty catch block hides the exception");
            }
        }

        // ---- public class name must match the file name ----
        String base = fileName.endsWith(".java") ? fileName.substring(0, fileName.length() - 5) : fileName;
        int pc = 0;
        while (true) {
            int at = code.indexOf("public", pc);
            if (at < 0) break;
            pc = at + 6;
            if (at > 0 && Character.isJavaIdentifierPart(code.charAt(at - 1))) continue;
            int p = skipWs(code, pc);
            // optional modifiers
            while (true) {
                if (code.startsWith("final", p) || code.startsWith("abstract", p)) {
                    p = skipWs(code, code.startsWith("final", p) ? p + 5 : p + 8);
                } else break;
            }
            if (!code.startsWith("class", p) || (p + 5 < code.length() && Character.isJavaIdentifierPart(code.charAt(p + 5)))) continue;
            int s = skipWs(code, p + 5);
            int e = s;
            while (e < code.length() && Character.isJavaIdentifierPart(code.charAt(e))) e++;
            if (e > s) {
                String name = code.substring(s, e);
                if (!name.equals(base)) {
                    add(out, fileName, lineOf(code, at), "public class " + name + " should be in " + name + ".java");
                }
            }
            break;
        }
        return out;
    }

    private static void add(Vector out, String file, int line, String msg) {
        Warning w = new Warning();
        w.file = file;
        w.line = line;
        w.message = msg;
        out.addElement(w);
    }

    private static int skipWs(String s, int i) {
        while (i < s.length() && Character.isWhitespace(s.charAt(i))) i++;
        return i;
    }

    private static int lineOf(String s, int offset) {
        int line = 1;
        for (int i = 0; i < offset && i < s.length(); i++) if (s.charAt(i) == '\n') line++;
        return line;
    }

    private static String[] split(String s) {
        Vector v = new Vector();
        int start = 0;
        for (int i = 0; i <= s.length(); i++) {
            if (i == s.length() || s.charAt(i) == '\n') {
                v.addElement(s.substring(start, i));
                start = i + 1;
            }
        }
        String[] a = new String[v.size()];
        for (int i = 0; i < a.length; i++) a[i] = (String) v.elementAt(i);
        return a;
    }

    /** Identifiers used outside import/package lines. */
    private static HashSet identifiers(String[] lines) {
        HashSet ids = new HashSet();
        for (int i = 0; i < lines.length; i++) {
            String l = lines[i];
            String t = l.trim();
            if (t.startsWith("import ") || t.startsWith("package ")) continue;
            int n = l.length();
            int j = 0;
            while (j < n) {
                char c = l.charAt(j);
                if (Character.isJavaIdentifierStart(c)) {
                    int k = j + 1;
                    while (k < n && Character.isJavaIdentifierPart(l.charAt(k))) k++;
                    ids.add(l.substring(j, k));
                    j = k;
                } else {
                    j++;
                }
            }
        }
        return ids;
    }

    /** Same length as the input; comments and literals become spaces (newlines kept). */
    public static String blank(String s) {
        char[] c = s.toCharArray();
        int n = c.length;
        int i = 0;
        while (i < n) {
            char ch = c[i];
            if (ch == '/' && i + 1 < n && c[i + 1] == '/') {
                while (i < n && c[i] != '\n') { c[i] = ' '; i++; }
            } else if (ch == '/' && i + 1 < n && c[i + 1] == '*') {
                c[i] = ' '; c[i + 1] = ' ';
                i += 2;
                while (i < n && !(c[i] == '*' && i + 1 < n && c[i + 1] == '/')) {
                    if (c[i] != '\n') c[i] = ' ';
                    i++;
                }
                if (i < n) { c[i] = ' '; i++; }
                if (i < n) { c[i] = ' '; i++; }
            } else if (ch == '"' || ch == '\'') {
                char q = ch;
                i++;
                while (i < n && c[i] != q && c[i] != '\n') {
                    if (c[i] == '\\' && i + 1 < n) { c[i] = ' '; i++; }
                    c[i] = ' ';
                    i++;
                }
                if (i < n && c[i] == q) i++;
            } else {
                i++;
            }
        }
        return new String(c);
    }
}
