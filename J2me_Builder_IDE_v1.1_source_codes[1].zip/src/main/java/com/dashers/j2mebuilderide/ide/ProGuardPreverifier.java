package com.dashers.j2mebuilderide.ide;

import android.content.Context;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Vector;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipInputStream;

/**
 * CLDC preverifier built on ProGuard-core 9.1.1 (com.guardsquare:proguard-core).
 *
 * Why this exists: ECJ writes class files WITHOUT the CLDC "StackMap" attribute and, for
 * -target 1.2, with jsr/ret subroutines (try/finally). Real J2ME phones (Nokia S40, MTK ...)
 * reject such classes ("Verification error", "Bad class file"). ProGuard-core ships the same
 * two passes ProGuard's -microedition mode uses:
 *   1. proguard.preverify.CodeSubroutineInliner  - inlines jsr/ret
 *   2. proguard.preverify.CodePreverifier(true)   - writes the CLDC StackMap attribute
 *      (true = micro edition: "StackMap", not the Java 6 "StackMapTable")
 *
 * Everything is reached through reflection (same approach as EcjCompiler), so the project still
 * compiles when the builder does not put proguard-core on the classpath. The library is found in
 * this order:
 *   a) on the app class path (build.gradle: com.guardsquare:proguard-core:9.1.1)
 *   b) assets/proguard/proguard-core-dex.jar (the same 9.1.1 already dexed) via DexClassLoader
 * proguard-core needs log4j-api at run time (CodePreverifier/PartialEvaluator log through it).
 * Gradle pulls it in transitively; if it is missing, status() says so and the build only warns.
 *
 * Class files are processed one by one: a class that fails keeps its original bytes and is
 * reported, the others are still preverified.
 */
public final class ProGuardPreverifier {
    public static final String ASSET = "proguard/proguard-core-dex.jar";
    public static final String VERSION = "9.1.1";

    /** Outcome of run(). */
    public static final class Result {
        public boolean ran;                 // false = library not usable, nothing changed
        public int total, ok, failed;
        public String note = "";            // one line for the build log
        public Vector errors = new Vector(); // "pkg/Class: reason" (first few)
    }

    private static Context app;
    private static ClassLoader cl;
    private static boolean tried;
    private static String status = "ProGuard preverifier: not loaded yet";

    private ProGuardPreverifier() {}

    public static void init(Context ctx) { app = ctx.getApplicationContext(); }

    public static String status() { return status; }

    public static synchronized boolean isAvailable() { return load(); }

    // ------------------------------------------------------------------
    // loading
    // ------------------------------------------------------------------

    private static synchronized boolean load() {
        if (cl != null) return true;
        if (tried) return false;
        tried = true;
        ClassLoader appLoader = app != null ? app.getClassLoader() : ProGuardPreverifier.class.getClassLoader();
        try {
            Class.forName("org.apache.logging.log4j.LogManager", false, appLoader);
        } catch (Throwable t) {
            status = "ProGuard preverifier: log4j-api is missing. Add org.apache.logging.log4j:log4j-api "
                    + "(build.gradle gets it with proguard-core " + VERSION + ")";
            return false;
        }
        try {
            Class.forName("proguard.preverify.CodePreverifier", false, appLoader);
            cl = appLoader;
            status = "ProGuard preverifier ready (proguard-core " + VERSION + ", app class path)";
            return true;
        } catch (Throwable notOnClassPath) {
            // fall through to the bundled dex
        }
        if (app == null) { status = "ProGuard preverifier: not initialised"; return false; }
        try {
            File code = new File(app.getCodeCacheDir(), "proguard");
            code.mkdirs();
            File local = new File(code, "proguard-core-" + VERSION + "-" + stamp() + ".jar");
            if (!local.exists() || local.length() == 0) {
                InputStream in = app.getAssets().open(ASSET);
                try {
                    OutputStream out = new FileOutputStream(local);
                    try {
                        byte[] b = new byte[16384];
                        int n;
                        while ((n = in.read(b)) != -1) out.write(b, 0, n);
                    } finally { out.close(); }
                } finally { in.close(); }
                local.setReadOnly();   // Android 14+ refuses writable dex files
            }
            File odex = new File(code, "odex");
            odex.mkdirs();
            // parent = app loader so the dex'd ProGuard sees log4j-api / kotlin from Gradle
            ClassLoader dex = new dalvik.system.DexClassLoader(
                    local.getAbsolutePath(), odex.getAbsolutePath(), null, appLoader);
            dex.loadClass("proguard.preverify.CodePreverifier");
            cl = dex;
            status = "ProGuard preverifier ready (bundled proguard-core " + VERSION + ")";
            return true;
        } catch (Throwable t) {
            status = "ProGuard preverifier could not be loaded: " + t;
            return false;
        }
    }

    private static String stamp() {
        try { return String.valueOf(app.getPackageManager().getPackageInfo(app.getPackageName(), 0).lastUpdateTime); }
        catch (Throwable t) { return "0"; }
    }

    // ------------------------------------------------------------------
    // run
    // ------------------------------------------------------------------

    /**
     * Preverifies classBytes[i] (internal class names in names[i]) in place.
     * apiZip = bundled J2ME API (CLDC/MIDP) as zip bytes, libJars = project library jars; both are
     * only used to resolve super classes, they are never changed.
     */
    public static Result run(String[] names, byte[][] classBytes, byte[] apiZip, File[] libJars) {
        Result r = new Result();
        r.total = classBytes == null ? 0 : classBytes.length;
        if (r.total == 0) { r.note = "Preverify: no classes."; return r; }
        if (!load()) { r.note = status; return r; }
        try {
            Object program = make("proguard.classfile.ClassPool");
            Object library = make("proguard.classfile.ClassPool");
            Object[] pcs = new Object[r.total];
            String[] internal = new String[r.total];

            // 1. program classes (our own output)
            for (int i = 0; i < r.total; i++) {
                internal[i] = names != null && i < names.length ? String.valueOf(names[i]).replace('.', '/') : "class" + i;
                try {
                    Object pc = make("proguard.classfile.ProgramClass");
                    DataInputStream in = new DataInputStream(new ByteArrayInputStream(classBytes[i]));
                    call(pc, "accept", make("proguard.classfile.io.ProgramClassReader", in));
                    call(program, "addClass", pc);
                    pcs[i] = pc;
                } catch (Throwable t) {
                    fail(r, internal[i], "cannot read class: " + why(t));
                }
            }

            // 2. library classes (CLDC/MIDP API + project jars) for super class lookups
            int libs = 0;
            if (apiZip != null) libs += addLibraryZip(library, program, new ZipInputStream(new ByteArrayInputStream(apiZip)));
            if (libJars != null) {
                for (int i = 0; i < libJars.length; i++) {
                    ZipFile zf = null;
                    try {
                        zf = new ZipFile(libJars[i]);
                        java.util.Enumeration en = zf.entries();
                        while (en.hasMoreElements()) {
                            ZipEntry ze = (ZipEntry) en.nextElement();
                            if (ze.isDirectory() || !ze.getName().endsWith(".class")) continue;
                            if (addLibraryClass(library, program, readAll(zf.getInputStream(ze)))) libs++;
                        }
                    } catch (Throwable t) {
                        // an unreadable library jar only means less type information
                    } finally {
                        if (zf != null) try { zf.close(); } catch (IOException ignore) { }
                    }
                }
            }

            // 3. same set-up ProGuard does before preverifying
            call(program, "classesAccept", make("proguard.classfile.visitor.ClassCleaner"));
            Object superInit = make("proguard.classfile.util.ClassSuperHierarchyInitializer", program, library);
            call(program, "classesAccept", superInit);
            call(library, "classesAccept", superInit);
            call(program, "classesAccept", make("proguard.classfile.util.ClassReferenceInitializer", program, library));
            try {
                call(library, "classesAccept", make("proguard.classfile.util.ClassReferenceInitializer", program, library));
            } catch (Throwable t) {
                // library references are an optimisation for the evaluator, not a requirement
            }

            // 4. per class: inline jsr/ret, then write the CLDC StackMap (true = micro edition)
            Object inliner = make("proguard.classfile.visitor.AllMethodVisitor",
                    make("proguard.classfile.attribute.visitor.AllAttributeVisitor",
                            make("proguard.preverify.CodeSubroutineInliner")));
            Object verifier = make("proguard.classfile.visitor.AllMethodVisitor",
                    make("proguard.classfile.attribute.visitor.AllAttributeVisitor",
                            make("proguard.preverify.CodePreverifier", Boolean.TRUE)));
            byte[][] out = new byte[r.total][];
            for (int i = 0; i < r.total; i++) {
                if (pcs[i] == null) continue;
                try {
                    call(pcs[i], "accept", inliner);
                    call(pcs[i], "accept", verifier);
                    ByteArrayOutputStream bos = new ByteArrayOutputStream(classBytes[i].length + 512);
                    call(pcs[i], "accept", make("proguard.classfile.io.ProgramClassWriter", new DataOutputStream(bos)));
                    byte[] b = bos.toByteArray();
                    if (b.length < 10 || (b[0] & 0xFF) != 0xCA || (b[1] & 0xFF) != 0xFE
                            || (b[2] & 0xFF) != 0xBA || (b[3] & 0xFF) != 0xBE) throw new IOException("written class is not a class file");
                    out[i] = b;
                } catch (Throwable t) {
                    fail(r, internal[i], why(t));
                }
            }
            for (int i = 0; i < r.total; i++) {
                if (out[i] != null) { classBytes[i] = out[i]; r.ok++; }
            }
            r.failed = r.total - r.ok;
            r.ran = true;
            r.note = "Preverify: " + r.ok + " of " + r.total + " class" + (r.total == 1 ? "" : "es")
                    + " preverified with ProGuard-core " + VERSION + " (CLDC StackMap, jsr/ret inlined; "
                    + libs + " library classes read).";
            return r;
        } catch (Throwable t) {
            r.ran = false;
            r.note = "Preverify skipped: " + why(t);
            status = "ProGuard preverifier error: " + why(t);
            return r;
        }
    }

    private static void fail(Result r, String cls, String why) {
        if (r.errors.size() < 8) r.errors.addElement(cls + ": " + why);
    }

    private static int addLibraryZip(Object library, Object program, ZipInputStream zin) {
        int n = 0;
        try {
            try {
                ZipEntry e;
                while ((e = zin.getNextEntry()) != null) {
                    if (e.isDirectory() || !e.getName().endsWith(".class")) continue;
                    if (addLibraryClass(library, program, readAll(zin))) n++;
                }
            } finally { zin.close(); }
        } catch (IOException ignore) { }
        return n;
    }

    /** Reads one .class as a LibraryClass (unless the project defines that class itself). */
    private static boolean addLibraryClass(Object library, Object program, byte[] data) {
        try {
            Object lc = make("proguard.classfile.LibraryClass");
            DataInputStream in = new DataInputStream(new ByteArrayInputStream(data));
            call(lc, "accept", make("proguard.classfile.io.LibraryClassReader", in, Boolean.FALSE, Boolean.FALSE));
            String name = (String) call(lc, "getName");
            if (name == null || call(program, "getClass", name) != null) return false;
            call(library, "addClass", lc);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    // ------------------------------------------------------------------
    // reflection helpers
    // ------------------------------------------------------------------

    private static Object make(String className, Object... args) throws Exception {
        Class k = cl.loadClass(className);
        java.lang.reflect.Constructor[] cs = k.getConstructors();
        for (int i = 0; i < cs.length; i++) {
            Class[] pt = cs[i].getParameterTypes();
            if (pt.length != args.length || !fits(pt, args)) continue;
            try { return cs[i].newInstance(args); }
            catch (InvocationTargetException ite) { throw unwrap(ite); }
        }
        throw new NoSuchMethodException(className + " has no constructor for " + args.length + " argument(s)");
    }

    private static Object call(Object target, String method, Object... args) throws Exception {
        Method[] ms = target.getClass().getMethods();
        for (int i = 0; i < ms.length; i++) {
            if (!ms[i].getName().equals(method)) continue;
            Class[] pt = ms[i].getParameterTypes();
            if (pt.length != args.length || !fits(pt, args)) continue;
            try {
                ms[i].setAccessible(true);
                return ms[i].invoke(target, args);
            } catch (InvocationTargetException ite) { throw unwrap(ite); }
        }
        throw new NoSuchMethodException(target.getClass().getName() + "." + method + "/" + args.length);
    }

    private static boolean fits(Class[] pt, Object[] args) {
        for (int i = 0; i < pt.length; i++) {
            Class p = pt[i];
            Object a = args[i];
            if (p.isPrimitive()) {
                if (p == boolean.class && a instanceof Boolean) continue;
                if (p == int.class && a instanceof Integer) continue;
                return false;
            }
            if (a != null && !p.isInstance(a)) return false;
        }
        return true;
    }

    private static Exception unwrap(InvocationTargetException e) {
        Throwable c = e.getCause();
        if (c instanceof Exception) return (Exception) c;
        return new RuntimeException(String.valueOf(c), c);
    }

    private static String why(Throwable t) {
        Throwable c = t;
        while (c.getCause() != null && c.getCause() != c) c = c.getCause();
        String m = c.getMessage();
        String s = c.getClass().getSimpleName() + (m == null ? "" : ": " + m);
        if (c instanceof NoClassDefFoundError || c instanceof ClassNotFoundException) {
            s += "  (a library class is missing - needs log4j-api / kotlin-stdlib from the proguard-core Gradle dependency)";
        }
        return s.length() > 240 ? s.substring(0, 240) : s;
    }

    private static byte[] readAll(InputStream in) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] b = new byte[8192];
        int n;
        while ((n = in.read(b)) != -1) out.write(b, 0, n);
        return out.toByteArray();
    }
}
