package com.dashers.j2mebuilderide.ide;

import com.dashers.j2mebuilderide.compiler.ApiIndex;
import com.dashers.j2mebuilderide.compiler.Compiler;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * J2ME library support.
 *
 * Two kinds of library:
 *  - platform libraries (M3G, OpenGL ES, MMAPI, Bluetooth ...): compile-time
 *    API that the phone provides. They are detected automatically from the
 *    imports of a project and reported in the build log ("Library loaded").
 *  - project libraries: .jar files the user adds to the project.
 *       lib/            classes are compiled against AND packed into the MIDlet JAR
 *       lib/provided/   compile-only stubs, NOT packed (the phone provides them)
 */
public final class Libraries {
    private Libraries() {}

    /** A platform library from the catalog. */
    public static final class Lib {
        public final String id, name, jsr, desc;
        public final String[] packages;
        Lib(String id, String name, String jsr, String desc, String[] packages) {
            this.id = id; this.name = name; this.jsr = jsr; this.desc = desc; this.packages = packages;
        }
    }

    public static final Lib[] CATALOG = {
        new Lib("m3g", "M3G 3D graphics", "JSR-184", "3D scene graph",
                new String[]{"javax.microedition.m3g"}),
        new Lib("gles", "OpenGL ES", "JSR-239", "Khronos GL10/GL11 + EGL",
                new String[]{"javax.microedition.khronos"}),
        new Lib("mmapi", "Multimedia (MMAPI)", "JSR-135", "Player, MIDI, audio, video",
                new String[]{"javax.microedition.media"}),
        new Lib("fc", "File access", "JSR-75", "FileConnection",
                new String[]{"javax.microedition.io.file"}),
        new Lib("bt", "Bluetooth + OBEX", "JSR-82", "Short-range networking",
                new String[]{"javax.bluetooth", "javax.obex"}),
        new Lib("wma", "Messaging (SMS)", "JSR-120", "Wireless messaging",
                new String[]{"javax.wireless.messaging"}),
        new Lib("pki", "Security / PKI", "MIDP 2.0", "Certificates",
                new String[]{"javax.microedition.pki"}),
    };

    public static boolean usesPackage(String text, String pkg) {
        return text.indexOf(pkg + ".") >= 0;
    }

    /** Catalog ids found in the given sources, in catalog order. */
    public static Vector detectUsed(Hashtable sources) {
        Vector out = new Vector();
        for (int i = 0; i < CATALOG.length; i++) {
            if (isUsed(CATALOG[i], sources)) out.addElement(CATALOG[i]);
        }
        return out;
    }

    private static boolean isUsed(Lib l, Hashtable sources) {
        Enumeration en = sources.elements();
        while (en.hasMoreElements()) {
            String src = (String) en.nextElement();
            for (int k = 0; k < l.packages.length; k++) if (usesPackage(src, l.packages[k])) return true;
        }
        return false;
    }

    /** Number of classes the bundled API index has for a platform library. */
    public static int classCount(Lib l, ApiIndex api) {
        int n = 0;
        Enumeration en = api.builtinNames();
        while (en.hasMoreElements()) {
            String fq = (String) en.nextElement();
            for (int k = 0; k < l.packages.length; k++) if (fq.startsWith(l.packages[k] + ".")) { n++; break; }
        }
        return n;
    }

    /** Simple class names of a platform library (for the API browser), sorted. */
    public static Vector classNames(Lib l, ApiIndex api) {
        Vector out = new Vector();
        Enumeration en = api.builtinNames();
        while (en.hasMoreElements()) {
            String fq = (String) en.nextElement();
            for (int k = 0; k < l.packages.length; k++) {
                if (fq.startsWith(l.packages[k] + ".")) { out.addElement(fq); break; }
            }
        }
        java.util.Collections.sort(out);
        return out;
    }

    // ------------------------------------------------------------------
    // project jar libraries
    // ------------------------------------------------------------------

    public static File libDir(Project p)      { return new File(p.rootUrl + "lib/"); }
    public static File providedDir(Project p) { return new File(p.rootUrl + "lib/provided/"); }

    /** Jar files in lib/ (embedded) or lib/provided/ (compile-only). */
    public static File[] jars(Project p, boolean provided) {
        File d = provided ? providedDir(p) : libDir(p);
        File[] f = d.listFiles();
        if (f == null) return new File[0];
        Vector v = new Vector();
        for (int i = 0; i < f.length; i++) {
            String n = f[i].getName().toLowerCase();
            if (f[i].isFile() && (n.endsWith(".jar") || n.endsWith(".zip"))) v.addElement(f[i]);
        }
        java.util.Collections.sort(v);
        File[] out = new File[v.size()];
        for (int i = 0; i < out.length; i++) out[i] = (File) v.elementAt(i);
        return out;
    }

    /** What prepare() found. All strings are ready for the build log. */
    public static final class Report {
        public Vector loaded = new Vector();      // "Name (JSR) - N classes" for platform libs in use
        public Vector jarLibs = new Vector();     // "name.jar - N classes (embedded|provided)"
        public Vector missing = new Vector();     // "import x.y.Z - no library provides it"
        public Vector missingFiles = new Vector();
        public Vector missingLines = new Vector();
        public int jarClasses;
    }

    /**
     * Indexes every library jar of the project into the compiler (as a per-build
     * overlay) and works out which libraries the sources need.
     */
    public static Report prepare(Project p, Hashtable sources) {
        Report r = new Report();
        ApiIndex api;
        try { api = Compiler.apiIndex(); } catch (Exception e) { return r; }

        Hashtable overlay = new Hashtable();
        for (int pass = 0; pass < 2; pass++) {
            File[] js = jars(p, pass == 1);
            for (int i = 0; i < js.length; i++) {
                int n = indexJar(js[i], overlay);
                r.jarClasses += n;
                r.jarLibs.addElement(js[i].getName() + " - " + n + " class" + (n == 1 ? "" : "es")
                        + (pass == 1 ? " (provided by phone)" : " (packed in JAR)"));
            }
        }
        api.setOverlay(overlay);

        Vector used = detectUsed(sources);
        for (int i = 0; i < used.size(); i++) {
            Lib l = (Lib) used.elementAt(i);
            r.loaded.addElement(l.name + " (" + l.jsr + ") - " + classCount(l, api) + " classes");
        }

        // imports nothing provides -> "library missing" hint
        Hashtable own = ownClasses(sources);
        Enumeration en = sources.keys();
        while (en.hasMoreElements()) {
            String file = (String) en.nextElement();
            String src = (String) sources.get(file);
            String[] lines = src.split("\n");
            for (int i = 0; i < lines.length; i++) {
                String t = lines[i].trim();
                if (!t.startsWith("import ") || !t.endsWith(";")) continue;
                String imp = t.substring(7, t.length() - 1).trim();
                if (imp.startsWith("static ")) continue;
                if (importResolves(imp, api, own)) continue;
                r.missing.addElement(imp);
                r.missingFiles.addElement(file);
                r.missingLines.addElement(new Integer(i + 1));
            }
        }
        return r;
    }

    /** Number of usable classes inside a jar (0 = not a library). */
    public static int countClasses(File jar) { return indexJar(jar, new Hashtable()); }

    /** Removes the per-build overlay again. */
    public static void clear() {
        try { Compiler.apiIndex().setOverlay(null); } catch (Exception ignore) { }
    }

    private static boolean importResolves(String imp, ApiIndex api, Hashtable own) {
        if (imp.startsWith("java.")) return true;
        if (imp.startsWith("javax.microedition.")) {
            if (imp.endsWith(".*")) return true;
            return api.has(imp);
        }
        if (imp.endsWith(".*")) {
            String pkg = imp.substring(0, imp.length() - 2);
            if (own.containsKey("pkg:" + pkg)) return true;
            Enumeration en = api.builtinNames();
            while (en.hasMoreElements()) if (((String) en.nextElement()).startsWith(pkg + ".")) return true;
            Vector all = api.classNames();
            for (int i = 0; i < all.size(); i++) if (((String) all.elementAt(i)).startsWith(pkg + ".")) return true;
            return false;
        }
        return own.containsKey(imp) || api.has(imp);
    }

    /** fqcn -> Boolean for every top-level type in the project, plus "pkg:<name>" markers. */
    private static Hashtable ownClasses(Hashtable sources) {
        Hashtable out = new Hashtable();
        Enumeration en = sources.elements();
        while (en.hasMoreElements()) {
            String src = (String) en.nextElement();
            String pkg = "";
            int pi = src.indexOf("package ");
            if (pi >= 0) {
                int semi = src.indexOf(';', pi);
                if (semi > pi) pkg = src.substring(pi + 8, semi).trim();
            }
            out.put("pkg:" + pkg, Boolean.TRUE);
            String[] kw = {"class ", "interface "};
            for (int k = 0; k < kw.length; k++) {
                int from = 0;
                while (true) {
                    int at = src.indexOf(kw[k], from);
                    if (at < 0) break;
                    from = at + kw[k].length();
                    if (at > 0 && Character.isJavaIdentifierPart(src.charAt(at - 1))) continue;
                    int e = from;
                    while (e < src.length() && Character.isJavaIdentifierPart(src.charAt(e))) e++;
                    if (e > from) out.put((pkg.length() > 0 ? pkg + "." : "") + src.substring(from, e), Boolean.TRUE);
                }
            }
        }
        return out;
    }

    /** Indexes all .class entries of one jar into the overlay table; returns the count. */
    private static int indexJar(File jar, Hashtable overlay) {
        int count = 0;
        ZipInputStream zin = null;
        try {
            zin = new ZipInputStream(new FileInputStream(jar));
            ZipEntry e;
            while ((e = zin.getNextEntry()) != null) {
                if (e.isDirectory() || !e.getName().endsWith(".class")) continue;
                byte[] b = readAll(zin);
                if (ApiIndex.indexClassInto(overlay, b) != null) count++;
            }
        } catch (IOException ignore) {
        } finally {
            if (zin != null) try { zin.close(); } catch (IOException ignore) { }
        }
        return count;
    }

    private static byte[] readAll(InputStream in) throws IOException {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
        return o.toByteArray();
    }

    /**
     * Packs the classes/resources of lib/*.jar into the MIDlet JAR.
     * Skips META-INF and names that are already in the jar. Returns the number of entries added.
     */
    public static int embedInto(ZipWriter zip, Project p, StringBuffer warnings) {
        File[] js = jars(p, false);
        int added = 0;
        for (int i = 0; i < js.length; i++) {
            ZipInputStream zin = null;
            try {
                zin = new ZipInputStream(new FileInputStream(js[i]));
                ZipEntry e;
                while ((e = zin.getNextEntry()) != null) {
                    String n = e.getName();
                    if (e.isDirectory() || n.startsWith("META-INF/")) continue;
                    if (zip.hasEntry(n)) continue;
                    zip.addEntry(n, readAll(zin));
                    added++;
                }
            } catch (IOException ex) {
                warnings.append("warning: could not read lib/").append(js[i].getName())
                        .append(": ").append(ex.getMessage()).append('\n');
            } finally {
                if (zin != null) try { zin.close(); } catch (IOException ignore) { }
            }
        }
        return added;
    }
}
