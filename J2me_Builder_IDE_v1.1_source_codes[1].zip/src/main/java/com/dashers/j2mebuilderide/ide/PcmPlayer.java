package com.dashers.j2mebuilderide.ide;

import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;

/** Plays a range of mono 16-bit PCM and reports the playing position. */
public final class PcmPlayer {
    public interface Done { void onDone(); }

    private AudioTrack track;
    private Thread thread;
    private volatile boolean stopped = true;
    private volatile int base;
    private volatile int written;
    private int rate;

    public boolean isPlaying() { return !stopped; }

    /** Absolute sample index being played right now. */
    public int position() {
        AudioTrack t = track;
        if (t == null) return base;
        try { return base + Math.min(written, t.getPlaybackHeadPosition()); } catch (Exception e) { return base + written; }
    }

    public void play(final short[] pcm, final int from, final int to, final int sampleRate, final Done done) {
        stop();
        final int a = Math.max(0, Math.min(pcm.length, from)), b = Math.max(a, Math.min(pcm.length, to));
        if (b <= a) { if (done != null) done.onDone(); return; }
        rate = sampleRate;
        int min = AudioTrack.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT);
        if (min <= 0) { if (done != null) done.onDone(); return; }
        final AudioTrack t;
        try {
            t = new AudioTrack(AudioManager.STREAM_MUSIC, sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT,
                    Math.max(min, 4096) * 2, AudioTrack.MODE_STREAM);
            t.play();
        } catch (Exception e) {
            if (done != null) done.onDone();
            return;
        }
        track = t;
        base = a;
        written = 0;
        stopped = false;
        thread = new Thread(new Runnable() {
            public void run() {
                int pos = a;
                try {
                    while (!stopped && pos < b) {
                        int n = Math.min(2048, b - pos);
                        int w = t.write(pcm, pos, n);
                        if (w <= 0) break;
                        pos += w;
                        written = pos - a;
                    }
                    // let the last buffered audio play out
                    int guard = 0;
                    while (!stopped && t.getPlaybackHeadPosition() < written && guard++ < 400) {
                        try { Thread.sleep(10); } catch (InterruptedException ignore) { break; }
                    }
                } catch (Exception ignore) {
                    // track released while writing
                }
                boolean natural = !stopped;
                stopped = true;
                try { t.stop(); } catch (Exception ignore) { }
                try { t.release(); } catch (Exception ignore) { }
                if (track == t) track = null;
                if (natural && done != null) done.onDone();
            }
        });
        thread.start();
    }

    public void stop() {
        stopped = true;
        Thread th = thread;
        thread = null;
        if (th != null) {
            try { th.join(500); } catch (InterruptedException ignore) { }
        }
        AudioTrack t = track;
        if (t != null) {
            try { t.pause(); t.flush(); t.release(); } catch (Exception ignore) { }
            track = null;
        }
    }
}
