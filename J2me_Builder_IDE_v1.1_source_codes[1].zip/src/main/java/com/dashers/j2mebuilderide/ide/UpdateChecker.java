package com.dashers.j2mebuilderide.ide;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Environment;
import android.widget.Toast;

import com.dashers.j2mebuilderide.ui.Ui;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Checks https://github.com/Dahmalahi/J2ME-BUILDER-IDE's releases for a newer build than this
 * one (via the public GitHub REST API, no extra library/dependency needed - the Sketchware
 * on-device builder can't fetch a JitPack dependency, so this talks to GitHub directly with
 * plain java.net/org.json) and offers to download + install it.
 *
 * Version matching: compares build.gradle's versionName (currently "1.1") against the release's
 * tag_name with any leading "v"/"V" stripped, splitting both on "." and comparing part by part
 * numerically. So the GitHub release tag just needs to contain that version somewhere sensible,
 * e.g. "v1.1" or "1.1" - a tag like "V1.0(1)" still won't parse as a clean version and will be
 * skipped (treated as "no update"), so keep tags plain.
 */
public final class UpdateChecker {
    private UpdateChecker() {}

    private static final String API_URL =
            "https://api.github.com/repos/Dahmalahi/J2ME-BUILDER-IDE/releases/latest";

    /** Silent check for the automatic cold-start call: only speaks up if an update was found. */
    public static void checkInBackground(Activity a) {
        checkInBackground(a, false);
    }

    /** Runs the check on a background thread (makes a network call).
     *  When announce is false (automatic, once per cold start): shows a dialog only if a newer
     *  release is actually found, otherwise stays completely silent.
     *  When announce is true (the Settings "Check for Updates" row): also toasts "up to date" /
     *  "couldn't check", since a result the user tapped for shouldn't come back with nothing. */
    public static void checkInBackground(final Activity a, final boolean announce) {
        if (announce) Toast.makeText(a, "Checking for updates...", Toast.LENGTH_SHORT).show();
        new Thread(new Runnable() {
            public void run() {
                String error = null;
                String tag = null, apkUrl = null, apkName = null;
                try {
                    String json = httpGet(API_URL);
                    JSONObject root = new JSONObject(json);
                    tag = root.optString("tag_name", "");
                    JSONArray assets = root.optJSONArray("assets");
                    if (assets != null) {
                        for (int i = 0; i < assets.length(); i++) {
                            JSONObject asset = assets.getJSONObject(i);
                            String name = asset.optString("name", "");
                            if (name.toLowerCase().endsWith(".apk")) {
                                apkName = name;
                                apkUrl = asset.optString("browser_download_url", "");
                                break;
                            }
                        }
                    }
                } catch (Exception e) {
                    error = e.getMessage();
                }
                final String fTag = tag, fApkUrl = apkUrl, fApkName = apkName, fError = error;
                a.runOnUiThread(new Runnable() {
                    public void run() {
                        if (a.isFinishing()) return;
                        if (fError != null || fTag == null || fApkUrl == null || fApkUrl.length() == 0) {
                            if (announce) {
                                Toast.makeText(a, "Couldn't check for updates - check your connection",
                                        Toast.LENGTH_SHORT).show();
                            }
                            return;
                        }
                        String current = currentVersionName(a);
                        if (isNewer(fTag, current)) {
                            offerUpdate(a, fTag, fApkUrl, fApkName);
                        } else if (announce) {
                            Toast.makeText(a, "You're on the latest version", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        }).start();
    }

    private static String currentVersionName(Activity a) {
        try {
            return a.getPackageManager().getPackageInfo(a.getPackageName(), 0).versionName;
        } catch (PackageManager.NameNotFoundException e) {
            return "0";
        }
    }

    /** Strips a leading v/V and compares dotted numeric parts (1.10 > 1.9, missing parts = 0). */
    private static boolean isNewer(String remoteTag, String localVersion) {
        String remote = stripV(remoteTag);
        String local = stripV(localVersion);
        String[] rp = remote.split("\\.");
        String[] lp = local.split("\\.");
        int n = Math.max(rp.length, lp.length);
        for (int i = 0; i < n; i++) {
            int r = partOf(rp, i);
            int l = partOf(lp, i);
            if (r != l) return r > l;
        }
        return false; // identical
    }

    private static String stripV(String s) {
        if (s == null) return "0";
        s = s.trim();
        if (s.length() > 0 && (s.charAt(0) == 'v' || s.charAt(0) == 'V')) s = s.substring(1);
        return s;
    }

    private static int partOf(String[] parts, int i) {
        if (i >= parts.length) return 0;
        try {
            // keep only leading digits, e.g. "1" from "1-beta"
            String p = parts[i];
            int end = 0;
            while (end < p.length() && Character.isDigit(p.charAt(end))) end++;
            return end == 0 ? 0 : Integer.parseInt(p.substring(0, end));
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    private static String httpGet(String url) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setRequestProperty("User-Agent", "J2ME-Builder-IDE-UpdateChecker");
        c.setRequestProperty("Accept", "application/vnd.github+json");
        c.setConnectTimeout(10000);
        c.setReadTimeout(10000);
        try {
            int code = c.getResponseCode();
            InputStream in = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
            if (code < 200 || code >= 300) throw new Exception("HTTP " + code);
            StringBuilder sb = new StringBuilder();
            BufferedReader r = new BufferedReader(new InputStreamReader(in, "UTF-8"));
            String line;
            while ((line = r.readLine()) != null) sb.append(line).append('\n');
            r.close();
            return sb.toString();
        } finally {
            c.disconnect();
        }
    }

    private static void offerUpdate(final Activity a, String tag, final String apkUrl, final String apkName) {
        new AlertDialog.Builder(a, Ui.dialogTheme())
            .setTitle("Update available")
            .setMessage("J2ME Builder IDE " + tag + " is on GitHub. Download it now?")
            .setPositiveButton("Download", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int which) {
                    download(a, apkUrl, apkName);
                }
            })
            .setNegativeButton("Later", null)
            .show();
    }

    /** Downloads the APK via DownloadManager (shows its own progress notification) and, once
     *  done, opens the system install prompt. */
    private static void download(final Activity a, String apkUrl, String apkName) {
        try {
            String fileName = (apkName == null || apkName.length() == 0) ? "update.apk" : apkName;
            DownloadManager dm = (DownloadManager) a.getSystemService(Context.DOWNLOAD_SERVICE);
            DownloadManager.Request req = new DownloadManager.Request(Uri.parse(apkUrl));
            req.setTitle("J2ME Builder IDE update");
            req.setDescription(fileName);
            req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            req.setMimeType("application/vnd.android.package-archive");
            req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName);
            final long id = dm.enqueue(req);
            Toast.makeText(a, "Downloading update...", Toast.LENGTH_SHORT).show();

            final BroadcastReceiver[] receiverHolder = new BroadcastReceiver[1];
            BroadcastReceiver receiver = new BroadcastReceiver() {
                public void onReceive(Context ctx, Intent intent) {
                    long done = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1);
                    if (done != id) return;
                    try {
                        if (receiverHolder[0] != null) a.unregisterReceiver(receiverHolder[0]);
                    } catch (RuntimeException ignore) { }
                    try {
                        DownloadManager dm2 = (DownloadManager) a.getSystemService(Context.DOWNLOAD_SERVICE);
                        Uri fileUri = dm2.getUriForDownloadedFile(id);
                        if (fileUri == null) {
                            Toast.makeText(a, "Download failed", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        Intent install = new Intent(Intent.ACTION_VIEW);
                        install.setDataAndType(fileUri, "application/vnd.android.package-archive");
                        install.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        a.startActivity(install);
                    } catch (RuntimeException e) {
                        Toast.makeText(a, "Downloaded - open it from your Downloads to install", Toast.LENGTH_LONG).show();
                    }
                }
            };
            receiverHolder[0] = receiver;
            a.registerReceiver(receiver, new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE));
        } catch (RuntimeException e) {
            Toast.makeText(a, "Could not start the download", Toast.LENGTH_SHORT).show();
        }
    }
}
