package com.dashers.j2mebuilderide.ide;

import java.util.Vector;

/**
 * Re-indents Java source by brace depth. Only the leading whitespace of lines, trailing whitespace and runs of
 * blank lines are changed - never the code itself, strings or comments. The caller double-checks that the
 * non-whitespace characters are identical before applying the result.
 */
public final class CodeFormatter {
    private CodeFormatter() {}

    private static final class Frame {
        boolean inCase;
        int parenBase;   // '(' that were already open when this block started
    }

    /** @param unit one indent level, e.g. "    " or "  ". */
    public static String format(String src, String unit) {
        String text = src.replace("\r\n", "\n").replace('\r', '\n');
        String[] lines = text.split("\n", -1);
        StringBuffer out = new StringBuffer(text.length() + 64);

        Vector frames = new Vector();   // brace frames
        int paren = 0;                  // open '(' carried over from previous lines
        boolean inBlockComment = false;
        boolean pendingStmt = false;    // previous line was "if (...)" / "else" without a brace
        int blank = 0;

        for (int li = 0; li < lines.length; li++) {
            String raw = lines[li];
            String line = rtrim(raw);
            String t = ltrim(line);

            if (t.length() == 0) {
                if (++blank <= 1) out.append('\n');
                continue;
            }
            blank = 0;

            if (inBlockComment) {
                // keep the author's layout inside comments, only align " * " lines
                if (t.startsWith("*")) out.append(indent(unit, frames, 0)).append(' ').append(t);
                else out.append(line);
                if (t.indexOf("*/") >= 0) inBlockComment = false;
                out.append('\n');
                continue;
            }

            // leading closers lower the indent of this very line
            boolean startsWithClose = t.charAt(0) == '}';
            int depthNow = frames.size();
            int extra = 0;
            if (startsWithClose) depthNow = Math.max(0, depthNow - countLeading(t, '}'));
            boolean isCaseLabel = isCaseLabel(t);
            if (!startsWithClose && frames.size() > 0) {
                Frame top = (Frame) frames.elementAt(frames.size() - 1);
                if (top.inCase && !isCaseLabel) extra++;
            }
            if (startsWithClose && depthNow > 0 && depthNow <= frames.size()) {
                // a '}' closing a block nested in a case body sits one level in, like the block's opener
                if (((Frame) frames.elementAt(depthNow - 1)).inCase) extra = 1;
            }
            if (!startsWithClose) {
                int base = frames.size() > 0 ? ((Frame) frames.elementAt(frames.size() - 1)).parenBase : 0;
                if (paren > base) extra++;
            }
            if (pendingStmt && t.charAt(0) != '{') extra++;

            out.append(indentN(unit, depthNow + extra)).append(t).append('\n');

            // ---- scan this line (code only) to update state ----
            boolean sawOpenBrace = false;
            char last = ' ';
            int i = 0, n = t.length();
            while (i < n) {
                char c = t.charAt(i);
                if (c == '/' && i + 1 < n && t.charAt(i + 1) == '/') break;
                if (c == '/' && i + 1 < n && t.charAt(i + 1) == '*') {
                    int e = t.indexOf("*/", i + 2);
                    if (e < 0) { inBlockComment = true; break; }
                    i = e + 2;
                    continue;
                }
                if (c == '"' || c == '\'') {
                    char q = c;
                    i++;
                    while (i < n && t.charAt(i) != q) {
                        if (t.charAt(i) == '\\') i++;
                        i++;
                    }
                    i++;
                    last = q;
                    continue;
                }
                if (c == '{') {
                    Frame nf = new Frame();
                    nf.parenBase = paren;
                    frames.addElement(nf);
                    sawOpenBrace = true;
                } else if (c == '}') {
                    if (frames.size() > 0) frames.removeElementAt(frames.size() - 1);
                } else if (c == '(') {
                    paren++;
                } else if (c == ')') {
                    if (paren > 0) paren--;
                }
                if (c != ' ' && c != '\t') last = c;
                i++;
            }

            if (isCaseLabel && frames.size() > 0) ((Frame) frames.elementAt(frames.size() - 1)).inCase = true;

            // single-statement if/for/while/else without braces: the next line is indented once
            if (pendingStmt) pendingStmt = false;
            if (!sawOpenBrace && paren == 0 && last != ';' && last != '{' && last != '}' && last != ',' && last != ':'
                    && startsControl(t)) {
                pendingStmt = true;
            }
        }

        String res = out.toString();
        // exactly one trailing newline
        int e = res.length();
        while (e > 0 && res.charAt(e - 1) == '\n') e--;
        return e == 0 ? "" : res.substring(0, e) + "\n";
    }

    private static boolean isCaseLabel(String t) {
        return t.startsWith("case ") || t.startsWith("default:") || t.startsWith("default :");
    }

    private static boolean startsControl(String t) {
        return t.startsWith("if ") || t.startsWith("if(") || t.startsWith("for ") || t.startsWith("for(")
                || t.startsWith("while ") || t.startsWith("while(") || t.equals("else")
                || t.startsWith("else if") ;
    }

    private static int countLeading(String t, char ch) {
        int k = 0;
        while (k < t.length() && t.charAt(k) == ch) k++;
        return k;
    }

    private static String indent(String unit, Vector frames, int extra) {
        return indentN(unit, frames.size() + extra);
    }

    private static String indentN(String unit, int n) {
        StringBuffer b = new StringBuffer();
        for (int i = 0; i < n; i++) b.append(unit);
        return b.toString();
    }

    private static String rtrim(String s) {
        int e = s.length();
        while (e > 0 && (s.charAt(e - 1) == ' ' || s.charAt(e - 1) == '\t')) e--;
        return s.substring(0, e);
    }

    private static String ltrim(String s) {
        int b = 0;
        while (b < s.length() && (s.charAt(b) == ' ' || s.charAt(b) == '\t')) b++;
        return s.substring(b);
    }

    /** True when both strings have the same characters once all whitespace is removed. */
    public static boolean sameCode(String a, String b) {
        int i = 0, j = 0;
        while (true) {
            while (i < a.length() && Character.isWhitespace(a.charAt(i))) i++;
            while (j < b.length() && Character.isWhitespace(b.charAt(j))) j++;
            if (i >= a.length() || j >= b.length()) return i >= a.length() && j >= b.length();
            if (a.charAt(i) != b.charAt(j)) return false;
            i++;
            j++;
        }
    }
}
