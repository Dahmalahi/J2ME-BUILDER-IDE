package com.dashers.j2mebuilderide.ide;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Vector;

/**
 * Standard MIDI File (type 0) writer for the IDE's MIDI Studio.
 *
 * Song text (whitespace separated tokens):
 *   C4 D#4 Eb5     note name + optional octave (default 4)
 *   C4+E4+G4       chord (notes played together)
 *   R              rest
 *   :w :h :q :e :s duration suffix: whole, half, quarter, eighth, sixteenth
 *   :q.            a dot makes it 1.5x longer
 * A token without a duration repeats the previous duration (starts at quarter).
 * Example:  C4:q E4 G4 C5:h R:q C4+E4+G4:w
 */
public final class MidiFile {
    private MidiFile() {}

    public static final int PPQ = 480;

    /** One parsed step: absolute notes (empty = rest) and length in ticks. */
    public static final class Step {
        public int[] notes;
        public int ticks;
    }

    public static final String[] PRESET_NAMES = { "Scale", "Arpeggio", "Chords", "Melody", "Bass line" };
    public static final String[] PRESET_SONGS = {
        "C4:q D4 E4 F4 G4 A4 B4 C5:h",
        "C4:e E4 G4 C5 G4 E4 C4 R  D4:e F4 A4 D5 A4 F4 D4 R  E4:e G4 B4 E5 B4 G4 E4 R  C4+E4+G4+C5:h",
        "C4+E4+G4:h F4+A4+C5:h G4+B4+D5:h C4+E4+G4+C5:w",
        "C4:q C4 G4 G4 A4 A4 G4:h F4:q F4 E4 E4 D4 D4 C4:h",
        "C2:e C2 G2 C2 A#1:e A#1 F2 A#1 G#1:e G#1 D#2 G#1 G1:e G1 D2 G1",
    };

    public static final String[] INSTRUMENTS = {
        "Acoustic Grand Piano","Bright Acoustic Piano","Electric Grand Piano","Honky-tonk Piano","Electric Piano 1","Electric Piano 2",
        "Harpsichord","Clavinet","Celesta","Glockenspiel","Music Box","Vibraphone","Marimba","Xylophone","Tubular Bells","Dulcimer",
        "Drawbar Organ","Percussive Organ","Rock Organ","Church Organ","Reed Organ","Accordion","Harmonica","Tango Accordion",
        "Nylon Guitar","Steel Guitar","Jazz Guitar","Clean Guitar","Muted Guitar","Overdriven Guitar","Distortion Guitar","Guitar Harmonics",
        "Acoustic Bass","Finger Bass","Pick Bass","Fretless Bass","Slap Bass 1","Slap Bass 2","Synth Bass 1","Synth Bass 2",
        "Violin","Viola","Cello","Contrabass","Tremolo Strings","Pizzicato Strings","Orchestral Harp","Timpani",
        "String Ensemble 1","String Ensemble 2","Synth Strings 1","Synth Strings 2","Choir Aahs","Voice Oohs","Synth Voice","Orchestra Hit",
        "Trumpet","Trombone","Tuba","Muted Trumpet","French Horn","Brass Section","Synth Brass 1","Synth Brass 2",
        "Soprano Sax","Alto Sax","Tenor Sax","Baritone Sax","Oboe","English Horn","Bassoon","Clarinet",
        "Piccolo","Flute","Recorder","Pan Flute","Blown Bottle","Shakuhachi","Whistle","Ocarina",
        "Square Lead","Sawtooth Lead","Calliope Lead","Chiff Lead","Charang Lead","Voice Lead","Fifths Lead","Bass + Lead",
        "New Age Pad","Warm Pad","Polysynth Pad","Choir Pad","Bowed Pad","Metallic Pad","Halo Pad","Sweep Pad",
        "Rain FX","Soundtrack FX","Crystal FX","Atmosphere FX","Brightness FX","Goblins FX","Echoes FX","Sci-fi FX",
        "Sitar","Banjo","Shamisen","Koto","Kalimba","Bagpipe","Fiddle","Shanai",
        "Tinkle Bell","Agogo","Steel Drums","Woodblock","Taiko Drum","Melodic Tom","Synth Drum","Reverse Cymbal",
        "Guitar Fret Noise","Breath Noise","Seashore","Bird Tweet","Telephone Ring","Helicopter","Applause","Gunshot"
    };

    // ---------------------------------------------------------------- parsing

    private static final int[] SEMI = { 9, 11, 0, 2, 4, 5, 7 };   // A B C D E F G

    /** Parses song text. Throws IllegalArgumentException with a readable message. */
    public static Vector parse(String song) {
        Vector steps = new Vector();
        int dur = PPQ;                       // quarter
        String[] toks = song.trim().split("\\s+");
        for (int i = 0; i < toks.length; i++) {
            String t = toks[i];
            if (t.length() == 0) continue;
            int colon = t.indexOf(':');
            String body = colon < 0 ? t : t.substring(0, colon);
            if (colon >= 0) dur = duration(t.substring(colon + 1), t);
            Step s = new Step();
            s.ticks = dur;
            if (body.equalsIgnoreCase("R") || body.equals("-")) {
                s.notes = new int[0];
            } else {
                String[] parts = body.split("\\+");
                s.notes = new int[parts.length];
                for (int k = 0; k < parts.length; k++) s.notes[k] = note(parts[k], t);
            }
            steps.addElement(s);
        }
        if (steps.size() == 0) throw new IllegalArgumentException("Write some notes first, for example: C4 D4 E4");
        return steps;
    }

    private static int duration(String d, String tok) {
        boolean dotted = d.endsWith(".");
        if (dotted) d = d.substring(0, d.length() - 1);
        int base;
        if (d.equalsIgnoreCase("w")) base = PPQ * 4;
        else if (d.equalsIgnoreCase("h")) base = PPQ * 2;
        else if (d.equalsIgnoreCase("q")) base = PPQ;
        else if (d.equalsIgnoreCase("e")) base = PPQ / 2;
        else if (d.equalsIgnoreCase("s")) base = PPQ / 4;
        else throw new IllegalArgumentException("Bad length in \"" + tok + "\" (use w, h, q, e or s)");
        return dotted ? base + base / 2 : base;
    }

    private static int note(String n, String tok) {
        if (n.length() == 0) throw new IllegalArgumentException("Empty note in \"" + tok + "\"");
        char c = Character.toUpperCase(n.charAt(0));
        if (c < 'A' || c > 'G') throw new IllegalArgumentException("Unknown note \"" + n + "\" (use A-G, R for rest)");
        int semi = SEMI[c - 'A'];
        int p = 1;
        while (p < n.length() && (n.charAt(p) == '#' || n.charAt(p) == 'b')) {
            semi += n.charAt(p) == '#' ? 1 : -1;
            p++;
        }
        int octave = 4;
        if (p < n.length()) {
            try { octave = Integer.parseInt(n.substring(p)); }
            catch (NumberFormatException e) { throw new IllegalArgumentException("Bad octave in \"" + n + "\""); }
        }
        int midi = (octave + 1) * 12 + semi;
        if (midi < 0 || midi > 127) throw new IllegalArgumentException("Note \"" + n + "\" is out of range");
        return midi;
    }

    /** Length of a song in seconds at the given tempo. */
    public static float seconds(Vector steps, int bpm) {
        long ticks = 0;
        for (int i = 0; i < steps.size(); i++) ticks += ((Step) steps.elementAt(i)).ticks;
        return ticks * 60f / (PPQ * (float) Math.max(20, bpm));
    }

    // ---------------------------------------------------------------- writing

    private static void u16(ByteArrayOutputStream o, int v) { o.write((v >>> 8) & 255); o.write(v & 255); }
    private static void u32(ByteArrayOutputStream o, int v) {
        o.write((v >>> 24) & 255); o.write((v >>> 16) & 255); o.write((v >>> 8) & 255); o.write(v & 255);
    }
    private static void vlq(ByteArrayOutputStream o, int v) {
        int buffer = v & 127;
        while ((v >>>= 7) != 0) buffer = (buffer << 8) | ((v & 127) | 128);
        for (;;) { o.write(buffer & 255); if ((buffer & 128) == 0) break; buffer >>>= 8; }
    }

    /** Builds a type-0 file from song text. */
    public static byte[] fromText(String song, int tempoBpm, int instrument) throws IOException {
        return build(parse(song), tempoBpm, instrument);
    }

    public static byte[] build(Vector steps, int tempoBpm, int instrument) throws IOException {
        if (tempoBpm < 20) tempoBpm = 20;
        if (tempoBpm > 300) tempoBpm = 300;
        if (instrument < 0) instrument = 0;
        if (instrument > 127) instrument = 127;

        ByteArrayOutputStream body = new ByteArrayOutputStream();
        vlq(body, 0); body.write(0xFF); body.write(0x51); body.write(3);
        int us = 60000000 / tempoBpm;
        body.write((us >>> 16) & 255); body.write((us >>> 8) & 255); body.write(us & 255);
        vlq(body, 0); body.write(0xC0); body.write(instrument);

        int pendingRest = 0;
        for (int i = 0; i < steps.size(); i++) {
            Step s = (Step) steps.elementAt(i);
            if (s.notes.length == 0) { pendingRest += s.ticks; continue; }
            for (int k = 0; k < s.notes.length; k++) {
                vlq(body, k == 0 ? pendingRest : 0);
                body.write(0x90); body.write(s.notes[k]); body.write(100);
            }
            pendingRest = 0;
            for (int k = 0; k < s.notes.length; k++) {
                vlq(body, k == 0 ? s.ticks : 0);
                body.write(0x80); body.write(s.notes[k]); body.write(0);
            }
        }
        vlq(body, pendingRest); body.write(0xFF); body.write(0x2F); body.write(0);

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        out.write('M'); out.write('T'); out.write('h'); out.write('d');
        u32(out, 6); u16(out, 0); u16(out, 1); u16(out, PPQ);
        out.write('M'); out.write('T'); out.write('r'); out.write('k');
        u32(out, body.size());
        out.write(body.toByteArray());
        return out.toByteArray();
    }

    /** Backwards compatible helper: 8-note C major scale. */
    public static byte[] createScale(int tempoBpm, int instrument) throws IOException {
        return fromText(PRESET_SONGS[0], tempoBpm, instrument);
    }
}
