package com.dashers.j2mebuilderide.ide;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Vector;
import java.util.zip.Deflater;

/**
 * Builds a real, spec-valid ZIP (used as a MIDlet .jar) entirely by hand.
 *
 * Entries are raw-DEFLATEd (method 8) via java.util.zip.Deflater (this runs
 * on Android). Entries that do not shrink, and tiny ones, fall back to
 * STORED (method 0).
 *
 * Usage:
 *   ZipWriter zw = new ZipWriter();
 *   zw.addEntry("META-INF/MANIFEST.MF", manifestBytes);
 *   zw.addEntry("HelloMIDlet.class", classBytes);
 *   byte[] jarBytes = zw.toByteArray();
 */
public class ZipWriter {

    private static final int LOCAL_SIG = 0x04034b50;
    private static final int CENTRAL_SIG = 0x02014b50;
    private static final int EOCD_SIG = 0x06054b50;

    // Fixed DOS date/time (2026-01-01 00:00:00) -- feature-phone jar
    // loaders don't care about mtimes, and CLDC 1.1 has no
    // java.util.Calendar-backed DOS-date conversion worth writing.
    private static final int DOS_TIME = 0x0000;
    private static final int DOS_DATE = 0x0021;

    private final Vector names = new Vector();   // String
    private final Vector datas = new Vector();   // byte[]
    private final Vector packed = new Vector();  // byte[] raw-deflated, or null = store

    public boolean hasEntry(String name) { return names.contains(name); }

    public void addEntry(String name, byte[] data) {
        names.addElement(name);
        datas.addElement(data);
        packed.addElement(deflate(data));
    }

    /** Raw DEFLATE; returns null when it does not shrink the data (entry is then STORED). */
    private static byte[] deflate(byte[] data) {
        if (data.length < 32) return null;
        Deflater d = new Deflater(Deflater.BEST_COMPRESSION, true);
        try {
            d.setInput(data);
            d.finish();
            ByteArrayOutputStream bo = new ByteArrayOutputStream(data.length / 2 + 16);
            byte[] tmp = new byte[4096];
            while (!d.finished()) {
                int n = d.deflate(tmp);
                bo.write(tmp, 0, n);
            }
            byte[] r = bo.toByteArray();
            return r.length < data.length ? r : null;
        } finally {
            d.end();
        }
    }

    public byte[] toByteArray() throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        int count = names.size();
        long[] offsets = new long[count];
        long[] crcs = new long[count];

        // ---- local file headers + data ----
        for (int i = 0; i < count; i++) {
            String name = (String) names.elementAt(i);
            byte[] data = (byte[]) datas.elementAt(i);
            byte[] nameBytes = toUtf8Bytes(name);
            byte[] pk = (byte[]) packed.elementAt(i);
            int method = pk == null ? 0 : 8;
            byte[] body = pk == null ? data : pk;
            long crc = CRC32.of(data);
            crcs[i] = crc;
            offsets[i] = out.size();

            writeIntLE(out, LOCAL_SIG);
            writeShortLE(out, 20);           // version needed
            writeShortLE(out, 0);            // flags
            writeShortLE(out, method);       // 0 stored, 8 deflate
            writeShortLE(out, DOS_TIME);
            writeShortLE(out, DOS_DATE);
            writeIntLE(out, (int) crc);
            writeIntLE(out, body.length);    // compressed size
            writeIntLE(out, data.length);    // uncompressed size
            writeShortLE(out, nameBytes.length);
            writeShortLE(out, 0);            // extra length
            out.write(nameBytes, 0, nameBytes.length);
            out.write(body, 0, body.length);
        }

        long centralStart = out.size();

        // ---- central directory ----
        for (int i = 0; i < count; i++) {
            String name = (String) names.elementAt(i);
            byte[] data = (byte[]) datas.elementAt(i);
            byte[] nameBytes = toUtf8Bytes(name);
            byte[] pk = (byte[]) packed.elementAt(i);
            int method = pk == null ? 0 : 8;
            int csize = pk == null ? data.length : pk.length;

            writeIntLE(out, CENTRAL_SIG);
            writeShortLE(out, 20);           // version made by
            writeShortLE(out, 20);           // version needed
            writeShortLE(out, 0);            // flags
            writeShortLE(out, method);
            writeShortLE(out, DOS_TIME);
            writeShortLE(out, DOS_DATE);
            writeIntLE(out, (int) crcs[i]);
            writeIntLE(out, csize);
            writeIntLE(out, data.length);
            writeShortLE(out, nameBytes.length);
            writeShortLE(out, 0);            // extra length
            writeShortLE(out, 0);            // comment length
            writeShortLE(out, 0);            // disk number start
            writeShortLE(out, 0);            // internal attrs
            writeIntLE(out, 0);              // external attrs
            writeIntLE(out, (int) offsets[i]);
            out.write(nameBytes, 0, nameBytes.length);
        }

        long centralSize = out.size() - centralStart;

        // ---- end of central directory ----
        writeIntLE(out, EOCD_SIG);
        writeShortLE(out, 0);                // this disk
        writeShortLE(out, 0);                // disk with CD start
        writeShortLE(out, count);            // entries this disk
        writeShortLE(out, count);            // entries total
        writeIntLE(out, (int) centralSize);
        writeIntLE(out, (int) centralStart);
        writeShortLE(out, 0);                // comment length

        return out.toByteArray();
    }

    // ---- little-endian primitive writers (CLDC's DataOutputStream is
    //      big-endian only, so ZIP's little-endian fields are written
    //      by hand, byte at a time) ----

    private static void writeShortLE(ByteArrayOutputStream out, int v) {
        out.write(v & 0xFF);
        out.write((v >> 8) & 0xFF);
    }

    private static void writeIntLE(ByteArrayOutputStream out, int v) {
        out.write(v & 0xFF);
        out.write((v >> 8) & 0xFF);
        out.write((v >> 16) & 0xFF);
        out.write((v >> 24) & 0xFF);
    }

    private static byte[] toUtf8Bytes(String s) {
        // CLDC 1.1's String.getBytes() with no args uses the platform's
        // default encoding, which on real handsets is effectively UTF-8/
        // ASCII for the plain filenames a JCompiler project produces, so
        // this stays a plain getBytes() rather than pulling in an explicit
        // charset that CLDC's String constructor may not accept.
        return s.getBytes();
    }
}
