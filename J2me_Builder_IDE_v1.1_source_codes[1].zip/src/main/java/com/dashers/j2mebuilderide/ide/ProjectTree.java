package com.dashers.j2mebuilderide.ide;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;

/**
 * Builds the full folder / file tree of a project (project root, src/, res/, optionally bin/ and
 * the built jar/jad) and holds the plain file operations used by the Files screen: new folder,
 * new file, rename, delete.
 *
 * Pure Java (no Android classes) so it can be unit-tested on a desktop JVM.
 *
 * Every path in this class is RELATIVE to the project root, uses '/', has no leading or trailing
 * slash, and is "" for the project root itself. Examples: "src", "src/com/example/Main.java",
 * "res/img/icon.png".
 */
public final class ProjectTree {
    private ProjectTree() {}

    public static final int ROOT = 0;   // the project folder
    public static final int SRC  = 1;   // src/
    public static final int RES  = 2;   // res/
    public static final int BIN  = 3;   // bin/
    public static final int DIR  = 4;   // any other folder (packages, res sub-folders)
    public static final int JAVA = 5;   // *.java
    public static final int FILE = 6;   // anything else

    public static final class Node {
        public String name = "";
        public String path = "";
        public int kind = FILE;
        public long size = 0;
        public Node parent;
        public final ArrayList<Node> children = new ArrayList<Node>();

        public boolean isDir() { return kind <= DIR; }
        public boolean isJava() { return kind == JAVA; }

        /** Path relative to src/ ("" for src itself) or null when the node is not inside src/. */
        public String srcRel() {
            if (path.equals("src")) return "";
            return path.startsWith("src/") ? path.substring(4) : null;
        }

        /** Path relative to res/ ("" for res itself) or null when the node is not inside res/. */
        public String resRel() {
            if (path.equals("res")) return "";
            return path.startsWith("res/") ? path.substring(4) : null;
        }

        /** Dotted Java package for a folder inside src/ (""= default package), else null. */
        public String packageName() {
            if (!isDir()) return null;
            String s = srcRel();
            return s == null ? null : s.replace('/', '.');
        }

        /** Number of files (not folders) below this node, or 1 for a file. */
        public int fileCount() {
            if (!isDir()) return 1;
            int n = 0;
            for (int i = 0; i < children.size(); i++) n += children.get(i).fileCount();
            return n;
        }
    }

    /** What the tree shows. Defaults mirror a normal IDE project view. */
    public static final class Options {
        public boolean showRes = true;
        public boolean showEmpty = true;
        public boolean showBuild = false;   // bin/, .jar, .jad
        public boolean javaOnly = false;    // only .java files, hides res/ and build output
    }

    // ------------------------------------------------------------------ build

    public static Node build(Project p, Options o) {
        if (o == null) o = new Options();
        Node root = new Node();
        root.name = p.folderName == null ? "" : p.folderName;
        root.path = "";
        root.kind = ROOT;

        File src = new File(p.srcUrl());
        Node srcNode = newDir("src", SRC, root);
        fill(srcNode, src, o, true);
        root.children.add(srcNode);

        if (o.showRes && !o.javaOnly) {
            File res = new File(p.resUrl());
            if (res.isDirectory()) {
                Node resNode = newDir("res", RES, root);
                fill(resNode, res, o, false);
                root.children.add(resNode);
            }
        }
        if (o.showBuild && !o.javaOnly) {
            File bin = new File(p.binUrl());
            if (bin.isDirectory()) {
                Node binNode = newDir("bin", BIN, root);
                fill(binNode, bin, o, false);
                root.children.add(binNode);
            }
            String[] extra = { "project.properties", p.folderName + ".jar", p.folderName + ".jad" };
            for (int i = 0; i < extra.length; i++) {
                File f = new File(p.rootUrl + extra[i]);
                if (f.isFile()) root.children.add(fileNode(extra[i], f, root));
            }
        }
        return root;
    }

    private static Node newDir(String path, int kind, Node parent) {
        Node n = new Node();
        n.path = path;
        n.name = path.substring(path.lastIndexOf('/') + 1);
        n.kind = kind;
        n.parent = parent;
        return n;
    }

    private static Node fileNode(String path, File f, Node parent) {
        Node n = new Node();
        n.path = path;
        n.name = f.getName();
        n.kind = n.name.endsWith(".java") ? JAVA : FILE;
        n.size = f.length();
        n.parent = parent;
        return n;
    }

    private static void fill(Node dirNode, File dir, Options o, boolean inSrc) {
        File[] list = dir.listFiles();
        if (list == null) return;
        Arrays.sort(list, new Comparator<File>() {
            public int compare(File a, File b) {
                if (a.isDirectory() != b.isDirectory()) return a.isDirectory() ? -1 : 1;
                return a.getName().compareToIgnoreCase(b.getName());
            }
        });
        for (int i = 0; i < list.length; i++) {
            File f = list[i];
            String name = f.getName();
            if (name.startsWith(".")) continue;
            String path = dirNode.path + "/" + name;
            if (f.isDirectory()) {
                Node d = newDir(path, DIR, dirNode);
                fill(d, f, o, inSrc);
                if (!o.showEmpty && d.fileCount() == 0) continue;
                dirNode.children.add(d);
            } else {
                if (o.javaOnly && !name.endsWith(".java")) continue;
                dirNode.children.add(fileNode(path, f, dirNode));
            }
        }
    }

    // ------------------------------------------------------------------ helpers

    /** ".../b/c" for a path with more than two segments, otherwise the path unchanged. */
    public static String shortPath(String path) {
        if (path == null || path.length() == 0) return "";
        String[] seg = path.split("/");
        if (seg.length <= 2) return path;
        return ".../" + seg[seg.length - 2] + "/" + seg[seg.length - 1];
    }

    /** Upper-case extension without the dot, "" when there is none. */
    public static String ext(String name) {
        int dot = name.lastIndexOf('.');
        return (dot <= 0 || dot == name.length() - 1) ? "" : name.substring(dot + 1).toUpperCase();
    }

    /** Total files in the tree (what the "Project (N)" header shows). */
    public static int countFiles(Node root) {
        return root == null ? 0 : root.fileCount();
    }

    /** Resolves a project-relative path to a File, refusing anything that escapes the project. */
    public static File resolve(Project p, String rel) throws IOException {
        if (rel == null) throw new IOException("Bad path");
        String r = rel.replace('\\', '/');
        while (r.startsWith("/")) r = r.substring(1);
        String[] seg = r.split("/");
        for (int i = 0; i < seg.length; i++) {
            if (seg[i].equals("..")) throw new IOException("Bad path: " + rel);
        }
        File root = new File(p.rootUrl);
        File f = r.length() == 0 ? root : new File(root, r);
        String rc = root.getCanonicalPath();
        String fc = f.getCanonicalPath();
        if (!fc.equals(rc) && !fc.startsWith(rc + File.separator)) throw new IOException("Bad path: " + rel);
        return f;
    }

    /** "" when `name` is usable as a single file or folder name, otherwise the reason. */
    public static String validateName(String name) {
        if (name == null) return "Enter a name";
        String n = name.trim();
        if (n.length() == 0) return "Enter a name";
        if (n.equals(".") || n.equals("..")) return "Invalid name";
        if (n.startsWith(".")) return "Name cannot start with a dot";
        if (n.length() > 100) return "Name is too long";
        for (int i = 0; i < n.length(); i++) {
            char c = n.charAt(i);
            if (c == '/' || c == '\\' || c == ':' || c == '*' || c == '?' || c == '"'
                    || c == '<' || c == '>' || c == '|' || c < 32) return "Invalid character '" + c + "'";
        }
        return "";
    }

    /** Folders / files that make up the project skeleton and may not be renamed or deleted. */
    public static boolean isProtected(String rel) {
        return rel.length() == 0 || rel.equals("src") || rel.equals("res") || rel.equals("bin")
                || rel.equals("project.properties");
    }

    // ------------------------------------------------------------------ operations

    /** Creates folder `name` inside `parentRel`. Returns "" or an error message. */
    public static String createFolder(Project p, String parentRel, String name) {
        String bad = validateName(name);
        if (bad.length() > 0) return bad;
        try {
            File parent = resolve(p, parentRel);
            if (!parent.isDirectory()) return "Parent folder not found";
            File f = new File(parent, name.trim());
            if (f.exists()) return name.trim() + " already exists";
            if (!f.mkdirs()) return "Could not create folder";
            return "";
        } catch (IOException e) {
            return e.getMessage();
        }
    }

    /** Creates an empty file `name` inside `parentRel`. Returns "" or an error message. */
    public static String createFile(Project p, String parentRel, String name) {
        String bad = validateName(name);
        if (bad.length() > 0) return bad;
        try {
            File parent = resolve(p, parentRel);
            if (!parent.isDirectory()) return "Parent folder not found";
            File f = new File(parent, name.trim());
            if (f.exists()) return name.trim() + " already exists";
            if (!f.createNewFile()) return "Could not create file";
            return "";
        } catch (IOException e) {
            return e.getMessage();
        }
    }

    /** Renames a file or folder in place (same parent). Returns "" or an error message.
     *  Java sources and src/ package folders go through JCompilerBridge / PackageTools instead,
     *  because they also need code updated. */
    public static String rename(Project p, String rel, String newName) {
        if (isProtected(rel)) return "This item cannot be renamed";
        String bad = validateName(newName);
        if (bad.length() > 0) return bad;
        try {
            File from = resolve(p, rel);
            if (!from.exists()) return "Not found: " + rel;
            File to = new File(from.getParentFile(), newName.trim());
            if (to.getName().equals(from.getName())) return "";
            if (to.exists()) return newName.trim() + " already exists";
            if (!from.renameTo(to)) return "Could not rename";
            return "";
        } catch (IOException e) {
            return e.getMessage();
        }
    }

    /** Deletes a file, or a folder with everything in it. Returns "" or an error message. */
    public static String delete(Project p, String rel) {
        if (isProtected(rel)) return "This item cannot be deleted";
        try {
            File f = resolve(p, rel);
            if (!f.exists()) return "";
            return deleteRecursive(f) ? "" : "Could not delete everything in " + rel;
        } catch (IOException e) {
            return e.getMessage();
        }
    }

    private static boolean deleteRecursive(File f) {
        boolean ok = true;
        if (f.isDirectory()) {
            File[] kids = f.listFiles();
            if (kids != null) for (int i = 0; i < kids.length; i++) ok &= deleteRecursive(kids[i]);
        }
        return f.delete() && ok;
    }

    /** Number of files below `rel` (1 for a file, 0 if missing) - for "delete N files?" prompts. */
    public static int countBelow(Project p, String rel) {
        try {
            return count(resolve(p, rel));
        } catch (IOException e) {
            return 0;
        }
    }

    private static int count(File f) {
        if (!f.exists()) return 0;
        if (!f.isDirectory()) return 1;
        int n = 0;
        File[] kids = f.listFiles();
        if (kids != null) for (int i = 0; i < kids.length; i++) n += count(kids[i]);
        return n;
    }
}