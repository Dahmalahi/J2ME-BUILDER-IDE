package com.dashers.j2mebuilderide.ide;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;

/** Mono 16-bit PCM helpers for the Audio Studio: WAV read / write, resample, trim, split, normalise, fade. */
public final class AudioBuf {
    private AudioBuf() { }

    /** A recorded or imported sound (mono). */
    public static final class Clip {
        public String name;
        public short[] pcm;
        public int rate;
        public Clip(String name, short[] pcm, int rate) { this.name = name; this.pcm = pcm; this.rate = rate; }
        public float seconds() { return rate > 0 ? pcm.length / (float) rate : 0f; }
    }

    // ------------------------------------------------------------------ WAV

    private static void le16(ByteArrayOutputStream o, int v) { o.write(v); o.write(v >>> 8); }

    private static void le32(ByteArrayOutputStream o, int v) { o.write(v); o.write(v >>> 8); o.write(v >>> 16); o.write(v >>> 24); }

    public static long wavSize(int samples, int bits) { return 44L + (long) samples * (bits == 8 ? 1 : 2); }

    /** Mono PCM WAV, 8 or 16 bit. */
    public static byte[] wav(short[] pcm, int rate, int bits) {
        boolean b8 = bits == 8;
        int dataLen = pcm.length * (b8 ? 1 : 2);
        ByteArrayOutputStream o = new ByteArrayOutputStream(44 + dataLen);
        o.write('R'); o.write('I'); o.write('F'); o.write('F');
        le32(o, 36 + dataLen);
        o.write('W'); o.write('A'); o.write('V'); o.write('E');
        o.write('f'); o.write('m'); o.write('t'); o.write(' ');
        le32(o, 16);
        le16(o, 1);
        le16(o, 1);
        le32(o, rate);
        le32(o, rate * (b8 ? 1 : 2));
        le16(o, b8 ? 1 : 2);
        le16(o, b8 ? 8 : 16);
        o.write('d'); o.write('a'); o.write('t'); o.write('a');
        le32(o, dataLen);
        byte[] body = new byte[dataLen];
        if (b8) {
            for (int i = 0; i < pcm.length; i++) body[i] = (byte) (((pcm[i] >> 8) + 128) & 0xFF);
        } else {
            for (int i = 0; i < pcm.length; i++) { body[i * 2] = (byte) pcm[i]; body[i * 2 + 1] = (byte) (pcm[i] >> 8); }
        }
        o.write(body, 0, body.length);
        return o.toByteArray();
    }

    private static int rd16(byte[] b, int p) { return (b[p] & 0xFF) | ((b[p + 1] & 0xFF) << 8); }

    private static int rd32(byte[] b, int p) { return rd16(b, p) | (rd16(b, p + 2) << 16); }

    /** Reads a PCM (8 / 16 bit) WAV and mixes it down to mono. Returns null when it is another kind of WAV. */
    public static Clip readWav(byte[] b, String name) {
        if (b == null || b.length < 44 || b[0] != 'R' || b[1] != 'I' || b[2] != 'F' || b[3] != 'F' || b[8] != 'W') return null;
        int p = 12, ch = 1, rate = 0, bits = 16, fmtTag = 1;
        int dataPos = -1, dataLen = 0;
        while (p + 8 <= b.length) {
            int len = rd32(b, p + 4);
            String id = "" + (char) b[p] + (char) b[p + 1] + (char) b[p + 2] + (char) b[p + 3];
            if (id.equals("fmt ")) {
                fmtTag = rd16(b, p + 8);
                ch = rd16(b, p + 10);
                rate = rd32(b, p + 12);
                bits = rd16(b, p + 22);
            } else if (id.equals("data")) {
                dataPos = p + 8;
                dataLen = len < 0 || dataPos + len > b.length ? b.length - dataPos : len;
                break;
            }
            if (len < 0) return null;
            p += 8 + len + (len & 1);
        }
        if (dataPos < 0 || rate <= 0 || ch < 1 || fmtTag != 1 || (bits != 8 && bits != 16)) return null;
        int bytes = bits / 8, frames = dataLen / (bytes * ch);
        short[] out = new short[frames];
        for (int i = 0; i < frames; i++) {
            int sum = 0;
            for (int c = 0; c < ch; c++) {
                int q = dataPos + (i * ch + c) * bytes;
                sum += bits == 16 ? (short) rd16(b, q) : ((b[q] & 0xFF) - 128) << 8;
            }
            out[i] = (short) (sum / ch);
        }
        return new Clip(name, out, rate);
    }

    // ------------------------------------------------------------------ editing

    public static short[] slice(short[] s, int from, int to) {
        from = Math.max(0, Math.min(s.length, from));
        to = Math.max(from, Math.min(s.length, to));
        short[] o = new short[to - from];
        System.arraycopy(s, from, o, 0, o.length);
        return o;
    }

    /** Remove [from, to) from the sound. */
    public static short[] cut(short[] s, int from, int to) {
        from = Math.max(0, Math.min(s.length, from));
        to = Math.max(from, Math.min(s.length, to));
        short[] o = new short[s.length - (to - from)];
        System.arraycopy(s, 0, o, 0, from);
        System.arraycopy(s, to, o, from, s.length - to);
        return o;
    }

    /** Box-filter downsample / linear upsample. */
    public static short[] resample(short[] in, int from, int to) {
        if (from == to || in.length == 0) return in.clone();
        int n = (int) ((long) in.length * to / from);
        short[] o = new short[Math.max(1, n)];
        double step = from / (double) to;
        for (int i = 0; i < o.length; i++) {
            double pos = i * step;
            if (step > 1.0) {
                int a = (int) pos, b = Math.min(in.length, Math.max(a + 1, (int) (pos + step)));
                long sum = 0;
                for (int k = a; k < b; k++) sum += in[k];
                o[i] = (short) (sum / (b - a));
            } else {
                int a = (int) pos;
                double f = pos - a;
                int s0 = in[Math.min(in.length - 1, a)], s1 = in[Math.min(in.length - 1, a + 1)];
                o[i] = (short) Math.round(s0 + (s1 - s0) * f);
            }
        }
        return o;
    }

    public static void normalize(short[] s, float target) {
        int peak = 1;
        for (int i = 0; i < s.length; i++) peak = Math.max(peak, Math.abs((int) s[i]));
        float g = target * 32767f / peak;
        for (int i = 0; i < s.length; i++) s[i] = (short) Math.max(-32768, Math.min(32767, Math.round(s[i] * g)));
    }

    public static void fade(short[] s, int rate, int inMs, int outMs) {
        int fi = Math.min(s.length, (int) ((long) rate * inMs / 1000)), fo = Math.min(s.length, (int) ((long) rate * outMs / 1000));
        for (int i = 0; i < fi; i++) s[i] = (short) (s[i] * (i / (float) fi));
        for (int i = 0; i < fo; i++) s[s.length - 1 - i] = (short) (s[s.length - 1 - i] * (i / (float) fo));
    }

    /** RMS per 10 ms block, in percent of full scale. */
    private static float[] blocks(short[] s, int rate) {
        int blk = Math.max(1, rate / 100);
        float[] r = new float[(s.length + blk - 1) / blk];
        for (int b = 0; b < r.length; b++) {
            long sum = 0;
            int from = b * blk, to = Math.min(s.length, from + blk);
            for (int i = from; i < to; i++) sum += (long) s[i] * s[i];
            r[b] = (float) (Math.sqrt(sum / (double) Math.max(1, to - from)) / 327.67);
        }
        return r;
    }

    /** Remove silence at the start and the end (threshold in percent of full scale). */
    public static short[] trimSilence(short[] s, int rate, float thresholdPct) {
        float[] r = blocks(s, rate);
        int blk = Math.max(1, rate / 100), a = 0, b = r.length - 1;
        while (a < r.length && r[a] < thresholdPct) a++;
        while (b > a && r[b] < thresholdPct) b--;
        if (a >= r.length) return s;
        return slice(s, a * blk, (b + 1) * blk);
    }

    /** Parts separated by silence: each int[]{from, to} in samples. */
    public static ArrayList<int[]> splitOnSilence(short[] s, int rate, float thresholdPct, int minSilenceMs, int minPartMs) {
        float[] r = blocks(s, rate);
        int blk = Math.max(1, rate / 100), minSil = Math.max(1, minSilenceMs / 10), minPart = Math.max(1, minPartMs / 10);
        ArrayList<int[]> out = new ArrayList<int[]>();
        int start = -1, quiet = 0;
        for (int b = 0; b < r.length; b++) {
            if (r[b] >= thresholdPct) {
                if (start < 0) start = b;
                quiet = 0;
            } else if (start >= 0) {
                quiet++;
                if (quiet >= minSil) {
                    int end = b - quiet + 1;
                    if (end - start >= minPart) out.add(new int[]{start * blk, Math.min(s.length, end * blk)});
                    start = -1;
                    quiet = 0;
                }
            }
        }
        if (start >= 0 && r.length - quiet - start >= minPart) out.add(new int[]{start * blk, s.length});
        return out;
    }
}
