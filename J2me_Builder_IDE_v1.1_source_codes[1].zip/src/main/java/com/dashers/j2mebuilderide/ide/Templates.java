package com.dashers.j2mebuilderide.ide;

/** Starter sources for "New project". Every template is verified to
 *  compile with this app's own compiler engine. */
public class Templates {

    public static final String[] NAMES = { "Hello Form", "Canvas animation", "Menu list", "3D cube (M3G)", "OpenGL ES triangle" };

    public static String get(int index, String n) {
        return get(index, "", n);
    }

    public static String get(int index, String pkg, String n) {
        if (index == 1) return canvas(pkg, n);
        if (index == 2) return menu(pkg, n);
        if (index == 3) return m3gCube(pkg, n);
        if (index == 4) return glTriangle(pkg, n);
        return form(pkg, n);
    }

    private static String packageLine(String pkg) {
        return (pkg != null && pkg.length() > 0) ? "package " + pkg + ";\n\n" : "";
    }

    private static String form(String pkg, String n) {
        return
            packageLine(pkg) +
            "import javax.microedition.midlet.MIDlet;\n" +
            "import javax.microedition.lcdui.Display;\n" +
            "import javax.microedition.lcdui.Form;\n" +
            "\n" +
            "public class " + n + " extends MIDlet {\n" +
            "    Display display;\n" +
            "    Form form;\n" +
            "\n" +
            "    public " + n + "() {\n" +
            "        display = Display.getDisplay(this);\n" +
            "        form = new Form(\"" + n + "\");\n" +
            "        form.append(\"Hello, world!\");\n" +
            "    }\n" +
            "\n" +
            "    protected void startApp() {\n" +
            "        display.setCurrent(form);\n" +
            "    }\n" +
            "\n" +
            "    protected void pauseApp() {\n" +
            "    }\n" +
            "\n" +
            "    protected void destroyApp(boolean unconditional) {\n" +
            "    }\n" +
            "}\n";
    }

    private static String canvas(String pkg, String n) {
        return
            packageLine(pkg) +
            "import javax.microedition.midlet.MIDlet;\n" +
            "import javax.microedition.lcdui.Canvas;\n" +
            "import javax.microedition.lcdui.Display;\n" +
            "import javax.microedition.lcdui.Graphics;\n" +
            "\n" +
            "public class " + n + " extends MIDlet {\n" +
            "    Display display;\n" +
            "    BounceCanvas canvas;\n" +
            "\n" +
            "    public " + n + "() {\n" +
            "        display = Display.getDisplay(this);\n" +
            "        canvas = new BounceCanvas();\n" +
            "    }\n" +
            "\n" +
            "    protected void startApp() {\n" +
            "        display.setCurrent(canvas);\n" +
            "        canvas.start();\n" +
            "    }\n" +
            "\n" +
            "    protected void pauseApp() {\n" +
            "        canvas.stop();\n" +
            "    }\n" +
            "\n" +
            "    protected void destroyApp(boolean unconditional) {\n" +
            "        canvas.stop();\n" +
            "    }\n" +
            "}\n" +
            "\n" +
            "class BounceCanvas extends Canvas implements Runnable {\n" +
            "    int x = 20;\n" +
            "    int y = 20;\n" +
            "    int dx = 3;\n" +
            "    int dy = 2;\n" +
            "    int size = 16;\n" +
            "    boolean running;\n" +
            "\n" +
            "    void start() {\n" +
            "        running = true;\n" +
            "        Thread t = new Thread(this);\n" +
            "        t.start();\n" +
            "    }\n" +
            "\n" +
            "    void stop() {\n" +
            "        running = false;\n" +
            "    }\n" +
            "\n" +
            "    public void run() {\n" +
            "        while (running) {\n" +
            "            x = x + dx;\n" +
            "            y = y + dy;\n" +
            "            if (x < 0 || x + size > getWidth()) dx = -dx;\n" +
            "            if (y < 0 || y + size > getHeight()) dy = -dy;\n" +
            "            repaint();\n" +
            "            try {\n" +
            "                Thread.sleep(40);\n" +
            "            } catch (InterruptedException e) {\n" +
            "            }\n" +
            "        }\n" +
            "    }\n" +
            "\n" +
            "    protected void paint(Graphics g) {\n" +
            "        g.setColor(0x101820);\n" +
            "        g.fillRect(0, 0, getWidth(), getHeight());\n" +
            "        g.setColor(0x4C8DFF);\n" +
            "        g.fillRect(x, y, size, size);\n" +
            "    }\n" +
            "}\n";
    }

    private static String menu(String pkg, String n) {
        return
            packageLine(pkg) +
            "import javax.microedition.midlet.MIDlet;\n" +
            "import javax.microedition.lcdui.Command;\n" +
            "import javax.microedition.lcdui.CommandListener;\n" +
            "import javax.microedition.lcdui.Displayable;\n" +
            "import javax.microedition.lcdui.Display;\n" +
            "import javax.microedition.lcdui.List;\n" +
            "\n" +
            "public class " + n + " extends MIDlet implements CommandListener {\n" +
            "    Display display;\n" +
            "    List list;\n" +
            "    Command exit;\n" +
            "\n" +
            "    public " + n + "() {\n" +
            "        display = Display.getDisplay(this);\n" +
            "        list = new List(\"" + n + "\", List.IMPLICIT);\n" +
            "        list.append(\"Start\", null);\n" +
            "        list.append(\"Options\", null);\n" +
            "        list.append(\"About\", null);\n" +
            "        exit = new Command(\"Exit\", Command.EXIT, 1);\n" +
            "        list.addCommand(exit);\n" +
            "        list.setCommandListener(this);\n" +
            "    }\n" +
            "\n" +
            "    public void commandAction(Command c, Displayable d) {\n" +
            "        if (c == exit) {\n" +
            "            destroyApp(true);\n" +
            "            notifyDestroyed();\n" +
            "        }\n" +
            "    }\n" +
            "\n" +
            "    protected void startApp() {\n" +
            "        display.setCurrent(list);\n" +
            "    }\n" +
            "\n" +
            "    protected void pauseApp() {\n" +
            "    }\n" +
            "\n" +
            "    protected void destroyApp(boolean unconditional) {\n" +
            "    }\n" +
            "}\n";
    }

    /** Spinning vertex-coloured cube using the M3G (JSR-184) scene graph. */
    private static String m3gCube(String pkg, String n) {
        return
            packageLine(pkg) +
            "import javax.microedition.midlet.MIDlet;\n" +
            "import javax.microedition.lcdui.Canvas;\n" +
            "import javax.microedition.lcdui.Display;\n" +
            "import javax.microedition.lcdui.Graphics;\n" +
            "import javax.microedition.m3g.Background;\n" +
            "import javax.microedition.m3g.Appearance;\n" +
            "import javax.microedition.m3g.Camera;\n" +
            "import javax.microedition.m3g.Graphics3D;\n" +
            "import javax.microedition.m3g.IndexBuffer;\n" +
            "import javax.microedition.m3g.Mesh;\n" +
            "import javax.microedition.m3g.PolygonMode;\n" +
            "import javax.microedition.m3g.TriangleStripArray;\n" +
            "import javax.microedition.m3g.VertexArray;\n" +
            "import javax.microedition.m3g.VertexBuffer;\n" +
            "import javax.microedition.m3g.World;\n" +
            "\n" +
            "public class " + n + " extends MIDlet {\n" +
            "    Display display;\n" +
            "    " + n + "Canvas canvas;\n" +
            "\n" +
            "    public " + n + "() {\n" +
            "        display = Display.getDisplay(this);\n" +
            "    }\n" +
            "\n" +
            "    protected void startApp() {\n" +
            "        if (canvas == null) canvas = new " + n + "Canvas();\n" +
            "        display.setCurrent(canvas);\n" +
            "        canvas.start();\n" +
            "    }\n" +
            "\n" +
            "    protected void pauseApp() {\n" +
            "        if (canvas != null) canvas.stop();\n" +
            "    }\n" +
            "\n" +
            "    protected void destroyApp(boolean unconditional) {\n" +
            "        if (canvas != null) canvas.stop();\n" +
            "    }\n" +
            "}\n" +
            "\n" +
            "class " + n + "Canvas extends Canvas implements Runnable {\n" +
            "    Graphics3D g3d;\n" +
            "    World world;\n" +
            "    Mesh cube;\n" +
            "    float angle;\n" +
            "    boolean running;\n" +
            "\n" +
            "    " + n + "Canvas() {\n" +
            "        g3d = Graphics3D.getInstance();\n" +
            "        world = new World();\n" +
            "\n" +
            "        Camera cam = new Camera();\n" +
            "        cam.setPerspective(60.0f, (float) getWidth() / (float) getHeight(), 1.0f, 50.0f);\n" +
            "        cam.translate(0.0f, 0.0f, 5.0f);\n" +
            "        world.addChild(cam);\n" +
            "        world.setActiveCamera(cam);\n" +
            "\n" +
            "        Background bg = new Background();\n" +
            "        bg.setColor(0x202040);\n" +
            "        world.setBackground(bg);\n" +
            "\n" +
            "        short[] pos = {\n" +
            "            -1, -1, 1,   1, -1, 1,   -1, 1, 1,   1, 1, 1,\n" +
            "            -1, -1, -1,  1, -1, -1,  -1, 1, -1,  1, 1, -1\n" +
            "        };\n" +
            "        byte[] col = {\n" +
            "            (byte) 255, 0, 0,    0, (byte) 255, 0,    0, 0, (byte) 255,    (byte) 255, (byte) 255, 0,\n" +
            "            (byte) 255, 0, (byte) 255,  0, (byte) 255, (byte) 255,  (byte) 255, (byte) 255, (byte) 255,  (byte) 128, (byte) 128, (byte) 128\n" +
            "        };\n" +
            "        int[] idx = {\n" +
            "            0, 1, 3,  0, 3, 2,   5, 4, 6,  5, 6, 7,\n" +
            "            4, 0, 2,  4, 2, 6,   1, 5, 7,  1, 7, 3,\n" +
            "            2, 3, 7,  2, 7, 6,   4, 5, 1,  4, 1, 0\n" +
            "        };\n" +
            "        int[] strips = { 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3 };\n" +
            "\n" +
            "        VertexArray positions = new VertexArray(8, 3, 2);\n" +
            "        positions.set(0, 8, pos);\n" +
            "        VertexArray colors = new VertexArray(8, 3, 1);\n" +
            "        colors.set(0, 8, col);\n" +
            "\n" +
            "        VertexBuffer vb = new VertexBuffer();\n" +
            "        vb.setPositions(positions, 1.0f, null);\n" +
            "        vb.setColors(colors);\n" +
            "\n" +
            "        IndexBuffer tris = new TriangleStripArray(idx, strips);\n" +
            "        Appearance app = new Appearance();\n" +
            "        PolygonMode pm = new PolygonMode();\n" +
            "        pm.setCulling(PolygonMode.CULL_BACK);\n" +
            "        app.setPolygonMode(pm);\n" +
            "\n" +
            "        cube = new Mesh(vb, tris, app);\n" +
            "        world.addChild(cube);\n" +
            "    }\n" +
            "\n" +
            "    void start() {\n" +
            "        running = true;\n" +
            "        new Thread(this).start();\n" +
            "    }\n" +
            "\n" +
            "    void stop() {\n" +
            "        running = false;\n" +
            "    }\n" +
            "\n" +
            "    public void run() {\n" +
            "        while (running) {\n" +
            "            angle += 3.0f;\n" +
            "            repaint();\n" +
            "            serviceRepaints();\n" +
            "            try {\n" +
            "                Thread.sleep(40);\n" +
            "            } catch (InterruptedException e) {\n" +
            "            }\n" +
            "        }\n" +
            "    }\n" +
            "\n" +
            "    protected void paint(Graphics g) {\n" +
            "        try {\n" +
            "            g3d.bindTarget(g);\n" +
            "            g3d.setViewport(0, 0, getWidth(), getHeight());\n" +
            "            cube.setOrientation(angle, 1.0f, 1.0f, 0.0f);\n" +
            "            g3d.render(world);\n" +
            "        } finally {\n" +
            "            g3d.releaseTarget();\n" +
            "        }\n" +
            "    }\n" +
            "}\n";
    }

    /** Spinning triangle using OpenGL ES 1.x (JSR-239) over EGL. */
    private static String glTriangle(String pkg, String n) {
        return
            packageLine(pkg) +
            "import javax.microedition.midlet.MIDlet;\n" +
            "import javax.microedition.lcdui.Canvas;\n" +
            "import javax.microedition.lcdui.Display;\n" +
            "import javax.microedition.lcdui.Graphics;\n" +
            "import javax.microedition.khronos.egl.EGL10;\n" +
            "import javax.microedition.khronos.egl.EGLConfig;\n" +
            "import javax.microedition.khronos.egl.EGLContext;\n" +
            "import javax.microedition.khronos.egl.EGLDisplay;\n" +
            "import javax.microedition.khronos.egl.EGLSurface;\n" +
            "import javax.microedition.khronos.opengles.GL10;\n" +
            "import java.nio.ByteBuffer;\n" +
            "import java.nio.ByteOrder;\n" +
            "import java.nio.FloatBuffer;\n" +
            "\n" +
            "public class " + n + " extends MIDlet {\n" +
            "    Display display;\n" +
            "    " + n + "Canvas canvas;\n" +
            "\n" +
            "    public " + n + "() {\n" +
            "        display = Display.getDisplay(this);\n" +
            "    }\n" +
            "\n" +
            "    protected void startApp() {\n" +
            "        if (canvas == null) canvas = new " + n + "Canvas();\n" +
            "        display.setCurrent(canvas);\n" +
            "        canvas.start();\n" +
            "    }\n" +
            "\n" +
            "    protected void pauseApp() {\n" +
            "        if (canvas != null) canvas.stop();\n" +
            "    }\n" +
            "\n" +
            "    protected void destroyApp(boolean unconditional) {\n" +
            "        if (canvas != null) canvas.stop();\n" +
            "    }\n" +
            "}\n" +
            "\n" +
            "class " + n + "Canvas extends Canvas implements Runnable {\n" +
            "    EGL10 egl;\n" +
            "    EGLDisplay dpy;\n" +
            "    EGLConfig config;\n" +
            "    EGLContext ctx;\n" +
            "    EGLSurface surf;\n" +
            "    GL10 gl;\n" +
            "    FloatBuffer verts;\n" +
            "    float angle;\n" +
            "    boolean running;\n" +
            "\n" +
            "    " + n + "Canvas() {\n" +
            "        float[] v = { 0.0f, 1.0f, 0.0f, -1.0f, -1.0f, 0.0f, 1.0f, -1.0f, 0.0f };\n" +
            "        ByteBuffer bb = ByteBuffer.allocateDirect(v.length * 4);\n" +
            "        bb.order(ByteOrder.nativeOrder());\n" +
            "        verts = bb.asFloatBuffer();\n" +
            "        verts.put(v);\n" +
            "        verts.position(0);\n" +
            "    }\n" +
            "\n" +
            "    void initGL() {\n" +
            "        egl = (EGL10) EGLContext.getEGL();\n" +
            "        dpy = egl.eglGetDisplay(EGL10.EGL_DEFAULT_DISPLAY);\n" +
            "        egl.eglInitialize(dpy, new int[2]);\n" +
            "        int[] attr = {\n" +
            "            EGL10.EGL_RED_SIZE, 5, EGL10.EGL_GREEN_SIZE, 6, EGL10.EGL_BLUE_SIZE, 5,\n" +
            "            EGL10.EGL_DEPTH_SIZE, 16, EGL10.EGL_NONE\n" +
            "        };\n" +
            "        EGLConfig[] configs = new EGLConfig[1];\n" +
            "        egl.eglChooseConfig(dpy, attr, configs, 1, new int[1]);\n" +
            "        config = configs[0];\n" +
            "        ctx = egl.eglCreateContext(dpy, config, EGL10.EGL_NO_CONTEXT, null);\n" +
            "        gl = (GL10) ctx.getGL();\n" +
            "    }\n" +
            "\n" +
            "    void start() {\n" +
            "        running = true;\n" +
            "        new Thread(this).start();\n" +
            "    }\n" +
            "\n" +
            "    void stop() {\n" +
            "        running = false;\n" +
            "    }\n" +
            "\n" +
            "    public void run() {\n" +
            "        while (running) {\n" +
            "            angle += 3.0f;\n" +
            "            repaint();\n" +
            "            serviceRepaints();\n" +
            "            try {\n" +
            "                Thread.sleep(40);\n" +
            "            } catch (InterruptedException e) {\n" +
            "            }\n" +
            "        }\n" +
            "    }\n" +
            "\n" +
            "    protected void paint(Graphics g) {\n" +
            "        if (egl == null) initGL();\n" +
            "        surf = egl.eglCreateWindowSurface(dpy, config, g, null);\n" +
            "        egl.eglMakeCurrent(dpy, surf, surf, ctx);\n" +
            "        int w = getWidth();\n" +
            "        int h = getHeight();\n" +
            "        gl.glViewport(0, 0, w, h);\n" +
            "        gl.glMatrixMode(GL10.GL_PROJECTION);\n" +
            "        gl.glLoadIdentity();\n" +
            "        gl.glFrustumf(-0.5f, 0.5f, -0.5f * h / w, 0.5f * h / w, 1.0f, 20.0f);\n" +
            "        gl.glMatrixMode(GL10.GL_MODELVIEW);\n" +
            "        gl.glLoadIdentity();\n" +
            "        gl.glClearColor(0.1f, 0.1f, 0.25f, 1.0f);\n" +
            "        gl.glClear(GL10.GL_COLOR_BUFFER_BIT | GL10.GL_DEPTH_BUFFER_BIT);\n" +
            "        gl.glTranslatef(0.0f, 0.0f, -4.0f);\n" +
            "        gl.glRotatef(angle, 0.0f, 1.0f, 0.0f);\n" +
            "        gl.glColor4f(1.0f, 0.6f, 0.1f, 1.0f);\n" +
            "        gl.glEnableClientState(GL10.GL_VERTEX_ARRAY);\n" +
            "        gl.glVertexPointer(3, GL10.GL_FLOAT, 0, verts);\n" +
            "        gl.glDrawArrays(GL10.GL_TRIANGLES, 0, 3);\n" +
            "        gl.glDisableClientState(GL10.GL_VERTEX_ARRAY);\n" +
            "        egl.eglSwapBuffers(dpy, surf);\n" +
            "        egl.eglDestroySurface(dpy, surf);\n" +
            "    }\n" +
            "}\n";
    }
}
