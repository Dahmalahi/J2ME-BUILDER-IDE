package com.dashers.j2mebuilderide.ide;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Java package management for a project's src/ tree: list packages, create / rename / delete a
 * package, move a class to another package, and keep every `package x.y;` line in sync with the
 * folder the file really sits in.
 *
 * Pure Java (no Android classes). All "srcRel" paths are relative to src/ and use '/', e.g.
 * "com/example/app/Main.java". The default package is "".
 */
public final class PackageTools {
    private PackageTools() {}

    private static final String[] RESERVED = {
        "abstract", "boolean", "break", "byte", "case", "catch", "char", "class", "const", "continue",
        "default", "do", "double", "else", "extends", "final", "finally", "float", "for", "goto", "if",
        "implements", "import", "instanceof", "int", "interface", "long", "native", "new", "package",
        "private", "protected", "public", "return", "short", "static", "super", "switch", "synchronized",
        "this", "throw", "throws", "try", "void", "volatile", "while", "true", "false", "null", "assert",
        "strictfp"
    };

    // ------------------------------------------------------------------ model

    /** One package folder of src/. */
    public static final class PackageInfo {
        public String name = "";                 // dotted, "" = default package
        public String path = "";                 // folder relative to src/, "" for the default package
        public final ArrayList<String> classes = new ArrayList<String>(); // srcRel of direct .java files
        public int subPackages = 0;              // direct sub-folders
        public int totalFiles = 0;               // every file below, any type
        public boolean isEmpty() { return totalFiles == 0; }
    }

    /** A source file whose `package` line does not match its folder. */
    public static final class Mismatch {
        public String file;       // srcRel
        public String expected;   // package implied by the folder
        public String declared;   // package written in the file ("" = none)
    }

    // ------------------------------------------------------------------ validation

    /** "" when `n` is a valid, non-empty dotted package name, otherwise the reason. */
    public static String validate(String n) {
        if (n == null || n.trim().length() == 0) return "Enter a package name";
        String s = n.trim();
        if (s.startsWith(".") || s.endsWith(".") || s.indexOf("..") >= 0) return "Dots must separate names";
        String[] parts = s.split("\\.");
        for (int i = 0; i < parts.length; i++) {
            String seg = parts[i];
            if (seg.length() == 0) return "Empty package segment";
            char c0 = seg.charAt(0);
            if (!(Character.isLetter(c0) || c0 == '_') || c0 > 127) return "'" + seg + "' must start with a letter";
            for (int k = 0; k < seg.length(); k++) {
                char c = seg.charAt(k);
                if (!(Character.isLetterOrDigit(c) || c == '_') || c > 127) return "Only letters, digits and _ in '" + seg + "'";
            }
            for (int r = 0; r < RESERVED.length; r++) {
                if (RESERVED[r].equals(seg)) return "'" + seg + "' is a Java keyword";
            }
        }
        return "";
    }

    // ------------------------------------------------------------------ source helpers

    private static final Pattern PACKAGE_DECL =
            Pattern.compile("(?m)^[ \\t]*package[ \\t\\r\\n]+([A-Za-z_$][\\w$]*(?:[ \\t]*\\.[ \\t]*[A-Za-z_$][\\w$]*)*)[ \\t]*;");
    private static final Pattern IMPORT_LINE =
            Pattern.compile("(?m)^[ \\t]*import[ \\t]+[^;\\n]+;[^\\n]*$");

    /** Package written in the source, or "" when there is no `package` statement. */
    public static String declaredPackage(String source) {
        Matcher m = PACKAGE_DECL.matcher(Lint.blank(source));
        if (!m.find()) return "";
        return source.substring(m.start(1), m.end(1)).replaceAll("\\s+", "");
    }

    /** Package implied by a src-relative file path ("com/a/B.java" -> "com.a"). */
    public static String expectedPackage(String srcRel) {
        int slash = srcRel.lastIndexOf('/');
        return slash < 0 ? "" : srcRel.substring(0, slash).replace('/', '.');
    }

    static String setPackageDeclaration(String source, String pkg) {
        Matcher m = PACKAGE_DECL.matcher(Lint.blank(source));
        if (m.find()) {
            if (pkg.length() > 0) {
                return source.substring(0, m.start(1)) + pkg + source.substring(m.end(1));
            }
            int end = m.end();
            while (end < source.length() && (source.charAt(end) == '\r' || source.charAt(end) == '\n')) end++;
            return source.substring(0, m.start()) + source.substring(end);
        }
        return pkg.length() == 0 ? source : "package " + pkg + ";\n\n" + source;
    }

    static boolean uses(String maskedSource, String simpleName) {
        return Pattern.compile("(?<![\\w$.])" + Pattern.quote(simpleName) + "(?![\\w$])").matcher(maskedSource).find();
    }

    static boolean hasImport(String maskedSource, String fqcn) {
        return Pattern.compile("(?m)^[ \\t]*import[ \\t]+" + Pattern.quote(fqcn) + "[ \\t]*;").matcher(maskedSource).find();
    }

    static boolean hasWildcardImport(String maskedSource, String pkg) {
        return Pattern.compile("(?m)^[ \\t]*import[ \\t]+" + Pattern.quote(pkg) + "\\.\\*[ \\t]*;").matcher(maskedSource).find();
    }

    static String addImport(String source, String fqcn) {
        String masked = Lint.blank(source);
        if (hasImport(masked, fqcn)) return source;
        String stmt = "import " + fqcn + ";";
        Matcher im = IMPORT_LINE.matcher(masked);
        int last = -1;
        while (im.find()) last = im.end();
        if (last >= 0) return source.substring(0, last) + "\n" + stmt + source.substring(last);
        Matcher pm = PACKAGE_DECL.matcher(masked);
        if (pm.find()) {
            int end = pm.end();
            return source.substring(0, end) + "\n\n" + stmt + source.substring(end);
        }
        return stmt + "\n\n" + source;
    }

    private static String read(Project p, String srcRel) throws IOException {
        byte[] b = Project.readWholeFile(p.srcUrl() + srcRel);
        return b == null ? "" : new String(b, "UTF-8");
    }

    private static void write(Project p, String srcRel, String text) throws IOException {
        Project.writeWholeFile(p.srcUrl() + srcRel, text.getBytes("UTF-8"));
    }

    /** Every .java file below src/, as src-relative paths, sorted. */
    public static ArrayList<String> javaFiles(Project p) {
        ArrayList<String> out = new ArrayList<String>();
        collectJava(new File(p.srcUrl()), "", out);
        Collections.sort(out);
        return out;
    }

    private static void collectJava(File dir, String rel, ArrayList<String> out) {
        File[] list = dir.listFiles();
        if (list == null) return;
        for (int i = 0; i < list.length; i++) {
            File f = list[i];
            String r = rel.length() == 0 ? f.getName() : rel + "/" + f.getName();
            if (f.isDirectory()) collectJava(f, r, out);
            else if (f.getName().endsWith(".java")) out.add(r);
        }
    }

    // ------------------------------------------------------------------ listing

    /**
     * All package folders of src/. With includeIntermediate=false the in-between folders that only
     * hold other folders (com, com/example) are left out, like the package view of a normal IDE.
     */
    public static ArrayList<PackageInfo> list(Project p, boolean includeIntermediate) {
        TreeMap<String, PackageInfo> map = new TreeMap<String, PackageInfo>();
        File src = new File(p.srcUrl());
        PackageInfo root = new PackageInfo();
        map.put("", root);
        scan(src, "", map);
        ArrayList<PackageInfo> out = new ArrayList<PackageInfo>();
        for (PackageInfo pi : map.values()) {
            boolean intermediate = pi.classes.size() == 0 && pi.subPackages > 0;
            if (pi.path.length() == 0 && pi.classes.size() == 0) continue;   // empty default package
            if (!includeIntermediate && intermediate && pi.totalFiles > 0) continue;
            if (!includeIntermediate && intermediate && pi.totalFiles == 0 && hasEmptyLeafBelow(map, pi)) continue;
            out.add(pi);
        }
        Collections.sort(out, new Comparator<PackageInfo>() {
            public int compare(PackageInfo a, PackageInfo b) { return a.name.compareToIgnoreCase(b.name); }
        });
        return out;
    }

    private static boolean hasEmptyLeafBelow(TreeMap<String, PackageInfo> map, PackageInfo pi) {
        for (PackageInfo o : map.values()) {
            if (o != pi && o.path.startsWith(pi.path + "/") && o.subPackages == 0) return true;
        }
        return false;
    }

    private static int scan(File dir, String rel, TreeMap<String, PackageInfo> map) {
        PackageInfo pi = map.get(rel);
        if (pi == null) {
            pi = new PackageInfo();
            pi.path = rel;
            pi.name = rel.replace('/', '.');
            map.put(rel, pi);
        }
        int total = 0;
        File[] list = dir.listFiles();
        if (list != null) {
            Arrays.sort(list);
            for (int i = 0; i < list.length; i++) {
                File f = list[i];
                String r = rel.length() == 0 ? f.getName() : rel + "/" + f.getName();
                if (f.isDirectory()) {
                    pi.subPackages++;
                    total += scan(f, r, map);
                } else {
                    total++;
                    if (f.getName().endsWith(".java")) pi.classes.add(r);
                }
            }
        }
        pi.totalFiles = total;
        return total;
    }

    // ------------------------------------------------------------------ health check

    /** Files whose `package` line differs from their folder. */
    public static ArrayList<Mismatch> findMismatches(Project p) {
        ArrayList<Mismatch> out = new ArrayList<Mismatch>();
        ArrayList<String> files = javaFiles(p);
        for (int i = 0; i < files.size(); i++) {
            String f = files.get(i);
            try {
                String exp = expectedPackage(f);
                String dec = declaredPackage(read(p, f));
                if (!exp.equals(dec)) {
                    Mismatch m = new Mismatch();
                    m.file = f;
                    m.expected = exp;
                    m.declared = dec;
                    out.add(m);
                }
            } catch (IOException ignore) { }
        }
        return out;
    }

    /** Rewrites the `package` line of one file to match its folder. Returns "" or an error. */
    public static String fixDeclaration(Project p, String srcRel) {
        try {
            String src = read(p, srcRel);
            String out = setPackageDeclaration(src, expectedPackage(srcRel));
            if (!out.equals(src)) write(p, srcRel, out);
            return "";
        } catch (IOException e) {
            return "Could not update " + srcRel + ": " + e.getMessage();
        }
    }

    /** Fixes every mismatch (folder wins). Returns the number fixed; errors are appended to `errors`. */
    public static int fixAllDeclarations(Project p, StringBuffer errors) {
        ArrayList<Mismatch> list = findMismatches(p);
        int fixed = 0;
        for (int i = 0; i < list.size(); i++) {
            String err = fixDeclaration(p, list.get(i).file);
            if (err.length() == 0) fixed++;
            else if (errors != null) errors.append(err).append('\n');
        }
        return fixed;
    }

    /** Alternative fix: moves the file into the folder its `package` line points at. */
    public static String moveToDeclaredFolder(Project p, String srcRel) {
        try {
            String src = read(p, srcRel);
            String dec = declaredPackage(src);
            String name = srcRel.substring(srcRel.lastIndexOf('/') + 1);
            String newRel = dec.length() == 0 ? name : dec.replace('.', '/') + "/" + name;
            if (newRel.equals(srcRel)) return "";
            if (new File(p.srcUrl() + newRel).exists()) return newRel + " already exists";
            write(p, newRel, src);
            if (!new File(p.srcUrl() + srcRel).delete()) return "Could not remove the old copy of " + srcRel;
            pruneEmptyDirs(new File(p.srcUrl()), new File(p.srcUrl() + srcRel).getParentFile());
            return "";
        } catch (IOException e) {
            return "Move failed: " + e.getMessage();
        }
    }

    // ------------------------------------------------------------------ create / delete

    public static String create(Project p, String pkg) {
        String bad = validate(pkg);
        if (bad.length() > 0) return bad;
        File dir = new File(p.srcUrl() + pkg.trim().replace('.', '/'));
        if (dir.exists()) return "Package " + pkg.trim() + " already exists";
        return dir.mkdirs() ? "" : "Could not create the package folder";
    }

    /** Deletes a package folder only when nothing is in it (sub-folders must be empty too). */
    public static String delete(Project p, String pkg) {
        if (pkg == null || pkg.length() == 0) return "The default package cannot be deleted";
        File dir = new File(p.srcUrl() + pkg.replace('.', '/'));
        if (!dir.isDirectory()) return "Package not found: " + pkg;
        int files = countFiles(dir);
        if (files > 0) return "Package is not empty (" + files + (files == 1 ? " file" : " files") + ")";
        deleteEmptyTree(dir);
        pruneEmptyDirs(new File(p.srcUrl()), dir.getParentFile());
        return dir.exists() ? "Could not delete the package folder" : "";
    }

    private static int countFiles(File f) {
        if (!f.isDirectory()) return 1;
        int n = 0;
        File[] kids = f.listFiles();
        if (kids != null) for (int i = 0; i < kids.length; i++) n += countFiles(kids[i]);
        return n;
    }

    private static void deleteEmptyTree(File dir) {
        File[] kids = dir.listFiles();
        if (kids != null) for (int i = 0; i < kids.length; i++) if (kids[i].isDirectory()) deleteEmptyTree(kids[i]);
        dir.delete();
    }

    /** Removes `dir` and its parents while they are empty, never going above `stop`. */
    private static void pruneEmptyDirs(File stop, File dir) {
        try {
            String stopC = stop.getCanonicalPath();
            while (dir != null && !dir.getCanonicalPath().equals(stopC) && dir.isDirectory()) {
                String[] kids = dir.list();
                if (kids != null && kids.length > 0) return;
                if (!dir.delete()) return;
                dir = dir.getParentFile();
            }
        } catch (IOException ignore) { }
    }

    // ------------------------------------------------------------------ rename package

    /**
     * Renames a package AND every sub-package under it (com.old -> org.new also turns
     * com.old.ui into org.new.ui). Moves the folder, rewrites `package` lines, imports and fully
     * qualified names (also inside strings, for Class.forName) in the whole project, and updates
     * the project's package setting.
     */
    public static String rename(Project p, String oldPkg, String newPkg) {
        if (oldPkg == null || oldPkg.length() == 0) return "The default package cannot be renamed";
        String bad = validate(newPkg);
        if (bad.length() > 0) return bad;
        newPkg = newPkg.trim();
        if (newPkg.equals(oldPkg)) return "";
        if (newPkg.startsWith(oldPkg + ".")) return "The new name cannot be inside the old package";
        File from = new File(p.srcUrl() + oldPkg.replace('.', '/'));
        File to = new File(p.srcUrl() + newPkg.replace('.', '/'));
        if (!from.isDirectory()) return "Package not found: " + oldPkg;
        if (to.exists()) return "Package " + newPkg + " already exists";

        Pattern pat = Pattern.compile("(?<![\\w$.])" + Pattern.quote(oldPkg) + "(?![\\w$])");
        String replacement = Matcher.quoteReplacement(newPkg);
        String oldDir = oldPkg.replace('.', '/') + "/";
        String newDir = newPkg.replace('.', '/') + "/";

        ArrayList<String> files = javaFiles(p);
        ArrayList<String> paths = new ArrayList<String>();   // final src-relative path after the move
        ArrayList<String> texts = new ArrayList<String>();
        ArrayList<Boolean> changed = new ArrayList<Boolean>();
        try {
            for (int i = 0; i < files.size(); i++) {
                String f = files.get(i);
                String src = read(p, f);
                String out = pat.matcher(src).replaceAll(replacement);
                String target = f.startsWith(oldDir) ? newDir + f.substring(oldDir.length()) : f;
                paths.add(target);
                texts.add(out);
                changed.add(Boolean.valueOf(!out.equals(src)));
            }
            File parent = to.getParentFile();
            if (parent != null && !parent.isDirectory() && !parent.mkdirs()) return "Could not create folder for " + newPkg;
            if (!from.renameTo(to)) return "Could not move the package folder";
            for (int i = 0; i < paths.size(); i++) {
                if (changed.get(i).booleanValue()) write(p, paths.get(i), texts.get(i));
            }
            pruneEmptyDirs(new File(p.srcUrl()), from.getParentFile());
            if (p.packageName.equals(oldPkg) || p.packageName.startsWith(oldPkg + ".")) {
                p.packageName = newPkg + p.packageName.substring(oldPkg.length());
                p.save();
            }
            return "";
        } catch (IOException e) {
            return "Package rename failed: " + e.getMessage();
        }
    }

    // ------------------------------------------------------------------ move class

    /**
     * Moves one class file into another package and repairs the code around it: the moved file's
     * `package` line, imports of the classes it used to see for free (same old package), and the
     * imports / qualified names in every file that uses the class.
     * Returns "" or an error message.
     */
    public static String moveClass(Project p, String srcRel, String targetPkg) {
        if (srcRel == null || !srcRel.endsWith(".java")) return "Not a .java file";
        targetPkg = targetPkg == null ? "" : targetPkg.trim();
        if (targetPkg.length() > 0) {
            String bad = validate(targetPkg);
            if (bad.length() > 0) return bad;
        }
        String name = srcRel.substring(srcRel.lastIndexOf('/') + 1);
        String cls = name.substring(0, name.length() - 5);
        String oldPkg = expectedPackage(srcRel);
        if (oldPkg.equals(targetPkg)) return "";
        String newRel = targetPkg.length() == 0 ? name : targetPkg.replace('.', '/') + "/" + name;
        if (new File(p.srcUrl() + newRel).exists()) return newRel + " already exists";

        try {
            ArrayList<String> files = javaFiles(p);
            ArrayList<String> sameOldPkgClasses = new ArrayList<String>();
            for (int i = 0; i < files.size(); i++) {
                String f = files.get(i);
                if (!f.equals(srcRel) && expectedPackage(f).equals(oldPkg)) {
                    String n = f.substring(f.lastIndexOf('/') + 1);
                    sameOldPkgClasses.add(n.substring(0, n.length() - 5));
                }
            }

            // 1) the moved file itself
            String moved = read(p, srcRel);
            moved = setPackageDeclaration(moved, targetPkg);
            if (oldPkg.length() > 0) {
                String masked = Lint.blank(moved);
                for (int i = 0; i < sameOldPkgClasses.size(); i++) {
                    String other = sameOldPkgClasses.get(i);
                    if (uses(masked, other) && !hasImport(masked, oldPkg + "." + other)
                            && !hasWildcardImport(masked, oldPkg) && targetPkg.length() > 0) {
                        if (!hasWildcardImport(masked, oldPkg)) moved = addImport(moved, oldPkg + "." + other);
                    }
                }
            }

            // 2) every other file
            Pattern qualified = oldPkg.length() == 0 ? null
                    : Pattern.compile("(?<![\\w$.])" + Pattern.quote(oldPkg) + "\\." + Pattern.quote(cls) + "(?![\\w$])");
            String qualifiedRepl = Matcher.quoteReplacement(targetPkg.length() == 0 ? cls : targetPkg + "." + cls);
            ArrayList<String> editPaths = new ArrayList<String>();
            ArrayList<String> editTexts = new ArrayList<String>();
            for (int i = 0; i < files.size(); i++) {
                String f = files.get(i);
                if (f.equals(srcRel)) continue;
                String src = read(p, f);
                String out = src;
                if (qualified != null) out = qualified.matcher(out).replaceAll(qualifiedRepl);
                if (targetPkg.length() == 0) {
                    out = out.replaceAll("(?m)^[ \\t]*import[ \\t]+" + Pattern.quote(cls) + "[ \\t]*;[ \\t]*\\r?\\n?", "");
                }
                String filePkg = expectedPackage(f);
                String masked = Lint.blank(out);
                boolean needsImport = targetPkg.length() > 0 && !filePkg.equals(targetPkg) && uses(masked, cls)
                        && !hasImport(masked, targetPkg + "." + cls);
                if (needsImport) {
                    boolean sawItBefore = filePkg.equals(oldPkg) || hasWildcardImport(masked, oldPkg);
                    if (sawItBefore) out = addImport(out, targetPkg + "." + cls);
                }
                if (!out.equals(src)) { editPaths.add(f); editTexts.add(out); }
            }

            // 3) write everything, then move
            for (int i = 0; i < editPaths.size(); i++) write(p, editPaths.get(i), editTexts.get(i));
            write(p, newRel, moved);
            if (!new File(p.srcUrl() + srcRel).delete()) return "Could not remove the old copy of " + srcRel;
            if (cls.equals(p.mainClass) && p.packageName.equals(oldPkg)) {
                p.packageName = targetPkg;
                p.save();
            }
            return "";
        } catch (IOException e) {
            return "Move failed: " + e.getMessage();
        }
    }
}