package com.dashers.j2mebuilderide.ide;

import android.content.Context;

import java.io.InputStream;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Eclipse (ECJ) compiler messages, loaded from assets/ecj_messages.properties
 * (org/eclipse/jdt/internal/compiler/problem/messages.properties, EPL licence, header kept).
 *
 * The file maps a problem id to a text with {0} {1} ... placeholders, for example
 *   2  = {0} cannot be resolved to a type
 *   55 = Duplicate local variable {0}
 *
 * Java 1.4 additions: "'assert' should not be used as an identifier..." -> id 440, and the
 * existing "cannot assign X to Y" pattern (id 17) now also covers the long/float/double
 * narrowing and no-autoboxing failures, since CodeGen.checkAssignable reports all of
 * them with that same prefix. No new ids are introduced.
 *
 * The built-in compiler has its own wording, so translate() rewrites its messages into the
 * Eclipse wording whenever the matching Eclipse message and all of its arguments are known.
 * Anything it does not recognise is left untouched.
 */
public final class EcjMessages {

    private static Properties props;

    private EcjMessages() { }

    public static void init(Context c) {
        if (props != null) return;
        InputStream in = null;
        try {
            in = c.getAssets().open("ecj_messages.properties");
            Properties p = new Properties();
            p.load(in);
            props = p;
        } catch (Exception e) {
            props = null;
        } finally {
            if (in != null) try { in.close(); } catch (Exception ignore) { }
        }
    }

    public static boolean ready() { return props != null; }

    /** Message for an Eclipse problem id with its arguments filled in, or null. */
    public static String get(int id, String... args) {
        if (props == null) return null;
        String t = props.getProperty(String.valueOf(id));
        if (t == null) return null;
        t = t.replace("''", "'");
        for (int i = 0; i < args.length; i++) t = t.replace("{" + i + "}", args[i]);
        return t.trim();
    }

    private static final Pattern UNKNOWN_TYPE = Pattern.compile("^unknown type '([^']+)'.*", Pattern.DOTALL);
    private static final Pattern UNKNOWN_TARGET = Pattern.compile("^unknown (?:call|field access) target '([^']+)'.*", Pattern.DOTALL);
    private static final Pattern UNDEFINED_NAME = Pattern.compile("^undefined name '([^']+)'.*", Pattern.DOTALL);
    private static final Pattern DUP_VAR = Pattern.compile("^variable '([^']+)' already declared.*", Pattern.DOTALL);
    private static final Pattern DUP_PARAM = Pattern.compile("^duplicate parameter '([^']+)'.*", Pattern.DOTALL);
    private static final Pattern FINAL_VAR = Pattern.compile("^cannot assign a value to final variable '([^']+)'.*", Pattern.DOTALL);
    private static final Pattern STATIC_FIELD = Pattern.compile("^cannot access instance field '([^']+)' from a static method.*", Pattern.DOTALL);
    private static final Pattern INSTANTIATE = Pattern.compile("^cannot instantiate (?:abstract class|interface) (\\S+).*", Pattern.DOTALL);
    private static final Pattern ASSIGN = Pattern.compile("^cannot assign (\\S+) to (\\S+) \\('.*'\\).*", Pattern.DOTALL);
    private static final Pattern DUP_CASE = Pattern.compile("^duplicate case label .*", Pattern.DOTALL);
    private static final Pattern UNUSED_IMPORT = Pattern.compile("^unused import (.+)$");
    private static final Pattern DUP_IMPORT = Pattern.compile("^duplicate import (.+)$");

    private static String simple(String name) {
        int d = name.lastIndexOf('.');
        return d >= 0 ? name.substring(d + 1) : name;
    }

    private static String or(String original, String translated) {
        return translated != null ? translated : original;
    }

    /** Rewrites a built-in compiler / lint message into the Eclipse wording (or returns it as is). */
    public static String translate(String msg) {
        if (props == null || msg == null || msg.length() == 0) return msg;
        Matcher m;

        if ((m = UNKNOWN_TYPE.matcher(msg)).matches()) return or(msg, get(2, simple(m.group(1))));
        if ((m = UNKNOWN_TARGET.matcher(msg)).matches()) return or(msg, get(50, m.group(1)));
        if ((m = UNDEFINED_NAME.matcher(msg)).matches()) {
            String n = m.group(1);
            boolean type = Character.isUpperCase(n.charAt(0));
            return or(msg, type ? get(50, n) : get(83, n));
        }
        if ((m = DUP_VAR.matcher(msg)).matches()) return or(msg, get(55, m.group(1)));
        if ((m = DUP_PARAM.matcher(msg)).matches()) return or(msg, get(56, m.group(1)));
        if ((m = FINAL_VAR.matcher(msg)).matches()) return or(msg, get(58, m.group(1)));
        if ((m = STATIC_FIELD.matcher(msg)).matches()) return or(msg, get(74, m.group(1)));
        if ((m = INSTANTIATE.matcher(msg)).matches()) return or(msg, get(157, simple(m.group(1))));
        if ((m = ASSIGN.matcher(msg)).matches()) return or(msg, get(17, m.group(1), m.group(2)));
        if (DUP_CASE.matcher(msg).matches()) return or(msg, get(170));
        // Java 1.4 source level: 'assert' used as an identifier (Parser.assertAsIdentifier) -> ECJ id 440
        if (msg.startsWith("'assert' should not be used as an identifier")) return or(msg, get(440));
        if (msg.startsWith("'break' outside of a loop")) return or(msg, get(172));
        if (msg.startsWith("'continue' outside of a loop")) return or(msg, get(173));
        if (msg.startsWith("cannot return a value from a void method")) return or(msg, get(105));
        if (msg.startsWith("missing return value")) return or(msg, get(164));
        if ((m = UNUSED_IMPORT.matcher(msg)).matches()) return or(msg, get(388, m.group(1)));
        if ((m = DUP_IMPORT.matcher(msg)).matches()) return or(msg, get(386, m.group(1)));
        return msg;
    }
}
