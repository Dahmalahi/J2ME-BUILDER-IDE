package com.dashers.j2mebuilderide.ide;

/**
 * Builds the two descriptor files every real MIDP 2.0 suite needs:
 *
 *  - META-INF/MANIFEST.MF, packed inside the .jar itself
 *  - the .jad, shipped next to the .jar for OTA install (and required
 *    by most feature-phone installers even for on-device/USB installs)
 *
 * Field set and line format follow JSR-118 (MIDP 2.0) section 1.3 --
 * both files carry the same core attributes, but the .jad additionally
 * needs MIDlet-Jar-URL and MIDlet-Jar-Size, which aren't known until
 * after the jar bytes exist, so buildJad() takes the jar's byte length.
 * The .jad also carries the install-time-only attributes (MIDlet-Data-Size,
 * MIDlet-Install-Notify, MIDlet-Delete-Notify) that have no meaning to the
 * already-installed suite's own manifest.
 */
public class ManifestBuilder {

    public static String buildManifest(Project p, String iconEntry) {
        StringBuffer sb = new StringBuffer();
        sb.append("Manifest-Version: 1.0\r\n");
        sb.append("Created-By: J2ME BUILDER IDE BY DASH ANIMATION V2\r\n");
        sb.append("MIDlet-Name: ").append(p.displayName()).append("\r\n");
        sb.append("MIDlet-Version: ").append(p.version).append("\r\n");
        sb.append("MIDlet-Vendor: ").append(p.vendor).append("\r\n");
        appendOptionalMetadata(sb, p);
        sb.append("MIDlet-1: ").append(p.displayName()).append(", ")
          .append(iconEntry != null ? iconEntry : "").append(", ")
          .append(p.mainClass.length() > 0 && p.packageName.length() > 0 ? p.packageName + "." + p.mainClass : p.mainClass).append("\r\n");
        appendPermissions(sb, p);
        sb.append("MicroEdition-Profile: MIDP-2.0\r\n");
        sb.append("MicroEdition-Configuration: CLDC-1.1\r\n");
        // A MANIFEST.MF must end with a blank line per the jar spec.
        sb.append("\r\n");
        return sb.toString();
    }

    public static String buildJad(Project p, int jarSizeBytes, String iconEntry) {
        StringBuffer sb = new StringBuffer();
        sb.append("MIDlet-Name: ").append(p.displayName()).append("\r\n");
        sb.append("MIDlet-Version: ").append(p.version).append("\r\n");
        sb.append("MIDlet-Vendor: ").append(p.vendor).append("\r\n");
        appendOptionalMetadata(sb, p);
        sb.append("MIDlet-1: ").append(p.displayName()).append(", ")
          .append(iconEntry != null ? iconEntry : "").append(", ")
          .append(p.mainClass.length() > 0 && p.packageName.length() > 0 ? p.packageName + "." + p.mainClass : p.mainClass).append("\r\n");
        sb.append("MIDlet-Jar-URL: ").append(p.folderName).append(".jar\r\n");
        sb.append("MIDlet-Jar-Size: ").append(jarSizeBytes).append("\r\n");
        if (p.dataSize > 0) {
            sb.append("MIDlet-Data-Size: ").append(p.dataSize).append("\r\n");
        }
        appendPermissions(sb, p);
        if (p.installNotify != null && p.installNotify.length() > 0) {
            sb.append("MIDlet-Install-Notify: ").append(p.installNotify).append("\r\n");
        }
        if (p.deleteNotify != null && p.deleteNotify.length() > 0) {
            sb.append("MIDlet-Delete-Notify: ").append(p.deleteNotify).append("\r\n");
        }
        sb.append("MicroEdition-Profile: MIDP-2.0\r\n");
        sb.append("MicroEdition-Configuration: CLDC-1.1\r\n");
        return sb.toString();
    }

    private static void appendOptionalMetadata(StringBuffer sb, Project p) {
        if (p.description != null && p.description.length() > 0) {
            sb.append("MIDlet-Description: ").append(p.description).append("\r\n");
        }
        if (p.infoUrl != null && p.infoUrl.length() > 0) {
            sb.append("MIDlet-Info-URL: ").append(p.infoUrl).append("\r\n");
        }
        if (p.nokiaCategory != null && p.nokiaCategory.length() > 0) {
            sb.append("Nokia-MIDlet-Category: ").append(p.nokiaCategory).append("\r\n");
        }
        if (p.nokiaName != null && p.nokiaName.length() > 0) {
            sb.append("Nokia-MIDlet-Name: ").append(p.nokiaName).append("\r\n");
        }
        if (p.pushRegistration != null && p.pushRegistration.length() > 0) {
            sb.append("MIDlet-Push-1: ").append(p.pushRegistration).append("\r\n");
        }
    }

    /** MIDlet-Permissions/-Opt are shared verbatim between the jad and the
     *  manifest (a signed suite's runtime permission check matches them
     *  against each other, so keeping both build paths through one place
     *  avoids the two ever drifting apart). */
    private static void appendPermissions(StringBuffer sb, Project p) {
        if (p.permissions != null && p.permissions.length() > 0) {
            sb.append("MIDlet-Permissions: ").append(p.permissions).append("\r\n");
        }
        if (p.permissionsOpt != null && p.permissionsOpt.length() > 0) {
            sb.append("MIDlet-Permissions-Opt: ").append(p.permissionsOpt).append("\r\n");
        }
    }
}
