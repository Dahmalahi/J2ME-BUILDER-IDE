package com.dashers.j2mebuilderide.ide;

import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;

import java.util.Arrays;

/** Records the microphone to mono 16-bit PCM (needs the RECORD_AUDIO permission). */
public final class VoiceRecorder {
    private static final int MAX_SECONDS = 600;

    private final int rate;
    private AudioRecord rec;
    private Thread thread;
    private volatile boolean running;
    private volatile int peak;
    private short[] buf;
    private volatile int len;

    public VoiceRecorder(int rate) {
        this.rate = rate;
        this.buf = new short[rate * 15];
    }

    public int rate() { return rate; }

    /** Level of the last chunk, 0..32767. */
    public int peak() { return peak; }

    public float seconds() { return len / (float) rate; }

    public boolean isRecording() { return running; }

    /** Returns false when the microphone cannot be opened. */
    public boolean start() {
        try {
            int min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
            if (min <= 0) return false;
            rec = new AudioRecord(MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, min * 4);
            if (rec.getState() != AudioRecord.STATE_INITIALIZED) {
                rec.release();
                rec = null;
                return false;
            }
            rec.startRecording();
        } catch (Exception e) {
            if (rec != null) { try { rec.release(); } catch (Exception ignore) { } rec = null; }
            return false;
        }
        running = true;
        len = 0;
        thread = new Thread(new Runnable() {
            public void run() {
                short[] chunk = new short[1024];
                while (running) {
                    int n = rec.read(chunk, 0, chunk.length);
                    if (n <= 0) continue;
                    int pk = 0;
                    for (int i = 0; i < n; i++) pk = Math.max(pk, Math.abs((int) chunk[i]));
                    peak = pk;
                    if (len + n > buf.length) buf = Arrays.copyOf(buf, buf.length * 2);
                    System.arraycopy(chunk, 0, buf, len, n);
                    len += n;
                    if (len >= rate * MAX_SECONDS) running = false;
                }
            }
        });
        thread.start();
        return true;
    }

    /** Stop and return everything that was recorded. */
    public short[] stop() {
        running = false;
        if (thread != null) {
            try { thread.join(1000); } catch (InterruptedException ignore) { }
            thread = null;
        }
        if (rec != null) {
            try { rec.stop(); } catch (Exception ignore) { }
            try { rec.release(); } catch (Exception ignore) { }
            rec = null;
        }
        return Arrays.copyOf(buf, len);
    }
}
