package com.dashers.j2mebuilderide.ide;

import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.ShortBuffer;
import java.util.Arrays;

/** Decodes MP3 / AAC / OGG / FLAC / WAV ... files to mono 16-bit PCM using the phone's own codecs. */
public final class AudioDecoder {
    private AudioDecoder() { }

    public static AudioBuf.Clip decode(File f, String name, int maxSeconds) throws IOException {
        // plain WAV: read directly (also works where no decoder is installed)
        byte[] head = new byte[12];
        FileInputStream in = new FileInputStream(f);
        try {
            int n = in.read(head);
            if (n == 12 && head[0] == 'R' && head[1] == 'I' && head[2] == 'F' && head[3] == 'F' && f.length() < 64L * 1024 * 1024) {
                byte[] all = new byte[(int) f.length()];
                FileInputStream in2 = new FileInputStream(f);
                try {
                    int off = 0;
                    while (off < all.length) {
                        int k = in2.read(all, off, all.length - off);
                        if (k < 0) break;
                        off += k;
                    }
                } finally { in2.close(); }
                AudioBuf.Clip w = AudioBuf.readWav(all, name);
                if (w != null) return w;
            }
        } finally { in.close(); }

        MediaExtractor ex = new MediaExtractor();
        MediaCodec codec = null;
        try {
            ex.setDataSource(f.getAbsolutePath());
            int track = -1;
            MediaFormat fmt = null;
            for (int i = 0; i < ex.getTrackCount(); i++) {
                MediaFormat tf = ex.getTrackFormat(i);
                String mime = tf.getString(MediaFormat.KEY_MIME);
                if (mime != null && mime.startsWith("audio/")) { track = i; fmt = tf; break; }
            }
            if (track < 0) throw new IOException("No audio found in this file");
            ex.selectTrack(track);
            codec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME));
            codec.configure(fmt, null, null, 0);
            codec.start();
            int rate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE);
            int ch = Math.max(1, fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT));
            long maxSamples = (long) maxSeconds * rate;
            short[] out = new short[Math.max(16384, rate * 5)];
            int len = 0;
            boolean inDone = false, outDone = false;
            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            int idle = 0;
            while (!outDone) {
                if (!inDone) {
                    int ii = codec.dequeueInputBuffer(10000);
                    if (ii >= 0) {
                        ByteBuffer ib = codec.getInputBuffer(ii);
                        int n = ex.readSampleData(ib, 0);
                        if (n < 0) {
                            codec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                            inDone = true;
                        } else {
                            codec.queueInputBuffer(ii, 0, n, ex.getSampleTime(), 0);
                            ex.advance();
                        }
                    }
                }
                int oi = codec.dequeueOutputBuffer(info, 10000);
                if (oi >= 0) {
                    idle = 0;
                    if (info.size > 0) {
                        ByteBuffer ob = codec.getOutputBuffer(oi);
                        ob.position(info.offset);
                        ob.limit(info.offset + info.size);
                        ShortBuffer sb = ob.order(ByteOrder.nativeOrder()).asShortBuffer();
                        int frames = sb.remaining() / ch;
                        if (len + frames > out.length) out = Arrays.copyOf(out, Math.max(out.length * 2, len + frames));
                        for (int i = 0; i < frames; i++) {
                            int sum = 0;
                            for (int c = 0; c < ch; c++) sum += sb.get();
                            out[len++] = (short) (sum / ch);
                        }
                    }
                    codec.releaseOutputBuffer(oi, false);
                    if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0 || len >= maxSamples) outDone = true;
                } else if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    MediaFormat nf = codec.getOutputFormat();
                    if (nf.containsKey(MediaFormat.KEY_SAMPLE_RATE)) rate = nf.getInteger(MediaFormat.KEY_SAMPLE_RATE);
                    if (nf.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) ch = Math.max(1, nf.getInteger(MediaFormat.KEY_CHANNEL_COUNT));
                } else if (inDone && ++idle > 300) {
                    outDone = true;                 // decoder stopped answering
                }
            }
            if (len == 0) throw new IOException("Could not decode this file");
            return new AudioBuf.Clip(name, Arrays.copyOf(out, len), rate);
        } finally {
            if (codec != null) {
                try { codec.stop(); } catch (Exception ignore) { }
                try { codec.release(); } catch (Exception ignore) { }
            }
            ex.release();
        }
    }
}
