package com.dashers.j2mebuilderide.ide;

/** Small built-in synthesizer: renders a song to mono PCM (for WAV export and as a preview fallback) and makes short audition tones. */
public final class NoteSynth {
    private NoteSynth() { }

    public static final int RATE = 22050;
    private static final int MAX_SECONDS = 300;

    private static int seed = 12345;

    private static float noise() {
        seed ^= seed << 13;
        seed ^= seed >>> 17;
        seed ^= seed << 5;
        return (seed & 0xFFFF) / 32768f - 1f;
    }

    private static int wave(int program) {
        if (program < 16) return 1;                 // piano / mallets: triangle
        if (program >= 32 && program < 40) return 2; // basses: square
        if (program >= 56 && program < 80) return 3; // brass / reeds: saw
        if (program >= 80 && program < 88) return 3; // leads: saw
        if (program >= 24 && program < 32) return 1; // guitars
        return 0;                                    // strings / organ / pads: sine
    }

    private static boolean percussive(int program) {
        return program < 16 || (program >= 24 && program < 32) || program >= 104;
    }

    private static float osc(int kind, double ph) {
        double f = ph - Math.floor(ph);
        switch (kind) {
            case 1: return (float) (f < 0.5 ? 4 * f - 1 : 3 - 4 * f);
            case 2: return f < 0.5 ? 0.7f : -0.7f;
            case 3: return (float) (2 * f - 1) * 0.8f;
            default: return (float) (Math.sin(2 * Math.PI * f) + 0.25 * Math.sin(4 * Math.PI * f));
        }
    }

    private static void melodic(float[] mix, int from, int len, int pitch, float amp, int program) {
        double freq = 440.0 * Math.pow(2.0, (pitch - 69) / 12.0);
        int kind = wave(program);
        boolean perc = percussive(program);
        double ph = 0, inc = freq / RATE;
        int rel = RATE / 30;
        int total = len + rel;
        for (int i = 0; i < total; i++) {
            int idx = from + i;
            if (idx < 0 || idx >= mix.length) { if (idx >= mix.length) break; continue; }
            float env = i < 110 ? i / 110f : 1f;
            if (perc) env *= (float) Math.exp(-i / (RATE * 0.45));
            if (i >= len) env *= 1f - (i - len) / (float) rel;
            mix[idx] += osc(kind, ph) * env * amp;
            ph += inc;
        }
    }

    private static void drum(float[] mix, int from, int pitch, float amp) {
        int len;
        switch (pitch) {
            case 36: case 35: len = RATE / 3; break;
            case 38: case 40: case 39: len = RATE / 5; break;
            case 42: case 44: len = RATE / 20; break;
            case 46: len = RATE / 4; break;
            case 49: case 57: len = RATE; break;
            case 51: case 59: len = RATE / 2; break;
            default: len = RATE / 3; break;
        }
        double ph = 0;
        float hp = 0, prev = 0;
        for (int i = 0; i < len; i++) {
            int idx = from + i;
            if (idx >= mix.length) break;
            float t = i / (float) len, env = (float) Math.exp(-5.0 * t), v;
            switch (pitch) {
                case 36: case 35: {
                    double fr = 45 + 90 * Math.exp(-i / (RATE * 0.04));
                    ph += fr / RATE;
                    v = (float) Math.sin(2 * Math.PI * ph) * env * 1.4f;
                    break;
                }
                case 38: case 40: {
                    ph += 190.0 / RATE;
                    v = ((float) Math.sin(2 * Math.PI * ph) * 0.5f + noise() * 0.7f) * env;
                    break;
                }
                case 39: {
                    float burst = (i % (RATE / 90)) < 400 ? 1f : 0.35f;
                    v = noise() * env * burst;
                    break;
                }
                case 45: case 41: case 43: case 47: case 48: case 50: {
                    double fr = 85 + 80 * Math.exp(-i / (RATE * 0.06));
                    ph += fr / RATE;
                    v = (float) Math.sin(2 * Math.PI * ph) * env * 1.2f;
                    break;
                }
                default: {
                    float nz = noise();
                    hp = nz - prev;                           // crude high-pass
                    prev = nz;
                    v = hp * 0.6f * env;
                    break;
                }
            }
            mix[idx] += v * amp;
        }
    }

    /** Render all unmuted tracks. Silence of one second is added at the end. */
    public static short[] render(SeqModel.Project p) {
        double secPerTick = 60.0 / (Math.max(20, p.bpm) * (double) SeqModel.PPQ);
        int endTick = Math.max(p.endTick(), p.lengthTicks());
        double seconds = Math.min(MAX_SECONDS, endTick * secPerTick + 1.5);
        float[] mix = new float[(int) (seconds * RATE)];
        for (int ti = 0; ti < p.tracks.size(); ti++) {
            SeqModel.Track t = p.tracks.get(ti);
            if (t.mute) continue;
            for (int i = 0; i < t.notes.size(); i++) {
                SeqModel.Note n = t.notes.get(i);
                int from = (int) (n.start * secPerTick * RATE);
                if (from >= mix.length) continue;
                float amp = 0.22f * (n.vel / 127f) * (t.volume / 127f);
                if (t.drum) drum(mix, from, n.pitch, amp * 1.6f);
                else melodic(mix, from, Math.max(200, (int) (n.len * secPerTick * RATE)), n.pitch, amp, t.program);
            }
        }
        float peak = 0.0001f;
        for (int i = 0; i < mix.length; i++) peak = Math.max(peak, Math.abs(mix[i]));
        float g = peak > 0.9f ? 0.9f / peak : 1f;
        short[] out = new short[mix.length];
        for (int i = 0; i < out.length; i++) out[i] = (short) Math.round(Math.max(-1f, Math.min(1f, mix[i] * g)) * 32767f);
        return out;
    }

    /** A short sound to hear a note while editing. */
    public static short[] tone(int pitch, boolean drum, int program) {
        float[] mix = new float[drum ? RATE : RATE / 2];
        if (drum) drum(mix, 0, pitch, 0.5f);
        else melodic(mix, 0, RATE / 6, pitch, 0.3f, program);
        short[] out = new short[mix.length];
        for (int i = 0; i < out.length; i++) out[i] = (short) Math.round(Math.max(-1f, Math.min(1f, mix[i])) * 32767f);
        return out;
    }
}
