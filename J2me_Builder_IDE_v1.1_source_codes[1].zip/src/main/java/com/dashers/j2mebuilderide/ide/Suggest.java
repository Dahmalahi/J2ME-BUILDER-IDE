package com.dashers.j2mebuilderide.ide;

import com.dashers.j2mebuilderide.compiler.ApiIndex;

import java.util.HashSet;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Editor assistance driven by the same API index the compiler uses, so the
 * names offered here are exactly the ones that will resolve at build time:
 *
 *   - class names while typing (adds the missing import for you)
 *   - full class names inside an "import ..." line
 *   - fields / methods after a '.'
 *   - words already used in the file
 *   - one-tap "add import" fix for "unknown type 'Graphics'" style errors
 */
public final class Suggest {
    private Suggest() {}

    public static final class Item {
        public String label;
        public String insert;
        public int from, to;
        public String importFqcn;   // null when no import is needed
        public int caretBack;       // move the caret this many chars back after inserting
        public int kind;            // 0 class, 1 method, 2 field, 3 word, 4 import path, 5 closing bracket
    }

    /** Text change describing where an import line should be added. */
    public static final class Edit {
        public int offset;
        public String text;
    }

    private static final int MAX = 14;

    private static boolean isId(char c) {
        return Character.isJavaIdentifierPart(c);
    }

    /**
     * Closing-bracket suggestions: offers ) ] } for every ( [ { that is opened before the caret and is
     * never closed anywhere in the file. Comments, "strings" and 'c' chars are skipped. Items are the
     * innermost closer, then innermost two, then three ("close ) }" ...), kind 5, inserted AT the caret.
     * Empty when the brackets balance or the caret is in the middle of a word.
     */
    public static Vector closers(String text, int caret) {
        Vector out = new Vector();
        if (text == null || caret <= 0 || caret > text.length()) return out;
        int n = text.length();
        char[] stk = new char[64];
        int[] pos = new int[64];
        int sp = 0;
        int i = 0;
        while (i < n) {
            char c = text.charAt(i);
            if (c == '/' && i + 1 < n && text.charAt(i + 1) == '/') {
                int j = text.indexOf('\n', i);
                i = j < 0 ? n : j;
            } else if (c == '/' && i + 1 < n && text.charAt(i + 1) == '*') {
                int j = text.indexOf("*/", i + 2);
                i = j < 0 ? n : j + 2;
            } else if (c == '"' || c == '\'') {
                int j = i + 1;
                while (j < n) {
                    char d = text.charAt(j);
                    if (d == '\\') { j += 2; continue; }
                    if (d == c) { j++; break; }
                    if (d == '\n') break;
                    j++;
                }
                i = Math.min(j, n);
            } else {
                if (c == '(' || c == '[' || c == '{') {
                    if (sp == stk.length) {
                        char[] ns = new char[sp * 2]; System.arraycopy(stk, 0, ns, 0, sp); stk = ns;
                        int[] np = new int[sp * 2]; System.arraycopy(pos, 0, np, 0, sp); pos = np;
                    }
                    stk[sp] = c; pos[sp] = i; sp++;
                } else if ((c == ')' || c == ']' || c == '}') && sp > 0) {
                    char want = c == ')' ? '(' : (c == ']' ? '[' : '{');
                    if (stk[sp - 1] == want) sp--;
                }
                i++;
            }
        }
        if (sp == 0) return out;                       // balanced: nothing to suggest
        // the caret must not be inside a word, and the next char must not continue an expression
        if (caret < n) {
            char nx = text.charAt(caret);
            if (isId(nx) || nx == '(' || nx == '.') return out;
        }
        // innermost-first closers of the openers that sit before the caret
        StringBuffer seq = new StringBuffer();
        for (int k = sp - 1; k >= 0 && seq.length() < 3; k--) {
            if (pos[k] >= caret) continue;
            char o = stk[k];
            seq.append(o == '(' ? ')' : (o == '[' ? ']' : '}'));
            Item it = new Item();
            String s = seq.toString();
            StringBuffer lab = new StringBuffer("close");
            for (int q = 0; q < s.length(); q++) lab.append(' ').append(s.charAt(q));
            it.label = lab.toString();
            it.insert = s;
            it.from = caret;
            it.to = caret;
            it.caretBack = 0;
            it.kind = 5;
            out.addElement(it);
        }
        return out;
    }

    public static Vector suggest(String text, int caret, ApiIndex api) {
        Vector out = new Vector();
        if (text == null || api == null || caret <= 0 || caret > text.length()) return out;

        int s = caret;
        while (s > 0 && isId(text.charAt(s - 1))) s--;
        String prefix = text.substring(s, caret);

        int lineStart = text.lastIndexOf('\n', caret - 1) + 1;
        String lineHead = text.substring(lineStart, caret).trim();

        // ---------- inside an import line ----------
        if (lineHead.startsWith("import ") || lineHead.equals("import")) {
            int ps = caret;
            while (ps > lineStart && (isId(text.charAt(ps - 1)) || text.charAt(ps - 1) == '.')) ps--;
            String path = text.substring(ps, caret);
            if (path.length() < 2) return out;
            int to = caret;
            if (to < text.length() && text.charAt(to) == ';') to++;
            String low = path.toLowerCase();
            Vector all = api.classNames();
            for (int i = 0; i < all.size() && out.size() < MAX; i++) {
                String fq = (String) all.elementAt(i);
                String simple = fq.substring(fq.lastIndexOf('.') + 1);
                boolean hit = fq.toLowerCase().startsWith(low)
                        || (path.indexOf('.') < 0 && simple.toLowerCase().startsWith(low));
                if (!hit || fq.equals(path)) continue;
                Item it = new Item();
                it.label = simple;
                it.insert = fq + ";";
                it.from = ps;
                it.to = to;
                it.kind = 4;
                out.addElement(it);
            }
            return out;
        }

        // ---------- member access: receiver.xxx ----------
        if (s > 1 && text.charAt(s - 1) == '.') {
            int re = s - 1;
            int rs = re;
            while (rs > 0 && isId(text.charAt(rs - 1))) rs--;
            String receiver = text.substring(rs, re);
            if (receiver.length() == 0) return out;
            boolean staticCtx = Character.isUpperCase(receiver.charAt(0));
            String typeName = staticCtx ? receiver : declaredType(text, receiver, rs);
            if (typeName == null) return out;
            String fq = resolve(text, typeName, api);
            if (fq == null) return out;
            String low = prefix.toLowerCase();
            Vector members = api.members(fq);
            for (int pass = 0; pass < 2 && out.size() < MAX; pass++) {
                for (int i = 0; i < members.size() && out.size() < MAX; i++) {
                    ApiIndex.Member m = (ApiIndex.Member) members.elementAt(i);
                    if (staticCtx) {
                        if (!m.isStatic && m.method) continue;   // Class.xxx -> static methods (+ constants)
                    } else {
                        if (m.isStatic) continue;                // variable.xxx -> instance members
                    }
                    if ((pass == 0) != m.method) continue; // methods first, then fields
                    if (!m.name.toLowerCase().startsWith(low)) continue;
                    if (m.name.equals(prefix) && !m.method) continue;
                    Item it = new Item();
                    it.label = m.name + (m.method ? "()" : "");
                    it.insert = m.name + (m.method ? "()" : "");
                    it.from = s;
                    it.to = caret;
                    it.caretBack = (m.method && m.hasParams) ? 1 : 0;
                    it.kind = m.method ? 1 : 2;
                    out.addElement(it);
                }
            }
            return out;
        }

        if (prefix.length() < 2) return out;

        // ---------- class names (only when the prefix looks like a type) ----------
        if (Character.isUpperCase(prefix.charAt(0))) {
            HashSet imported = importedSimpleNames(text);
            Vector all = api.classNames();
            for (int i = 0; i < all.size() && out.size() < 8; i++) {
                String fq = (String) all.elementAt(i);
                String simple = fq.substring(fq.lastIndexOf('.') + 1);
                if (!simple.startsWith(prefix) || simple.equals(prefix)) continue;
                Item it = new Item();
                it.label = simple;
                it.insert = simple;
                it.from = s;
                it.to = caret;
                it.kind = 0;
                if (!fq.startsWith("java.lang.") && !imported.contains(simple) && !hasWildcard(text, fq)) {
                    it.importFqcn = fq;
                }
                out.addElement(it);
            }
        }

        // ---------- words already in the file ----------
        HashSet seen = new HashSet();
        for (int i = 0; i < out.size(); i++) seen.add(((Item) out.elementAt(i)).label);
        int n = text.length();
        int i = 0;
        int added = 0;
        while (i < n && out.size() < MAX && added < 6) {
            char c = text.charAt(i);
            if (Character.isJavaIdentifierStart(c)) {
                int j = i + 1;
                while (j < n && isId(text.charAt(j))) j++;
                if (i != s && j - i > prefix.length() && text.startsWith(prefix, i) && !seen.contains(text.substring(i, j))) {
                    String w = text.substring(i, j);
                    seen.add(w);
                    Item it = new Item();
                    it.label = w;
                    it.insert = w;
                    it.from = s;
                    it.to = caret;
                    it.kind = 3;
                    out.addElement(it);
                    added++;
                }
                i = j;
            } else {
                i++;
            }
        }
        return out;
    }

    // ------------------------------------------------------------------
    // helpers
    // ------------------------------------------------------------------

    /** Finds "Type name" declarations before `before` and returns Type (last one wins). */
    private static String declaredType(String text, String var, int before) {
        Pattern p = Pattern.compile("\\b([A-Z][A-Za-z0-9_]*)\\s*(?:\\[\\s*\\])?\\s+" + Pattern.quote(var) + "\\b\\s*[;=,)]");
        Matcher m = p.matcher(text);
        String found = null;
        int limit = Math.min(text.length(), Math.max(before, 0));
        while (m.find()) {
            if (m.start() > limit) break;
            found = m.group(1);
        }
        return found;
    }

    /** Simple type name -> fully qualified API name via imports, java.lang, then any match. */
    private static String resolve(String text, String simple, ApiIndex api) {
        Matcher m = Pattern.compile("import\\s+([\\w.]+\\." + Pattern.quote(simple) + ")\\s*;").matcher(text);
        if (m.find() && api.has(m.group(1))) return m.group(1);
        if (api.has("java.lang." + simple)) return "java.lang." + simple;
        if (api.has("java.util." + simple) && wildcardFor(text, "java.util")) return "java.util." + simple;
        Vector all = api.classNames();
        for (int i = 0; i < all.size(); i++) {
            String fq = (String) all.elementAt(i);
            if (fq.endsWith("." + simple) && wildcardFor(text, fq.substring(0, fq.lastIndexOf('.')))) return fq;
        }
        for (int i = 0; i < all.size(); i++) {
            String fq = (String) all.elementAt(i);
            if (fq.endsWith("." + simple)) return fq;
        }
        return null;
    }

    private static boolean wildcardFor(String text, String pkg) {
        return text.indexOf("import " + pkg + ".*;") >= 0;
    }

    private static boolean hasWildcard(String text, String fq) {
        return wildcardFor(text, fq.substring(0, fq.lastIndexOf('.')));
    }

    private static HashSet importedSimpleNames(String text) {
        HashSet set = new HashSet();
        Matcher m = Pattern.compile("import\\s+[\\w.]*\\.(\\w+)\\s*;").matcher(text);
        while (m.find()) set.add(m.group(1));
        return set;
    }

    /** Where to put "import fq;" -- or null if it is already imported. */
    public static Edit importEdit(String text, String fq) {
        if (text.indexOf("import " + fq + ";") >= 0) return null;
        String pkg = fq.substring(0, fq.lastIndexOf('.'));
        if (wildcardFor(text, pkg)) return null;

        Edit e = new Edit();
        int lastImportEnd = -1;
        Matcher m = Pattern.compile("(?m)^[ \\t]*import\\s+[^;\\n]*;[ \\t]*\\r?\\n?").matcher(text);
        while (m.find()) lastImportEnd = m.end();
        if (lastImportEnd >= 0) {
            e.offset = lastImportEnd;
            boolean needsNl = lastImportEnd > 0 && text.charAt(lastImportEnd - 1) != '\n';
            e.text = (needsNl ? "\n" : "") + "import " + fq + ";\n";
            return e;
        }
        Matcher pk = Pattern.compile("(?m)^[ \\t]*package\\s+[^;\\n]*;[ \\t]*\\r?\\n?").matcher(text);
        if (pk.find()) {
            e.offset = pk.end();
            e.text = "\nimport " + fq + ";\n";
        } else {
            e.offset = 0;
            e.text = "import " + fq + ";\n" + (text.startsWith("\n") ? "" : "\n");
        }
        return e;
    }

    /** Pulls 'Name' out of messages like "unknown type 'Graphics' -- is an 'import' ...". */
    public static String missingTypeFrom(String message) {
        if (message == null) return null;
        // Eclipse wording: "Graphics cannot be resolved [to a type]"
        java.util.regex.Matcher em = java.util.regex.Pattern.compile(
                "^([A-Za-z_$][A-Za-z0-9_$]*) cannot be resolved(?: to a type| to a variable)?$").matcher(message.trim());
        if (em.matches() && Character.isUpperCase(em.group(1).charAt(0))) return em.group(1);
        if (message.indexOf("unknown type '") < 0 && message.indexOf("undefined name '") < 0
                && message.indexOf("unknown call target '") < 0 && message.indexOf("unknown field access target '") < 0) {
            return null;
        }
        int a = message.indexOf('\'');
        if (a < 0) return null;
        int b = message.indexOf('\'', a + 1);
        if (b < 0) return null;
        String name = message.substring(a + 1, b);
        if (name.length() == 0 || !Character.isUpperCase(name.charAt(0))) return null;
        for (int i = 0; i < name.length(); i++) if (!isId(name.charAt(i))) return null;
        return name;
    }

    /** All API classes with this simple name (usually one). */
    public static Vector candidatesFor(String simple, ApiIndex api) {
        Vector out = new Vector();
        if (api == null || simple == null) return out;
        Vector all = api.classNames();
        for (int i = 0; i < all.size(); i++) {
            String fq = (String) all.elementAt(i);
            if (fq.endsWith("." + simple)) out.addElement(fq);
        }
        return out;
    }
}
