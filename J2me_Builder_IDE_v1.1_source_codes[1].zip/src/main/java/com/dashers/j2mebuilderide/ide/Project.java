package com.dashers.j2mebuilderide.ide;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * One JCompiler project: a folder containing src/, res/, bin/ and a flat
 * key=value project.properties file.
 *
 * This is the Android port of the original J2ME/MIDP Project.java. The only
 * real change is storage: the original used JSR-75 FileConnection with
 * "file:///E:/..." style URLs (since that's what MIDP feature phones use);
 * Android just uses plain java.io.File paths under the app's normal
 * storage (e.g. getFilesDir(), or a folder the user picked via Storage
 * Access Framework). Every path here is now a plain absolute path string,
 * not a "file:///" URL -- rootUrl is still named that for continuity with
 * the original codebase, but holds a normal path like
 * "/storage/emulated/0/JCompiler/projects/MyApp/".
 *
 * Layout under <projectsRoot>/<name>/ :
 *   project.properties   name / vendor / version / mainclass
 *   src/                 *.java sources (one or more top-level classes per file)
 *   res/                 resources bundled into the jar as-is, preserving
 *                        any subfolder structure (res/img/icon.png -> the
 *                        jar entry "img/icon.png")
 *   bin/                 compiled .class output (mirrors src/ by class name)
 *   <name>.jar            written by ProjectManager.packageProject()
 *   <name>.jad            written alongside it
 */
public class Project {

    public String folderName;   // directory name on disk (also the default MIDlet-Name)
    public String vendor = "DASH ANIMATION V2";
    /** Fixed default vendor used by newly created projects; editable in Project Settings. */
    public String version = "1.0.0";
    public String mainClass = "";  // simple class name, e.g. "HelloMIDlet"
    /** Java package for project sources. Empty means the default package. */
    public String packageName = "";

    /** MIDlet-Name shown on the phone. Blank = use the folder name. */
    public String midletName = "";

    /** 0 = none .. 9 = maximum. See ide/Obfuscator.java for what each level does. */
    public int obfuscation = 0;

    // ---- optional JAD/manifest metadata (all blank/zero = omit the
    // corresponding attribute, same "absent means don't emit" convention
    // ManifestBuilder already used for the pre-existing fields) ----

    /** res/-relative path to a PNG icon (e.g. "icon.png" or "img/icon.png")
     *  for the MIDlet-1 attribute's icon slot. If blank, packageProject()
     *  auto-detects a top-level "icon.png" in res/ when one exists. */
    public String icon = "";

    /** MIDlet-Data-Size: RMS storage (bytes) the suite expects to use.
     *  <= 0 omits the attribute. */
    public int dataSize = 0;

    /** MIDlet-Permissions: comma-separated list of required permissions,
     *  e.g. "javax.microedition.io.Connector.http". */
    public String permissions = "";

    /** MIDlet-Permissions-Opt: comma-separated list of optional permissions. */
    public String permissionsOpt = "";

    /** MIDlet-Install-Notify: URL the installer POSTs an install status
     *  report to. */
    public String installNotify = "";

    /** MIDlet-Delete-Notify: URL the installer POSTs a delete status
     *  report to. */
    public String deleteNotify = "";

    /** Optional standard descriptor metadata. */
    public String description = "";
    public String infoUrl = "";

    /** Optional Nokia/legacy vendor-specific metadata. */
    public String nokiaCategory = "Application";
    public String nokiaName = "";

    /** Optional MIDP push registration, e.g. protocol://:port,ClassName,* */
    public String pushRegistration = "";

    /** Absolute path to the project's root folder, always ending in "/".
     *  e.g. "/storage/emulated/0/JCompiler/projects/MyApp/". Named rootUrl
     *  (not rootPath) to keep this file diffable against the original
     *  J2ME Project.java -- it's a plain path on Android, not a URL. */
    public String rootUrl;

    public String srcUrl() { return rootUrl + "src/"; }
    public String resUrl() { return rootUrl + "res/"; }
    public String binUrl() { return rootUrl + "bin/"; }
    public String propsUrl() { return rootUrl + "project.properties"; }
    public String jarUrl() { return rootUrl + folderName + ".jar"; }
    public String jadUrl() { return rootUrl + folderName + ".jad"; }

    /** MIDlet-Name shown to the user; defaults to the folder name. */
    public String displayName() {
        return (midletName != null && midletName.length() > 0) ? midletName : folderName;
    }

    // ---------------- properties (de)serialization ----------------
    // Unchanged from the original -- this part has no J2ME/MIDP dependency
    // at all, it's plain String parsing.

    public String toPropertiesText() {
        StringBuffer sb = new StringBuffer();
        sb.append("vendor=").append(vendor).append('\n');
        sb.append("version=").append(version).append('\n');
        sb.append("mainclass=").append(mainClass).append('\n');
        sb.append("package=").append(packageName).append('\n');
        sb.append("midletname=").append(midletName).append('\n');
        sb.append("obfuscation=").append(obfuscation).append('\n');
        sb.append("icon=").append(icon).append('\n');
        sb.append("datasize=").append(dataSize).append('\n');
        sb.append("permissions=").append(permissions).append('\n');
        sb.append("permissionsopt=").append(permissionsOpt).append('\n');
        sb.append("installnotify=").append(installNotify).append('\n');
        sb.append("deletenotify=").append(deleteNotify).append('\n');
        sb.append("description=").append(description).append('\n');
        sb.append("infourl=").append(infoUrl).append('\n');
        sb.append("nokiacategory=").append(nokiaCategory).append('\n');
        sb.append("nokianame=").append(nokiaName).append('\n');
        sb.append("pushregistration=").append(pushRegistration).append('\n');
        return sb.toString();
    }

    public void loadFromPropertiesText(String text) {
        int pos = 0;
        int len = text.length();
        while (pos < len) {
            int nl = text.indexOf('\n', pos);
            String line = (nl < 0) ? text.substring(pos) : text.substring(pos, nl);
            applyLine(line.trim());
            if (nl < 0) break;
            pos = nl + 1;
        }
    }

    private void applyLine(String line) {
        if (line.length() == 0 || line.charAt(0) == '#') return;
        int eq = line.indexOf('=');
        if (eq < 0) return;
        String key = line.substring(0, eq).trim();
        String value = line.substring(eq + 1).trim();
        if (key.equals("vendor")) vendor = value;
        else if (key.equals("version")) version = value;
        else if (key.equals("mainclass")) mainClass = value;
        else if (key.equals("package")) packageName = value;
        else if (key.equals("midletname")) midletName = value;
        else if (key.equals("obfuscation")) {
            try {
                obfuscation = Math.max(0, Math.min(9, Integer.parseInt(value)));
            } catch (NumberFormatException nfe) {
                obfuscation = 0;
            }
        }
        else if (key.equals("icon")) icon = value;
        else if (key.equals("datasize")) {
            try {
                dataSize = Integer.parseInt(value);
            } catch (NumberFormatException nfe) {
                dataSize = 0; // malformed value -- treat as "not set" rather than failing the load
            }
        }
        else if (key.equals("permissions")) permissions = value;
        else if (key.equals("permissionsopt")) permissionsOpt = value;
        else if (key.equals("installnotify")) installNotify = value;
        else if (key.equals("deletenotify")) deleteNotify = value;
        else if (key.equals("description")) description = value;
        else if (key.equals("infourl")) infoUrl = value;
        else if (key.equals("nokiacategory")) nokiaCategory = value;
        else if (key.equals("nokianame")) nokiaName = value;
        else if (key.equals("pushregistration")) pushRegistration = value;
        // unknown keys are ignored, not dropped from round-tripping being
        // required -- this file is small enough that losing a stray
        // custom key on save is an acceptable tradeoff for keeping the
        // parser this simple on-device.
    }

    // ---------------- disk I/O ----------------
    // Ported from JSR-75 FileConnection to plain java.io.File. Same method
    // names/signatures as the original (readWholeFile/writeWholeFile take
    // and return a path string, not a File), so ProjectManager's calls
    // into these don't need to change at all.

    public void save() throws IOException {
        writeWholeFile(propsUrl(), toPropertiesText().getBytes("UTF-8"));
    }

    public void load() throws IOException {
        byte[] data = readWholeFile(propsUrl());
        if (data != null) loadFromPropertiesText(new String(data, "UTF-8"));
    }

    /** Returns null if the file doesn't exist (matches the original
     *  FileConnection-based behavior, where callers check for null rather
     *  than catching a not-found exception). */
    public static byte[] readWholeFile(String path) throws IOException {
        File f = new File(path);
        if (!f.exists()) return null;
        InputStream in = new FileInputStream(f);
        try {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
            return bos.toByteArray();
        } finally {
            in.close();
        }
    }

    /** Overwrites the file at `path` with `data`, creating parent
     *  directories if needed (java.io.File.createNewFile() -- unlike JSR-75
     *  FileConnection.create() -- does NOT create missing parent
     *  directories on its own, so this does that explicitly first). */
    public static void writeWholeFile(String path, byte[] data) throws IOException {
        File f = new File(path);
        File parent = f.getParentFile();
        if (parent != null && !parent.exists()) {
            if (!parent.mkdirs() && !parent.exists()) {
                throw new IOException("Could not create parent directory: " + parent.getPath());
            }
        }
        OutputStream out = new FileOutputStream(f); // truncates/overwrites if it already exists
        try {
            out.write(data);
        } finally {
            out.close();
        }
    }
}
