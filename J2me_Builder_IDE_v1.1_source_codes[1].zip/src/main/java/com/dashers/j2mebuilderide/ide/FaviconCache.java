package com.dashers.j2mebuilderide.ide;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Link icons for the About screen. An icon is downloaded once (only while the device is online),
 * saved as a PNG in the app's private storage and reused from disk afterwards.
 */
public final class FaviconCache {
    private FaviconCache() {}

    public static String host(String url) {
        try { return new URL(url).getHost(); } catch (Exception e) { return ""; }
    }

    private static File dir(Context c) {
        File d = new File(c.getFilesDir(), "favicons");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    private static File fileFor(Context c, String url) {
        String h = host(url).replaceAll("[^A-Za-z0-9.-]", "_");
        return new File(dir(c), h + ".png");
    }

    /** The saved icon, or null when it has not been downloaded yet. */
    public static Bitmap cached(Context c, String url) {
        try {
            File f = fileFor(c, url);
            if (f.isFile() && f.length() > 0) return BitmapFactory.decodeFile(f.getPath());
        } catch (Throwable t) { }
        return null;
    }

    public static boolean isOnline(Context c) {
        try {
            ConnectivityManager cm = (ConnectivityManager) c.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) return false;
            NetworkInfo ni = cm.getActiveNetworkInfo();
            return ni != null && ni.isConnected();
        } catch (Throwable t) { return false; }
    }

    /** Downloads and stores the icon (call from a worker thread). Returns it, or null on failure. */
    public static Bitmap download(Context c, String url) {
        String h = host(url);
        if (h.length() == 0) return null;
        String[] sources = {
            "https://www.google.com/s2/favicons?sz=64&domain=" + h,
            "https://" + h + "/favicon.ico"
        };
        for (int i = 0; i < sources.length; i++) {
            try {
                byte[] raw = fetch(sources[i]);
                if (raw == null || raw.length == 0) continue;
                Bitmap bm = BitmapFactory.decodeByteArray(raw, 0, raw.length);
                if (bm == null) continue;
                FileOutputStream out = new FileOutputStream(fileFor(c, url));
                try { bm.compress(Bitmap.CompressFormat.PNG, 100, out); } finally { out.close(); }
                return bm;
            } catch (Throwable t) { }
        }
        return null;
    }

    private static byte[] fetch(String u) throws Exception {
        HttpURLConnection con = (HttpURLConnection) new URL(u).openConnection();
        con.setConnectTimeout(8000);
        con.setReadTimeout(8000);
        con.setInstanceFollowRedirects(true);
        con.setRequestProperty("User-Agent", "J2MEBuilderIDE");
        try {
            if (con.getResponseCode() != 200) return null;
            InputStream in = con.getInputStream();
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int r, total = 0;
            while ((r = in.read(buf)) > 0) {
                bos.write(buf, 0, r);
                total += r;
                if (total > 512 * 1024) return null;
            }
            in.close();
            return bos.toByteArray();
        } finally {
            con.disconnect();
        }
    }
}
