package com.dashers.j2mebuilderide.ide;

/**
 * Best-effort filename-extension -> MIME type lookup for resources bundled
 * into a MIDlet suite jar. CLDC 1.1 ships no file-type sniffing API (no
 * java.net.URLConnection#guessContentTypeFromStream, no javax.activation),
 * so this is a small hand-rolled extension table rather than real content
 * inspection.
 *
 * The main present-day use is validating a MIDlet-Icon candidate: JSR-118
 * (MIDP 2.0) section 1.3 requires the MIDlet-1 icon to be a PNG image, so
 * ProjectManager checks isPng() before wiring an auto-detected or
 * explicitly-configured icon into the jar/jad. The general guess() table
 * is kept public too since it's cheap and other resource-aware code (a
 * future resource browser in the IDE, for instance) can reuse it.
 */
public class MimeTypes {

    public static String guess(String filename) {
        String lower = filename.toLowerCase();
        int dot = lower.lastIndexOf('.');
        String ext = (dot >= 0) ? lower.substring(dot + 1) : "";
        if (ext.equals("png")) return "image/png";
        if (ext.equals("gif")) return "image/gif";
        if (ext.equals("jpg") || ext.equals("jpeg")) return "image/jpeg";
        if (ext.equals("txt")) return "text/plain";
        if (ext.equals("xml")) return "application/xml";
        if (ext.equals("properties")) return "text/x-java-properties";
        if (ext.equals("class")) return "application/java-vm";
        if (ext.equals("jar")) return "application/java-archive";
        if (ext.equals("wav")) return "audio/x-wav";
        if (ext.equals("mid") || ext.equals("midi")) return "audio/midi";
        if (ext.equals("amr")) return "audio/amr";
        if (ext.equals("3gp") || ext.equals("3gpp")) return "video/3gpp";
        return "application/octet-stream";
    }

    /** Whether `filename`'s guessed type is PNG -- the only image format
     *  JSR-118 permits for a MIDlet-1 icon. */
    public static boolean isPng(String filename) {
        return guess(filename).equals("image/png");
    }
}
