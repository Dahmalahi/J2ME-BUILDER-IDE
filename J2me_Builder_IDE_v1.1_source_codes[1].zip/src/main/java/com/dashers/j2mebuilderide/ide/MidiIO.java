package com.dashers.j2mebuilderide.ide;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/** Standard MIDI File (format 1) writer and reader for {@link SeqModel.Project}. */
public final class MidiIO {
    private MidiIO() { }

    private static final class Ev {
        final int tick, order;
        final byte[] data;
        Ev(int tick, int order, byte[] data) { this.tick = tick; this.order = order; this.data = data; }
    }

    // ------------------------------------------------------------------ write

    private static void vlq(ByteArrayOutputStream o, int v) {
        int buf = v & 0x7F;
        while ((v >>= 7) > 0) { buf <<= 8; buf |= ((v & 0x7F) | 0x80); }
        while (true) {
            o.write(buf & 0xFF);
            if ((buf & 0x80) != 0) buf >>>= 8; else break;
        }
    }

    private static void i32(ByteArrayOutputStream o, int v) {
        o.write(v >>> 24); o.write(v >>> 16); o.write(v >>> 8); o.write(v);
    }

    private static void i16(ByteArrayOutputStream o, int v) { o.write(v >>> 8); o.write(v); }

    private static void chunk(ByteArrayOutputStream out, String id, byte[] body) {
        for (int i = 0; i < 4; i++) out.write(id.charAt(i));
        i32(out, body.length);
        out.write(body, 0, body.length);
    }

    private static byte[] ev3(int a, int b, int c) { return new byte[]{(byte) a, (byte) b, (byte) c}; }

    /** Muted tracks are skipped. */
    public static byte[] write(SeqModel.Project p) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        ArrayList<byte[]> tracks = new ArrayList<byte[]>();

        ByteArrayOutputStream t0 = new ByteArrayOutputStream();
        vlq(t0, 0);
        int tempo = 60000000 / Math.max(20, Math.min(300, p.bpm));
        t0.write(0xFF); t0.write(0x51); t0.write(3); t0.write(tempo >>> 16); t0.write(tempo >>> 8); t0.write(tempo);
        vlq(t0, 0);
        t0.write(0xFF); t0.write(0x58); t0.write(4); t0.write(4); t0.write(2); t0.write(24); t0.write(8);
        vlq(t0, 0);
        t0.write(0xFF); t0.write(0x2F); t0.write(0);
        tracks.add(t0.toByteArray());

        int melodicIndex = 0;
        for (int ti = 0; ti < p.tracks.size(); ti++) {
            SeqModel.Track t = p.tracks.get(ti);
            int ch;
            if (t.drum) {
                ch = 9;
            } else {
                ch = melodicIndex % 15;
                if (ch >= 9) ch++;
                melodicIndex++;
            }
            if (t.mute) continue;
            ArrayList<Ev> evs = new ArrayList<Ev>();
            if (!t.drum) evs.add(new Ev(0, 0, new byte[]{(byte) (0xC0 | ch), (byte) (t.program & 127)}));
            evs.add(new Ev(0, 0, ev3(0xB0 | ch, 7, Math.max(0, Math.min(127, t.volume)))));
            for (int i = 0; i < t.notes.size(); i++) {
                SeqModel.Note n = t.notes.get(i);
                int pitch = Math.max(0, Math.min(127, n.pitch)), vel = Math.max(1, Math.min(127, n.vel));
                int len = Math.max(1, n.len);
                evs.add(new Ev(n.start, 2, ev3(0x90 | ch, pitch, vel)));
                evs.add(new Ev(n.start + len, 1, ev3(0x80 | ch, pitch, 0)));
            }
            Collections.sort(evs, new Comparator<Ev>() {
                public int compare(Ev a, Ev b) { return a.tick != b.tick ? (a.tick < b.tick ? -1 : 1) : a.order - b.order; }
            });
            ByteArrayOutputStream tb = new ByteArrayOutputStream();
            String name = t.name == null ? "Track" : t.name;
            byte[] nm = name.getBytes("UTF-8");
            vlq(tb, 0);
            tb.write(0xFF); tb.write(0x03); vlq(tb, nm.length); tb.write(nm, 0, nm.length);
            int last = 0;
            for (int i = 0; i < evs.size(); i++) {
                Ev e = evs.get(i);
                vlq(tb, e.tick - last);
                last = e.tick;
                tb.write(e.data, 0, e.data.length);
            }
            vlq(tb, 0);
            tb.write(0xFF); tb.write(0x2F); tb.write(0);
            tracks.add(tb.toByteArray());
        }

        ByteArrayOutputStream head = new ByteArrayOutputStream();
        i16(head, 1);
        i16(head, tracks.size());
        i16(head, SeqModel.PPQ);
        chunk(out, "MThd", head.toByteArray());
        for (int i = 0; i < tracks.size(); i++) chunk(out, "MTrk", tracks.get(i));
        return out.toByteArray();
    }

    // ------------------------------------------------------------------ read

    private static final class Rd {
        final byte[] d;
        int p;
        Rd(byte[] d, int p) { this.d = d; this.p = p; }
        int u8() throws IOException { if (p >= d.length) throw new IOException("Unexpected end of MIDI file"); return d[p++] & 0xFF; }
        int u16() throws IOException { return (u8() << 8) | u8(); }
        int i32() throws IOException { return (u8() << 24) | (u8() << 16) | (u8() << 8) | u8(); }
        int vlq() throws IOException {
            int v = 0;
            for (int i = 0; i < 4; i++) {
                int b = u8();
                v = (v << 7) | (b & 0x7F);
                if ((b & 0x80) == 0) break;
            }
            return v;
        }
    }

    /** Parse a .mid file into a song (one track per MIDI track and channel). Throws IOException when unreadable. */
    public static SeqModel.Project read(byte[] data) throws IOException {
        if (data == null || data.length < 14 || data[0] != 'M' || data[1] != 'T' || data[2] != 'h' || data[3] != 'd') {
            throw new IOException("Not a MIDI file");
        }
        Rd r = new Rd(data, 4);
        int hl = r.i32();
        r.u16();                                  // format
        int ntrk = r.u16();
        int div = r.u16();
        if ((div & 0x8000) != 0 || div == 0) throw new IOException("SMPTE time MIDI files are not supported");
        r.p = 8 + hl;

        SeqModel.Project proj = new SeqModel.Project();
        int tempo = 0, total = 0;
        final int maxNotes = 20000;
        int[] program = new int[16];
        for (int tn = 0; tn < ntrk && r.p + 8 <= data.length; tn++) {
            boolean isTrk = data[r.p] == 'M' && data[r.p + 1] == 'T' && data[r.p + 2] == 'r' && data[r.p + 3] == 'k';
            r.p += 4;
            int len = r.i32();
            int end = Math.min(data.length, r.p + Math.max(0, len));
            if (!isTrk) { r.p = end; continue; }
            SeqModel.Track[] byCh = new SeqModel.Track[16];
            int[][] startTick = new int[16][128];
            int[][] startVel = new int[16][128];
            for (int c = 0; c < 16; c++) java.util.Arrays.fill(startTick[c], -1);
            String tname = null;
            long tick = 0;
            int running = 0;
            try {
                while (r.p < end) {
                    tick += r.vlq();
                    int st = r.u8();
                    if (st < 0x80) { r.p--; st = running; if (st == 0) break; }
                    if (st == 0xFF) {
                        int type = r.u8(), ml = r.vlq();
                        if (type == 0x51 && ml == 3 && tempo == 0) {
                            tempo = (r.u8() << 16) | (r.u8() << 8) | r.u8();
                        } else if (type == 0x03 && tname == null) {
                            byte[] b = new byte[Math.max(0, Math.min(ml, end - r.p))];
                            System.arraycopy(data, r.p, b, 0, b.length);
                            tname = new String(b, "UTF-8").trim();
                            r.p += ml;
                        } else if (type == 0x2F) {
                            r.p = end;
                        } else {
                            r.p += ml;
                        }
                        continue;
                    }
                    if (st == 0xF0 || st == 0xF7) { r.p += r.vlq(); continue; }
                    running = st;
                    int ch = st & 15, kind = st & 0xF0;
                    int t480 = (int) (tick * SeqModel.PPQ / div);
                    if (kind == 0xC0) { program[ch] = r.u8(); continue; }
                    if (kind == 0xD0) { r.u8(); continue; }
                    int a = r.u8(), b = r.u8();
                    if (kind == 0x90 && b > 0) {
                        if (startTick[ch][a] < 0) { startTick[ch][a] = t480; startVel[ch][a] = b; }
                    } else if (kind == 0x80 || kind == 0x90) {
                        if (startTick[ch][a] >= 0 && total < maxNotes) {
                            if (byCh[ch] == null) {
                                boolean drum = ch == 9;
                                String nm = tname != null && tname.length() > 0 ? tname : (drum ? "Drums" : "Channel " + (ch + 1));
                                byCh[ch] = proj.addTrack(nm, program[ch], drum);
                            }
                            int pitch = ch == 9 ? SeqModel.mapDrum(a) : a;
                            int s = startTick[ch][a];
                            byCh[ch].notes.add(new SeqModel.Note(pitch, s, Math.max(1, t480 - s), startVel[ch][a]));
                            total++;
                        }
                        startTick[ch][a] = -1;
                    }
                }
            } catch (IOException cut) {
                // a damaged track: keep what was read so far
            }
            r.p = end;
            for (int c = 0; c < 16; c++) if (byCh[c] != null) byCh[c].program = program[c];
        }
        if (tempo > 0) proj.bpm = Math.max(20, Math.min(300, Math.round(60000000f / tempo)));
        // a drum row holds one hit per time
        for (int i = 0; i < proj.tracks.size(); i++) {
            SeqModel.Track t = proj.tracks.get(i);
            if (!t.drum) continue;
            ArrayList<SeqModel.Note> keep = new ArrayList<SeqModel.Note>();
            for (int j = 0; j < t.notes.size(); j++) {
                SeqModel.Note n = t.notes.get(j);
                boolean dup = false;
                for (int k = keep.size() - 1; k >= 0 && k >= keep.size() - 40; k--) {
                    if (keep.get(k).pitch == n.pitch && keep.get(k).start == n.start) { dup = true; break; }
                }
                if (!dup) keep.add(n);
            }
            t.notes.clear();
            t.notes.addAll(keep);
        }
        if (proj.tracks.isEmpty()) throw new IOException("No notes found in this MIDI file");
        proj.bars = 1;
        proj.fitBars();
        if (proj.bars < 2) proj.bars = 2;
        return proj;
    }
}
