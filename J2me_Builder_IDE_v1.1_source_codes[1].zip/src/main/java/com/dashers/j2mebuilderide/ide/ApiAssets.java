package com.dashers.j2mebuilderide.ide;

import android.content.Context;
import android.content.res.AssetManager;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

import com.dashers.j2mebuilderide.compiler.ApiIndex;

/**
 * Loads the bundled J2ME SDK API (CLDC/MIDP/JSR classes) for compilation.
 * Source order: assets/j2me-sdk-api.jar, then the decompressed copy in
 * assets/j2me/api/ (same .class files, unpacked). Works with or without ECJ:
 * ECJ gets the API as a jar image, the built-in compiler gets any class its
 * api_index_core.txt does not already describe.
 */
public final class ApiAssets {
    public static final String JAR = "j2me-sdk-api.jar";
    public static final String DIR = "j2me/api";

    private ApiAssets() {}

    /** The API as zip bytes (jar if present, else repacked from the decompressed folder); null if neither exists. */
    public static byte[] loadZipBytes(Context ctx) {
        AssetManager am = ctx.getAssets();
        try {
            InputStream in = am.open(JAR);
            try { return readAll(in); } finally { in.close(); }
        } catch (IOException noJar) {
            // fall through to the decompressed folder
        }
        try {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            ZipOutputStream zos = new ZipOutputStream(bos);
            int n = packDir(am, DIR, zos);
            zos.close();
            return n > 0 ? bos.toByteArray() : null;
        } catch (IOException e) {
            return null;
        }
    }

    private static int packDir(AssetManager am, String dir, ZipOutputStream zos) throws IOException {
        String[] kids = am.list(dir);
        if (kids == null) return 0;
        int count = 0;
        for (int i = 0; i < kids.length; i++) {
            String path = dir + "/" + kids[i];
            if (kids[i].endsWith(".class")) {
                InputStream in = am.open(path);
                try {
                    zos.putNextEntry(new ZipEntry(path.substring(DIR.length() + 1)));
                    zos.write(readAll(in));
                    zos.closeEntry();
                    count++;
                } finally { in.close(); }
            } else {
                count += packDir(am, path, zos);
            }
        }
        return count;
    }

    /** Real J2ME API jars (CLDC 1.1, MIDP 2.0 and the optional JSRs) kept as separate files in assets/j2me/jars/. */
    public static final String JARS_DIR = "j2me/jars";
    private static final String[] PREVERIFY_JARS = {
        "cldcapi11.jar", "midpapi20.jar", "mmapi.jar", "jsr75.jar", "jsr184.jar", "jsr226.jar", "jsr234.jar", "jsr238.jar", "jsr239.jar"
    };
    private static byte[] preverifyCache;

    /**
     * The classes the preverifier resolves super classes against (like ProGuard's -libraryjars): the real
     * cldcapi11 + midpapi20 jars first, then the JSR jars. One merged zip; the first copy of a class wins.
     * Returns null when cldcapi11.jar / midpapi20.jar are not in the assets (callers then use loadZipBytes).
     */
    public static synchronized byte[] loadPreverifyZipBytes(Context ctx) {
        if (preverifyCache != null) return preverifyCache;
        AssetManager am = ctx.getAssets();
        java.util.HashSet seen = new java.util.HashSet();
        try {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            ZipOutputStream zos = new ZipOutputStream(bos);
            int have = 0;
            for (int i = 0; i < PREVERIFY_JARS.length; i++) {
                byte[] jar;
                try {
                    InputStream in = am.open(JARS_DIR + "/" + PREVERIFY_JARS[i]);
                    try { jar = readAll(in); } finally { in.close(); }
                } catch (IOException missing) {
                    continue;
                }
                have++;
                ZipInputStream zin = new ZipInputStream(new ByteArrayInputStream(jar));
                try {
                    ZipEntry e;
                    while ((e = zin.getNextEntry()) != null) {
                        String n = e.getName();
                        if (e.isDirectory() || !n.endsWith(".class") || !seen.add(n)) continue;
                        zos.putNextEntry(new ZipEntry(n));
                        zos.write(readAll(zin));
                        zos.closeEntry();
                    }
                } finally { zin.close(); }
            }
            zos.close();
            if (have < 2 || !seen.contains("java/lang/Object.class") || !seen.contains("javax/microedition/midlet/MIDlet.class")) return null;
            preverifyCache = bos.toByteArray();
            return preverifyCache;
        } catch (IOException e) {
            return null;
        }
    }

    /** Adds every API class missing from the built-in index. Returns how many were added. */
    public static int fillIndex(ApiIndex idx, byte[] zipBytes) {
        if (idx == null || zipBytes == null) return 0;
        int added = 0;
        try {
            ZipInputStream zin = new ZipInputStream(new ByteArrayInputStream(zipBytes));
            try {
                ZipEntry e;
                while ((e = zin.getNextEntry()) != null) {
                    if (e.isDirectory() || !e.getName().endsWith(".class")) continue;
                    if (idx.addBuiltinIfAbsent(readAll(zin))) added++;
                }
            } finally { zin.close(); }
        } catch (IOException ignore) { }
        return added;
    }

    private static byte[] readAll(InputStream in) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] b = new byte[8192];
        int n;
        while ((n = in.read(b)) != -1) out.write(b, 0, n);
        return out.toByteArray();
    }
}
