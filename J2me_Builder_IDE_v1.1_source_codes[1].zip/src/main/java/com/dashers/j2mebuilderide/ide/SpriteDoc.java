package com.dashers.j2mebuilderide.ide;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * Pixel-art document for the Sprite Editor: ARGB pixels (not premultiplied), undo / redo and the editing
 * operations. Plain Java - no Android classes. Operations named flip / rotate / resize / clear / replace /
 * invert / grayscale / outline record an undo step themselves; the drawing primitives (plot, line, rect,
 * ellipse, fill) do not - the caller calls {@link #push()} once before a stroke.
 */
public final class SpriteDoc {
    public int w, h;
    public int[] px;
    public boolean dirty;
    /** Sprite-sheet frame size (0 = no frame grid). */
    public int frameW, frameH;

    private static final int MAX_STEPS = 60;
    private static final long MAX_UNDO_INTS = 8000000L;

    private static final class Snap {
        final int w, h;
        final int[] px;
        Snap(int w, int h, int[] px) { this.w = w; this.h = h; this.px = px; }
    }

    private final ArrayList<Snap> undo = new ArrayList<Snap>();
    private final ArrayList<Snap> redo = new ArrayList<Snap>();

    public SpriteDoc(int w, int h) {
        this.w = Math.max(1, w);
        this.h = Math.max(1, h);
        this.px = new int[this.w * this.h];
    }

    public static SpriteDoc of(int w, int h, int[] pixels) {
        SpriteDoc d = new SpriteDoc(w, h);
        System.arraycopy(pixels, 0, d.px, 0, Math.min(pixels.length, d.px.length));
        return d;
    }

    // ---- pixels ----

    public boolean in(int x, int y) { return x >= 0 && y >= 0 && x < w && y < h; }

    public int get(int x, int y) { return in(x, y) ? px[y * w + x] : 0; }

    public void set(int x, int y, int c) { if (in(x, y)) px[y * w + x] = c; }

    private static boolean same(int a, int b) {
        return a == b || ((a >>> 24) == 0 && (b >>> 24) == 0);
    }

    // ---- history ----

    /** Remember the current pixels as an undo step (call once before changing them). */
    public void push() {
        undo.add(new Snap(w, h, px.clone()));
        redo.clear();
        dirty = true;
        long total = 0;
        for (int i = 0; i < undo.size(); i++) total += undo.get(i).px.length;
        while (undo.size() > MAX_STEPS || (total > MAX_UNDO_INTS && undo.size() > 1)) {
            total -= undo.remove(0).px.length;
        }
    }

    public boolean canUndo() { return !undo.isEmpty(); }

    public boolean canRedo() { return !redo.isEmpty(); }

    public boolean undo() {
        if (undo.isEmpty()) return false;
        redo.add(new Snap(w, h, px.clone()));
        adopt(undo.remove(undo.size() - 1));
        return true;
    }

    public boolean redo() {
        if (redo.isEmpty()) return false;
        undo.add(new Snap(w, h, px.clone()));
        adopt(redo.remove(redo.size() - 1));
        return true;
    }

    /** Throw the last undo step away while restoring it (a cancelled gesture). */
    public void cancelLast() {
        if (undo.isEmpty()) return;
        adopt(undo.remove(undo.size() - 1));
    }

    private void adopt(Snap s) {
        w = s.w;
        h = s.h;
        px = s.px;
        dirty = true;
    }

    // ---- drawing primitives (no undo step) ----

    /** Square brush of the given size centred on x,y. */
    public void plot(int x, int y, int c, int brush) {
        if (brush <= 1) { set(x, y, c); return; }
        int o = brush / 2;
        for (int dy = 0; dy < brush; dy++) for (int dx = 0; dx < brush; dx++) set(x - o + dx, y - o + dy, c);
    }

    public void line(int x0, int y0, int x1, int y1, int c, int brush) {
        int dx = Math.abs(x1 - x0), dy = -Math.abs(y1 - y0);
        int sx = x0 < x1 ? 1 : -1, sy = y0 < y1 ? 1 : -1;
        int err = dx + dy;
        int guard = (w + h) * 4 + 16;
        while (guard-- > 0) {
            plot(x0, y0, c, brush);
            if (x0 == x1 && y0 == y1) break;
            int e2 = 2 * err;
            if (e2 >= dy) { err += dy; x0 += sx; }
            if (e2 <= dx) { err += dx; y0 += sy; }
        }
    }

    public void rect(int x0, int y0, int x1, int y1, int c, boolean filled, int brush) {
        int l = Math.min(x0, x1), r = Math.max(x0, x1), t = Math.min(y0, y1), b = Math.max(y0, y1);
        if (filled) {
            for (int y = t; y <= b; y++) for (int x = l; x <= r; x++) set(x, y, c);
            return;
        }
        line(l, t, r, t, c, brush);
        line(l, b, r, b, c, brush);
        line(l, t, l, b, c, brush);
        line(r, t, r, b, c, brush);
    }

    private static boolean insideEllipse(int x, int y, double cx, double cy, double rx, double ry) {
        double dx = (x - cx) / rx, dy = (y - cy) / ry;
        return dx * dx + dy * dy <= 1.0;
    }

    public void ellipse(int x0, int y0, int x1, int y1, int c, boolean filled, int brush) {
        int l = Math.min(x0, x1), r = Math.max(x0, x1), t = Math.min(y0, y1), b = Math.max(y0, y1);
        double cx = (l + r) / 2.0, cy = (t + b) / 2.0, rx = (r - l) / 2.0 + 0.5, ry = (b - t) / 2.0 + 0.5;
        for (int y = t; y <= b; y++) {
            for (int x = l; x <= r; x++) {
                if (!insideEllipse(x, y, cx, cy, rx, ry)) continue;
                if (filled) { set(x, y, c); continue; }
                boolean edge = !insideEllipse(x - 1, y, cx, cy, rx, ry) || !insideEllipse(x + 1, y, cx, cy, rx, ry)
                        || !insideEllipse(x, y - 1, cx, cy, rx, ry) || !insideEllipse(x, y + 1, cx, cy, rx, ry);
                if (edge) plot(x, y, c, brush);
            }
        }
    }

    /** Flood fill (4-neighbour, all fully transparent pixels count as equal). */
    public void fill(int x, int y, int c) {
        if (!in(x, y)) return;
        int target = px[y * w + x];
        if (same(target, c)) return;
        int[] st = new int[1024];
        int sp = 0;
        st[sp++] = y * w + x;
        while (sp > 0) {
            int p = st[--sp];
            int cy = p / w, cx = p % w;
            if (!same(px[p], target)) continue;
            int l = cx, r = cx;
            while (l > 0 && same(px[cy * w + l - 1], target)) l--;
            while (r < w - 1 && same(px[cy * w + r + 1], target)) r++;
            for (int i = l; i <= r; i++) px[cy * w + i] = c;
            for (int d = -1; d <= 1; d += 2) {
                int ny = cy + d;
                if (ny < 0 || ny >= h) continue;
                boolean span = false;
                for (int i = l; i <= r; i++) {
                    boolean m = same(px[ny * w + i], target);
                    if (m && !span) {
                        if (sp == st.length) st = Arrays.copyOf(st, sp * 2);
                        st[sp++] = ny * w + i;
                        span = true;
                    } else if (!m) {
                        span = false;
                    }
                }
            }
        }
    }

    /** Move the whole picture by dx,dy with wrap-around, reading from 'src' (used live while dragging). */
    public void shiftFrom(int[] src, int dx, int dy) {
        for (int y = 0; y < h; y++) {
            int sy = ((y - dy) % h + h) % h;
            for (int x = 0; x < w; x++) {
                int sx = ((x - dx) % w + w) % w;
                px[y * w + x] = src[sy * w + sx];
            }
        }
    }

    // ---- whole-image operations (each records an undo step) ----

    public void flipH() {
        push();
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w / 2; x++) {
                int a = y * w + x, b = y * w + (w - 1 - x);
                int t = px[a]; px[a] = px[b]; px[b] = t;
            }
        }
    }

    public void flipV() {
        push();
        for (int y = 0; y < h / 2; y++) {
            for (int x = 0; x < w; x++) {
                int a = y * w + x, b = (h - 1 - y) * w + x;
                int t = px[a]; px[a] = px[b]; px[b] = t;
            }
        }
    }

    public void rotate(boolean clockwise) {
        push();
        int[] n = new int[w * h];
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int nx = clockwise ? h - 1 - y : y;
                int ny = clockwise ? x : w - 1 - x;
                n[ny * h + nx] = px[y * w + x];
            }
        }
        px = n;
        int t = w; w = h; h = t;
    }

    /** New canvas size keeping the pixels (anchor 0 = top-left, 1 = centre); new area is transparent. */
    public void resizeCrop(int nw, int nh, int anchor) {
        nw = Math.max(1, nw);
        nh = Math.max(1, nh);
        push();
        int[] n = new int[nw * nh];
        int ox = anchor == 1 ? (nw - w) / 2 : 0, oy = anchor == 1 ? (nh - h) / 2 : 0;
        for (int y = 0; y < h; y++) {
            int ty = y + oy;
            if (ty < 0 || ty >= nh) continue;
            for (int x = 0; x < w; x++) {
                int tx = x + ox;
                if (tx < 0 || tx >= nw) continue;
                n[ty * nw + tx] = px[y * w + x];
            }
        }
        px = n;
        w = nw;
        h = nh;
    }

    /** Nearest-neighbour scale to a new size. */
    public void scaleTo(int nw, int nh) {
        nw = Math.max(1, nw);
        nh = Math.max(1, nh);
        push();
        int[] n = new int[nw * nh];
        for (int y = 0; y < nh; y++) {
            int sy = Math.min(h - 1, (int) ((long) y * h / nh));
            for (int x = 0; x < nw; x++) {
                int sx = Math.min(w - 1, (int) ((long) x * w / nw));
                n[y * nw + x] = px[sy * w + sx];
            }
        }
        px = n;
        w = nw;
        h = nh;
    }

    public void clear(int c) {
        push();
        Arrays.fill(px, c);
    }

    /** Replace every pixel equal to 'from' by 'to'. Returns how many changed. */
    public int replace(int from, int to) {
        push();
        int n = 0;
        for (int i = 0; i < px.length; i++) {
            if (same(px[i], from)) { px[i] = to; n++; }
        }
        return n;
    }

    public void invert() {
        push();
        for (int i = 0; i < px.length; i++) {
            int a = px[i] >>> 24;
            if (a != 0) px[i] = (a << 24) | (~px[i] & 0x00FFFFFF);
        }
    }

    public void grayscale() {
        push();
        for (int i = 0; i < px.length; i++) {
            int p = px[i], a = p >>> 24;
            if (a == 0) continue;
            int r = (p >> 16) & 255, g = (p >> 8) & 255, b = p & 255;
            int y = (r * 30 + g * 59 + b * 11) / 100;
            px[i] = (a << 24) | (y << 16) | (y << 8) | y;
        }
    }

    /** One-pixel outline (4-neighbour) around the opaque shape. */
    public void outline(int c) {
        push();
        int[] src = px.clone();
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                if ((src[y * w + x] >>> 24) != 0) continue;
                boolean near = (x > 0 && (src[y * w + x - 1] >>> 24) != 0) || (x < w - 1 && (src[y * w + x + 1] >>> 24) != 0)
                        || (y > 0 && (src[(y - 1) * w + x] >>> 24) != 0) || (y < h - 1 && (src[(y + 1) * w + x] >>> 24) != 0);
                if (near) px[y * w + x] = c;
            }
        }
    }

    // ---- region helpers (no undo step; the caller calls push() first) ----

    /** Copy of the pixels in the rectangle (parts outside the picture are transparent). */
    public int[] copyRect(int x, int y, int rw, int rh) {
        int[] o = new int[Math.max(1, rw * rh)];
        for (int j = 0; j < rh; j++) {
            for (int i = 0; i < rw; i++) o[j * rw + i] = get(x + i, y + j);
        }
        return o;
    }

    public void clearRect(int x, int y, int rw, int rh) {
        for (int j = 0; j < rh; j++) {
            for (int i = 0; i < rw; i++) set(x + i, y + j, 0);
        }
    }

    /** Draw an ARGB block with normal alpha blending at dx,dy (parts outside the picture are cut off). */
    public void stamp(int[] src, int sw, int sh, int dx, int dy) {
        for (int j = 0; j < sh; j++) {
            int ty = dy + j;
            if (ty < 0 || ty >= h) continue;
            for (int i = 0; i < sw; i++) {
                int tx = dx + i;
                if (tx < 0 || tx >= w) continue;
                int s = src[j * sw + i], sa = s >>> 24;
                if (sa == 0) continue;
                int di = ty * w + tx, d = px[di], da = d >>> 24;
                if (sa == 255 || da == 0) { px[di] = s; continue; }
                float fa = sa / 255f, fb = da / 255f * (1f - fa), oa = fa + fb;
                int r = Math.round((((s >> 16) & 255) * fa + ((d >> 16) & 255) * fb) / oa);
                int g = Math.round((((s >> 8) & 255) * fa + ((d >> 8) & 255) * fb) / oa);
                int b = Math.round(((s & 255) * fa + (d & 255) * fb) / oa);
                px[di] = (Math.round(oa * 255f) << 24) | (r << 16) | (g << 8) | b;
            }
        }
    }

    /** Nearest-neighbour scaled copy of an ARGB block. */
    public static int[] scaleBlock(int[] src, int sw, int sh, int nw, int nh) {
        int[] o = new int[nw * nh];
        for (int y = 0; y < nh; y++) {
            int sy = Math.min(sh - 1, (int) ((long) y * sh / nh));
            for (int x = 0; x < nw; x++) {
                o[y * nw + x] = src[sy * sw + Math.min(sw - 1, (int) ((long) x * sw / nw))];
            }
        }
        return o;
    }

    /** Crop away fully transparent borders. Returns false when there is nothing to crop. */
    public boolean trim() {
        int l = w, t = h, r = -1, b = -1;
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                if ((px[y * w + x] >>> 24) == 0) continue;
                if (x < l) l = x;
                if (x > r) r = x;
                if (y < t) t = y;
                if (y > b) b = y;
            }
        }
        if (r < 0 || (l == 0 && t == 0 && r == w - 1 && b == h - 1)) return false;
        push();
        int nw = r - l + 1, nh = b - t + 1;
        int[] n = new int[nw * nh];
        for (int y = 0; y < nh; y++) System.arraycopy(px, (t + y) * w + l, n, y * nw, nw);
        px = n;
        w = nw;
        h = nh;
        frameW = 0;
        frameH = 0;
        return true;
    }

    /** The picture's colours (not fully transparent), most used first, at most 'max'. */
    public int[] usedColors(int max) {
        final java.util.HashMap<Integer, int[]> m = new java.util.HashMap<Integer, int[]>();
        for (int i = 0; i < px.length; i++) {
            if ((px[i] >>> 24) == 0) continue;
            Integer k = Integer.valueOf(px[i]);
            int[] c = m.get(k);
            if (c == null) m.put(k, new int[]{1}); else c[0]++;
        }
        ArrayList<java.util.Map.Entry<Integer, int[]>> list = new ArrayList<java.util.Map.Entry<Integer, int[]>>(m.entrySet());
        java.util.Collections.sort(list, new java.util.Comparator<java.util.Map.Entry<Integer, int[]>>() {
            public int compare(java.util.Map.Entry<Integer, int[]> x, java.util.Map.Entry<Integer, int[]> y) {
                return y.getValue()[0] - x.getValue()[0];
            }
        });
        int n = Math.min(max, list.size());
        int[] o = new int[n];
        for (int i = 0; i < n; i++) o[i] = list.get(i).getKey().intValue();
        return o;
    }

    /** Number of sprite-sheet frames for the current frame size (0 when no frame grid is set). */
    public int frameCount() {
        if (frameW <= 0 || frameH <= 0 || frameW > w || frameH > h) return 0;
        return (w / frameW) * (h / frameH);
    }
}
