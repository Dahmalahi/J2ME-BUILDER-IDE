package com.dashers.j2mebuilderide.ide;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import com.dashers.j2mebuilderide.JCompilerBridge;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

/**
 * Read-only provider that hands a built .jar/.jad to an emulator (J2ME Loader, ...) without
 * file:// URIs (which crash on Android 7+). Framework classes only, no support library.
 * Only *.jar and *.jad files inside the projects folder are ever served.
 */
public class JarProvider extends ContentProvider {
    public static final String AUTH = "com.dashers.j2mebuilderide.files";

    /** content://AUTH/<path of the file relative to the projects folder, one segment per folder> */
    public static Uri uriFor(File f) {
        String root = JCompilerBridge.getRoot();
        String abs = f.getAbsolutePath();
        if (root.length() == 0 || !abs.startsWith(root)) return null;
        Uri.Builder b = new Uri.Builder().scheme("content").authority(AUTH);
        String[] parts = abs.substring(root.length()).split("/");
        for (int i = 0; i < parts.length; i++) if (parts[i].length() > 0) b.appendPath(parts[i]);
        return b.build();
    }

    private File resolve(Uri uri) throws FileNotFoundException {
        String root = JCompilerBridge.getRoot();
        List<String> seg = uri.getPathSegments();
        if (root.length() == 0 || seg.isEmpty()) throw new FileNotFoundException("no file");
        StringBuilder rel = new StringBuilder();
        for (int i = 0; i < seg.size(); i++) rel.append(i > 0 ? "/" : "").append(seg.get(i));
        String name = seg.get(seg.size() - 1).toLowerCase();
        if (!name.endsWith(".jar") && !name.endsWith(".jad")) throw new FileNotFoundException("not a jar/jad");
        try {
            File f = new File(root + rel).getCanonicalFile();
            String base = new File(root).getCanonicalPath() + File.separator;
            if (!f.getPath().startsWith(base) || !f.isFile()) throw new FileNotFoundException("not found");
            return f;
        } catch (IOException e) {
            throw new FileNotFoundException(e.getMessage());
        }
    }

    @Override public boolean onCreate() { return true; }

    @Override public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        if (mode != null && mode.indexOf('w') >= 0) throw new FileNotFoundException("read-only");
        return ParcelFileDescriptor.open(resolve(uri), ParcelFileDescriptor.MODE_READ_ONLY);
    }

    @Override public Cursor query(Uri uri, String[] projection, String sel, String[] args, String order) {
        File f;
        try { f = resolve(uri); } catch (FileNotFoundException e) { return null; }
        String[] cols = projection != null ? projection
                : new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE};
        MatrixCursor c = new MatrixCursor(cols);
        Object[] row = new Object[cols.length];
        for (int i = 0; i < cols.length; i++) {
            if (OpenableColumns.DISPLAY_NAME.equals(cols[i])) row[i] = f.getName();
            else if (OpenableColumns.SIZE.equals(cols[i])) row[i] = Long.valueOf(f.length());
        }
        c.addRow(row);
        return c;
    }

    @Override public String getType(Uri uri) {
        List<String> seg = uri.getPathSegments();
        String n = seg.isEmpty() ? "" : seg.get(seg.size() - 1).toLowerCase();
        return n.endsWith(".jad") ? "text/vnd.sun.j2me.app-descriptor" : "application/java-archive";
    }

    @Override public Uri insert(Uri uri, ContentValues v) { throw new UnsupportedOperationException("read-only"); }
    @Override public int delete(Uri uri, String s, String[] a) { return 0; }
    @Override public int update(Uri uri, ContentValues v, String s, String[] a) { return 0; }
}
