package com.dashers.j2mebuilderide.ide;

import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.StrictMode;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

/** Opens a built .jar in a J2ME emulator app (J2ME Loader, JL-Mod, FreeJ2ME, ...). */
public final class EmulatorLauncher {
    public static final String MIME = "application/java-archive";

    private EmulatorLauncher() {}

    private static Intent viewIntent(Uri uri) {
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setDataAndType(uri, MIME);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_GRANT_READ_URI_PERMISSION);
        i.setClipData(ClipData.newRawUri("jar", uri));
        return i;
    }

    /** Apps that declare they can open a .jar (any installed emulator shows up here). */
    public static List<ResolveInfo> installed(Context c) {
        List<ResolveInfo> out = new ArrayList<ResolveInfo>();
        PackageManager pm = c.getPackageManager();
        Uri[] probes = {
            new Uri.Builder().scheme("content").authority(JarProvider.AUTH).appendPath("probe.jar").build(),
            Uri.parse("file:///sdcard/probe.jar")
        };
        for (int k = 0; k < probes.length; k++) {
            List<ResolveInfo> l = pm.queryIntentActivities(viewIntent(probes[k]), 0);
            for (int i = 0; i < l.size(); i++) {
                ResolveInfo ri = l.get(i);
                if (ri.activityInfo == null || c.getPackageName().equals(ri.activityInfo.packageName)) continue;
                boolean dup = false;
                for (int j = 0; j < out.size(); j++)
                    if (out.get(j).activityInfo.packageName.equals(ri.activityInfo.packageName)) dup = true;
                if (!dup) out.add(ri);
            }
        }
        return out;
    }

    public static String labelOf(Context c, String pkg) {
        try {
            PackageManager pm = c.getPackageManager();
            return pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString();
        } catch (Exception e) {
            return pkg;
        }
    }

    /** @return null on success, otherwise a short reason to show the user */
    public static String open(Context c, File jar, String pkg) {
        if (jar == null || !jar.isFile()) return "no .jar to open - build first";
        PackageManager pm = c.getPackageManager();
        Uri content = JarProvider.uriFor(jar);
        if (content != null) {
            Intent i = viewIntent(content);
            if (pkg != null && pkg.length() > 0) i.setPackage(pkg);
            if (i.resolveActivity(pm) != null) {
                try { c.startActivity(i); return null; } catch (Exception ignore) { /* try file:// next */ }
            }
        }
        // Some emulators only register file:// for .jar: allow it for this one hand-off.
        Intent f = viewIntent(Uri.fromFile(jar));
        f.setClipData(null);
        if (pkg != null && pkg.length() > 0) f.setPackage(pkg);
        if (f.resolveActivity(pm) == null) {
            return (pkg != null && pkg.length() > 0)
                    ? labelOf(c, pkg) + " cannot open this file (is it still installed?)"
                    : "no J2ME emulator installed (try J2ME Loader)";
        }
        StrictMode.VmPolicy old = StrictMode.getVmPolicy();
        try {
            StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().build());
            c.startActivity(f);
            return null;
        } catch (Exception e) {
            return "could not start the emulator: " + e.getMessage();
        } finally {
            StrictMode.setVmPolicy(old);
        }
    }
}
