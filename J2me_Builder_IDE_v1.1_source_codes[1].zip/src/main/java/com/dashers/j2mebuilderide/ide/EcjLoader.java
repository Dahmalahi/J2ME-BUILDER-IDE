package com.dashers.j2mebuilderide.ide;

import android.content.Context;
import android.os.Environment;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.zip.ZipFile;

import com.dashers.j2mebuilderide.compiler.EcjCompiler;

/**
 * Finds a user-supplied ECJ when it is not packaged in the APK.
 *
 * The user drops a DEXED ecj jar (a .jar/.zip/.apk that contains classes.dex,
 * or a raw .dex) named ecj*.* into  /J2MEBuilder/Library/  (or the app's own
 * Library folder). It is looked up again every time a compile starts, loaded
 * with a DexClassLoader and used through EcjCompiler. A plain ecj-mini.jar
 * with .class files cannot be loaded by Android; status() says so.
 */
public final class EcjLoader {
    private static Context app;
    private static String status = "ECJ not installed - using built-in compiler";
    private static String loadedKey = "";

    private EcjLoader() {}

    public static void init(Context ctx) {
        app = ctx.getApplicationContext();
        for (int i = 0; i < dirs().length; i++) {
            try { dirs()[i].mkdirs(); } catch (Throwable ignore) { }
        }
        EcjCompiler.setLocator(new Runnable() { public void run() { locate(); } });
        EcjCompiler.setFallback(new Runnable() { public void run() { loadBundled(true); } });
        locate();
    }

    public static String status() { return status; }

    public static File[] dirs() {
        File shared = new File(Environment.getExternalStorageDirectory(), "J2MEBuilder/Library");
        File priv = app == null ? null : app.getExternalFilesDir(null);
        if (priv != null) priv = new File(priv, "Library");
        return priv == null ? new File[] { shared } : new File[] { shared, priv };
    }

    private static synchronized void locate() {
        if (app == null) return;
        File[] dirs = dirs();
        String plain = null;
        for (int d = 0; d < dirs.length; d++) {
            File[] fs = dirs[d].listFiles();
            if (fs == null) continue;
            for (int i = 0; i < fs.length; i++) {
                File f = fs[i];
                String n = f.getName().toLowerCase();
                if (!f.isFile() || !n.startsWith("ecj")) continue;
                if (!(n.endsWith(".jar") || n.endsWith(".zip") || n.endsWith(".apk") || n.endsWith(".dex"))) continue;
                String key = f.getAbsolutePath() + "|" + f.length() + "|" + f.lastModified();
                if (key.equals(loadedKey)) return; // already tried this exact file
                loadedKey = key;
                if (!hasDex(f)) { plain = f.getName(); continue; }
                try {
                    File code = new File(app.getCodeCacheDir(), "ecj");
                    code.mkdirs();
                    File local = new File(code, f.getName());
                    if (local.exists()) { local.setWritable(true); local.delete(); }
                    copy(f, local);
                    local.setReadOnly(); // Android 14+ refuses writable dex files
                    File odex = new File(code, "odex");
                    odex.mkdirs();
                    ClassLoader cl = new dalvik.system.DexClassLoader(
                            local.getAbsolutePath(), odex.getAbsolutePath(), null, bootParent());
                    cl.loadClass("org.eclipse.jdt.internal.compiler.Compiler");
                    EcjCompiler.setClassLoader(cl);
                    status = "ECJ ready (" + f.getName() + ")";
                    return;
                } catch (Throwable t) {
                    status = "ECJ file " + f.getName() + " could not be loaded: " + t;
                }
            }
        }
        if (loadBundled(plain == null)) return;
        if (plain != null) {
            status = plain + " has no classes.dex. Android cannot load plain .class jars - use a dexed ECJ jar "
                    + "(d8 ecj-mini.jar) or add it as a Local library in Sketchware.";
        } else if (loadedKey.length() == 0) {
            status = "ECJ not installed - put a dexed ecj jar in /J2MEBuilder/Library/ (built-in compiler is used meanwhile)";
        }
    }

    /** assets/ecj/ecj-dex.jar: ECJ 3.20.0 already converted to dex, shipped with the app. */
    private static int bundledLoads;

    private static boolean loadBundled(boolean quiet) {
        bundledLoads++;
        try {
            File code = new File(app.getCodeCacheDir(), "ecj");
            code.mkdirs();
            String asset = bundledAsset();
            File local = new File(code, "ecj-bundled-" + asset.replace('/', '_') + "-" + bundleVersion() + ".jar");
            if (bundledLoads >= 3 && local.exists()) { local.setWritable(true); local.delete(); }   // retry: re-extract a possibly corrupt copy
            if (!local.exists() || local.length() == 0) {
                InputStream in = app.getAssets().open(asset);
                try {
                    OutputStream out = new FileOutputStream(local);
                    try {
                        byte[] b = new byte[16384];
                        int n;
                        while ((n = in.read(b)) != -1) out.write(b, 0, n);
                    } finally { out.close(); }
                } finally { in.close(); }
                local.setReadOnly();
            }
            File odex = new File(code, "odex");
            odex.mkdirs();
            ClassLoader cl = new dalvik.system.DexClassLoader(
                    local.getAbsolutePath(), odex.getAbsolutePath(), null, bootParent());
            cl.loadClass("org.eclipse.jdt.internal.compiler.Compiler");
            EcjCompiler.setClassLoader(cl);
            status = "ECJ ready (bundled ECJ 3.20.0)";
            return true;
        } catch (Throwable t) {
            if (quiet) status = "Bundled ECJ could not be loaded: " + t;
            return false;
        }
    }

    /** Parent loader that does NOT see ECJ, so a DexClassLoader always uses its own (complete) copy. */
    private static ClassLoader bootParent() {
        ClassLoader b = Object.class.getClassLoader();
        return b != null ? b : ClassLoader.getSystemClassLoader();
    }

    /** Android < 7 has no java.util.stream / java.util.function, which ECJ 3.20 uses. A legacy ECJ 3.10.2 dex
     *  (assets/ecj/ecj-dex-legacy.jar) is preferred there when it is shipped. */
    private static String bundledAsset() {
        if (android.os.Build.VERSION.SDK_INT < 24) {
            try { app.getAssets().open("ecj/ecj-dex-legacy.jar").close(); return "ecj/ecj-dex-legacy.jar"; }
            catch (IOException ignore) { }
        }
        return "ecj/ecj-dex.jar";
    }

    private static String bundleVersion() {
        try { return String.valueOf(app.getPackageManager().getPackageInfo(app.getPackageName(), 0).lastUpdateTime); }
        catch (Throwable t) { return "0"; }
    }

    private static boolean hasDex(File f) {
        if (f.getName().toLowerCase().endsWith(".dex")) return true;
        ZipFile z = null;
        try { z = new ZipFile(f); return z.getEntry("classes.dex") != null; }
        catch (IOException e) { return false; }
        finally { if (z != null) try { z.close(); } catch (IOException ignore) { } }
    }

    private static void copy(File from, File to) throws IOException {
        InputStream in = new FileInputStream(from);
        try {
            OutputStream out = new FileOutputStream(to);
            try {
                byte[] b = new byte[16384];
                int n;
                while ((n = in.read(b)) != -1) out.write(b, 0, n);
            } finally { out.close(); }
        } finally { in.close(); }
    }
}
