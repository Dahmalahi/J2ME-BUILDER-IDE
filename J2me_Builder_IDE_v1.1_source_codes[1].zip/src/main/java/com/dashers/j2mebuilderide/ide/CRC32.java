package com.dashers.j2mebuilderide.ide;

/**
 * Hand-rolled CRC-32 (ISO 3309 / ZIP polynomial 0xEDB88320).
 *
 * CLDC 1.1 has no java.util.zip package at all -- not CRC32, not
 * Deflater, not ZipOutputStream -- so ZipWriter needs its own CRC and
 * its own ZIP structure writer. This class only uses int/byte-array
 * math, no CLDC-missing APIs.
 */
public final class CRC32 {

    private static final int[] TABLE = buildTable();

    private static int[] buildTable() {
        int[] t = new int[256];
        for (int n = 0; n < 256; n++) {
            int c = n;
            for (int k = 0; k < 8; k++) {
                if ((c & 1) != 0) {
                    c = 0xEDB88320 ^ (c >>> 1);
                } else {
                    c = c >>> 1;
                }
            }
            t[n] = c;
        }
        return t;
    }

    /** Computes the CRC-32 of an entire byte array, returned as an
     *  unsigned 32-bit value held in a long (ZIP fields are unsigned). */
    public static long of(byte[] data) {
        return of(data, 0, data.length);
    }

    public static long of(byte[] data, int off, int len) {
        int crc = 0xFFFFFFFF;
        for (int i = off; i < off + len; i++) {
            int idx = (crc ^ data[i]) & 0xFF;
            crc = (crc >>> 8) ^ TABLE[idx];
        }
        crc = crc ^ 0xFFFFFFFF;
        return ((long) crc) & 0xFFFFFFFFL;
    }
}
