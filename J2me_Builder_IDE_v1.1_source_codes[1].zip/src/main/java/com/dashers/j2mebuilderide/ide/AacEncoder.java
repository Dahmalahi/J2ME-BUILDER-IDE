package com.dashers.j2mebuilderide.ide;

import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaFormat;
import android.media.MediaMuxer;

import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.ShortBuffer;

/** Compresses mono PCM to AAC in an .m4a file with the phone's hardware / software encoder. */
public final class AacEncoder {
    private AacEncoder() { }

    public static void encode(short[] mono, int rate, int bitrate, File out) throws IOException {
        if (mono.length == 0) throw new IOException("Nothing to encode");
        MediaCodec enc = null;
        MediaMuxer mux = null;
        boolean muxStarted = false;
        try {
            MediaFormat fmt = MediaFormat.createAudioFormat("audio/mp4a-latm", rate, 1);
            fmt.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC);
            fmt.setInteger(MediaFormat.KEY_BIT_RATE, bitrate);
            fmt.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384);
            enc = MediaCodec.createEncoderByType("audio/mp4a-latm");
            enc.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
            enc.start();
            mux = new MediaMuxer(out.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            int track = -1, pos = 0, idle = 0;
            boolean inDone = false, outDone = false;
            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            while (!outDone) {
                if (!inDone) {
                    int ii = enc.dequeueInputBuffer(10000);
                    if (ii >= 0) {
                        ByteBuffer ib = enc.getInputBuffer(ii);
                        ib.clear();
                        int n = Math.min(ib.capacity() / 2, mono.length - pos);
                        long pts = (long) pos * 1000000L / rate;
                        if (n <= 0) {
                            enc.queueInputBuffer(ii, 0, 0, pts, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                            inDone = true;
                        } else {
                            ShortBuffer sb = ib.order(ByteOrder.nativeOrder()).asShortBuffer();
                            sb.put(mono, pos, n);
                            enc.queueInputBuffer(ii, 0, n * 2, pts, 0);
                            pos += n;
                        }
                    }
                }
                int oi = enc.dequeueOutputBuffer(info, 10000);
                if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    track = mux.addTrack(enc.getOutputFormat());
                    mux.start();
                    muxStarted = true;
                } else if (oi >= 0) {
                    idle = 0;
                    ByteBuffer ob = enc.getOutputBuffer(oi);
                    if ((info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) info.size = 0;
                    if (info.size > 0 && muxStarted) {
                        ob.position(info.offset);
                        ob.limit(info.offset + info.size);
                        mux.writeSampleData(track, ob, info);
                    }
                    enc.releaseOutputBuffer(oi, false);
                    if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outDone = true;
                } else if (inDone && ++idle > 300) {
                    throw new IOException("The AAC encoder stopped answering");
                }
            }
        } catch (IllegalStateException e) {
            throw new IOException("AAC encoding is not supported on this phone: " + e.getMessage());
        } finally {
            if (enc != null) {
                try { enc.stop(); } catch (Exception ignore) { }
                try { enc.release(); } catch (Exception ignore) { }
            }
            if (mux != null) {
                if (muxStarted) { try { mux.stop(); } catch (Exception ignore) { } }
                try { mux.release(); } catch (Exception ignore) { }
            }
        }
    }
}
