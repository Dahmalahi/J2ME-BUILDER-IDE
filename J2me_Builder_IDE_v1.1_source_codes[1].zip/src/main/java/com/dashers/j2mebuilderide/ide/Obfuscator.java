package com.dashers.j2mebuilderide.ide;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Small, dependency-free class-file obfuscator that runs on the finished
 * .class bytes just before they are zipped into the JAR.
 *
 *   level 0  None     - untouched
 *   level 1  class names renamed (the MIDlet main class stays as it is,
 *                        because the manifest refers to it)
 *   level 2  + level 1, plus every PRIVATE field/method of your own classes renamed
 *   level 3  + every PROTECTED field/method renamed too
 *   level 4  + every PACKAGE-PRIVATE (default access) field/method renamed too
 *   level 5  + every PUBLIC field/method renamed too, except names that match a
 *                        known MIDP/CLDC callback (startApp, paint, keyPressed, ...)
 *                        or a common java.lang.Object override, so framework
 *                        callbacks still get invoked correctly by the platform
 *   level 6  + level 5, plus debug metadata stripped: SourceFile (class) and
 *                        Deprecated/Synthetic (class + members)
 *   level 7  + level 6, plus LineNumberTable/LocalVariableTable/
 *                        LocalVariableTypeTable stripped out of every method's
 *                        Code attribute (stack traces lose line numbers, jar shrinks)
 *   level 8  + level 7, plus the declared field/method order of every class is
 *                        reversed (pure diffing noise, no functional effect)
 *   level 9  + level 8, plus remaining optional metadata stripped: Exceptions,
 *                        Signature, RuntimeVisibleAnnotations, RuntimeInvisibleAnnotations
 *
 * It never edits an existing constant-pool entry in place and never renumbers
 * anything: new Utf8 / NameAndType entries are appended and the references
 * that need to change are re-pointed. Code, StackMap and exception tables
 * therefore stay valid byte-for-byte (aside from the debug tables levels 7/9
 * deliberately remove). The result is parsed again before it is returned;
 * ProjectManager falls back to the untouched classes on any error.
 *
 * Not handled (by design): names used as strings, e.g. Class.forName("Foo").
 */
public final class Obfuscator {
    private Obfuscator() {}

    public static final int ACC_PUBLIC = 0x0001;
    public static final int ACC_PRIVATE = 0x0002;
    public static final int ACC_PROTECTED = 0x0004;

    public static final int MAX_LEVEL = 9;

    /** Common MIDP/CLDC callback + java.lang.Object override names: never renamed at level 5,
     *  because the platform (or overriding code elsewhere) calls them by this exact name. */
    private static final HashSet LIFECYCLE_NAMES = new HashSet();
    static {
        String[] n = {
            "startApp", "pauseApp", "destroyApp", "run",
            "paint", "keyPressed", "keyReleased", "keyRepeated",
            "pointerPressed", "pointerReleased", "pointerDragged",
            "commandAction", "itemStateChanged", "sizeChanged",
            "showNotify", "hideNotify", "serviceRepaints",
            "main", "toString", "equals", "hashCode", "compareTo"
        };
        for (int i = 0; i < n.length; i++) LIFECYCLE_NAMES.add(n[i]);
    }

    private static final HashSet CLASS_STRIP_6 = new HashSet();
    private static final HashSet MEMBER_STRIP_6 = new HashSet();
    private static final HashSet CLASS_STRIP_9 = new HashSet();
    private static final HashSet MEMBER_STRIP_9 = new HashSet();
    static {
        CLASS_STRIP_6.add("SourceFile");
        CLASS_STRIP_6.add("Deprecated");
        CLASS_STRIP_6.add("Synthetic");
        MEMBER_STRIP_6.add("Deprecated");
        MEMBER_STRIP_6.add("Synthetic");
        CLASS_STRIP_9.add("Signature");
        MEMBER_STRIP_9.add("Exceptions");
        MEMBER_STRIP_9.add("Signature");
        MEMBER_STRIP_9.add("RuntimeVisibleAnnotations");
        MEMBER_STRIP_9.add("RuntimeInvisibleAnnotations");
    }

    private static final HashSet CODE_DEBUG_ATTRS = new HashSet();
    static {
        CODE_DEBUG_ATTRS.add("LineNumberTable");
        CODE_DEBUG_ATTRS.add("LocalVariableTable");
        CODE_DEBUG_ATTRS.add("LocalVariableTypeTable");
    }

    public static final class Result {
        public String[] names;      // internal names (use '/' separators), same order as the input
        public byte[][] classes;
        public int classesRenamed;
        public int membersRenamed;
        public String mapping = "";
    }

    // ------------------------------------------------------------------
    // class-file model
    // ------------------------------------------------------------------

    private static final class Mem {
        int access, name, desc;
        byte[] attrs;           // starts with attributes_count
    }

    private static final class CF {
        int minor, major, count;
        int[] tag, a, b;
        byte[][] raw;
        int access, thisIdx, superIdx;
        int[] ifaces;
        Mem[] fields, methods;
        byte[] tail;            // class attributes (count + data)

        HashMap utf8Cache = new HashMap(); // String -> Integer (only for entries we add)

        String utf(int i) {
            try {
                return new String(raw[i], "UTF-8");
            } catch (java.io.UnsupportedEncodingException e) {
                return new String(raw[i]);
            }
        }

        String className(int classIdx) {
            return utf(a[classIdx]);
        }

        String internalName() {
            return className(thisIdx);
        }

        void grow() {
            if (count < tag.length) return;
            int n = tag.length * 2 + 8;
            tag = copyOf(tag, n);
            a = copyOf(a, n);
            b = copyOf(b, n);
            byte[][] r2 = new byte[n][];
            System.arraycopy(raw, 0, r2, 0, raw.length);
            raw = r2;
        }

        int addUtf8(String s) throws IOException {
            Integer hit = (Integer) utf8Cache.get(s);
            if (hit != null) return hit.intValue();
            grow();
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            new DataOutputStream(bos).writeUTF(s);
            byte[] all = bos.toByteArray();
            byte[] payload = new byte[all.length - 2];
            System.arraycopy(all, 2, payload, 0, payload.length);
            int idx = count++;
            tag[idx] = 1;
            raw[idx] = payload;
            utf8Cache.put(s, new Integer(idx));
            return idx;
        }

        int addNameAndType(int nameIdx, int descIdx) {
            grow();
            int idx = count++;
            tag[idx] = 12;
            a[idx] = nameIdx;
            b[idx] = descIdx;
            return idx;
        }
    }

    private static int[] copyOf(int[] src, int n) {
        int[] d = new int[n];
        System.arraycopy(src, 0, d, 0, src.length);
        return d;
    }

    // ------------------------------------------------------------------
    // parse / write
    // ------------------------------------------------------------------

    private static CF parse(byte[] data) throws IOException {
        DataInputStream in = new DataInputStream(new ByteArrayInputStream(data));
        if (in.readInt() != 0xCAFEBABE) throw new IOException("bad magic");
        CF c = new CF();
        c.minor = in.readUnsignedShort();
        c.major = in.readUnsignedShort();
        c.count = in.readUnsignedShort();
        int cap = c.count + 4;
        c.tag = new int[cap];
        c.a = new int[cap];
        c.b = new int[cap];
        c.raw = new byte[cap][];
        for (int i = 1; i < c.count; i++) {
            int t = in.readUnsignedByte();
            c.tag[i] = t;
            switch (t) {
                case 1: {
                    int len = in.readUnsignedShort();
                    byte[] r = new byte[len];
                    in.readFully(r);
                    c.raw[i] = r;
                    break;
                }
                case 3:
                case 4: {
                    byte[] r = new byte[4];
                    in.readFully(r);
                    c.raw[i] = r;
                    break;
                }
                case 5:
                case 6: {
                    byte[] r = new byte[8];
                    in.readFully(r);
                    c.raw[i] = r;
                    i++; // long/double occupy two slots
                    break;
                }
                case 7:
                case 8:
                    c.a[i] = in.readUnsignedShort();
                    break;
                case 9:
                case 10:
                case 11:
                case 12:
                    c.a[i] = in.readUnsignedShort();
                    c.b[i] = in.readUnsignedShort();
                    break;
                default:
                    throw new IOException("unsupported constant pool tag " + t);
            }
        }
        c.access = in.readUnsignedShort();
        c.thisIdx = in.readUnsignedShort();
        c.superIdx = in.readUnsignedShort();
        int ni = in.readUnsignedShort();
        c.ifaces = new int[ni];
        for (int i = 0; i < ni; i++) c.ifaces[i] = in.readUnsignedShort();
        c.fields = readMembers(in);
        c.methods = readMembers(in);

        ByteArrayOutputStream rest = new ByteArrayOutputStream();
        byte[] buf = new byte[512];
        int n;
        while ((n = in.read(buf)) > 0) rest.write(buf, 0, n);
        c.tail = rest.toByteArray();
        checkAttributes(c.tail);
        return c;
    }

    private static Mem[] readMembers(DataInputStream in) throws IOException {
        int n = in.readUnsignedShort();
        Mem[] out = new Mem[n];
        for (int i = 0; i < n; i++) {
            Mem m = new Mem();
            m.access = in.readUnsignedShort();
            m.name = in.readUnsignedShort();
            m.desc = in.readUnsignedShort();
            int ac = in.readUnsignedShort();
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            DataOutputStream out2 = new DataOutputStream(bos);
            out2.writeShort(ac);
            for (int k = 0; k < ac; k++) {
                int an = in.readUnsignedShort();
                int len = in.readInt();
                if (len < 0) throw new IOException("bad attribute length");
                byte[] body = new byte[len];
                in.readFully(body);
                out2.writeShort(an);
                out2.writeInt(len);
                out2.write(body);
            }
            m.attrs = bos.toByteArray();
            out[i] = m;
        }
        return out;
    }

    /** Throws unless `attrs` is exactly one attributes_count + that many attributes. */
    private static void checkAttributes(byte[] attrs) throws IOException {
        DataInputStream in = new DataInputStream(new ByteArrayInputStream(attrs));
        int ac = in.readUnsignedShort();
        for (int k = 0; k < ac; k++) {
            in.readUnsignedShort();
            int len = in.readInt();
            if (len < 0 || in.skipBytes(len) != len) throw new IOException("truncated attribute");
        }
        if (in.available() != 0) throw new IOException("trailing bytes after class attributes");
    }

    private static byte[] write(CF c) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        DataOutputStream out = new DataOutputStream(bos);
        out.writeInt(0xCAFEBABE);
        out.writeShort(c.minor);
        out.writeShort(c.major);
        out.writeShort(c.count);
        for (int i = 1; i < c.count; i++) {
            int t = c.tag[i];
            if (t == 0) continue; // second slot of a long/double
            out.writeByte(t);
            switch (t) {
                case 1:
                    out.writeShort(c.raw[i].length);
                    out.write(c.raw[i]);
                    break;
                case 3:
                case 4:
                case 5:
                case 6:
                    out.write(c.raw[i]);
                    break;
                case 7:
                case 8:
                    out.writeShort(c.a[i]);
                    break;
                default:
                    out.writeShort(c.a[i]);
                    out.writeShort(c.b[i]);
                    break;
            }
        }
        out.writeShort(c.access);
        out.writeShort(c.thisIdx);
        out.writeShort(c.superIdx);
        out.writeShort(c.ifaces.length);
        for (int i = 0; i < c.ifaces.length; i++) out.writeShort(c.ifaces[i]);
        writeMembers(out, c.fields);
        writeMembers(out, c.methods);
        out.write(c.tail);
        out.flush();
        return bos.toByteArray();
    }

    private static void writeMembers(DataOutputStream out, Mem[] ms) throws IOException {
        out.writeShort(ms.length);
        for (int i = 0; i < ms.length; i++) {
            out.writeShort(ms[i].access);
            out.writeShort(ms[i].name);
            out.writeShort(ms[i].desc);
            out.write(ms[i].attrs);
        }
    }

    // ------------------------------------------------------------------
    // flat attribute-list helpers (used both for a member's attrs and for
    // a class's tail -- both are u2 attributes_count + repeated
    // (u2 name_index, u4 length, body) and for a Code attribute's own
    // nested attributes, which have exactly the same shape)
    // ------------------------------------------------------------------

    private static final class AttrEntry {
        int nameIdx;
        byte[] body;
    }

    private static List parseAttrs(byte[] blob) throws IOException {
        DataInputStream in = new DataInputStream(new ByteArrayInputStream(blob));
        int count = in.readUnsignedShort();
        ArrayList list = new ArrayList();
        for (int i = 0; i < count; i++) {
            AttrEntry e = new AttrEntry();
            e.nameIdx = in.readUnsignedShort();
            int len = in.readInt();
            byte[] body = new byte[len];
            in.readFully(body);
            e.body = body;
            list.add(e);
        }
        return list;
    }

    private static byte[] writeAttrs(List list) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        DataOutputStream out = new DataOutputStream(bos);
        out.writeShort(list.size());
        for (int i = 0; i < list.size(); i++) {
            AttrEntry e = (AttrEntry) list.get(i);
            out.writeShort(e.nameIdx);
            out.writeInt(e.body.length);
            out.write(e.body);
        }
        out.flush();
        return bos.toByteArray();
    }

    /** Drops any top-level attribute whose name is in `drop`. Never touches "Code". */
    private static byte[] stripAttrs(CF c, byte[] blob, Set drop) throws IOException {
        List list = parseAttrs(blob);
        ArrayList kept = new ArrayList();
        for (int i = 0; i < list.size(); i++) {
            AttrEntry e = (AttrEntry) list.get(i);
            String nm = c.utf(e.nameIdx);
            if (drop.contains(nm) && !nm.equals("Code")) continue;
            kept.add(e);
        }
        return writeAttrs(kept);
    }

    /** Strips LineNumberTable / LocalVariableTable(TypeTable) out of one Code attribute's body. */
    private static byte[] stripCodeDebug(byte[] codeBody, CF c) throws IOException {
        DataInputStream in = new DataInputStream(new ByteArrayInputStream(codeBody));
        int maxStack = in.readUnsignedShort();
        int maxLocals = in.readUnsignedShort();
        int codeLen = in.readInt();
        byte[] code = new byte[codeLen];
        in.readFully(code);
        int excLen = in.readUnsignedShort();
        byte[] excTable = new byte[excLen * 8];
        in.readFully(excTable);
        int attrCount = in.readUnsignedShort();
        ByteArrayOutputStream restBos = new ByteArrayOutputStream();
        DataOutputStream restOut = new DataOutputStream(restBos);
        restOut.writeShort(attrCount);
        byte[] buf = new byte[1024];
        int n;
        while ((n = in.read(buf)) > 0) restOut.write(buf, 0, n);
        byte[] filteredAttrs = stripAttrs(c, restBos.toByteArray(), CODE_DEBUG_ATTRS);

        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        DataOutputStream out = new DataOutputStream(bos);
        out.writeShort(maxStack);
        out.writeShort(maxLocals);
        out.writeInt(code.length);
        out.write(code);
        out.writeShort(excLen);
        out.write(excTable);
        out.write(filteredAttrs); // already starts with its own attributes_count
        out.flush();
        return bos.toByteArray();
    }

    /** Rewrites a method's Code attribute (if any) to drop its debug tables, leaving every
     *  other top-level attribute of the method untouched. */
    private static byte[] stripMethodCodeDebug(CF c, byte[] attrsBlob) throws IOException {
        List list = parseAttrs(attrsBlob);
        for (int i = 0; i < list.size(); i++) {
            AttrEntry e = (AttrEntry) list.get(i);
            if (c.utf(e.nameIdx).equals("Code")) {
                e.body = stripCodeDebug(e.body, c);
            }
        }
        return writeAttrs(list);
    }

    // ------------------------------------------------------------------
    // renaming
    // ------------------------------------------------------------------

    /** Short lowercase names: a..z, aa..az, ba.. */
    private static String shortName(int k) {
        StringBuffer sb = new StringBuffer();
        k++;
        while (k > 0) {
            k--;
            sb.insert(0, (char) ('a' + (k % 26)));
            k /= 26;
        }
        return sb.toString();
    }

    private static String packageOf(String internal) {
        int s = internal.lastIndexOf('/');
        return s < 0 ? "" : internal.substring(0, s + 1);
    }

    /** Rewrites every class reference inside a field/method descriptor (or array class name). */
    private static String mapDesc(String d, Map classMap) {
        if (d.indexOf('L') < 0) return d;
        StringBuffer sb = new StringBuffer();
        int i = 0;
        while (i < d.length()) {
            char ch = d.charAt(i);
            if (ch == 'L') {
                int semi = d.indexOf(';', i);
                if (semi < 0) { sb.append(d.substring(i)); break; }
                String name = d.substring(i + 1, semi);
                String repl = (String) classMap.get(name);
                sb.append('L').append(repl != null ? repl : name).append(';');
                i = semi + 1;
            } else {
                sb.append(ch);
                i++;
            }
        }
        return sb.toString();
    }

    /** True if a field/method at this access level, with this name, should be renamed at `level`. */
    private static boolean eligible(int access, String name, boolean inPrivateSet, int level) {
        if (name.length() > 0 && name.charAt(0) == '<') return false; // <init>/<clinit>
        boolean priv = (access & ACC_PRIVATE) != 0;
        boolean prot = (access & ACC_PROTECTED) != 0;
        boolean pub = (access & ACC_PUBLIC) != 0;
        boolean pkg = !priv && !prot && !pub;
        if (priv || inPrivateSet) return level >= 2;
        if (prot) return level >= 3;
        if (pkg) return level >= 4;
        if (pub) return level >= 5 && !LIFECYCLE_NAMES.contains(name);
        return false;
    }

    /**
     * @param names      class names as produced by the compiler (parallel to bytes)
     * @param bytes      the compiled .class files
     * @param mainClass  MIDlet-1 class; never renamed
     * @param level      0 = none .. 9 = maximum (see class javadoc)
     */
    public static Result run(String[] names, byte[][] bytes, String mainClass, int level,
                             java.util.Set privateMembers) throws IOException {
        level = Math.max(0, Math.min(MAX_LEVEL, level));
        int n = bytes.length;
        CF[] cf = new CF[n];
        String[] internal = new String[n];
        HashSet taken = new HashSet();
        for (int i = 0; i < n; i++) {
            cf[i] = parse(bytes[i]);
            internal[i] = cf[i].internalName();
            taken.add(internal[i]);
        }
        String mainInternal = mainClass == null ? "" : mainClass.replace('.', '/');

        // ---- class map (level >= 1) ----
        HashMap classMap = new HashMap();
        StringBuffer mapping = new StringBuffer();
        if (level >= 1) {
            HashMap counters = new HashMap(); // package -> next index
            for (int i = 0; i < n; i++) {
                if (internal[i].equals(mainInternal)) continue;
                String pkg = packageOf(internal[i]);
                Integer start = (Integer) counters.get(pkg);
                int k = start == null ? 0 : start.intValue();
                String cand;
                do {
                    cand = pkg + shortName(k);
                    k++;
                } while (taken.contains(cand));
                counters.put(pkg, new Integer(k));
                taken.add(cand);
                classMap.put(internal[i], cand);
                mapping.append(internal[i]).append(" -> ").append(cand).append('\n');
            }
        }

        // ---- member map (level >= 2) ----
        HashMap memberMap = new HashMap(); // owner.name:desc -> new name
        int memberCount = 0;
        if (level >= 2) {
            for (int i = 0; i < n; i++) {
                CF c = cf[i];
                HashSet used = new HashSet();
                collectNames(c, c.fields, used);
                collectNames(c, c.methods, used);
                int k = 0;
                for (int pass = 0; pass < 2; pass++) {
                    Mem[] list = pass == 0 ? c.fields : c.methods;
                    for (int j = 0; j < list.length; j++) {
                        Mem m = list[j];
                        String nm = c.utf(m.name);
                        boolean inSet = privateMembers != null && privateMembers.contains(internal[i] + "." + nm);
                        if (!eligible(m.access, nm, inSet, level)) continue;
                        String cand;
                        do {
                            cand = shortName(k);
                            k++;
                        } while (used.contains(cand));
                        used.add(cand);
                        String key = internal[i] + "." + nm + ":" + c.utf(m.desc);
                        memberMap.put(key, cand);
                        mapping.append(internal[i]).append('.').append(nm).append(" -> ").append(cand).append('\n');
                        memberCount++;
                    }
                }
            }
        }

        // ---- rewrite each class ----
        Result res = new Result();
        res.names = new String[n];
        res.classes = new byte[n][];
        for (int i = 0; i < n; i++) {
            CF c = cf[i];
            String owner = internal[i];

            // (1) member references (uses ORIGINAL owner names, so do this first)
            if (!memberMap.isEmpty()) {
                HashMap natCache = new HashMap();
                int pool = c.count;
                for (int e = 1; e < pool; e++) {
                    int t = c.tag[e];
                    if (t != 9 && t != 10 && t != 11) continue;
                    String refOwner = c.className(c.a[e]);
                    int nat = c.b[e];
                    String nm = c.utf(c.a[nat]);
                    String ds = c.utf(c.b[nat]);
                    String nn = (String) memberMap.get(refOwner + "." + nm + ":" + ds);
                    if (nn == null) continue;
                    String ck = nat + "/" + nn;
                    Integer hit = (Integer) natCache.get(ck);
                    if (hit == null) {
                        hit = new Integer(c.addNameAndType(c.addUtf8(nn), c.b[nat]));
                        natCache.put(ck, hit);
                    }
                    c.b[e] = hit.intValue();
                }
                // (2) own declarations
                for (int pass = 0; pass < 2; pass++) {
                    Mem[] list = pass == 0 ? c.fields : c.methods;
                    for (int j = 0; j < list.length; j++) {
                        Mem m = list[j];
                        String nn = (String) memberMap.get(owner + "." + c.utf(m.name) + ":" + c.utf(m.desc));
                        if (nn != null) m.name = c.addUtf8(nn);
                    }
                }
            }

            // (3) descriptors
            if (level >= 1) {
                int pool = c.count;
                for (int e = 1; e < pool; e++) {
                    if (c.tag[e] != 12) continue;
                    String d = c.utf(c.b[e]);
                    String nd = mapDesc(d, classMap);
                    if (!nd.equals(d)) c.b[e] = c.addUtf8(nd);
                }
                for (int pass = 0; pass < 2; pass++) {
                    Mem[] list = pass == 0 ? c.fields : c.methods;
                    for (int j = 0; j < list.length; j++) {
                        String d = c.utf(list[j].desc);
                        String nd = mapDesc(d, classMap);
                        if (!nd.equals(d)) list[j].desc = c.addUtf8(nd);
                    }
                }

                // (4) class names
                pool = c.count;
                for (int e = 1; e < pool; e++) {
                    if (c.tag[e] != 7) continue;
                    String nm = c.utf(c.a[e]);
                    String nn;
                    if (nm.length() > 0 && nm.charAt(0) == '[') {
                        nn = mapDesc(nm, classMap);
                    } else {
                        nn = (String) classMap.get(nm);
                        if (nn == null) nn = nm;
                    }
                    if (!nn.equals(nm)) c.a[e] = c.addUtf8(nn);
                }
            }

            // (5) debug-metadata stripping (level >= 6), including the nested
            // Code debug tables (level >= 7)
            if (level >= 6) {
                try {
                    c.tail = stripAttrs(c, c.tail, CLASS_STRIP_6);
                    for (int pass = 0; pass < 2; pass++) {
                        Mem[] list = pass == 0 ? c.fields : c.methods;
                        for (int j = 0; j < list.length; j++) {
                            list[j].attrs = stripAttrs(c, list[j].attrs, MEMBER_STRIP_6);
                        }
                    }
                } catch (IOException stripFail) {
                    // leave this class's metadata as-is rather than fail the whole build
                }
            }
            if (level >= 7) {
                try {
                    for (int j = 0; j < c.methods.length; j++) {
                        c.methods[j].attrs = stripMethodCodeDebug(c, c.methods[j].attrs);
                    }
                } catch (IOException stripFail) {
                    // leave this class's Code attributes as-is rather than fail the whole build
                }
            }
            if (level >= 9) {
                try {
                    c.tail = stripAttrs(c, c.tail, CLASS_STRIP_9);
                    for (int pass = 0; pass < 2; pass++) {
                        Mem[] list = pass == 0 ? c.fields : c.methods;
                        for (int j = 0; j < list.length; j++) {
                            list[j].attrs = stripAttrs(c, list[j].attrs, MEMBER_STRIP_9);
                        }
                    }
                } catch (IOException stripFail) {
                    // leave this class's metadata as-is rather than fail the whole build
                }
            }

            // (6) reverse declaration order (level >= 8) -- pure noise, no functional effect
            if (level >= 8) {
                c.fields = reversed(c.fields);
                c.methods = reversed(c.methods);
            }

            byte[] out = write(c);
            // sanity: the result must parse again and keep its shape
            CF check = parse(out);
            if (check.fields.length != c.fields.length || check.methods.length != c.methods.length) {
                throw new IOException("verification failed for " + owner);
            }
            res.classes[i] = out;
            res.names[i] = check.internalName();
        }
        res.classesRenamed = classMap.size();
        res.membersRenamed = memberCount;
        res.mapping = mapping.toString();
        return res;
    }

    private static Mem[] reversed(Mem[] in) {
        Mem[] out = new Mem[in.length];
        for (int i = 0; i < in.length; i++) out[i] = in[in.length - 1 - i];
        return out;
    }

    private static void collectNames(CF c, Mem[] list, HashSet used) {
        for (int j = 0; j < list.length; j++) used.add(c.utf(list[j].name));
    }
}
