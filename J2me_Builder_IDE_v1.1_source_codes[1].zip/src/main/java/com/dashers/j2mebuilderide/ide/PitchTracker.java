package com.dashers.j2mebuilderide.ide;

import java.util.ArrayList;

/**
 * Audio to MIDI: follows the pitch of ONE voice or instrument (YIN algorithm) and turns it into notes.
 * Chords and several instruments at once are not detected - it works best on humming, singing and single-line melodies.
 */
public final class PitchTracker {
    private PitchTracker() { }

    public interface Progress {
        /** Percent 0..100. Return false to cancel. */
        boolean update(int percent);
    }

    /**
     * @param sensitivity 0..1 - higher also picks up quiet parts
     * @param minNoteMs   shorter sounds are ignored
     * @param gridTicks   notes snap to this grid (480 ticks = one quarter note)
     */
    public static ArrayList<SeqModel.Note> detect(short[] pcm, int rate, int bpm, float sensitivity, int minNoteMs, int gridTicks,
                                                  Progress progress) {
        // bring the signal down to about 11 kHz: much faster, and enough for notes up to ~1.2 kHz
        int f = Math.max(1, Math.round(rate / 11025f));
        int r2 = rate / f;
        int n = pcm.length / f;
        float[] x = new float[n];
        for (int i = 0; i < n; i++) {
            int sum = 0;
            for (int k = 0; k < f; k++) sum += pcm[i * f + k];
            x[i] = sum / (f * 32768f);
        }
        final int w = 512, hop = 256;
        int tauMin = Math.max(2, r2 / 1200), tauMax = Math.min(w - 1, r2 / 65);
        int frames = Math.max(0, (n - w - tauMax) / hop);
        float[] rms = new float[frames];
        float peakRms = 1e-6f;
        for (int fr = 0; fr < frames; fr++) {
            int s = fr * hop;
            double sum = 0;
            for (int i = 0; i < w; i++) sum += x[s + i] * x[s + i];
            rms[fr] = (float) Math.sqrt(sum / w);
            if (rms[fr] > peakRms) peakRms = rms[fr];
        }
        float thr = Math.max(0.004f, peakRms * (0.04f + 0.30f * (1f - Math.max(0f, Math.min(1f, sensitivity)))));

        int[] midi = new int[frames];
        float[] d = new float[tauMax + 1];
        float[] cm = new float[tauMax + 1];
        for (int fr = 0; fr < frames; fr++) {
            midi[fr] = -1;
            if (progress != null && (fr & 63) == 0 && !progress.update(fr * 90 / Math.max(1, frames))) return new ArrayList<SeqModel.Note>();
            if (rms[fr] < thr) continue;
            int s = fr * hop;
            for (int tau = 1; tau <= tauMax; tau++) {
                float sum = 0;
                for (int i = 0; i < w; i++) {
                    float diff = x[s + i] - x[s + i + tau];
                    sum += diff * diff;
                }
                d[tau] = sum;
            }
            float run = 0;
            cm[0] = 1;
            for (int tau = 1; tau <= tauMax; tau++) {
                run += d[tau];
                cm[tau] = run > 0 ? d[tau] * tau / run : 1f;
            }
            int best = -1;
            for (int tau = tauMin; tau < tauMax; tau++) {
                if (cm[tau] < 0.15f) {
                    while (tau + 1 < tauMax && cm[tau + 1] < cm[tau]) tau++;
                    best = tau;
                    break;
                }
            }
            if (best < 0) {
                float m = 0.3f;
                for (int tau = tauMin; tau < tauMax; tau++) if (cm[tau] < m) { m = cm[tau]; best = tau; }
            }
            if (best < 0) continue;
            float t = best;
            if (best > 1 && best < tauMax) {
                float a = cm[best - 1], b = cm[best], c = cm[best + 1], den = a - 2 * b + c;
                if (Math.abs(den) > 1e-9f) t = best + 0.5f * (a - c) / den;
            }
            float hz = r2 / t;
            if (hz < 60f || hz > 1300f) continue;
            midi[fr] = Math.round(69f + 12f * (float) (Math.log(hz / 440f) / Math.log(2)));
        }

        // remove one-frame wobbles
        for (int i = 1; i + 1 < frames; i++) {
            if (midi[i - 1] == midi[i + 1] && midi[i] != midi[i - 1]) midi[i] = midi[i - 1];
        }

        double secPerFrame = hop / (double) r2;
        double secPerTick = 60.0 / (Math.max(20, bpm) * (double) SeqModel.PPQ);
        int grid = Math.max(1, gridTicks);
        ArrayList<SeqModel.Note> out = new ArrayList<SeqModel.Note>();
        int cur = -1, startFr = 0, lastVoiced = 0, gap = 0;
        float velSum = 0;
        int velCount = 0;
        for (int fr = 0; fr <= frames; fr++) {
            int m = fr < frames ? midi[fr] : -1;
            if (cur >= 0 && m == cur) {
                lastVoiced = fr;
                gap = 0;
                velSum += rms[fr];
                velCount++;
                continue;
            }
            if (cur >= 0 && m < 0 && gap < 2 && fr < frames) { gap++; continue; }
            if (cur >= 0) {
                double durSec = (lastVoiced + 1 - startFr) * secPerFrame;
                if (durSec * 1000 >= minNoteMs) {
                    int st = (int) Math.round(startFr * secPerFrame / secPerTick / grid) * grid;
                    int ln = Math.max(grid, (int) Math.round(durSec / secPerTick / grid) * grid);
                    float avg = velCount > 0 ? velSum / velCount : peakRms;
                    int vel = Math.max(40, Math.min(120, Math.round(40 + 80 * Math.min(1f, avg / peakRms))));
                    out.add(new SeqModel.Note(Math.max(0, Math.min(127, cur)), st, ln, vel));
                }
                cur = -1;
            }
            if (m >= 0) {
                cur = m;
                startFr = fr;
                lastVoiced = fr;
                gap = 0;
                velSum = rms[fr];
                velCount = 1;
            }
        }
        // snapping must not stack notes on top of each other
        for (int i = 0; i + 1 < out.size(); i++) {
            SeqModel.Note a = out.get(i), b = out.get(i + 1);
            if (b.start <= a.start) { out.remove(i + 1); i--; continue; }
            if (a.start + a.len > b.start) a.len = Math.max(grid, b.start - a.start);
        }
        if (progress != null) progress.update(100);
        return out;
    }
}
