package com.dashers.j2mebuilderide.ide;

import java.util.ArrayList;

/** Song data for the Audio Studio piano roll: tracks of notes on a tick grid (480 ticks per quarter note, 4/4). */
public final class SeqModel {
    public static final int PPQ = 480;
    public static final int MAX_BARS = 64;

    public static final class Note {
        public int pitch, start, len, vel;
        public Note(int pitch, int start, int len, int vel) { this.pitch = pitch; this.start = start; this.len = len; this.vel = vel; }
        public Note copy() { return new Note(pitch, start, len, vel); }
    }

    public static final class Track {
        public String name;
        public int program;           // General MIDI program 0..127 (ignored for drums)
        public boolean drum;          // plays on MIDI channel 10
        public boolean mute;
        public int volume = 100;      // 0..127
        public int color;
        public final ArrayList<Note> notes = new ArrayList<Note>();

        public Track(String name, int program, boolean drum, int color) {
            this.name = name;
            this.program = program;
            this.drum = drum;
            this.color = color;
        }
    }

    public static final class Project {
        public int bpm = 120;
        public int bars = 4;
        public final ArrayList<Track> tracks = new ArrayList<Track>();

        public int lengthTicks() { return bars * 4 * PPQ; }

        public Track addTrack(String name, int program, boolean drum) {
            Track t = new Track(name, program, drum, TRACK_COLORS[tracks.size() % TRACK_COLORS.length]);
            tracks.add(t);
            return t;
        }

        public int endTick() {
            int e = 0;
            for (int i = 0; i < tracks.size(); i++) {
                ArrayList<Note> n = tracks.get(i).notes;
                for (int j = 0; j < n.size(); j++) e = Math.max(e, n.get(j).start + n.get(j).len);
            }
            return e;
        }

        /** Grow the song length (in bars) so every note fits. */
        public void fitBars() {
            int need = (endTick() + 4 * PPQ - 1) / (4 * PPQ);
            if (need > bars) bars = Math.min(MAX_BARS, need);
        }

        public int noteCount() {
            int c = 0;
            for (int i = 0; i < tracks.size(); i++) c += tracks.get(i).notes.size();
            return c;
        }
    }

    /** A fresh song: one piano track and one drum track. */
    public static Project newSong() {
        Project p = new Project();
        p.addTrack("Piano", 0, false);
        p.addTrack("Drums", 0, true);
        return p;
    }

    public static final int[] TRACK_COLORS = {0xFFFF9100, 0xFF40C4FF, 0xFF69F0AE, 0xFFFF5252, 0xFFE040FB, 0xFFFFD740, 0xFF7C4DFF, 0xFF1DE9B6};

    /** Drum rows shown top to bottom (General MIDI percussion note numbers). */
    public static final int[] DRUM_ROWS = {49, 51, 46, 42, 39, 38, 45, 36};
    public static final String[] DRUM_NAMES = {"Crash", "Ride", "Open hat", "Closed hat", "Clap", "Snare", "Tom", "Kick"};

    public static int drumRow(int pitch) {
        for (int i = 0; i < DRUM_ROWS.length; i++) if (DRUM_ROWS[i] == pitch) return i;
        return -1;
    }

    /** Map any General MIDI drum note to one of the eight rows. */
    public static int mapDrum(int p) {
        switch (p) {
            case 35: case 36: return 36;
            case 37: case 38: case 40: return 38;
            case 39: return 39;
            case 41: case 43: case 45: case 47: case 48: case 50: return 45;
            case 42: case 44: return 42;
            case 46: return 46;
            case 49: case 52: case 55: case 57: return 49;
            case 51: case 53: case 59: return 51;
            default: return 42;
        }
    }

    /** Ready-made one-bar drum patterns (16 steps; rows in DRUM_ROWS order). */
    public static final String[] DRUM_PRESET_NAMES = {"Rock", "Four on the floor", "Hip hop", "Half time"};
    private static final String[][] DRUM_PRESETS = {
        // crash, ride, open hat, closed hat, clap, snare, tom, kick
        {"................", "................", "................", "x.x.x.x.x.x.x.x.", "................", "....x.......x...", "................", "x.......x.x....."},
        {"................", "................", "..x...x...x...x.", "x.x.x.x.x.x.x.x.", "....x.......x...", "................", "................", "x...x...x...x..."},
        {"................", "................", "......x.......x.", "x.x.x.x.x.x.x.x.", "................", "....x.......x...", "................", "x.....x...x.x..."},
        {"................", "................", "................", "x.x.x.x.x.x.x.x.", "................", "........x.......", "................", "x.......x..x...."},
    };

    /** Fill the track with a one-bar pattern repeated over the whole song. */
    public static void applyDrumPreset(Project p, Track t, int preset) {
        t.notes.clear();
        String[] rows = DRUM_PRESETS[Math.max(0, Math.min(DRUM_PRESETS.length - 1, preset))];
        int step = PPQ / 4;
        for (int bar = 0; bar < p.bars; bar++) {
            for (int r = 0; r < DRUM_ROWS.length; r++) {
                for (int s = 0; s < 16; s++) {
                    if (rows[r].charAt(s) == 'x') t.notes.add(new Note(DRUM_ROWS[r], bar * 16 * step + s * step, step, 100));
                }
            }
        }
    }

    public static final String[] NOTE_NAMES = {"C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"};

    public static String noteName(int pitch) { return NOTE_NAMES[((pitch % 12) + 12) % 12] + (pitch / 12 - 1); }

    public static boolean isBlack(int pitch) {
        int n = ((pitch % 12) + 12) % 12;
        return n == 1 || n == 3 || n == 6 || n == 8 || n == 10;
    }

    public static final String[] SCALE_NAMES = {"Chromatic (no highlight)", "Major", "Minor", "Pentatonic", "Blues"};
    private static final int[][] SCALE_STEPS = {{0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11}, {0, 2, 4, 5, 7, 9, 11}, {0, 2, 3, 5, 7, 8, 10},
        {0, 2, 4, 7, 9}, {0, 3, 5, 6, 7, 10}};

    public static boolean inScale(int pitch, int root, int scale) {
        int rel = (((pitch - root) % 12) + 12) % 12;
        int[] s = SCALE_STEPS[Math.max(0, Math.min(SCALE_STEPS.length - 1, scale))];
        for (int i = 0; i < s.length; i++) if (s[i] == rel) return true;
        return false;
    }
}
