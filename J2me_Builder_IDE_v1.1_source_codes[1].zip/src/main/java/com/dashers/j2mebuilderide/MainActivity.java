package com.dashers.j2mebuilderide;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.Drawable;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.DocumentsContract;
import android.provider.OpenableColumns;
import android.text.Editable;
import android.text.InputFilter;
import android.text.InputType;
import android.text.Spanned;
import android.text.TextWatcher;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.WindowManager;
import android.media.MediaPlayer;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Space;
import android.widget.TextView;
import android.widget.Toast;

import com.dashers.j2mebuilderide.ide.AppSettings;
import com.dashers.j2mebuilderide.ide.CodeFormatter;
import com.dashers.j2mebuilderide.ide.EmulatorLauncher;
import com.dashers.j2mebuilderide.ide.FaviconCache;
import com.dashers.j2mebuilderide.ide.Libraries;
import com.dashers.j2mebuilderide.ide.Lint;
import com.dashers.j2mebuilderide.ide.MidiFile;
import com.dashers.j2mebuilderide.ide.Project;
import com.dashers.j2mebuilderide.ide.ProjectTree;
import com.dashers.j2mebuilderide.ide.PackageTools;
import com.dashers.j2mebuilderide.ide.Suggest;
import com.dashers.j2mebuilderide.ide.Templates;
import com.dashers.j2mebuilderide.ui.CodeEditText;
import com.dashers.j2mebuilderide.ui.ColorPaletteScreen;
import com.dashers.j2mebuilderide.ui.ConsoleLog;
import com.dashers.j2mebuilderide.ui.Highlighter;
import com.dashers.j2mebuilderide.ui.SplashBar;
import com.dashers.j2mebuilderide.ui.SpriteEditorScreen;
import com.dashers.j2mebuilderide.ui.AudioStudioScreen;
import com.dashers.j2mebuilderide.ui.SwatchView;
import com.dashers.j2mebuilderide.ui.Themes;
import com.dashers.j2mebuilderide.ui.ToggleView;
import com.dashers.j2mebuilderide.ui.ToolHost;
import com.dashers.j2mebuilderide.ui.Ui;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Vector;

/**
 * J2ME Builder IDE -- every screen is built in code (no XML layouts to go missing)
 * with Material Design vector icons from res/drawable.
 *
 *   Home -> New project / Open project / Settings
 *   Editor -> files, find, build console, project settings
 */
public class MainActivity extends Activity {

    private static final int REQ_PERM = 11;
    private static final int REQ_IMPORT = 12;
    private static final int REQ_EXPORT = 13;
    private static final int REQ_ICON = 14;
    private static final int REQ_EXPORT_FILE = 15;
    private static final int REQ_EXPORT_ZIP = 16;
    private static final int REQ_PERM_DL = 17;
    private static final int REQ_IMPORT_PROJECT = 18;
    private static final int REQ_MIDI_OPEN = 19;
    private static final int REQ_LIB = 20;
    private static final int REQ_IMPORT_FOLDER = 21;        // folder -> NEW project
    private static final int REQ_IMPORT_FOLDER_INTO = 22;   // folder -> merged into the OPEN project
    private static final int REQ_PICK_IMAGE = 23;           // image for the colour picker / sprite editor
    private static final int REQ_PICK_IMAGES = 24;          // several images -> one sprite sheet
    private static final int REQ_PICK_FILE = 26;            // any file for the Audio Studio
    private static final int REQ_MIC = 27;                  // microphone permission
    private static final int REQ_EXPORT_SPRITE = 25;         // save a PNG / ZIP from the sprite editor
    private ToolHost.ImageSink pendingImageSink;
    private ToolHost.FileSink pendingFileSink;
    private Runnable pendingMicGranted;
    private AudioStudioScreen audioScreen;
    private ToolHost.ImagesSink pendingImagesSink;
    private byte[] pendingExportBytes;
    private String pendingEditorInsert;                      // text to insert once the editor is back on screen
    /** Resource import target, relative to res/ ("" means res/ root). */
    private String pendingResourceDir = "";

    private FrameLayout host;
    private AppSettings settings;
    private final Handler handler = new Handler();

    /** What the system Back button does on the current screen. */
    private Runnable backAction;
    /** Rebuilds the current screen (used after a theme switch). */
    private Runnable reshow;

    // ---- editor state ----
    private boolean inEditor = false;
    private CodeEditText editor;
    private String openFile = "";
    private boolean dirty = false;
    private boolean loading = false;
    private boolean selfEdit = false;
    private LinearLayout tabsRow;
    private TextView subtitle;
    private boolean building = false;
    private LinearLayout findBar;
    private EditText findField;
    private EditText replaceField;
    private HorizontalScrollView suggestScroll;
    private LinearLayout suggestRow;
    private LinearLayout consolePanel;
    private LinearLayout consoleTabs;
    private TextView consoleStatus;
    private View consoleDot;
    private ImageView consoleChevron;
    private ScrollView consoleLogScroll;
    private TextView consoleBody;
    private ScrollView consoleListScroll;
    private LinearLayout consoleList;
    private TextView tabLog;
    private TextView tabProblems;
    private TextView tabWarnings;
    private ConsoleLog log;
    private boolean consoleOpen = false;
    private int consoleTab = 0;
    private Vector lastProblems = new Vector();
    private Vector lastWarnings = new Vector();
    private boolean keyboardOpen = false;
    private View editorTopBar, editorTabWrap;
    private ViewTreeObserver.OnGlobalLayoutListener kbListener;
    private int consoleHeightPx;
    private boolean consoleExpanded = false;
    private ImageView consoleExpandBtn;
    private static final int LIST_PAGE = 60;   // problem/warning rows built per page (keeps 500+ errors smooth)

    // ---- undo / redo ----
    private final ArrayList<String> history = new ArrayList<String>();
    private int histPos = -1;
    private boolean undoing = false;

    // ---- new project / project settings forms ----
    private byte[] pendingIconBytes;
    private String pendingIconName = "";
    private ImageView iconPreview;
    private TextView iconLabel;
    private boolean iconForProject = false;
    private String pendingExportFile = "";

    private final Runnable highlightRun = new Runnable() {
        public void run() {
            highlightNow();
        }
    };

    /** Small files are coloured in one pass; big ones (4000+ lines) only around what is on screen. */
    private void highlightNow() {
        if (editor == null) return;
        try {
            Editable t = editor.getText();
            if (t.length() <= Highlighter.FULL_LIMIT) { Highlighter.apply(t); return; }
            int[] r = editor.visibleRange();
            Highlighter.applyRange(t, r[0], r[1]);
        } catch (RuntimeException ignore) { }
    }

    private final Runnable scrollHighlightRun = new Runnable() {
        public void run() { if (editor != null && editor.length() > Highlighter.FULL_LIMIT) highlightNow(); }
    };

    private final Runnable snapshotRun = new Runnable() {
        public void run() { pushSnapshot(); }
    };

    private final Runnable autoSaveRun = new Runnable() {
        public void run() {
            if (inEditor && settings.autoSave()) saveCurrent();
        }
    };

    private final Runnable suggestRun = new Runnable() {
        public void run() { refreshSuggestions(); }
    };

    // ------------------------------------------------------------------
    // lifecycle
    // ------------------------------------------------------------------

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Ui.init(this);
        settings = new AppSettings(this);
        com.dashers.j2mebuilderide.compiler.Compiler.setStackMapLongDoubleOneEntry(settings.stackMapLongDoubleOneEntry());
        Ui.applyTheme(Themes.theme(settings.theme()), settings.syntaxTheme());
        Ui.applySystemBars(this);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        applyKeepOn();

        installCrashLog();

        host = new FrameLayout(this);
        host.setBackgroundColor(Ui.BG);
        setContentView(host);

        final boolean savedFresh = (b == null);
        if (settings.showSplash() && b == null) {
            showSplash();
            final long t0 = System.currentTimeMillis();
            new Thread(new Runnable() {
                public void run() {
                    initEngine();
                    long left = 1500 - (System.currentTimeMillis() - t0);
                    if (left > 0) try { Thread.sleep(left); } catch (InterruptedException ignore) { }
                    splashStep(1f, "Ready");
                    try { Thread.sleep(260); } catch (InterruptedException ignore) { }
                    runOnUiThread(new Runnable() {
                        public void run() {
                            if (isFinishing()) return;
                            splashBar = null; splashStatus = null;
                            showHome();
                            if (savedFresh) showStartupPrompts();
                        }
                    });
                }
            }).start();
        } else {
            initEngine();
            showHome();
            if (b == null) showStartupPrompts();
        }
    }

    // ---- start-up prompts: shared storage question, then YouTube subscribe ----

    /** Same channel as the link in the About screen. */
    private static final String YOUTUBE_CHANNEL_URL = "https://www.youtube.com/@dash______animationv2";

    private void showStartupPrompts() {
        if (isFinishing()) return;
        com.dashers.j2mebuilderide.ide.UpdateChecker.checkInBackground(this);
        if (!usingShared() && !settings.sharedPromptDisabled()) {
            AlertDialog dlg = new AlertDialog.Builder(this, Ui.dialogTheme())
                    .setTitle("Use shared storage?")
                    .setMessage("Keep your projects in /J2MEBuilder/projects so they are visible in file "
                            + "managers and survive an app uninstall. Android will ask for storage permission.")
                    .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface d, int w) { enableSharedStorage(); }
                    })
                    .setNegativeButton("No", null)
                    .setNeutralButton("Don't ask again", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface d, int w) { settings.setSharedPromptDisabled(true); }
                    })
                    .create();
            dlg.setOnDismissListener(new DialogInterface.OnDismissListener() {
                public void onDismiss(DialogInterface d) { showSubscribePrompt(); }
            });
            dlg.show();
        } else {
            showSubscribePrompt();
        }
    }

    /** Shown every time the app is opened. */
    private void showSubscribePrompt() {
        if (isFinishing()) return;
        new AlertDialog.Builder(this, Ui.dialogTheme())
                .setTitle("Enjoying J2ME Builder?")
                .setMessage("Please subscribe to my YouTube channel for tutorials, updates and new tools. "
                        + "It's free and it really helps the project!")
                .setPositiveButton("Subscribe", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) {
                        try {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(YOUTUBE_CHANNEL_URL)));
                        } catch (Exception e) {
                            toast("Could not open YouTube");
                        }
                    }
                })
                .setNegativeButton("Later", null)
                .show();
    }

    // ---- start-up work (runs behind the splash screen) ----
    private SplashBar splashBar;
    private TextView splashStatus;

    private void splashStep(final float progress, final String text) {
        runOnUiThread(new Runnable() {
            public void run() {
                if (splashBar != null) splashBar.setProgress(progress);
                if (splashStatus != null) splashStatus.setText(text);
            }
        });
    }

    private void initEngine() {
        splashStep(0.25f, "Loading compiler");
        JCompilerBridge.init(this);
        splashStep(0.65f, "Loading libraries");
        if (settings.sharedStorage() && hasStoragePermission()) {
            String err = JCompilerBridge.tryUseRoot(sharedRoot());
            if (err.length() > 0) settings.setSharedStorage(false);
        }
        splashStep(0.9f, "Opening projects");
    }

    /** Splash: app icon, name, developer, animated progress. */
    private void showSplash() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Ui.BG);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);

        FrameLayout iconBox = new FrameLayout(this);
        iconBox.setBackground(Ui.rect(Ui.SURFACE, 32, Ui.STROKE));
        iconBox.setElevation(Ui.dp(6));
        View logo = appIconView();
        if (logo == null) logo = Ui.icon(this, R.drawable.ic_code, Ui.ACCENT, 48);
        iconBox.addView(logo, new FrameLayout.LayoutParams(Ui.dp(84), Ui.dp(84), Gravity.CENTER));
        col.addView(iconBox, Ui.lp(Ui.dp(120), Ui.dp(120)));

        // Full app name + vendor, on their own wide row so neither is ever clipped:
        // maxLines(2) + wrapping lets "J2ME Builder IDE" break onto a second line on a
        // narrow/old phone instead of being cut off, and letting the column be as wide as
        // the screen (instead of WRAP_CONTENT) stops a long word from forcing an early wrap.
        TextView name = Ui.label(this, "J2ME Builder IDE", 24, Ui.TEXT, true);
        name.setGravity(Gravity.CENTER);
        name.setMaxLines(2);
        name.setEllipsize(null);
        name.setPadding(Ui.dp(16), Ui.dp(22), Ui.dp(16), 0);
        col.addView(name, Ui.lp(Ui.MATCH, Ui.WRAP));
        TextView dev = Ui.label(this, "by DASH ANIMATION V2", 13, Ui.ACCENT, true);
        dev.setGravity(Gravity.CENTER);
        dev.setMaxLines(2);
        dev.setEllipsize(null);
        dev.setLetterSpacing(0.1f);
        dev.setPadding(Ui.dp(16), Ui.dp(6), Ui.dp(16), 0);
        col.addView(dev, Ui.lp(Ui.MATCH, Ui.WRAP));

        SplashBar bar = new SplashBar(this);
        col.addView(bar, Ui.lpMargin(Ui.dp(180), Ui.dp(4), 0, 40, 0, 0));
        TextView status = Ui.label(this, "Starting", 12, Ui.MUTED, false);
        status.setPadding(0, Ui.dp(12), 0, 0);
        col.addView(status);

        root.addView(col, new FrameLayout.LayoutParams(Ui.WRAP, Ui.WRAP, Gravity.CENTER));
        TextView ver = Ui.label(this, "V" + versionLabel(), 11.5f, Ui.MUTED, false);
        FrameLayout.LayoutParams vp = new FrameLayout.LayoutParams(Ui.WRAP, Ui.WRAP, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        vp.bottomMargin = Ui.dp(28);
        root.addView(ver, vp);

        splashBar = bar;
        splashStatus = status;
        host.removeAllViews();
        host.addView(root, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        backAction = null;

        // entrance animation
        iconBox.setAlpha(0f); iconBox.setScaleX(0.6f); iconBox.setScaleY(0.6f);
        iconBox.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(650)
                .setInterpolator(new android.view.animation.OvershootInterpolator(1.4f)).start();
        View[] later = {name, dev, bar, status, ver};
        for (int i = 0; i < later.length; i++) {
            later[i].setAlpha(0f);
            later[i].animate().alpha(1f).setStartDelay(260 + i * 90).setDuration(420).start();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (audioScreen != null) audioScreen.pause();
        if (inEditor) saveCurrent();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (log != null) log.clear();
    }

    @Override
    public void onBackPressed() {
        if (backAction != null) backAction.run();
        else super.onBackPressed();
    }

    private void applyKeepOn() {
        if (settings.keepScreenOn()) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    // ------------------------------------------------------------------
    // storage
    // ------------------------------------------------------------------

    private String sharedRoot() {
        return Environment.getExternalStorageDirectory().getPath() + "/J2MEBuilder/projects/";
    }

    private boolean hasStoragePermission() {
        if (Build.VERSION.SDK_INT < 23) return true;
        return checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean usingShared() {
        return JCompilerBridge.getRoot().equals(sharedRoot());
    }

    private void enableSharedStorage() {
        if (hasStoragePermission()) {
            applySharedStorage();
        } else {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.READ_EXTERNAL_STORAGE}, REQ_PERM);
        }
    }

    private void applySharedStorage() {
        String err = JCompilerBridge.tryUseRoot(sharedRoot());
        if (err.length() == 0) {
            settings.setSharedStorage(true);
            toast("Projects now live in /J2MEBuilder/projects");
        } else {
            settings.setSharedStorage(false);
            toast(err);
        }
        if (reshow != null) reshow.run();
    }

    private void disableSharedStorage() {
        String err = JCompilerBridge.tryUseRoot(JCompilerBridge.defaultRoot(this));
        settings.setSharedStorage(false);
        if (err.length() > 0) toast(err);
        else toast("Projects now live in the app folder");
        if (reshow != null) reshow.run();
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code == REQ_PERM) {
            if (hasStoragePermission()) applySharedStorage();
            else {
                toast("Storage permission denied - staying in app folder");
                if (reshow != null) reshow.run();
            }
        } else if (code == REQ_MIC) {
            Runnable granted = pendingMicGranted;
            pendingMicGranted = null;
            if (results.length > 0 && results[0] == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                if (granted != null) granted.run();
            } else {
                toast("Microphone permission denied - recording is off");
            }
        } else if (code == REQ_PERM_DL) {
            if (!hasStoragePermission()) {
                settings.setCopyToDownloads(false);
                toast("Storage permission denied - copy to Download turned off");
                if (reshow != null) reshow.run();
            }
        }
    }

    // ------------------------------------------------------------------
    // screen scaffolding
    // ------------------------------------------------------------------

    private void onTap(View v, final Runnable r) {
        v.setOnClickListener(new View.OnClickListener() {
            public void onClick(View x) { r.run(); }
        });
    }

    /** Swaps the whole screen. `back` runs for the system Back button; `again` rebuilds this screen. */
    private void present(View root, Runnable back, Runnable again) {
        host.setBackgroundColor(Ui.BG);
        host.removeAllViews();
        host.addView(root, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        backAction = back;
        reshow = again;
    }

    private void leaveEditorState() {
        drawerOpen = false;
        drawerPanel = null;
        drawerScrim = null;
        drawerList = null;
        drawerSearch = null;
        stopMidi();
        if (audioScreen != null) { audioScreen.release(); audioScreen = null; }
        inEditor = false;
        editor = null;
        handler.removeCallbacks(highlightRun);
        handler.removeCallbacks(snapshotRun);
        handler.removeCallbacks(autoSaveRun);
        handler.removeCallbacks(suggestRun);
        handler.removeCallbacks(liveCheckRun);
        if (log != null) log.clear();
        building = false;
        if (kbListener != null) {
            try {
                getWindow().getDecorView().getViewTreeObserver().removeOnGlobalLayoutListener(kbListener);
            } catch (Exception ignore) { }
            kbListener = null;
        }
        keyboardOpen = false;
        hideKeyboard();
    }

    // ------------------------------------------------------------------
    // crash log: the stack trace of the last crash is kept and shown at the next start
    // ------------------------------------------------------------------

    private File crashFile() { return new File(getFilesDir(), "last_crash.txt"); }

    private void installCrashLog() {
        final Thread.UncaughtExceptionHandler prev = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            public void uncaughtException(Thread t, Throwable ex) {
                try {
                    java.io.StringWriter sw = new java.io.StringWriter();
                    ex.printStackTrace(new java.io.PrintWriter(sw));
                    java.io.FileOutputStream fo = new java.io.FileOutputStream(crashFile());
                    fo.write(sw.toString().getBytes("UTF-8"));
                    fo.close();
                } catch (Throwable ignore) { }
                if (prev != null) prev.uncaughtException(t, ex);
            }
        });
        handler.postDelayed(new Runnable() {
            public void run() { showLastCrash(); }
        }, 600);
    }

    private void showLastCrash() {
        File f = crashFile();
        if (!f.exists()) return;
        String txt;
        try {
            txt = new String(readAll(new FileInputStream(f)), "UTF-8");
        } catch (Exception e) {
            return;
        }
        f.delete();
        if (txt.length() > 6000) txt = txt.substring(0, 6000);
        final String report = txt;
        new AlertDialog.Builder(this, Ui.dialogTheme())
                .setTitle("The app closed last time")
                .setMessage(report)
                .setPositiveButton("Copy", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) {
                        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                        if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("crash", report));
                        toast("Crash report copied");
                    }
                })
                .setNegativeButton("Close", null)
                .show();
    }

    private void hideKeyboard() {
        try {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            View f = getCurrentFocus();
            if (imm != null && f != null) imm.hideSoftInputFromWindow(f.getWindowToken(), 0);
        } catch (Exception ignore) { }
    }

    /** Title bar with a back arrow, optional subtitle and right-hand action views. */
    private LinearLayout topBar(String title, String sub, Runnable back, View... actions) {
        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(Ui.SURFACE);
        bar.setPadding(Ui.dp(4), Ui.dp(6), Ui.dp(8), Ui.dp(6));
        bar.setElevation(Ui.dp(2));
        if (back != null) {
            final Runnable b = back;
            ImageView ic = Ui.iconButton(this, R.drawable.ic_arrow_back, Ui.TEXT, new View.OnClickListener() {
                public void onClick(View v) { b.run(); }
            });
            bar.addView(ic, Ui.lp(Ui.dp(44), Ui.dp(44)));
        } else {
            bar.setPadding(Ui.dp(16), Ui.dp(6), Ui.dp(8), Ui.dp(6));
        }
        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        TextView t = Ui.label(this, title, 17, Ui.TEXT, true);
        t.setSingleLine(true);
        t.setEllipsize(android.text.TextUtils.TruncateAt.END);
        titles.addView(t);
        if (sub != null) {
            TextView s = Ui.label(this, sub, 12, Ui.MUTED, false);
            s.setSingleLine(true);
            s.setEllipsize(android.text.TextUtils.TruncateAt.END);
            titles.addView(s);
            subtitle = s;
        }
        bar.addView(titles, Ui.lpWeight(0, Ui.WRAP, 1));
        for (int i = 0; i < actions.length; i++) {
            if (actions[i] instanceof ImageView) bar.addView(actions[i], Ui.lp(Ui.dp(44), Ui.dp(44)));
            else bar.addView(actions[i]);
        }
        return bar;
    }

    /** Vertical page: top bar + scrolling body. Returns {root, body}. */
    private LinearLayout[] page(LinearLayout bar, int padDp) {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);
        root.addView(bar, Ui.lp(Ui.MATCH, Ui.WRAP));
        ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        sv.setFillViewport(true);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(Ui.dp(padDp), Ui.dp(padDp), Ui.dp(padDp), Ui.dp(40));
        sv.addView(body, new ScrollView.LayoutParams(Ui.MATCH, Ui.WRAP));
        root.addView(sv, Ui.lpWeight(Ui.MATCH, 0, 1));
        return new LinearLayout[]{root, body};
    }

    private ImageView chevron() {
        return Ui.icon(this, R.drawable.ic_chevron_right, Ui.MUTED, 24);
    }

    private String humanSize(long b) {
        if (b < 1024) return b + " B";
        return (Math.round(b / 102.4f) / 10f) + " KB";
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private PopupMenu popup(View anchor) {
        Context themed = new ContextThemeWrapper(this, Ui.dark
                ? android.R.style.Theme_Material : android.R.style.Theme_Material_Light);
        return new PopupMenu(themed, anchor);
    }

    // ------------------------------------------------------------------
    // 1. HOME
    // ------------------------------------------------------------------

    private void showHome() {
        leaveEditorState();
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);

        ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        sv.setFillViewport(true);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(Ui.dp(20), Ui.dp(32), Ui.dp(20), Ui.dp(24));
        sv.addView(col, new ScrollView.LayoutParams(Ui.MATCH, Ui.WRAP));
        root.addView(sv, Ui.lpWeight(Ui.MATCH, 0, 1));

        // ---- brand header ----
        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        View logo = appIconView();
        if (logo == null) {
            FrameLayout fb = new FrameLayout(this);
            fb.setBackground(Ui.rect(Ui.ACCENT, 16, 0));
            fb.addView(Ui.icon(this, R.drawable.ic_code, Ui.WHITE, 24), new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
            logo = fb;
        }
        head.addView(logo, Ui.lpMargin(Ui.dp(52), Ui.dp(52), 0, 0, 14, 0));
        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.addView(Ui.label(this, "J2ME Builder IDE", 22, Ui.TEXT, true));
        TextView by = Ui.label(this, "by DASH ANIMATION V2", 12, Ui.ACCENT, true);
        by.setPadding(0, Ui.dp(2), 0, 0);
        titles.addView(by);
        head.addView(titles, Ui.lpWeight(0, Ui.WRAP, 1));
        col.addView(head, Ui.lpMargin(Ui.MATCH, Ui.WRAP, 0, 0, 0, 24));

        // ---- main action + tool grid (titles only) ----
        col.addView(homeAction(R.drawable.ic_create_new_folder, "New project", "", true, new Runnable() {
            public void run() { showNewProject(); }
        }));
        col.addView(homeRow(
            homeTile(R.drawable.ic_folder_open, "Open", new Runnable() { public void run() { showOpenProject(); } }),
            homeTile(R.drawable.ic_file_upload, "Import", new Runnable() { public void run() { pickImportProjectZip(); } })));
        col.addView(homeRow(
            homeTile(R.drawable.ic_graphic_eq, "Audio Studio", new Runnable() {
                public void run() { showAudioStudio(new Runnable() { public void run() { showHome(); } }, false); }
            }),
            homeTile(R.drawable.ic_layers, "Libraries", new Runnable() {
                public void run() { showLibraries(new Runnable() { public void run() { showHome(); } }, false); }
            })));
        col.addView(homeRow(
            homeTile(R.drawable.ic_palette, "Color Palette", new Runnable() {
                public void run() { showColorPalette(new Runnable() { public void run() { showHome(); } }, false); }
            }),
            homeTile(R.drawable.ic_image, "Sprite Editor", new Runnable() {
                public void run() { showSpriteEditor(new Runnable() { public void run() { showHome(); } }, false, null); }
            })));
        col.addView(homeRow(
            homeTile(R.drawable.ic_settings, "Settings", new Runnable() {
                public void run() { showAppSettings(new Runnable() { public void run() { showHome(); } }); }
            }),
            homeTile(R.drawable.ic_info, "About", new Runnable() {
                public void run() { showAbout(new Runnable() { public void run() { showHome(); } }); }
            })));

        // ---- recent ----
        String[] recent = settings.recent();
        Vector valid = new Vector();
        for (int i = 0; i < recent.length; i++) {
            if (recent[i].length() > 0 && new File(JCompilerBridge.getRoot() + recent[i]).isDirectory()) valid.addElement(recent[i]);
        }
        if (valid.size() > 0) {
            col.addView(Ui.section(this, "Recent"));
            for (int i = 0; i < valid.size(); i++) col.addView(projectCard((String) valid.elementAt(i), false));
        }

        // ---- engine status ----
        LinearLayout engineRow = new LinearLayout(this);
        engineRow.setGravity(Gravity.CENTER_VERTICAL);
        View dot = new View(this);
        dot.setBackground(Ui.circle(JCompilerBridge.isReady() ? Ui.GREEN : Ui.RED));
        engineRow.addView(dot, Ui.lpMargin(Ui.dp(8), Ui.dp(8), 4, 0, 10, 0));
        engineRow.addView(Ui.label(this, JCompilerBridge.isReady() ? "Compiler ready"
                : "Compiler failed: " + JCompilerBridge.getLastError(), 13,
                JCompilerBridge.isReady() ? Ui.MUTED : Ui.RED, false));
        col.addView(engineRow, Ui.lpMargin(Ui.MATCH, Ui.WRAP, 0, 18, 0, 0));
        col.addView(Ui.label(this, com.dashers.j2mebuilderide.compiler.EcjCompiler.isAvailable()
                ? "ECJ compiler: active" : com.dashers.j2mebuilderide.ide.EcjLoader.status(), 12, Ui.MUTED, false),
                Ui.lpMargin(Ui.MATCH, Ui.WRAP, 0, 4, 0, 0));

        present(root, null, new Runnable() { public void run() { showHome(); } });
    }

    private View homeRow(View a, View b) {
        LinearLayout row = new LinearLayout(this);
        LinearLayout.LayoutParams pa = Ui.lpWeight(0, Ui.WRAP, 1);
        pa.setMargins(0, 0, Ui.dp(5), 0);
        LinearLayout.LayoutParams pb = Ui.lpWeight(0, Ui.WRAP, 1);
        pb.setMargins(Ui.dp(5), 0, 0, 0);
        row.addView(a, pa);
        row.addView(b, pb);
        row.setLayoutParams(Ui.lpMargin(Ui.MATCH, Ui.WRAP, 0, 0, 0, 10));
        return row;
    }

    private View homeTile(int icon, String title, final Runnable action) {
        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.VERTICAL);
        t.setPadding(Ui.dp(14), Ui.dp(14), Ui.dp(14), Ui.dp(14));
        t.setBackground(Ui.ripple(Ui.rect(Ui.SURFACE, 18, Ui.STROKE)));
        t.setClickable(true);
        onTap(t, action);
        FrameLayout badge = new FrameLayout(this);
        badge.setBackground(Ui.rect(Ui.ACCENT_SOFT, 12, 0));
        badge.addView(Ui.icon(this, icon, Ui.ACCENT, 24), new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        t.addView(badge, Ui.lp(Ui.dp(40), Ui.dp(40)));
        TextView l = Ui.label(this, title, 15, Ui.TEXT, true);
        l.setPadding(0, Ui.dp(10), 0, 0);
        t.addView(l);
        return t;
    }

    private View homeAction(int icon, String title, String sub, boolean primary, final Runnable action) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(Ui.dp(16), Ui.dp(16), Ui.dp(12), Ui.dp(16));
        row.setBackground(Ui.ripple(primary ? Ui.rect(Ui.ACCENT, 18, 0) : Ui.rect(Ui.SURFACE, 18, Ui.STROKE)));
        row.setClickable(true);
        onTap(row, action);

        FrameLayout badge = new FrameLayout(this);
        badge.setBackground(Ui.rect(primary ? 0x33FFFFFF : Ui.ACCENT_SOFT, 14, 0));
        badge.addView(Ui.icon(this, icon, primary ? Ui.WHITE : Ui.ACCENT, 24), new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        row.addView(badge, Ui.lpMargin(Ui.dp(44), Ui.dp(44), 0, 0, 14, 0));

        LinearLayout mid = new LinearLayout(this);
        mid.setOrientation(LinearLayout.VERTICAL);
        mid.addView(Ui.label(this, title, 16, primary ? Ui.WHITE : Ui.TEXT, true));
        if (sub != null && sub.length() > 0) {
            TextView s = Ui.label(this, sub, 12, primary ? 0xCCFFFFFF : Ui.MUTED, false);
            s.setPadding(0, Ui.dp(2), 0, 0);
            mid.addView(s);
        }
        row.addView(mid, Ui.lpWeight(0, Ui.WRAP, 1));
        row.addView(Ui.icon(this, R.drawable.ic_chevron_right, primary ? Ui.WHITE : Ui.MUTED, 24));
        row.setLayoutParams(Ui.lpMargin(Ui.MATCH, Ui.WRAP, 0, 0, 0, 10));
        return row;
    }

    // ------------------------------------------------------------------
    // 2. OPEN PROJECT (with search)
    // ------------------------------------------------------------------

    private Vector listProjectNames() {
        try {
            return splitNames(JCompilerBridge.listProjects());
        } catch (RuntimeException e) {
            return new Vector();
        }
    }

    private static Vector splitNames(String csv) {
        Vector v = new Vector();
        int pos = 0;
        while (pos <= csv.length()) {
            int c = csv.indexOf(',', pos);
            String part = (c < 0) ? csv.substring(pos) : csv.substring(pos, c);
            if (part.length() > 0) v.addElement(part);
            if (c < 0) break;
            pos = c + 1;
        }
        Collections.sort(v);
        return v;
    }

    private void showOpenProject() {
        leaveEditorState();
        final Runnable back = new Runnable() { public void run() { showHome(); } };
        ImageView add = Ui.iconButton(this, R.drawable.ic_add, Ui.ACCENT, new View.OnClickListener() {
            public void onClick(View v) { showNewProject(); }
        });
        ImageView imp = Ui.iconButton(this, R.drawable.ic_file_upload, Ui.ACCENT, new View.OnClickListener() {
            public void onClick(View v) { pickImportProjectZip(); }
        });
        LinearLayout[] pg = page(topBar("Open project", null, back, imp, add), 16);
        final LinearLayout body = pg[1];

        final EditText search = Ui.field(this, "Search projects", "");
        search.setCompoundDrawablePadding(Ui.dp(8));
        LinearLayout sRow = new LinearLayout(this);
        sRow.setGravity(Gravity.CENTER_VERTICAL);
        sRow.setBackground(Ui.rect(Ui.SURFACE2, 14, Ui.STROKE));
        sRow.setPadding(Ui.dp(12), 0, Ui.dp(4), 0);
        sRow.addView(Ui.icon(this, R.drawable.ic_search, Ui.MUTED, 24), Ui.lp(Ui.dp(24), Ui.dp(24)));
        search.setBackground(null);
        sRow.addView(search, Ui.lpWeight(0, Ui.WRAP, 1));
        body.addView(sRow, Ui.lpMargin(Ui.MATCH, Ui.WRAP, 0, 0, 0, 12));

        final LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        body.addView(list);

        final Vector names = listProjectNames();
        final Runnable fill = new Runnable() {
            public void run() {
                list.removeAllViews();
                String q = search.getText().toString().trim().toLowerCase();
                int shown = 0;
                for (int i = 0; i < names.size(); i++) {
                    String n = (String) names.elementAt(i);
                    if (q.length() > 0 && n.toLowerCase().indexOf(q) < 0) continue;
                    list.addView(projectCard(n, true));
                    shown++;
                }
                if (shown == 0) {
                    LinearLayout empty = new LinearLayout(MainActivity.this);
                    empty.setOrientation(LinearLayout.VERTICAL);
                    empty.setGravity(Gravity.CENTER);
                    empty.setPadding(Ui.dp(20), Ui.dp(56), Ui.dp(20), 0);
                    empty.addView(Ui.icon(MainActivity.this, R.drawable.ic_folder, Ui.MUTED, 56), Ui.lp(Ui.dp(56), Ui.dp(56)));
                    empty.addView(Ui.label(MainActivity.this, names.size() == 0 ? "No projects yet" : "No match", 16, Ui.TEXT, true));
                    TextView hint = Ui.label(MainActivity.this, names.size() == 0
                            ? "Tap + to create your first MIDlet." : "Try a different search.", 13, Ui.MUTED, false);
                    hint.setGravity(Gravity.CENTER);
                    empty.addView(hint);
                    list.addView(empty);
                }
            }
        };
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            public void onTextChanged(CharSequence s, int a, int b, int c) {}
            public void afterTextChanged(Editable e) { fill.run(); }
        });
        fill.run();
        present(pg[0], back, new Runnable() { public void run() { showOpenProject(); } });
    }

    private Bitmap loadProjectIcon(Project p) {
        try {
            if (p == null || p.icon == null || p.icon.length() == 0) return null;
            File f = new File(p.resUrl() + p.icon);
            if (!f.exists() || f.length() > 400000) return null;
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inSampleSize = 2;
            return BitmapFactory.decodeFile(f.getPath(), o);
        } catch (Throwable t) {
            return null;
        }
    }

    private View projectCard(final String name, final boolean withMenu) {
        File src = new File(JCompilerBridge.getRoot() + name + "/src");
        String[] files = src.list();
        int n = 0;
        if (files != null) for (int i = 0; i < files.length; i++) if (files[i].endsWith(".java")) n++;
        File jar = new File(JCompilerBridge.getRoot() + name + "/" + name + ".jar");
        Project meta = JCompilerBridge.peekProject(name);

        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(Ui.dp(14), Ui.dp(12), Ui.dp(withMenu ? 4 : 14), Ui.dp(12));
        row.setBackground(Ui.ripple(Ui.rect(Ui.SURFACE, 16, Ui.STROKE)));
        row.setClickable(true);

        Bitmap bm = loadProjectIcon(meta);
        if (bm != null) {
            ImageView iv = new ImageView(this);
            iv.setImageBitmap(bm);
            iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
            iv.setBackground(Ui.rect(Ui.SURFACE2, 12, 0));
            iv.setPadding(Ui.dp(6), Ui.dp(6), Ui.dp(6), Ui.dp(6));
            row.addView(iv, Ui.lpMargin(Ui.dp(44), Ui.dp(44), 0, 0, 14, 0));
        } else {
            TextView badge = Ui.label(this, name.substring(0, 1).toUpperCase(), 18, Ui.ACCENT, true);
            badge.setGravity(Gravity.CENTER);
            badge.setBackground(Ui.rect(Ui.ACCENT_SOFT, 12, 0));
            row.addView(badge, Ui.lpMargin(Ui.dp(44), Ui.dp(44), 0, 0, 14, 0));
        }

        LinearLayout mid = new LinearLayout(this);
        mid.setOrientation(LinearLayout.VERTICAL);
        TextView title = Ui.label(this, name, 16, Ui.TEXT, true);
        title.setSingleLine(true);
        mid.addView(title);
        String ver = (meta != null && meta.version.length() > 0) ? "v" + meta.version + "  \u00B7  " : "";
        String metaLine = ver + n + (n == 1 ? " file" : " files")
                + (jar.exists() ? "  \u00B7  " + humanSize(jar.length()) + " jar" : "  \u00B7  not built");
        TextView m = Ui.label(this, metaLine, 12, Ui.MUTED, false);
        m.setSingleLine(true);
        mid.addView(m);

        // last build status + date
        android.content.SharedPreferences bs = getSharedPreferences("buildstat", MODE_PRIVATE);
        long bt = bs.getLong("t_" + name, 0);
        String stText;
        int stCol;
        if (bt == 0) {
            stText = "Never built";
            stCol = Ui.MUTED;
        } else if (!bs.getBoolean("ok_" + name, false)) {
            int ec = bs.getInt("err_" + name, 0);
            stText = "Build failed" + (ec > 0 ? "  \u00B7  " + ec + (ec == 1 ? " error" : " errors") : "") + "  \u00B7  " + friendlyDate(bt);
            stCol = Ui.RED;
        } else {
            long ms = bs.getLong("ms_" + name, 0);
            stText = (bs.getBoolean("jarkind_" + name, false) ? "Built" : "Compiled") + "  \u00B7  " + friendlyDate(bt)
                    + (ms > 0 ? "  \u00B7  " + (Math.round(ms / 100f) / 10f) + " s" : "");
            stCol = Ui.GREEN;
            if (newestSource(src, 0) > bt + 1000) { stText += "  \u00B7  edited since"; stCol = Ui.AMBER; }
        }
        LinearLayout st = new LinearLayout(this);
        st.setGravity(Gravity.CENTER_VERTICAL);
        st.setPadding(0, Ui.dp(5), 0, 0);
        View dot = new View(this);
        dot.setBackground(Ui.circle(stCol));
        st.addView(dot, Ui.lpMargin(Ui.dp(7), Ui.dp(7), 0, 0, 7, 0));
        TextView stv = Ui.label(this, stText, 11.5f, stCol, false);
        stv.setSingleLine(true);
        st.addView(stv);
        mid.addView(st);
        row.addView(mid, Ui.lpWeight(0, Ui.WRAP, 1));

        if (withMenu) {
            final ImageView more = Ui.iconButton(this, R.drawable.ic_more_vert, Ui.MUTED, null);
            more.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    PopupMenu pm = popup(more);
                    pm.getMenu().add(0, 1, 0, "Open");
                    pm.getMenu().add(0, 2, 1, "Rename");
                    pm.getMenu().add(0, 3, 2, "Delete");
                    pm.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                        public boolean onMenuItemClick(MenuItem item) {
                            if (item.getItemId() == 1) openProjectScreen(name);
                            else if (item.getItemId() == 2) renameProjectDialog(name);
                            else confirmDeleteProject(name);
                            return true;
                        }
                    });
                    pm.show();
                }
            });
            row.addView(more, Ui.lp(Ui.dp(44), Ui.dp(44)));
        } else {
            row.addView(chevron());
        }
        onTap(row, new Runnable() { public void run() { openProjectScreen(name); } });
        row.setLayoutParams(Ui.lpMargin(Ui.MATCH, Ui.WRAP, 0, 0, 0, 10));
        return row;
    }

    private void confirmDeleteProject(final String name) {
        new AlertDialog.Builder(this, Ui.dialogTheme())
            .setTitle("Delete " + name + "?")
            .setMessage("All source files, resources and the built JAR will be removed.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int w) {
                    String err = JCompilerBridge.deleteProject(name);
                    if (err.length() > 0) toast(err);
                    settings.dropRecent(name);
                    if (reshow != null) reshow.run();
                }
            }).show();
    }

    private void renameProjectDialog(final String oldName) {
        final EditText name = Ui.field(this, "New project name", oldName);
        FrameLayout box = new FrameLayout(this);
        box.setPadding(Ui.dp(22), Ui.dp(8), Ui.dp(22), 0);
        box.addView(name);
        final AlertDialog dlg = new AlertDialog.Builder(this, Ui.dialogTheme())
            .setTitle("Rename project").setView(box)
            .setNegativeButton("Cancel", null).setPositiveButton("Rename", null).create();
        dlg.show();
        dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String n = name.getText().toString().trim();
                if (n.equals(oldName)) { dlg.dismiss(); return; }
                String err = JCompilerBridge.renameProject(oldName, n);
                if (err.length() > 0) { name.setError(err); return; }
                settings.dropRecent(oldName);
                dlg.dismiss();
                if (reshow != null) reshow.run();
            }
        });
    }

    private void openProjectScreen(String name) {
        String err = JCompilerBridge.openProject(name);
        if (err.length() > 0) { toast(err); return; }
        settings.pushRecent(name);
        showEditor("");
    }

    // ------------------------------------------------------------------
    // 3. NEW PROJECT
    // ------------------------------------------------------------------

    private static final int MAX_OBF_LEVEL = 9;
    private static final String[] OBF_NAMES = {
        "None", "1", "2", "3", "4", "5", "6", "7", "8", "9"
    };
    private static final String[] OBF_INFO = {
        "Readable names",
        "Short class names",
        "+ private members renamed",
        "+ protected members renamed",
        "+ package-private members renamed",
        "+ public members renamed",
        "+ debug metadata stripped",
        "+ line numbers stripped",
        "+ member order reversed",
        "Maximum: + all remaining metadata stripped"
    };

    /** Pill-style 0-9 obfuscation level slider: a SeekBar instead of a row of pills, so the
     *  level name/description never overlaps or gets cut off on a narrow phone screen. */
    private View obfuscationSlider(final int[] state, final TextView caption) {
        final LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackground(Ui.rect(Ui.SURFACE2, 14, Ui.STROKE));
        box.setPadding(Ui.dp(12), Ui.dp(10), Ui.dp(12), Ui.dp(10));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        final TextView levelLabel = Ui.label(this, "Level " + OBF_NAMES[state[0]], 14, Ui.TEXT, true);
        row.addView(levelLabel, Ui.lpWeight(0, Ui.WRAP, 1));
        final SeekBar bar = new SeekBar(this);
        bar.setMax(MAX_OBF_LEVEL);
        bar.setProgress(state[0]);
        row.addView(bar, Ui.lp(Ui.dp(170), Ui.WRAP));
        box.addView(row, Ui.lp(Ui.MATCH, Ui.WRAP));
        caption.setText(OBF_INFO[state[0]]);
        box.addView(caption);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar sb, int progress, boolean fromUser) {
                state[0] = progress;
                levelLabel.setText("Level " + OBF_NAMES[progress]);
                caption.setText(OBF_INFO[progress]);
            }
            public void onStartTrackingTouch(SeekBar sb) {}
            public void onStopTrackingTouch(SeekBar sb) {}
        });
        return box;
    }

    /** Pill-style 3-way selector. state[0] holds the chosen index. */
    private View segmented(final String[] labels, final int[] state, final TextView caption, final String[] captions) {
        final LinearLayout row = new LinearLayout(this);
        row.setBackground(Ui.rect(Ui.SURFACE2, 14, Ui.STROKE));
        row.setPadding(Ui.dp(3), Ui.dp(3), Ui.dp(3), Ui.dp(3));
        final TextView[] tvs = new TextView[labels.length];
        for (int i = 0; i < labels.length; i++) {
            final int idx = i;
            tvs[i] = Ui.label(this, labels[i], 14, Ui.TEXT, true);
            tvs[i].setGravity(Gravity.CENTER);
            tvs[i].setPadding(0, Ui.dp(10), 0, Ui.dp(10));
            tvs[i].setClickable(true);
            tvs[i].setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    state[0] = idx;
                    for (int k = 0; k < tvs.length; k++) {
                        boolean on = k == idx;
                        tvs[k].setTextColor(on ? Ui.WHITE : Ui.TEXT);
                        tvs[k].setBackground(on ? Ui.rect(Ui.ACCENT, 11, 0) : null);
                    }
                    if (caption != null) caption.setText(captions[idx]);
                }
            });
            row.addView(tvs[i], Ui.lpWeight(0, Ui.WRAP, 1));
        }
        tvs[state[0]].performClick();
        return row;
    }

    private View iconPickerRow(String currentName, Bitmap currentBitmap, final boolean forProject) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(Ui.dp(12), Ui.dp(10), Ui.dp(8), Ui.dp(10));
        row.setBackground(Ui.ripple(Ui.rect(Ui.SURFACE2, 12, Ui.STROKE)));
        row.setClickable(true);

        iconPreview = new ImageView(this);
        iconPreview.setScaleType(ImageView.ScaleType.FIT_CENTER);
        iconPreview.setBackground(Ui.rect(Ui.SURFACE2, 10, Ui.STROKE));
        iconPreview.setPadding(Ui.dp(4), Ui.dp(4), Ui.dp(4), Ui.dp(4));
        if (currentBitmap != null) iconPreview.setImageBitmap(currentBitmap);
        else iconPreview.setImageResource(R.drawable.ic_image);
        if (currentBitmap == null) Ui.setTint(iconPreview, Ui.MUTED);
        row.addView(iconPreview, Ui.lpMargin(Ui.dp(52), Ui.dp(52), 0, 0, 12, 0));

        LinearLayout mid = new LinearLayout(this);
        mid.setOrientation(LinearLayout.VERTICAL);
        iconLabel = Ui.label(this, currentName.length() > 0 ? currentName : "No icon selected", 14, Ui.TEXT, true);
        iconLabel.setSingleLine(true);
        iconLabel.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
        mid.addView(iconLabel);
        mid.addView(Ui.label(this, "Tap to pick a PNG / JPG from your phone", 12, Ui.MUTED, false));
        row.addView(mid, Ui.lpWeight(0, Ui.WRAP, 1));

        ImageView clear = Ui.iconButton(this, R.drawable.ic_close, Ui.MUTED, new View.OnClickListener() {
            public void onClick(View v) { clearIcon(forProject); }
        });
        row.addView(clear, Ui.lp(Ui.dp(40), Ui.dp(40)));
        onTap(row, new Runnable() { public void run() { pickIcon(forProject); } });
        return row;
    }

    private void pickIcon(boolean forProject) {
        iconForProject = forProject;
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("image/*");
        try {
            startActivityForResult(i, REQ_ICON);
        } catch (Exception e) {
            toast("No file picker available: " + e.getMessage());
        }
    }

    private void clearIcon(boolean forProject) {
        pendingIconBytes = null;
        pendingIconName = "";
        if (forProject) {
            JCompilerBridge.setIcon("");
        }
        if (iconPreview != null) {
            iconPreview.setImageResource(R.drawable.ic_image);
            Ui.setTint(iconPreview, Ui.MUTED);
        }
        if (iconLabel != null) iconLabel.setText("No icon selected");
    }

    /** Decodes any image and re-encodes it as a PNG no larger than 128px (J2ME icons must be PNG). */
    private byte[] toIconPng(Uri uri) {
        try {
            byte[] raw = readAll(getContentResolver().openInputStream(uri));
            BitmapFactory.Options b = new BitmapFactory.Options();
            b.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(raw, 0, raw.length, b);
            int sample = 1;
            while (b.outWidth / (sample * 2) >= 256 && b.outHeight / (sample * 2) >= 256) sample *= 2;
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inSampleSize = sample;
            Bitmap bm = BitmapFactory.decodeByteArray(raw, 0, raw.length, o);
            if (bm == null) return null;
            int w = bm.getWidth(), h = bm.getHeight(), max = Math.max(w, h);
            if (max > 128) {
                float k = 128f / max;
                bm = Bitmap.createScaledBitmap(bm, Math.max(1, Math.round(w * k)), Math.max(1, Math.round(h * k)), true);
            }
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            bm.compress(Bitmap.CompressFormat.PNG, 100, bos);
            return bos.toByteArray();
        } catch (Throwable t) {
            return null;
        }
    }

    /** Lists every image in the project's res/ folder so the user can pick the icon (auto-detected one is marked). */
    private void showResIconChooser() {
        final Project cp = JCompilerBridge.getCurrent();
        if (cp == null) return;
        Vector all = JCompilerBridge.listResources();
        final Vector imgs = new Vector();
        for (int i = 0; i < all.size(); i++) {
            String rel = (String) all.elementAt(i);
            String low = rel.toLowerCase();
            if (low.endsWith(".png") || low.endsWith(".jpg") || low.endsWith(".jpeg") || low.endsWith(".gif") || low.endsWith(".bmp")) imgs.addElement(rel);
        }
        if (imgs.size() == 0) { toast("No images found in res/ - add some in the Files screen first"); return; }
        final String auto = JCompilerBridge.autoIconCandidate();

        ScrollView sv = new ScrollView(this);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(Ui.dp(10), Ui.dp(6), Ui.dp(10), Ui.dp(6));
        sv.addView(col, new FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP));
        final AlertDialog[] dlg = new AlertDialog[1];

        if (auto.length() > 0) {
            TextView best = Ui.pill(this, "Use auto-detected: " + auto, Ui.ACCENT, Ui.WHITE, new View.OnClickListener() {
                public void onClick(View v) { applyResIcon(auto); if (dlg[0] != null) dlg[0].dismiss(); }
            });
            best.setSingleLine(true);
            best.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
            col.addView(best, Ui.lpMargin(Ui.MATCH, Ui.WRAP, 0, 0, 0, 8));
        }
        final int cols = 3;
        LinearLayout rowL = null;
        for (int i = 0; i < imgs.size(); i++) {
            if (i % cols == 0) {
                rowL = new LinearLayout(this);
                col.addView(rowL, Ui.lp(Ui.MATCH, Ui.WRAP));
            }
            final String rel = (String) imgs.elementAt(i);
            LinearLayout cell = new LinearLayout(this);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(Gravity.CENTER_HORIZONTAL);
            cell.setPadding(Ui.dp(4), Ui.dp(6), Ui.dp(4), Ui.dp(6));
            cell.setBackground(Ui.ripple(Ui.rect(rel.equals(auto) ? ((Ui.ACCENT & 0x00FFFFFF) | 0x33000000) : 0x00000000, 10, 0)));
            cell.setClickable(true);
            ImageView iv = new ImageView(this);
            iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
            iv.setBackground(Ui.rect(Ui.SURFACE2, 8, Ui.STROKE));
            iv.setPadding(Ui.dp(3), Ui.dp(3), Ui.dp(3), Ui.dp(3));
            String dims = "";
            try {
                String path = cp.resUrl() + rel;
                BitmapFactory.Options bo = new BitmapFactory.Options();
                bo.inJustDecodeBounds = true;
                BitmapFactory.decodeFile(path, bo);
                dims = bo.outWidth + "x" + bo.outHeight;
                int sample = 1;
                while (bo.outWidth / (sample * 2) >= 160 && bo.outHeight / (sample * 2) >= 160) sample *= 2;
                BitmapFactory.Options o2 = new BitmapFactory.Options();
                o2.inSampleSize = sample;
                Bitmap th = BitmapFactory.decodeFile(path, o2);
                if (th != null) iv.setImageBitmap(th); else iv.setImageResource(R.drawable.ic_image);
            } catch (Throwable t) { iv.setImageResource(R.drawable.ic_image); }
            cell.addView(iv, Ui.lp(Ui.dp(72), Ui.dp(72)));
            TextView nm = Ui.label(this, rel.substring(rel.lastIndexOf('/') + 1), 11.5f, Ui.TEXT, false);
            nm.setSingleLine(true);
            nm.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
            nm.setGravity(Gravity.CENTER);
            cell.addView(nm, Ui.lpMargin(Ui.MATCH, Ui.WRAP, 0, 4, 0, 0));
            cell.addView(Ui.label(this, dims + (rel.equals(auto) ? "  \u2605" : ""), 10.5f, Ui.MUTED, false));
            onTap(cell, new Runnable() {
                public void run() { applyResIcon(rel); if (dlg[0] != null) dlg[0].dismiss(); }
            });
            rowL.addView(cell, Ui.lpWeight(0, Ui.WRAP, 1));
        }
        // fill the last row so cells keep equal width
        if (rowL != null) for (int k = imgs.size() % cols; k != 0 && k < cols; k++) rowL.addView(new Space(this), Ui.lpWeight(0, Ui.WRAP, 1));

        dlg[0] = new AlertDialog.Builder(this, Ui.dialogTheme())
            .setTitle("Choose icon from res (" + imgs.size() + ")")
            .setView(sv)
            .setNegativeButton("Cancel", null)
            .show();
    }

    /** Sets the MIDlet icon from a res/ image. PNG files are used as they are; other formats are converted to icon.png (max 128px). */
    private void applyResIcon(String rel) {
        Project cp = JCompilerBridge.getCurrent();
        if (cp == null) return;
        String use = rel;
        if (!rel.toLowerCase().endsWith(".png")) {
            try {
                byte[] raw = readAll(new java.io.FileInputStream(cp.resUrl() + rel));
                byte[] png = rawToIconPng(raw);
                if (png == null) { toast("Could not read " + rel); return; }
                String err = JCompilerBridge.writeResource("icon.png", png);
                if (err.length() > 0) { toast(err); return; }
                use = "icon.png";
            } catch (Throwable t) { toast("Could not convert " + rel + ": " + t.getMessage()); return; }
        }
        JCompilerBridge.setIcon(use);
        cp.icon = use;
        Bitmap bm = loadProjectIcon(cp);
        if (iconPreview != null && bm != null) { iconPreview.setColorFilter(null); iconPreview.setImageBitmap(bm); }
        if (iconLabel != null) iconLabel.setText(use.equals(rel) ? use : rel + "  \u2192  " + use);
        toast("Icon: " + use);
    }

    /** Decodes image bytes and re-encodes them as a PNG no larger than 128px. */
    private byte[] rawToIconPng(byte[] raw) {
        try {
            BitmapFactory.Options b = new BitmapFactory.Options();
            b.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(raw, 0, raw.length, b);
            int sample = 1;
            while (b.outWidth / (sample * 2) >= 256 && b.outHeight / (sample * 2) >= 256) sample *= 2;
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inSampleSize = sample;
            Bitmap bm = BitmapFactory.decodeByteArray(raw, 0, raw.length, o);
            if (bm == null) return null;
            int w = bm.getWidth(), h = bm.getHeight(), max = Math.max(w, h);
            if (max > 128) {
                float k = 128f / max;
                bm = Bitmap.createScaledBitmap(bm, Math.max(1, Math.round(w * k)), Math.max(1, Math.round(h * k)), true);
            }
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            bm.compress(Bitmap.CompressFormat.PNG, 100, bos);
            return bos.toByteArray();
        } catch (Throwable t) {
            return null;
        }
    }

    private void onIconPicked(Uri uri) {
        byte[] png = toIconPng(uri);
        if (png == null) { toast("Could not read that image"); return; }
        String shown = displayName(uri);
        pendingIconBytes = png;
        pendingIconName = shown;
        Bitmap bm = BitmapFactory.decodeByteArray(png, 0, png.length);
        if (iconPreview != null) {
            iconPreview.setColorFilter(null);
            iconPreview.setImageBitmap(bm);
        }
        if (iconLabel != null) iconLabel.setText(shown + "  \u2192  icon.png");
        if (iconForProject) {
            String err = JCompilerBridge.writeResource("icon.png", png);
            if (err.length() > 0) { toast(err); return; }
            JCompilerBridge.setIcon("icon.png");
        }
    }

    private void showNewProject() {
        leaveEditorState();
        pendingIconBytes = null;
        pendingIconName = "";
        final Runnable back = new Runnable() { public void run() { showHome(); } };
        LinearLayout[] pg = page(topBar("New project", "Set up your MIDlet", back), 18);
        final LinearLayout body = pg[1];

        // ---- fields ----
        final EditText nameF = Ui.field(this, "e.g. My Game", "");
        final EditText verF = Ui.field(this, "1.0.0", "1.0.0");
        final EditText vendorF = Ui.field(this, "Your name or company", "DASH ANIMATION V2");
        final EditText mainF = Ui.field(this, "Detected from the name", "");
        final EditText packageF = Ui.field(this, "e.g. com.example.myapp", "com.example.myapp");
        final boolean[] autoMain = {true};
        final boolean[] setting = {false};
        final TextView folderHint = Ui.label(this, "Project folder: -", 12, Ui.MUTED, false);

        body.addView(Ui.labeled(this, "MIDlet-Name", nameF));
        body.addView(Ui.labeled(this, "MIDlet-Version", verF));
        body.addView(Ui.labeled(this, "MIDlet-Vendor", vendorF));
        body.addView(Ui.labeled(this, "Package Name", packageF));

        // ---- MIDlet descriptor / manifest options ----
        final EditText descF = Ui.field(this, "Application description", "");
        final EditText infoUrlF = Ui.field(this, "https://example.com", "");
        final EditText permissionsF = Ui.field(this, "javax.microedition.io.Connector.http", "");
        final EditText permissionsOptF = Ui.field(this, "javax.microedition.io.Connector.socket", "");
        final EditText dataSizeF = Ui.field(this, "RMS storage size in bytes (optional)", "");
        final EditText installNotifyF = Ui.field(this, "Install notification URL (optional)", "");
        final EditText deleteNotifyF = Ui.field(this, "Delete notification URL (optional)", "");
        final EditText nokiaCategoryF = Ui.field(this, "Application", "Application");
        final EditText nokiaNameF = Ui.field(this, "Nokia application name (optional)", "");
        final EditText pushF = Ui.field(this, "protocol://:port,ClassName,*", "");

        LinearLayout descriptorBox = new LinearLayout(this);
        descriptorBox.setOrientation(LinearLayout.VERTICAL);
        descriptorBox.setPadding(0, Ui.dp(4), 0, Ui.dp(4));
        descriptorBox.addView(Ui.labeled(this, "MIDlet-Description", descF));
        descriptorBox.addView(Ui.labeled(this, "MIDlet-Info-URL", infoUrlF));
        descriptorBox.addView(Ui.labeled(this, "MIDlet-Permissions", permissionsF));
        descriptorBox.addView(Ui.labeled(this, "MIDlet-Permissions-Opt", permissionsOptF));
        descriptorBox.addView(Ui.labeled(this, "MIDlet-Data-Size", dataSizeF));
        descriptorBox.addView(Ui.labeled(this, "MIDlet-Install-Notify", installNotifyF));
        descriptorBox.addView(Ui.labeled(this, "MIDlet-Delete-Notify", deleteNotifyF));
        descriptorBox.addView(Ui.labeled(this, "Nokia-MIDlet-Category", nokiaCategoryF));
        descriptorBox.addView(Ui.labeled(this, "Nokia-MIDlet-Name", nokiaNameF));
        descriptorBox.addView(Ui.labeled(this, "MIDlet-Push-1", pushF));
        body.addView(collapsible("Advanced descriptor options", descriptorBox, false));

        LinearLayout mainBox = new LinearLayout(this);
        mainBox.setOrientation(LinearLayout.VERTICAL);
        mainBox.addView(mainF, Ui.lp(Ui.MATCH, Ui.WRAP));
        final TextView autoNote = Ui.label(this, "", 11.5f, Ui.MUTED, false);
        autoNote.setPadding(Ui.dp(4), Ui.dp(6), 0, 0);
        body.addView(Ui.labeled(this, "MainClass", mainBox));

        nameF.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            public void onTextChanged(CharSequence s, int a, int b, int c) {}
            public void afterTextChanged(Editable e) {
                String clean = JCompilerBridge.sanitize(e.toString());
                folderHint.setText("Project folder: " + (clean.length() > 0 ? clean : "-"));
                if (autoMain[0]) {
                    setting[0] = true;
                    mainF.setText(clean);
                    setting[0] = false;
                }
            }
        });
        mainF.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            public void onTextChanged(CharSequence s, int a, int b, int c) {}
            public void afterTextChanged(Editable e) {
                if (setting[0]) return;
                autoMain[0] = false;
                autoNote.setText("Custom class name.");
            }
        });

        // ---- icon ----
        body.addView(Ui.labeled(this, "Icon File", iconPickerRow("", null, false)));

        // ---- obfuscation ----
        final int[] obf = {0};
        final TextView obfCap = Ui.label(this, OBF_INFO[0], 11.5f, Ui.MUTED, false);
        obfCap.setPadding(Ui.dp(4), Ui.dp(6), 0, 0);
        body.addView(Ui.labeled(this, "Obfuscation Level", obfuscationSlider(obf, obfCap)));

        // ---- template ----
        final int[] chosen = {0};
        final TextView[] chips = new TextView[Templates.NAMES.length];
        LinearLayout chipRow = new LinearLayout(this);
        for (int i = 0; i < chips.length; i++) {
            final int idx = i;
            chips[i] = Ui.pill(this, Templates.NAMES[i], 0, Ui.TEXT, null);
            chips[i].setTextSize(12.5f);
            chips[i].setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    chosen[0] = idx;
                    for (int k = 0; k < chips.length; k++) {
                        boolean on = k == idx;
                        chips[k].setTextColor(on ? Ui.WHITE : Ui.TEXT);
                        chips[k].setBackground(Ui.ripple(on ? Ui.rect(Ui.ACCENT, 20, 0) : Ui.rect(0, 20, Ui.STROKE)));
                    }
                }
            });
            chipRow.addView(chips[i], Ui.lpMargin(Ui.WRAP, Ui.WRAP, 0, 0, 8, 0));
        }
        chips[0].performClick();
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        hs.addView(chipRow);
        body.addView(Ui.labeled(this, "Template", hs));
        body.addView(folderHint, Ui.lpMargin(Ui.WRAP, Ui.WRAP, 4, 0, 0, 14));

        // ---- create ----
        TextView create = Ui.pill(this, "Create project", Ui.ACCENT, Ui.WHITE, null);
        create.setTextSize(15);
        create.setPadding(0, Ui.dp(14), 0, Ui.dp(14));
        create.setBackground(Ui.ripple(Ui.rect(Ui.ACCENT, 16, 0)));
        body.addView(create, Ui.lp(Ui.MATCH, Ui.WRAP));
        create.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String midletName = nameF.getText().toString().trim();
                if (midletName.length() == 0) { nameF.setError("Enter a MIDlet-Name"); nameF.requestFocus(); return; }
                String folder = JCompilerBridge.sanitize(midletName);
                String bad = JCompilerBridge.validateClassName(folder);
                if (bad.length() > 0) { nameF.setError("Use letters or digits in the name"); return; }
                String packageName = packageF.getText().toString().trim();
                String packageError = JCompilerBridge.validatePackageName(packageName);
                if (packageError.length() > 0) { packageF.setError(packageError); packageF.requestFocus(); return; }
                String mainClass = mainF.getText().toString().trim();
                if (mainClass.length() == 0) mainClass = folder;
                bad = JCompilerBridge.validateClassName(mainClass);
                if (bad.length() > 0) { mainF.setError(bad); return; }
                if (new File(JCompilerBridge.getRoot() + folder).exists()) {
                    nameF.setError("A project named " + folder + " already exists");
                    return;
                }
                String ver = verF.getText().toString().trim();
                if (ver.length() == 0) ver = "1.0.0";
                String vendor = vendorF.getText().toString().trim();
                if (vendor.length() == 0) vendor = "Unknown";
                String err = JCompilerBridge.createProjectFull(folder, chosen[0], midletName, ver, vendor,
                        packageName, mainClass, obf[0], pendingIconBytes != null ? "icon.png" : "", pendingIconBytes);
                if (err.length() > 0) { toast(err); return; }
                JCompilerBridge.configureDescriptor(
                        descF.getText().toString(), infoUrlF.getText().toString(),
                        permissionsF.getText().toString(), permissionsOptF.getText().toString(),
                        installNotifyF.getText().toString(), deleteNotifyF.getText().toString(),
                        dataSizeF.getText().toString(), nokiaCategoryF.getText().toString(),
                        nokiaNameF.getText().toString(), pushF.getText().toString());
                hideKeyboard();
                settings.pushRecent(folder);
                toast("Project saved");
                showEditor("");
            }
        });
        present(pg[0], back, new Runnable() { public void run() { showNewProject(); } });
    }

    // ------------------------------------------------------------------
    // 4. PROJECT SETTINGS (gear icon / 3-dot menu inside a project)
    // ------------------------------------------------------------------

    private void showProjectSettings() {
        saveCurrent();
        final Project p = JCompilerBridge.getCurrent();
        if (p == null) { showHome(); return; }
        final String fileToReopen = openFile;
        leaveEditorState();
        pendingIconBytes = null;
        pendingIconName = "";
        final Runnable back = new Runnable() { public void run() { showEditor(fileToReopen); } };
        LinearLayout[] pg = page(topBar("Project settings", p.folderName, back), 18);
        final LinearLayout body = pg[1];

        final EditText nameF = Ui.field(this, "MIDlet-Name", p.midletName.length() > 0 ? p.midletName : p.folderName);
        final EditText verF = Ui.field(this, "1.0.0", p.version);
        final EditText vendorF = Ui.field(this, "DASH ANIMATION V2", p.vendor);
        final EditText mainF = Ui.field(this, "MIDlet main class", p.mainClass);
        final EditText packageF = Ui.field(this, "e.g. com.example.myapp", p.packageName);
        final EditText descF = Ui.field(this, "Application description", p.description);
        final EditText infoUrlF = Ui.field(this, "https://example.com", p.infoUrl);
        final EditText permF = Ui.field(this, "javax.microedition.io.Connector.http, ...", p.permissions);
        final EditText permOptF = Ui.field(this, "Optional permissions, comma-separated", p.permissionsOpt);
        final EditText dataSizeF = Ui.field(this, "0", String.valueOf(p.dataSize));
        final EditText installF = Ui.field(this, "Install notification URL", p.installNotify);
        final EditText deleteF = Ui.field(this, "Delete notification URL", p.deleteNotify);
        final EditText nokiaCatF = Ui.field(this, "Application", p.nokiaCategory);
        final EditText nokiaNameF = Ui.field(this, "Optional Nokia MIDlet name", p.nokiaName);
        final EditText pushF = Ui.field(this, "protocol://:port,ClassName,*", p.pushRegistration);

        body.addView(Ui.section(this, "MIDlet descriptor"));
        body.addView(Ui.labeled(this, "MIDlet-Name", nameF));
        body.addView(Ui.labeled(this, "MIDlet-Version", verF));
        body.addView(Ui.labeled(this, "MIDlet-Vendor", vendorF));
        body.addView(Ui.labeled(this, "Package Name", packageF));
        body.addView(Ui.labeled(this, "MIDlet-Description", descF));
        body.addView(Ui.labeled(this, "MIDlet-Info-URL", infoUrlF));

        LinearLayout mainBox = new LinearLayout(this);
        mainBox.setOrientation(LinearLayout.VERTICAL);
        mainBox.addView(mainF, Ui.lp(Ui.MATCH, Ui.WRAP));
        TextView detect = Ui.pill(this, "Detect MIDlet class", 0, Ui.ACCENT, null);
        detect.setTextSize(12.5f);
        mainBox.addView(detect, Ui.lpMargin(Ui.WRAP, Ui.WRAP, 0, 8, 0, 0));
        detect.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                final Vector found = JCompilerBridge.detectMidletClasses();
                if (found.size() == 0) { toast("No class extending MIDlet found"); return; }
                if (found.size() == 1) { mainF.setText((String) found.elementAt(0)); toast("Detected " + found.elementAt(0)); return; }
                final String[] items = new String[found.size()];
                for (int i = 0; i < items.length; i++) items[i] = (String) found.elementAt(i);
                new AlertDialog.Builder(MainActivity.this, Ui.dialogTheme())
                    .setTitle("Pick the main MIDlet")
                    .setItems(items, new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface d, int which) { mainF.setText(items[which]); }
                    }).show();
            }
        });
        body.addView(Ui.labeled(this, "MainClass", mainBox));

        if (p.icon == null || p.icon.length() == 0 || !new File(p.resUrl() + p.icon).isFile()) {
            String auto = JCompilerBridge.autoIconCandidate();   // pick from the project's res/ images
            if (auto.length() > 0) { JCompilerBridge.setIcon(auto); p.icon = auto; }
        }
        Bitmap cur = loadProjectIcon(p);
        body.addView(Ui.labeled(this, "Icon File", iconPickerRow(p.icon, cur, true)));
        TextView autoIcon = Ui.pill(this, "Auto-detect / choose from res", 0, Ui.ACCENT, new View.OnClickListener() {
            public void onClick(View v) { showResIconChooser(); }
        });
        body.addView(autoIcon, Ui.lpMargin(Ui.WRAP, Ui.WRAP, 0, 6, 0, 0));

        final int[] obf = {Math.max(0, Math.min(MAX_OBF_LEVEL, p.obfuscation))};
        final TextView obfCap = Ui.label(this, OBF_INFO[obf[0]], 11.5f, Ui.MUTED, false);
        obfCap.setPadding(Ui.dp(4), Ui.dp(6), 0, 0);
        body.addView(Ui.labeled(this, "Obfuscation Level", obfuscationSlider(obf, obfCap)));

        LinearLayout adv = new LinearLayout(this);
        adv.setOrientation(LinearLayout.VERTICAL);
        adv.addView(Ui.section(this, "Permissions and installation"));
        adv.addView(Ui.labeled(this, "MIDlet-Permissions", permF));
        adv.addView(Ui.labeled(this, "MIDlet-Permissions-Opt", permOptF));
        adv.addView(Ui.labeled(this, "MIDlet-Data-Size", dataSizeF));
        adv.addView(Ui.labeled(this, "MIDlet-Install-Notify", installF));
        adv.addView(Ui.labeled(this, "MIDlet-Delete-Notify", deleteF));

        adv.addView(Ui.section(this, "Legacy Nokia / Push metadata"));
        adv.addView(Ui.labeled(this, "Nokia-MIDlet-Category", nokiaCatF));
        adv.addView(Ui.labeled(this, "Nokia-MIDlet-Name", nokiaNameF));
        adv.addView(Ui.labeled(this, "MIDlet-Push-1", pushF));

        body.addView(collapsible("Advanced", adv, false));

        TextView save = Ui.pill(this, "Save changes", Ui.ACCENT, Ui.WHITE, null);
        save.setTextSize(15);
        save.setPadding(0, Ui.dp(14), 0, Ui.dp(14));
        save.setBackground(Ui.ripple(Ui.rect(Ui.ACCENT, 16, 0)));
        body.addView(save, Ui.lp(Ui.MATCH, Ui.WRAP));
        save.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String mc = mainF.getText().toString().trim();
                String packageName = packageF.getText().toString().trim();
                String packageBad = JCompilerBridge.validatePackageName(packageName);
                if (packageBad.length() > 0) { packageF.setError(packageBad); return; }
                String bad = JCompilerBridge.validateClassName(mc);
                if (bad.length() > 0) { mainF.setError(bad); return; }
                String mn = nameF.getText().toString().trim();
                JCompilerBridge.setMidletName(mn.equals(p.folderName) ? "" : mn);
                JCompilerBridge.setVersion(verF.getText().toString().trim());
                String vendor = vendorF.getText().toString().trim();
                if (vendor.length() == 0) vendor = "DASH ANIMATION V2";
                JCompilerBridge.setVendor(vendor);
                JCompilerBridge.setMainClass(mc);
                JCompilerBridge.setPackageName(packageName);
                JCompilerBridge.setDescription(descF.getText().toString().trim());
                JCompilerBridge.setInfoUrl(infoUrlF.getText().toString().trim());
                JCompilerBridge.setPermissions(permF.getText().toString().trim());
                JCompilerBridge.setPermissionsOpt(permOptF.getText().toString().trim());
                int dataSize = 0;
                try { dataSize = Math.max(0, Integer.parseInt(dataSizeF.getText().toString().trim())); }
                catch (NumberFormatException ignored) { dataSizeF.setError("Enter a valid number"); return; }
                JCompilerBridge.setDataSize(dataSize);
                JCompilerBridge.setInstallNotify(installF.getText().toString().trim());
                JCompilerBridge.setDeleteNotify(deleteF.getText().toString().trim());
                JCompilerBridge.setNokiaCategory(nokiaCatF.getText().toString().trim());
                JCompilerBridge.setNokiaName(nokiaNameF.getText().toString().trim());
                JCompilerBridge.setPushRegistration(pushF.getText().toString().trim());
                JCompilerBridge.setObfuscation(obf[0]);
                String err = JCompilerBridge.saveProperties();
                if (err.length() == 0) { hideKeyboard(); toast("Project settings saved"); back.run(); }
                else toast(err);
            }
        });

        // ---- project tools ----
        body.addView(Ui.section(this, "Project tools"));
        LinearLayout tools = Ui.card(this);
        tools.addView(toolTile(R.drawable.ic_layers, "Resources", "", new Runnable() {
            public void run() { resourcesDialog(); }
        }));
        tools.addView(Ui.divider(this));
        tools.addView(toolTile(R.drawable.ic_layers, "Libraries", "", new Runnable() {
            public void run() { showLibraries(back, true); }
        }));
        tools.addView(Ui.divider(this));
        tools.addView(toolTile(R.drawable.ic_file_upload, "Import files", "", new Runnable() {
            public void run() { pickImportFiles(); }
        }));
        tools.addView(Ui.divider(this));
        tools.addView(toolTile(R.drawable.ic_file_download, "Export JAR + JAD", "", new Runnable() {
            public void run() { pickExportFolder(); }
        }));
        tools.addView(Ui.divider(this));
        tools.addView(toolTile(R.drawable.ic_content_copy, "Export project (.zip)", "", new Runnable() {
            public void run() { pickExportZip(); }
        }));
        body.addView(tools);

        present(pg[0], back, new Runnable() { public void run() { showProjectSettings(); } });
    }

    private View toolTile(int icon, String title, String sub, final Runnable r) {
        LinearLayout t = Ui.tile(this, icon, title, sub, chevron());
        onTap(t, r);
        return t;
    }

    // ------------------------------------------------------------------
    // MIDI + optional Java ME graphics libraries
    // ------------------------------------------------------------------
    // ---- small shared widgets ----

    private View collapsible(String title, final View content, boolean open) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setPadding(Ui.dp(14), Ui.dp(12), Ui.dp(10), Ui.dp(12));
        head.setBackground(Ui.ripple(Ui.rect(Ui.SURFACE2, 14, Ui.STROKE)));
        head.setClickable(true);
        head.addView(Ui.label(this, title, 14, Ui.TEXT, true), Ui.lpWeight(0, Ui.WRAP, 1));
        final ImageView arrow = Ui.icon(this, open ? R.drawable.ic_expand_less : R.drawable.ic_expand_more, Ui.MUTED, 24);
        head.addView(arrow);
        content.setVisibility(open ? View.VISIBLE : View.GONE);
        head.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                boolean show = content.getVisibility() != View.VISIBLE;
                content.setVisibility(show ? View.VISIBLE : View.GONE);
                arrow.setImageResource(show ? R.drawable.ic_expand_less : R.drawable.ic_expand_more);
            }
        });
        box.addView(head);
        box.addView(content, Ui.lpMargin(Ui.MATCH, Ui.WRAP, 0, 10, 0, 0));
        box.setLayoutParams(Ui.lpMargin(Ui.MATCH, Ui.WRAP, 0, 0, 0, 16));
        return box;
    }

    /** 3-per-row preview grid. app=true: app themes; false: editor colour schemes (+ Auto). */
    private View swatchGrid(final boolean app) {
        LinearLayout grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);
        int count = app ? Themes.ALL.length : Themes.SYNTAX.length + 1;
        final String cur = app ? settings.theme() : settings.syntaxTheme();
        LinearLayout row = null;
        for (int i = 0; i < count; i++) {
            if (i % 3 == 0) {
                row = new LinearLayout(this);
                grid.addView(row, Ui.lpMargin(Ui.MATCH, Ui.WRAP, 0, 0, 0, 10));
            }
            final String id;
            final String label;
            SwatchView sw;
            if (app) {
                Themes.Theme t = Themes.ALL[i];
                id = t.id; label = t.name; sw = SwatchView.ofTheme(this, t);
            } else if (i == 0) {
                id = Themes.SYNTAX_AUTO; label = "Auto"; sw = SwatchView.ofSyntax(this, null);
            } else {
                Themes.Syntax x = Themes.SYNTAX[i - 1];
                id = x.id; label = x.name; sw = SwatchView.ofSyntax(this, x);
            }
            sw.setSelected2(id.equals(cur));
            LinearLayout cell = new LinearLayout(this);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setClickable(true);
            cell.addView(sw, Ui.lp(Ui.MATCH, Ui.dp(66)));
            TextView l = Ui.label(this, label, 11.5f, id.equals(cur) ? Ui.ACCENT : Ui.MUTED, id.equals(cur));
            l.setGravity(Gravity.CENTER);
            l.setSingleLine(true);
            l.setPadding(0, Ui.dp(5), 0, 0);
            cell.addView(l);
            cell.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    if (app) settings.setTheme(id); else settings.setSyntaxTheme(id);
                    Ui.applyTheme(Themes.theme(settings.theme()), settings.syntaxTheme());
                    Ui.applySystemBars(MainActivity.this);
                    handler.post(new Runnable() { public void run() { if (reshow != null) reshow.run(); } });
                }
            });
            LinearLayout.LayoutParams cp = Ui.lpWeight(0, Ui.WRAP, 1);
            cp.setMargins(Ui.dp(i % 3 == 0 ? 0 : 5), 0, Ui.dp(i % 3 == 2 ? 0 : 5), 0);
            row.addView(cell, cp);
        }
        // pad the last row so cells keep equal width
        int rem = count % 3;
        if (rem != 0 && row != null) {
            for (int k = rem; k < 3; k++) row.addView(new View(this), Ui.lpWeight(0, 1, 1));
        }
        return grid;
    }

    private interface NameCallback { void ok(String name); }

    private void askName(String title, String initial, final NameCallback cb) {
        final EditText f = Ui.field(this, "Name", initial);
        LinearLayout box = new LinearLayout(this);
        box.setPadding(Ui.dp(22), Ui.dp(8), Ui.dp(22), 0);
        box.addView(f, Ui.lp(Ui.MATCH, Ui.WRAP));
        new AlertDialog.Builder(this, Ui.dialogTheme()).setTitle(title).setView(box)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int w) {
                    String n = f.getText().toString().trim();
                    if (n.length() > 0) cb.ok(n);
                }
            }).show();
    }

    // ------------------------------------------------------------------
    // MIDI STUDIO
    // ------------------------------------------------------------------

    private MediaPlayer midiPlayer;
    private TextView midiPlayBtn;
    private byte[] pendingMidiBytes;
    private int midiInstrument = 0;

    private void stopMidi() {
        if (midiPlayer != null) {
            try { midiPlayer.stop(); } catch (Exception ignore) { }
            try { midiPlayer.release(); } catch (Exception ignore) { }
            midiPlayer = null;
        }
        if (midiPlayBtn != null) midiPlayBtn.setText("Play");
    }

    private boolean startMidi(String path) {
        stopMidi();
        MediaPlayer mp = new MediaPlayer();
        try {
            mp.setDataSource(path);
            mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                public void onCompletion(MediaPlayer m) { stopMidi(); }
            });
            mp.prepare();
            mp.start();
            midiPlayer = mp;
            if (midiPlayBtn != null) midiPlayBtn.setText("Stop");
            return true;
        } catch (Exception e) {
            try { mp.release(); } catch (Exception ignore) { }
            toast("Cannot play: " + e.getMessage());
            return false;
        }
    }

    private void showMidiStudio(final Runnable back, final boolean forProject) {
        saveCurrentIfEditor();
        leaveEditorState();
        final Runnable leave = new Runnable() { public void run() { stopMidi(); back.run(); } };
        ImageView help = Ui.iconButton(this, R.drawable.ic_info, Ui.MUTED, new View.OnClickListener() {
            public void onClick(View v) {
                new AlertDialog.Builder(MainActivity.this, Ui.dialogTheme()).setTitle("Song notation")
                    .setMessage("C4 D#4 Eb5   notes (octave optional)\\nC4+E4+G4   chord\\nR   rest\\n:w :h :q :e :s   whole, half, quarter, eighth, sixteenth\\n:q.   dotted\\n\\nExample:\\nC4:q E4 G4 C5:h R C4+E4+G4:w")
                    .setPositiveButton("OK", null).show();
            }
        });
        LinearLayout[] pg = page(topBar("MIDI Studio", null, leave, help), 16);
        final LinearLayout body = pg[1];

        final EditText songF = Ui.field(this, "C4 E4 G4:h R C5+E5:w", MidiFile.PRESET_SONGS[0]);
        songF.setSingleLine(false);
        songF.setMinLines(5);
        songF.setGravity(Gravity.TOP);
        songF.setTypeface(Typeface.MONOSPACE);
        songF.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);

        // presets
        LinearLayout chips = new LinearLayout(this);
        for (int i = 0; i < MidiFile.PRESET_NAMES.length; i++) {
            final int idx = i;
            TextView c = Ui.pill(this, MidiFile.PRESET_NAMES[i], 0, Ui.TEXT, new View.OnClickListener() {
                public void onClick(View v) { songF.setText(MidiFile.PRESET_SONGS[idx]); }
            });
            c.setTextSize(12.5f);
            chips.addView(c, Ui.lpMargin(Ui.WRAP, Ui.WRAP, 0, 0, 8, 0));
        }
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        hs.addView(chips);
        body.addView(hs, Ui.lpMargin(Ui.MATCH, Ui.WRAP, 0, 0, 0, 12));
        body.addView(songF, Ui.lpMargin(Ui.MATCH, Ui.WRAP, 0, 0, 0, 6));

        final TextView info = Ui.label(this, "", 12, Ui.MUTED, false);
        info.setPadding(Ui.dp(4), 0, 0, Ui.dp(14));
        body.addView(info);

        // tempo + instrument
        final EditText bpmF = Ui.field(this, "BPM", "120");
        bpmF.setInputType(InputType.TYPE_CLASS_NUMBER);
        final TextView instF = Ui.label(this, "", 15, Ui.TEXT, false);
        instF.setSingleLine(true);
        instF.setEllipsize(android.text.TextUtils.TruncateAt.END);
        instF.setPadding(Ui.dp(14), Ui.dp(12), Ui.dp(14), Ui.dp(12));
        instF.setBackground(Ui.rect(Ui.SURFACE2, 12, Ui.STROKE));
        instF.setClickable(true);
        instF.setText(midiInstrument + "  " + MidiFile.INSTRUMENTS[midiInstrument]);
        instF.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                final String[] names = new String[128];
                for (int i = 0; i < 128; i++) names[i] = i + "  " + MidiFile.INSTRUMENTS[i];
                new AlertDialog.Builder(MainActivity.this, Ui.dialogTheme()).setTitle("Instrument")
                    .setItems(names, new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface d, int which) {
                            midiInstrument = which;
                            instF.setText(names[which]);
                        }
                    }).show();
            }
        });
        LinearLayout opts = new LinearLayout(this);
        View tempoBox = Ui.labeled(this, "Tempo", bpmF);
        View instBox = Ui.labeled(this, "Instrument", instF);
        LinearLayout.LayoutParams tp = Ui.lpWeight(0, Ui.WRAP, 1);
        tp.setMargins(0, 0, Ui.dp(10), 0);
        opts.addView(tempoBox, tp);
        opts.addView(instBox, Ui.lpWeight(0, Ui.WRAP, 2));
        body.addView(opts);

        final Runnable refreshInfo = new Runnable() {
            public void run() {
                try {
                    Vector st = MidiFile.parse(songF.getText().toString());
                    int bpm = 120;
                    try { bpm = Integer.parseInt(bpmF.getText().toString().trim()); } catch (NumberFormatException ignore) { }
                    info.setTextColor(Ui.MUTED);
                    info.setText(st.size() + " steps  \u00B7  " + (Math.round(MidiFile.seconds(st, bpm) * 10f) / 10f) + " s");
                } catch (IllegalArgumentException e) {
                    info.setTextColor(Ui.RED);
                    info.setText(e.getMessage());
                }
            }
        };
        TextWatcher tw = new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            public void onTextChanged(CharSequence s, int a, int b, int c) {}
            public void afterTextChanged(Editable e) { refreshInfo.run(); }
        };
        songF.addTextChangedListener(tw);
        bpmF.addTextChangedListener(tw);
        refreshInfo.run();

        // actions
        midiPlayBtn = Ui.pill(this, "Play", Ui.ACCENT, Ui.WHITE, null);
        final TextView play = midiPlayBtn;
        play.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (midiPlayer != null) { stopMidi(); return; }
                byte[] data = midiBytes(songF, bpmF);
                if (data == null) return;
                try {
                    File f = new File(getCacheDir(), "preview.mid");
                    java.io.FileOutputStream fo = new java.io.FileOutputStream(f);
                    fo.write(data);
                    fo.close();
                    startMidi(f.getAbsolutePath());
                } catch (IOException e) { toast("Cannot write preview: " + e.getMessage()); }
            }
        });
        LinearLayout actions = new LinearLayout(this);
        LinearLayout.LayoutParams ap1 = Ui.lpWeight(0, Ui.WRAP, 1);
        ap1.setMargins(0, 0, Ui.dp(8), 0);
        actions.addView(play, ap1);
        if (forProject) {
            TextView add = Ui.pill(this, "Add to project", 0, Ui.ACCENT, new View.OnClickListener() {
                public void onClick(View v) {
                    final byte[] data = midiBytes(songF, bpmF);
                    if (data == null) return;
                    askName("File name", "song.mid", new NameCallback() {
                        public void ok(String n) {
                            String clean = n.replaceAll("[^A-Za-z0-9._-]", "_");
                            if (!clean.toLowerCase().endsWith(".mid")) clean += ".mid";
                            String err = JCompilerBridge.writeResource(clean, data);
                            toast(err.length() == 0 ? "Added res/" + clean : err);
                        }
                    });
                }
            });
            actions.addView(add, Ui.lpWeight(0, Ui.WRAP, 1));
            ((LinearLayout.LayoutParams) add.getLayoutParams()).setMargins(0, 0, Ui.dp(8), 0);
        }
        TextView export = Ui.pill(this, "Export", 0, Ui.ACCENT, new View.OnClickListener() {
            public void onClick(View v) {
                byte[] data = midiBytes(songF, bpmF);
                if (data == null) return;
                Intent x = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                x.addCategory(Intent.CATEGORY_OPENABLE);
                x.setType("audio/midi");
                x.putExtra(Intent.EXTRA_TITLE, "song.mid");
                pendingMidiBytes = data;
                try { startActivityForResult(x, REQ_EXPORT_FILE); }
                catch (Exception e) { toast("No file picker available"); }
            }
        });
        actions.addView(export, Ui.lpWeight(0, Ui.WRAP, 1));
        body.addView(actions, Ui.lpMargin(Ui.MATCH, Ui.WRAP, 0, 4, 0, 18));

        LinearLayout tools = Ui.card(this);
        tools.addView(toolTile(R.drawable.ic_folder_open, "Play a .mid file", "", new Runnable() {
            public void run() { pickMidiForPlayback(); }
        }));
        body.addView(tools);

        present(pg[0], leave, new Runnable() { public void run() { showMidiStudio(back, forProject); } });
    }

    private byte[] midiBytes(EditText songF, EditText bpmF) {
        int bpm = 120;
        try { bpm = Integer.parseInt(bpmF.getText().toString().trim()); } catch (NumberFormatException ignore) { }
        try {
            return MidiFile.fromText(songF.getText().toString(), bpm, midiInstrument);
        } catch (IllegalArgumentException e) {
            toast(e.getMessage());
        } catch (IOException e) {
            toast("Could not build MIDI: " + e.getMessage());
        }
        return null;
    }

    private void pickMidiForPlayback() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"audio/midi", "audio/mid", "audio/x-midi", "audio/sp-midi",
                "application/x-midi", "application/octet-stream"});
        try { startActivityForResult(i, REQ_MIDI_OPEN); }
        catch (Exception e) { toast("No file picker available"); }
    }

    // ------------------------------------------------------------------
    // LIBRARIES
    // ------------------------------------------------------------------

    private Runnable libBack;
    private boolean libForProject;
    private boolean pendingLibProvided;

    private int libIcon(String id) {
        if (id.equals("mmapi")) return R.drawable.ic_play_circle;
        if (id.equals("fc")) return R.drawable.ic_folder;
        if (id.equals("bt")) return R.drawable.ic_language;
        if (id.equals("wma")) return R.drawable.ic_send;
        if (id.equals("pki")) return R.drawable.ic_lock;
        return R.drawable.ic_layers;
    }

    private void showLibraries(final Runnable back, final boolean forProject) {
        saveCurrentIfEditor();
        leaveEditorState();
        libBack = back;
        libForProject = forProject;
        LinearLayout[] pg = page(topBar("Libraries", null, back), 16);
        final LinearLayout body = pg[1];
        final Project p = forProject ? JCompilerBridge.getCurrent() : null;
        com.dashers.j2mebuilderide.compiler.ApiIndex api = JCompilerBridge.api();

        java.util.Hashtable sources = new java.util.Hashtable();
        if (p != null) {
            String[] names = JCompilerBridge.listSourceFiles().split(",");
            for (int i = 0; i < names.length; i++) {
                if (names[i].length() > 0) sources.put(names[i], JCompilerBridge.readFile(names[i]));
            }
        }
        Vector used = Libraries.detectUsed(sources);

        body.addView(Ui.section(this, "Phone libraries"));
        LinearLayout card = Ui.card(this);
        for (int i = 0; i < Libraries.CATALOG.length; i++) {
            final Libraries.Lib lib = Libraries.CATALOG[i];
            int n = api == null ? 0 : Libraries.classCount(lib, api);
            View trailing;
            if (used.contains(lib)) {
                TextView tag = Ui.label(this, "In use", 12, Ui.GREEN, true);
                trailing = tag;
            } else {
                trailing = chevron();
            }
            LinearLayout t = Ui.tile(this, libIcon(lib.id), lib.name, lib.jsr + "  \u00B7  " + n + " classes", trailing);
            onTap(t, new Runnable() { public void run() { showLibraryClasses(lib); } });
            if (i > 0) card.addView(Ui.divider(this));
            card.addView(t);
        }
        body.addView(card);

        body.addView(Ui.section(this, "Project libraries"));
        if (p == null) {
            LinearLayout c2 = Ui.card(this);
            c2.addView(Ui.tile(this, R.drawable.ic_lock, "Open a project", "to add .jar libraries", null));
            body.addView(c2);
        } else {
            LinearLayout c2 = Ui.card(this);
            int shown = 0;
            for (int pass = 0; pass < 2; pass++) {
                final boolean provided = pass == 1;
                File[] jars = Libraries.jars(p, provided);
                for (int i = 0; i < jars.length; i++) {
                    final File jf = jars[i];
                    int n = Libraries.countClasses(jf);
                    ImageView del = Ui.iconButton(this, R.drawable.ic_delete, Ui.MUTED, null);
                    LinearLayout t = Ui.tile(this, R.drawable.ic_layers, jf.getName(),
                            n + " classes  \u00B7  " + (provided ? "compile only" : "packed in JAR"), del);
                    del.setLayoutParams(Ui.lp(Ui.dp(40), Ui.dp(40)));
                    del.setOnClickListener(new View.OnClickListener() {
                        public void onClick(View v) {
                            new AlertDialog.Builder(MainActivity.this, Ui.dialogTheme())
                                .setTitle("Remove " + jf.getName() + "?")
                                .setNegativeButton("Cancel", null)
                                .setPositiveButton("Remove", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface d, int w) {
                                        jf.delete();
                                        showLibraries(back, forProject);
                                    }
                                }).show();
                        }
                    });
                    if (shown > 0) c2.addView(Ui.divider(this));
                    c2.addView(t);
                    shown++;
                }
            }
            if (shown == 0) c2.addView(Ui.tile(this, R.drawable.ic_layers, "No .jar libraries yet", "", null));
            body.addView(c2);

            LinearLayout btns = new LinearLayout(this);
            TextView addJar = Ui.pill(this, "Add .jar", Ui.ACCENT, Ui.WHITE, new View.OnClickListener() {
                public void onClick(View v) { pickLibraryJar(false); }
            });
            LinearLayout.LayoutParams b1 = Ui.lpWeight(0, Ui.WRAP, 1);
            b1.setMargins(0, 0, Ui.dp(8), 0);
            btns.addView(addJar, b1);
            TextView addStub = Ui.pill(this, "Add stub (not packed)", 0, Ui.ACCENT, new View.OnClickListener() {
                public void onClick(View v) { pickLibraryJar(true); }
            });
            btns.addView(addStub, Ui.lpWeight(0, Ui.WRAP, 1));
            body.addView(btns, Ui.lpMargin(Ui.MATCH, Ui.WRAP, 0, 14, 0, 0));
        }
        present(pg[0], back, new Runnable() { public void run() { showLibraries(back, forProject); } });
    }

    private void showLibraryClasses(Libraries.Lib lib) {
        com.dashers.j2mebuilderide.compiler.ApiIndex api = JCompilerBridge.api();
        if (api == null) return;
        final Vector all = Libraries.classNames(lib, api);
        final String[] items = new String[all.size()];
        for (int i = 0; i < items.length; i++) {
            String fq = (String) all.elementAt(i);
            items[i] = fq.substring(fq.lastIndexOf('.') + 1);
        }
        new AlertDialog.Builder(this, Ui.dialogTheme())
            .setTitle(lib.name + " (" + items.length + ")")
            .setItems(items, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int which) {
                    ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    if (cm != null) {
                        cm.setPrimaryClip(ClipData.newPlainText("import", "import " + all.elementAt(which) + ";"));
                        toast("Import copied");
                    }
                }
            })
            .setPositiveButton("Close", null).show();
    }

    private void pickLibraryJar(boolean provided) {
        pendingLibProvided = provided;
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/java-archive", "application/zip",
                "application/x-zip-compressed", "application/octet-stream"});
        try { startActivityForResult(i, REQ_LIB); }
        catch (Exception e) { toast("No file picker available"); }
    }

    private void importLibrary(Uri uri) {
        Project p = JCompilerBridge.getCurrent();
        if (p == null || uri == null) { toast("Open a project first"); return; }
        try {
            byte[] b = readAll(getContentResolver().openInputStream(uri));
            String name = displayName(uri).replaceAll("[^A-Za-z0-9._-]", "_");
            String low = name.toLowerCase();
            if (!low.endsWith(".jar") && !low.endsWith(".zip")) name += ".jar";
            File dir = pendingLibProvided ? Libraries.providedDir(p) : Libraries.libDir(p);
            dir.mkdirs();
            File f = new File(dir, name);
            java.io.FileOutputStream fo = new java.io.FileOutputStream(f);
            fo.write(b);
            fo.close();
            int n = Libraries.countClasses(f);
            if (n == 0) { f.delete(); toast("No classes found in that file"); }
            else toast("Added " + name + " (" + n + " classes)");
        } catch (Exception e) {
            toast("Could not add library: " + e.getMessage());
        }
        if (libBack != null) showLibraries(libBack, libForProject);
    }

    // ------------------------------------------------------------------
    // 5. APP SETTINGS
    // ------------------------------------------------------------------

    private View toggleTile(int icon, String title, String sub, boolean initial, ToggleView.Listener l) {
        final ToggleView tv = new ToggleView(this, initial, l);
        LinearLayout row = Ui.tile(this, icon, title, sub, tv);
        row.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { tv.performClick(); }
        });
        return row;
    }

    private void showAppSettings(final Runnable back) {
        saveCurrentIfEditor();
        leaveEditorState();
        LinearLayout[] pg = page(topBar("Settings", "Options", back), 16);
        final LinearLayout body = pg[1];

        // ---- Appearance ----
        body.addView(Ui.section(this, "Theme"));
        LinearLayout ap = Ui.card(this);
        ap.setPadding(Ui.dp(14), Ui.dp(14), Ui.dp(14), Ui.dp(10));
        ap.addView(swatchGrid(true));
        body.addView(ap);

        body.addView(Ui.section(this, "Editor colors"));
        LinearLayout ec = Ui.card(this);
        ec.setPadding(Ui.dp(14), Ui.dp(14), Ui.dp(14), Ui.dp(10));
        ec.addView(swatchGrid(false));
        body.addView(ec);

        body.addView(Ui.section(this, "General"));
        LinearLayout gen = Ui.card(this);
        gen.addView(fontSizeTile());
        gen.addView(Ui.divider(this));
        gen.addView(toggleTile(R.drawable.ic_smartphone, "Splash screen", "", settings.showSplash(), new ToggleView.Listener() {
            public void onChanged(boolean on) { settings.setShowSplash(on); }
        }));
        gen.addView(Ui.divider(this));
        gen.addView(toolTile(R.drawable.ic_code, "Check for Updates", "v" + versionLabel(), new Runnable() {
            public void run() { com.dashers.j2mebuilderide.ide.UpdateChecker.checkInBackground(MainActivity.this, true); }
        }));
        body.addView(gen);

        // ---- Editor ----
        body.addView(Ui.section(this, "Editor"));
        LinearLayout ed = Ui.card(this);
        ed.addView(toggleTile(R.drawable.ic_wrap_text, "Word wrap", "", settings.wordWrap(), new ToggleView.Listener() {
            public void onChanged(boolean on) { settings.setWordWrap(on); }
        }));
        ed.addView(Ui.divider(this));
        ed.addView(toggleTile(R.drawable.ic_list, "Line numbers", "", settings.lineNumbers(), new ToggleView.Listener() {
            public void onChanged(boolean on) { settings.setLineNumbers(on); }
        }));
        ed.addView(Ui.divider(this));
        ed.addView(toggleTile(R.drawable.ic_code, "Code suggestions", "", settings.suggestions(), new ToggleView.Listener() {
            public void onChanged(boolean on) { settings.setSuggestions(on); }
        }));
        ed.addView(Ui.divider(this));
        ed.addView(toggleTile(R.drawable.ic_check, "Auto-close brackets", "", settings.autoPair(), new ToggleView.Listener() {
            public void onChanged(boolean on) { settings.setAutoPair(on); }
        }));
        ed.addView(Ui.divider(this));
        ed.addView(toggleTile(R.drawable.ic_text_fields, "Auto indent", "", settings.autoIndent(), new ToggleView.Listener() {
            public void onChanged(boolean on) { settings.setAutoIndent(on); }
        }));
        ed.addView(Ui.divider(this));
        ed.addView(toggleTile(R.drawable.ic_title, "Tab size 2", "", settings.tabSize() == 2, new ToggleView.Listener() {
            public void onChanged(boolean on) { settings.setTabSize(on ? 2 : 4); }
        }));
        ed.addView(Ui.divider(this));
        ed.addView(toggleTile(R.drawable.ic_save, "Auto-save", "", settings.autoSave(), new ToggleView.Listener() {
            public void onChanged(boolean on) { settings.setAutoSave(on); }
        }));
        ed.addView(Ui.divider(this));
        ed.addView(toggleTile(R.drawable.ic_check_circle, "Live error check", "Compile quietly after saving and mark errors", settings.autoCheck(), new ToggleView.Listener() {
            public void onChanged(boolean on) { settings.setAutoCheck(on); }
        }));
        ed.addView(Ui.divider(this));
        ed.addView(toggleTile(R.drawable.ic_info, "Keep screen on", "", settings.keepScreenOn(), new ToggleView.Listener() {
            public void onChanged(boolean on) { settings.setKeepScreenOn(on); applyKeepOn(); }
        }));
        body.addView(ed);

        // ---- Build ----
        body.addView(Ui.section(this, "Build"));
        LinearLayout bd = Ui.card(this);
        bd.addView(toggleTile(R.drawable.ic_build, "Open log on build", "", settings.autoOpenLog(), new ToggleView.Listener() {
            public void onChanged(boolean on) { settings.setAutoOpenLog(on); }
        }));
        bd.addView(Ui.divider(this));
        bd.addView(toggleTile(R.drawable.ic_play_arrow, "Typing animation", "", settings.animatedLog(), new ToggleView.Listener() {
            public void onChanged(boolean on) { settings.setAnimatedLog(on); }
        }));
        bd.addView(Ui.divider(this));
        bd.addView(toggleTile(R.drawable.ic_smartphone, "Auto-open in emulator",
                "J2ME Loader or similar",
                settings.autoOpenEmulator(), new ToggleView.Listener() {
            public void onChanged(boolean on) { settings.setAutoOpenEmulator(on); }
        }));
        bd.addView(Ui.divider(this));
        String emuPkg = settings.emulatorPkg();
        LinearLayout emuTile = Ui.tile(this, R.drawable.ic_open_in_new, "Emulator app",
                emuPkg.length() == 0 ? "Ask every time (Android chooser)" : EmulatorLauncher.labelOf(this, emuPkg),
                Ui.icon(this, R.drawable.ic_chevron_right, Ui.MUTED, 24));
        onTap(emuTile, new Runnable() { public void run() { chooseEmulator(); } });
        bd.addView(emuTile);
        bd.addView(Ui.divider(this));
        bd.addView(toggleTile(R.drawable.ic_build, "StackMap: long/double as 1 entry", "Turn off if a phone rejects long/double", settings.stackMapLongDoubleOneEntry(), new ToggleView.Listener() {
            public void onChanged(boolean on) {
                settings.setStackMapLongDoubleOneEntry(on);
                com.dashers.j2mebuilderide.compiler.Compiler.setStackMapLongDoubleOneEntry(on);
            }
        }));
        bd.addView(Ui.divider(this));
        bd.addView(toggleTile(R.drawable.ic_build, "ProGuard preverifier", "CLDC StackMap for ECJ classes (proguard-core 9.1.1)", settings.proguardPreverify(), new ToggleView.Listener() {
            public void onChanged(boolean on) { settings.setProguardPreverify(on); }
        }));
        bd.addView(Ui.divider(this));
        bd.addView(toggleTile(R.drawable.ic_file_download, "Copy JAR to Download", "After a successful build", settings.copyToDownloads(), new ToggleView.Listener() {
            public void onChanged(boolean on) {
                settings.setCopyToDownloads(on);
                if (on && !hasStoragePermission()) {
                    requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE,
                            Manifest.permission.READ_EXTERNAL_STORAGE}, REQ_PERM_DL);
                }
            }
        }));
        body.addView(bd);

        // ---- Storage ----
        body.addView(Ui.section(this, "Storage"));
        LinearLayout st = Ui.card(this);
        st.addView(toggleTile(R.drawable.ic_storage, "Shared storage", "Visible in file managers", usingShared(), new ToggleView.Listener() {
            public void onChanged(boolean on) {
                if (on) enableSharedStorage(); else disableSharedStorage();
            }
        }));
        st.addView(Ui.divider(this));
        LinearLayout path = Ui.tile(this, R.drawable.ic_folder, "Projects folder", JCompilerBridge.getRoot(), null);
        st.addView(path);
        body.addView(st);

        // ---- About ----
        body.addView(Ui.section(this, "About"));
        LinearLayout ab = Ui.card(this);
        ab.addView(Ui.tile(this, R.drawable.ic_info, "J2ME Builder IDE " + versionLabel(),
                "MIDP 2.0 / CLDC 1.1", null));
        ab.addView(Ui.divider(this));
        LinearLayout devTile = Ui.tile(this, R.drawable.ic_code, "About developer",
                "DASH ANIMATION V2", Ui.icon(this, R.drawable.ic_chevron_right, Ui.MUTED, 24));
        onTap(devTile, new Runnable() {
            public void run() { showAbout(new Runnable() { public void run() { showAppSettings(back); } }); }
        });
        ab.addView(devTile);
        body.addView(ab);

        present(pg[0], back, new Runnable() { public void run() { showAppSettings(back); } });
    }

    private void saveCurrentIfEditor() {
        if (inEditor) saveCurrent();
    }

    private View fontSizeTile() {
        final TextView value = Ui.label(this, settings.fontSize() + " sp", 14, Ui.TEXT, true);
        value.setGravity(Gravity.CENTER);
        ImageView minus = Ui.iconButton(this, R.drawable.ic_expand_more, Ui.TEXT, null);
        ImageView plus = Ui.iconButton(this, R.drawable.ic_expand_less, Ui.TEXT, null);
        minus.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                settings.setFontSize(settings.fontSize() - 1);
                value.setText(settings.fontSize() + " sp");
            }
        });
        plus.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                settings.setFontSize(settings.fontSize() + 1);
                value.setText(settings.fontSize() + " sp");
            }
        });
        LinearLayout stepper = new LinearLayout(this);
        stepper.setGravity(Gravity.CENTER_VERTICAL);
        stepper.addView(minus, Ui.lp(Ui.dp(40), Ui.dp(40)));
        stepper.addView(value, Ui.lp(Ui.dp(52), Ui.WRAP));
        stepper.addView(plus, Ui.lp(Ui.dp(40), Ui.dp(40)));
        return Ui.tile(this, R.drawable.ic_text_fields, "Code font size", "Used in the editor", stepper);
    }

    // ------------------------------------------------------------------
    // 6. FILES / PROJECT TREE / PACKAGE VIEW
    // ------------------------------------------------------------------

    /**
     * IDE-style project tree.  The tree is intentionally path-based (rather than a flat list):
     * project -> src -> package folders -> classes, plus res/ and (optionally) build output.
     */
    private void showFiles() {
        saveCurrent();
        final String reopen = openFile;
        leaveEditorState();
        final Runnable back = new Runnable() { public void run() { showEditor(reopen); } };
        final ImageView add = Ui.iconButton(this, R.drawable.ic_add, Ui.ACCENT, new View.OnClickListener() {
            public void onClick(View v) { showProjectAddMenu(v); }
        });
        final ImageView packages = Ui.iconButton(this, R.drawable.ic_layers, Ui.ACCENT, new View.OnClickListener() {
            public void onClick(View v) { showPackageManager(); }
        });
        Project p = JCompilerBridge.getCurrent();
        LinearLayout[] pg = page(topBar("Project (" + projectFileCount(p) + ")", p != null ? p.folderName : "", back, packages, add), 12);
        final LinearLayout body = pg[1];

        final EditText search = Ui.field(this, "Search file names...", "");
        LinearLayout sRow = new LinearLayout(this);
        sRow.setGravity(Gravity.CENTER_VERTICAL);
        sRow.setBackground(Ui.rect(Ui.SURFACE2, 14, Ui.STROKE));
        sRow.setPadding(Ui.dp(12), 0, Ui.dp(4), 0);
        sRow.addView(Ui.icon(this, R.drawable.ic_search, Ui.MUTED, 24), Ui.lp(Ui.dp(24), Ui.dp(24)));
        search.setBackground(null);
        sRow.addView(search, Ui.lpWeight(0, Ui.WRAP, 1));
        final Runnable[] optionsRef = new Runnable[1];
        ImageView filter = Ui.iconButton(this, R.drawable.ic_list, Ui.MUTED, new View.OnClickListener() {
            public void onClick(View v) { if (optionsRef[0] != null) optionsRef[0].run(); }
        });
        sRow.addView(filter, Ui.lp(Ui.dp(44), Ui.dp(44)));
        body.addView(sRow, Ui.lpMargin(Ui.MATCH, Ui.WRAP, 0, 0, 0, 10));

        final LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        body.addView(list, Ui.lp(Ui.MATCH, Ui.WRAP));

        final Vector expanded = new Vector();
        expanded.addElement("");
        expanded.addElement("src");
        final boolean[] showRes = {true};
        final boolean[] showBuild = {false};
        final boolean[] autoExpanded = {false};   // open src/ packages only the first time

        final Runnable[] fillRef = new Runnable[1];
        final Runnable fill = new Runnable() {
            public void run() {
                list.removeAllViews();
                Project p = JCompilerBridge.getCurrent();
                if (p == null) return;
                ProjectTree.Options o = new ProjectTree.Options();
                o.showRes = showRes[0];
                o.showBuild = showBuild[0];
                o.showEmpty = true;
                ProjectTree.Node root = ProjectTree.build(p, o);
                if (!autoExpanded[0]) { autoExpanded[0] = true; expandSourceFoldersOnce(root, expanded); }
                String q = search.getText().toString().trim().toLowerCase();
                if (q.length() == 0) {
                    renderTreeNode(root, 0, expanded, list, back, fillRef[0]);
                } else {
                    renderSearchTree(root, q, 0, list, back, fillRef[0]);
                    if (list.getChildCount() == 0) {
                        TextView none = Ui.label(MainActivity.this, "No files match \"" + q + "\"", 13, Ui.MUTED, false);
                        none.setGravity(Gravity.CENTER);
                        none.setPadding(Ui.dp(12), Ui.dp(24), Ui.dp(12), Ui.dp(24));
                        list.addView(none, Ui.lp(Ui.MATCH, Ui.WRAP));
                    }
                }
            }
        };
        fillRef[0] = fill;
        optionsRef[0] = new Runnable() {
            public void run() { showTreeOptions(expanded, showRes, showBuild, fill); }
        };
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            public void onTextChanged(CharSequence s, int a, int b, int c) {}
            public void afterTextChanged(Editable e) { fill.run(); }
        });
        fill.run();
        present(pg[0], back, new Runnable() { public void run() { showFiles(); } });
    }

    private int projectFileCount(Project p) {
        if (p == null) return 0;
        try { return ProjectTree.countFiles(ProjectTree.build(p, new ProjectTree.Options())); }
        catch (RuntimeException e) { return splitNames(JCompilerBridge.listSourceFiles()).size(); }
    }

    private void expandSourceFoldersOnce(ProjectTree.Node n, Vector expanded) {
        if (n == null) return;
        if (n.kind == ProjectTree.SRC || isSrcPackageNode(n)) expanded.addElement(n.path);
        for (int i = 0; i < n.children.size(); i++) {
            ProjectTree.Node c = n.children.get(i);
            if (c.isDir()) expandSourceFoldersOnce(c, expanded);
        }
    }

    private void renderTreeNode(final ProjectTree.Node n, final int depth, final Vector expanded,
                                final LinearLayout list, final Runnable back, final Runnable refresh) {
        if (n == null) return;
        list.addView(treeRow(n, depth, expanded, list, back, refresh));
        if (n.isDir() && expanded.contains(n.path)) {
            for (int i = 0; i < n.children.size(); i++) {
                renderTreeNode(n.children.get(i), depth + 1, expanded, list, back, refresh);
            }
        }
    }

    private void renderSearchTree(ProjectTree.Node n, String q, int depth, LinearLayout list,
                                  Runnable back, Runnable refresh) {
        if (n == null) return;
        boolean hit = n.name.toLowerCase().indexOf(q) >= 0 || n.path.toLowerCase().indexOf(q) >= 0;
        boolean childHit = false;
        if (n.isDir()) {
            for (int i = 0; i < n.children.size(); i++) {
                ProjectTree.Node c = n.children.get(i);
                if (treeContains(c, q)) { childHit = true; break; }
            }
        }
        if (hit || childHit) {
            list.addView(treeRow(n, depth, null, list, back, refresh));
            if (n.isDir()) {
                for (int i = 0; i < n.children.size(); i++) {
                    ProjectTree.Node c = n.children.get(i);
                    if (treeContains(c, q)) renderSearchTree(c, q, depth + 1, list, back, refresh);
                }
            }
        }
    }

    private boolean treeContains(ProjectTree.Node n, String q) {
        if (n.name.toLowerCase().indexOf(q) >= 0 || n.path.toLowerCase().indexOf(q) >= 0) return true;
        if (n.isDir()) for (int i = 0; i < n.children.size(); i++) if (treeContains(n.children.get(i), q)) return true;
        return false;
    }

    private View treeRow(final ProjectTree.Node n, final int depth, final Vector expanded,
                         final LinearLayout list, final Runnable back, final Runnable refresh) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setMinimumHeight(Ui.dp(58));
        row.setPadding(Ui.dp(4 + depth * 24), Ui.dp(5), Ui.dp(2), Ui.dp(5));
        row.setBackground(Ui.ripple(Ui.rect(0x00000000, 10, 0)));
        row.setClickable(true);

        if (n.isDir()) {
            ImageView chev = Ui.iconButton(this,
                    expanded != null && expanded.contains(n.path) ? R.drawable.ic_expand_less : R.drawable.ic_chevron_right,
                    Ui.MUTED, new View.OnClickListener() {
                public void onClick(View v) {
                    if (expanded == null) return;
                    if (expanded.contains(n.path)) expanded.removeElement(n.path); else expanded.addElement(n.path);
                    refresh.run();
                }
            });
            row.addView(chev, Ui.lp(Ui.dp(38), Ui.dp(42)));
        } else {
            row.addView(new Space(this), Ui.lp(Ui.dp(38), Ui.dp(1)));
        }

        int icon;
        if (n.isJava()) icon = R.drawable.ic_description;
        else if (n.isDir()) icon = (expanded != null && expanded.contains(n.path)) ? R.drawable.ic_folder_open : R.drawable.ic_folder;
        else icon = fileIconFor(n.name);
        int iconColor = n.isJava() ? Ui.ACCENT : (n.kind == ProjectTree.SRC ? Ui.ACCENT : Ui.MUTED);
        row.addView(Ui.icon(this, icon, iconColor, 25), Ui.lpMargin(Ui.dp(25), Ui.dp(25), 0, 0, 7, 0));

        LinearLayout text = new LinearLayout(this);
        text.setOrientation(LinearLayout.VERTICAL);
        TextView name = Ui.label(this, n.name.length() == 0 ? "Project" : n.name, 15, Ui.TEXT, true);
        name.setSingleLine(true);
        name.setEllipsize(android.text.TextUtils.TruncateAt.END);
        text.addView(name);
        String secondary = n.path.length() == 0 ? (JCompilerBridge.getRoot() + n.name) : ProjectTree.shortPath(n.path);
        if (!n.isDir() && n.size > 0) secondary += "  ·  " + humanSize(n.size);
        else if (n.isDir() && n.kind != ProjectTree.ROOT) {
            int fc = n.fileCount();
            secondary += "  ·  " + fc + (fc == 1 ? " file" : " files");
        }
        TextView sub = Ui.label(this, secondary, 11.5f, Ui.MUTED, false);
        sub.setSingleLine(true);
        sub.setEllipsize(android.text.TextUtils.TruncateAt.END);
        text.addView(sub);
        row.addView(text, Ui.lpWeight(0, Ui.WRAP, 1));

        String badge = n.isJava() ? "JAVA" : (isSrcPackageNode(n) ? "PKG" : (n.isDir() ? "DIR" : ProjectTree.ext(n.name)));
        if (badge.length() > 0) {
            TextView b = Ui.label(this, badge, 10.5f, n.isJava() ? Ui.ACCENT : Ui.MUTED, true);
            b.setGravity(Gravity.CENTER);
            b.setPadding(Ui.dp(7), Ui.dp(5), Ui.dp(7), Ui.dp(5));
            b.setBackground(Ui.rect(Ui.SURFACE2, 8, Ui.STROKE));
            row.addView(b, Ui.lpMargin(Ui.WRAP, Ui.WRAP, 3, 0, 4, 0));
        }

        ImageView more = Ui.iconButton(this, R.drawable.ic_more_vert, Ui.MUTED, new View.OnClickListener() {
            public void onClick(View v) { showTreeContext(n, expanded, refresh); }
        });
        row.addView(more, Ui.lp(Ui.dp(42), Ui.dp(42)));

        onTap(row, new Runnable() {
            public void run() {
                if (n.isDir()) {
                    if (expanded != null) {
                        if (expanded.contains(n.path)) expanded.removeElement(n.path); else expanded.addElement(n.path);
                        refresh.run();
                    } else refresh.run();
                } else if (n.isJava()) {
                    showEditor(n.srcRel());
                } else {
                    toast(n.name + "  ·  " + humanSize(n.size));
                }
            }
        });
        row.setOnLongClickListener(new View.OnLongClickListener() {
            public boolean onLongClick(View v) { showTreeContext(n, expanded, refresh); return true; }
        });
        row.setLayoutParams(Ui.lpMargin(Ui.MATCH, Ui.WRAP, 0, 0, 0, 1));
        return row;
    }

    private boolean isSrcPackageNode(ProjectTree.Node n) {
        return n != null && n.kind == ProjectTree.DIR && n.srcRel() != null;
    }

    private void showProjectAddMenu(View anchor) {
        final String[] items = {"New Java class", "New package", "New folder", "Import resource", "Import folder", "Package manager"};
        new AlertDialog.Builder(this, Ui.dialogTheme()).setTitle("Create").setItems(items, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface d, int which) {
                if (which == 0) newFileDialog(true);
                else if (which == 1) newPackageDialog("");
                else if (which == 2) newFolderDialog("src");
                else if (which == 3) pickImportFiles();
                else if (which == 4) pickImportFolder(true);
                else showPackageManager();
            }
        }).show();
    }

    private void showTreeOptions(final Vector expanded, final boolean[] showRes, final boolean[] showBuild,
                                 final Runnable refresh) {
        final String[] items = {"Package manager", "Create package", "Check package declarations", "Refresh",
            "Expand all", "Collapse all",
            showRes[0] ? "Hide res folder" : "Show res folder",
            showBuild[0] ? "Hide build output" : "Show build output"};
        new AlertDialog.Builder(this, Ui.dialogTheme()).setTitle("Project view").setItems(items, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface d, int which) {
                if (which == 0) showPackageManager();
                else if (which == 1) newPackageDialog("");
                else if (which == 2) packageHealthDialog();
                else if (which == 3) showFiles();
                else if (which == 4) {
                    Project p = JCompilerBridge.getCurrent();
                    if (p != null) {
                        ProjectTree.Options o = new ProjectTree.Options();
                        o.showRes = showRes[0];
                        o.showBuild = showBuild[0];
                        expanded.removeAllElements();
                        collectDirPaths(ProjectTree.build(p, o), expanded);
                    }
                    refresh.run();
                } else if (which == 5) {
                    expanded.removeAllElements();
                    expanded.addElement("");
                    refresh.run();
                } else if (which == 6) {
                    showRes[0] = !showRes[0];
                    refresh.run();
                } else {
                    showBuild[0] = !showBuild[0];
                    refresh.run();
                }
            }
        }).show();
    }

    private void collectDirPaths(ProjectTree.Node n, Vector out) {
        if (n == null || !n.isDir()) return;
        if (!out.contains(n.path)) out.addElement(n.path);
        for (int i = 0; i < n.children.size(); i++) collectDirPaths(n.children.get(i), out);
    }

    private int fileIconFor(String name) {
        String e = ProjectTree.ext(name).toLowerCase();
        if (e.equals("png") || e.equals("jpg") || e.equals("jpeg") || e.equals("gif") || e.equals("bmp")) return R.drawable.ic_image;
        if (e.equals("mid") || e.equals("midi") || e.equals("wav") || e.equals("mp3") || e.equals("amr") || e.equals("aac")) return R.drawable.ic_play_circle;
        if (e.equals("jar") || e.equals("jad")) return R.drawable.ic_smartphone;
        return R.drawable.ic_description;
    }

    private void showTreeContext(final ProjectTree.Node n, final Vector expanded, final Runnable refresh) {
        final ArrayList<String> labels = new ArrayList<String>();
        final ArrayList<Integer> actions = new ArrayList<Integer>();
        labels.add(n.isJava() ? "Open" : "Expand / collapse"); actions.add(0);
        if (n.isDir()) {
            if (n.kind == ProjectTree.SRC || isSrcPackageNode(n)) {
                labels.add("New Java class"); actions.add(1);
                labels.add("New package"); actions.add(2);
                if (isSrcPackageNode(n)) { labels.add("Rename package"); actions.add(3); labels.add("Delete package"); actions.add(4); }
                labels.add("Copy path"); actions.add(7);
            } else {
                labels.add("New file"); actions.add(5);
                labels.add("New folder"); actions.add(6);
                // Every folder inside the project's res/ tree can be the destination
                // of an import. The selected folder is preserved through the Android picker.
                if (n.path.equals("res") || n.path.startsWith("res/")) {
                    labels.add("Import resource here"); actions.add(11);
                }
                if (!ProjectTree.isProtected(n.path)) { labels.add("Rename"); actions.add(8); labels.add("Delete"); actions.add(9); }
                labels.add("Copy path"); actions.add(7);
            }
        } else if (n.isJava()) {
            labels.add("Rename"); actions.add(8);
            labels.add("Move to package"); actions.add(10);
            if (!ProjectTree.isProtected(n.path)) { labels.add("Delete"); actions.add(9); }
            labels.add("Copy path"); actions.add(7);
        } else {
            if (n.path.startsWith("res/") && isImageName(n.name)) { labels.add("Edit in Sprite Editor"); actions.add(12); }
            labels.add("Rename"); actions.add(8);
            labels.add("Delete"); actions.add(9);
            labels.add("Copy path"); actions.add(7);
        }
        final String[] a = labels.toArray(new String[labels.size()]);
        new AlertDialog.Builder(this, Ui.dialogTheme()).setTitle(n.name.length() == 0 ? "Project" : n.name)
            .setItems(a, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int which) {
                    int action = actions.get(which).intValue();
                    if (action == 0) {
                        if (n.isJava()) showEditor(n.srcRel());
                        else { if (expanded != null) { if (expanded.contains(n.path)) expanded.removeElement(n.path); else expanded.addElement(n.path); } refresh.run(); }
                    } else if (action == 1) newFileDialogInPackage(packageForNode(n), true);
                    else if (action == 2) newPackageDialog(packageForNode(n));
                    else if (action == 3) renamePackageDialog(packageForNode(n));
                    else if (action == 4) deletePackageDialog(packageForNode(n), refresh);
                    else if (action == 5) newFileDialog(true);
                    else if (action == 6) newFolderDialog(n.path);
                    else if (action == 7) copyProjectPath(n.path);
                    else if (action == 8) {
                        if (n.isJava()) renameFileDialog(n.srcRel()); else renameGenericDialog(n.path);
                    } else if (action == 9) {
                        if (n.isJava()) confirmDeleteFile(n.srcRel()); else deleteTreeNode(n.path, refresh);
                    } else if (action == 10) moveClassDialog(n.srcRel(), refresh);
                    else if (action == 11) {
                        String target = n.path.equals("res") ? "" : n.path.substring(4);
                        pickImportFiles(target);
                    } else if (action == 12) {
                        final String keep = openFile;
                        final boolean wasEditor = inEditor;
                        showSpriteEditor(new Runnable() {
                            public void run() { if (wasEditor && keep != null && keep.length() > 0) showEditor(keep); else showFiles(); }
                        }, wasEditor, n.path.substring(4));
                    }
                }
            }).show();
    }

    private String packageForNode(ProjectTree.Node n) {
        if (n == null) return "";
        String s = n.srcRel();
        if (s == null || s.length() == 0) return "";
        return s.replace('/', '.');
    }

    private void newPackageDialog(String parent) {
        final EditText f = Ui.field(this, "e.g. com.example.game", parent.length() == 0 ? "" : parent + ".");
        FrameLayout box = new FrameLayout(this);
        box.setPadding(Ui.dp(22), Ui.dp(8), Ui.dp(22), 0); box.addView(f);
        final AlertDialog dlg = new AlertDialog.Builder(this, Ui.dialogTheme()).setTitle(parent.length() == 0 ? "New package" : "New subpackage")
            .setMessage(parent.length() == 0 ? "Use a dotted Java package name, e.g. com.example.game" : "Creates a package inside " + parent)
            .setView(box)
            .setNegativeButton("Cancel", null).setPositiveButton("Create", null).create();
        dlg.show();
        dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String pkg = f.getText().toString().trim();
                String err = PackageTools.create(JCompilerBridge.getCurrent(), pkg);
                if (err.length() > 0) { f.setError(err); return; }
                dlg.dismiss(); toast("Package created: " + pkg); showFiles();
            }
        });
    }

    private void renamePackageDialog(final String pkg) {
        final EditText f = Ui.field(this, "New package name", pkg);
        FrameLayout box = new FrameLayout(this); box.setPadding(Ui.dp(22), Ui.dp(8), Ui.dp(22), 0); box.addView(f);
        final AlertDialog dlg = new AlertDialog.Builder(this, Ui.dialogTheme()).setTitle("Rename package")
            .setMessage("Sub-packages, package declarations and imports are updated too.")
            .setView(box)
            .setNegativeButton("Cancel", null).setPositiveButton("Rename", null).create();
        dlg.show();
        dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String err = PackageTools.rename(JCompilerBridge.getCurrent(), pkg, f.getText().toString().trim());
                if (err.length() > 0) { f.setError(err); return; }
                dlg.dismiss(); toast("Package renamed"); showFiles();
            }
        });
    }

    private void deletePackageDialog(final String pkg, final Runnable refresh) {
        final Project p = JCompilerBridge.getCurrent();
        int count = 0;
        ArrayList<PackageTools.PackageInfo> all = PackageTools.list(p, true);
        for (int i = 0; i < all.size(); i++) if (all.get(i).name.equals(pkg)) count = all.get(i).totalFiles;
        final int files = count;
        new AlertDialog.Builder(this, Ui.dialogTheme()).setTitle("Delete package " + pkg + "?")
            .setMessage(files > 0 ? "This removes " + files + " file(s) inside it." : "The package folder is empty.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int w) {
                    String err = ProjectTree.delete(p, "src/" + pkg.replace('.', '/'));
                    if (err.length() > 0) { toast(err); return; }
                    toast("Package deleted"); refresh.run();
                }
            }).show();
    }

    private void showPackageManager() {
        saveCurrent();
        final String reopen = openFile;
        leaveEditorState();
        final Runnable back = new Runnable() { public void run() { showEditor(reopen); } };
        ImageView add = Ui.iconButton(this, R.drawable.ic_add, Ui.ACCENT, new View.OnClickListener() {
            public void onClick(View v) { newPackageDialog(""); }
        });
        LinearLayout[] pg = page(topBar("Packages", JCompilerBridge.getCurrent() != null ? JCompilerBridge.getCurrent().folderName : "", back, add), 12);
        final LinearLayout body = pg[1];

        TextView intro = Ui.label(this,
                "Packages are folders under src/.",
                12, Ui.MUTED, false);
        intro.setPadding(Ui.dp(4), Ui.dp(4), Ui.dp(4), Ui.dp(10));
        body.addView(intro);

        LinearLayout tools = Ui.card(this);
        View healthTile = Ui.tile(this, R.drawable.ic_check_circle, "Check declarations",
                "Fix wrong package lines in .java files", chevron());
        onTap(healthTile, new Runnable() { public void run() { packageHealthDialog(); } });
        tools.addView(healthTile);
        tools.addView(Ui.divider(this));
        View createTile = Ui.tile(this, R.drawable.ic_folder, "Create package",
                "Create a dotted package, e.g. com.example.game", chevron());
        onTap(createTile, new Runnable() { public void run() { newPackageDialog(""); } });
        tools.addView(createTile);
        body.addView(tools);
        body.addView(Ui.section(this, "Source packages"));

        final LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        body.addView(list);
        Project p = JCompilerBridge.getCurrent();
        ArrayList<PackageTools.PackageInfo> packages = PackageTools.list(p, false);
        if (packages.size() == 0) {
            TextView none = Ui.label(this, "No packages yet.", 14, Ui.MUTED, false);
            none.setGravity(Gravity.CENTER);
            none.setPadding(0, Ui.dp(36), 0, Ui.dp(36));
            list.addView(none);
        } else {
            for (int i = 0; i < packages.size(); i++) {
                final PackageTools.PackageInfo pi = packages.get(i);
                if (pi.name.length() == 0) continue;
                LinearLayout row = new LinearLayout(this);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(Ui.dp(12), Ui.dp(10), Ui.dp(6), Ui.dp(10));
                row.setBackground(Ui.ripple(Ui.rect(Ui.SURFACE, 14, Ui.STROKE)));
                row.addView(Ui.icon(this, R.drawable.ic_folder, Ui.ACCENT, 26), Ui.lpMargin(Ui.dp(26), Ui.dp(26), 0, 0, 10, 0));
                LinearLayout txt = new LinearLayout(this); txt.setOrientation(LinearLayout.VERTICAL);
                txt.addView(Ui.label(this, pi.name, 15, Ui.TEXT, true));
                txt.addView(Ui.label(this, pi.classes.size() + " direct class(es)  ·  " + pi.totalFiles + " file(s)", 11.5f, Ui.MUTED, false));
                row.addView(txt, Ui.lpWeight(0, Ui.WRAP, 1));
                ImageView more = Ui.iconButton(this, R.drawable.ic_more_vert, Ui.MUTED, new View.OnClickListener() {
                    public void onClick(View v) { packageActions(pi.name); }
                });
                row.addView(more, Ui.lp(Ui.dp(44), Ui.dp(44)));
                onTap(row, new Runnable() { public void run() { packageActions(pi.name); } });
                list.addView(row, Ui.lpMargin(Ui.MATCH, Ui.WRAP, 0, 0, 0, 8));
            }
        }
        present(pg[0], back, new Runnable() { public void run() { showPackageManager(); } });
    }

    private void packageActions(final String pkg) {
        String[] items = {"Open package", "New Java class", "New subpackage", "Rename package", "Move a class here", "Delete package", "Copy package name"};
        new AlertDialog.Builder(this, Ui.dialogTheme()).setTitle(pkg).setItems(items, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface d, int which) {
                if (which == 0) { showFiles(); }
                else if (which == 1) newFileDialogInPackage(pkg, true);
                else if (which == 2) newPackageDialog(pkg);
                else if (which == 3) renamePackageDialog(pkg);
                else if (which == 4) chooseClassToMove(pkg);
                else if (which == 5) deletePackageDialog(pkg, new Runnable() { public void run() { showPackageManager(); } });
                else {
                    ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                    if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("Package", pkg));
                    toast("Package name copied");
                }
            }
        }).show();
    }

    private void chooseClassToMove(final String targetPkg) {
        final ArrayList<String> files = PackageTools.javaFiles(JCompilerBridge.getCurrent());
        if (files.size() == 0) { toast("No Java classes"); return; }
        final String[] items = files.toArray(new String[files.size()]);
        new AlertDialog.Builder(this, Ui.dialogTheme()).setTitle("Move class to " + targetPkg)
            .setItems(items, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int which) {
                    String err = PackageTools.moveClass(JCompilerBridge.getCurrent(), items[which], targetPkg);
                    if (err.length() > 0) toast(err); else { toast("Class moved"); showPackageManager(); }
                }
            }).setNegativeButton("Cancel", null).show();
    }

    private void packageHealthDialog() {
        Project p = JCompilerBridge.getCurrent();
        ArrayList<PackageTools.Mismatch> bad = PackageTools.findMismatches(p);
        if (bad.size() == 0) {
            new AlertDialog.Builder(this, Ui.dialogTheme()).setTitle("Package check").setMessage("All Java package declarations match their folders.")
                .setPositiveButton("OK", null).show();
            return;
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < bad.size(); i++) sb.append(bad.get(i).file).append("\n  expected: ").append(bad.get(i).expected).append("\n  declared: ").append(bad.get(i).declared).append("\n\n");
        new AlertDialog.Builder(this, Ui.dialogTheme()).setTitle("Package check (" + bad.size() + ")")
            .setMessage(sb.toString()).setNegativeButton("Close", null).setPositiveButton("Fix all", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int w) {
                    StringBuffer e = new StringBuffer(); int fixed = PackageTools.fixAllDeclarations(JCompilerBridge.getCurrent(), e);
                    toast("Fixed " + fixed + " declaration(s)" + (e.length() > 0 ? "; some errors remain" : "")); showFiles();
                }
            }).show();
    }

    private void moveClassDialog(final String srcRel, final Runnable refresh) {
        final EditText f = Ui.field(this, "Target package", "");
        FrameLayout box = new FrameLayout(this); box.setPadding(Ui.dp(22), Ui.dp(8), Ui.dp(22), 0); box.addView(f);
        final AlertDialog dlg = new AlertDialog.Builder(this, Ui.dialogTheme()).setTitle("Move class")
            .setMessage(srcRel + "\nThe package line is updated automatically.")
            .setView(box)
            .setNegativeButton("Cancel", null).setPositiveButton("Move", null).create();
        dlg.show();
        dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String err = PackageTools.moveClass(JCompilerBridge.getCurrent(), srcRel, f.getText().toString().trim());
                if (err.length() > 0) { f.setError(err); return; }
                dlg.dismiss(); toast("Class moved"); refresh.run();
            }
        });
    }

    private void newFolderDialog(final String parent) {
        final EditText f = Ui.field(this, "Folder name", "newfolder");
        FrameLayout box = new FrameLayout(this); box.setPadding(Ui.dp(22), Ui.dp(8), Ui.dp(22), 0); box.addView(f);
        final AlertDialog dlg = new AlertDialog.Builder(this, Ui.dialogTheme()).setTitle("New folder").setView(box)
            .setNegativeButton("Cancel", null).setPositiveButton("Create", null).create();
        dlg.show();
        dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String err = ProjectTree.createFolder(JCompilerBridge.getCurrent(), parent, f.getText().toString().trim());
                if (err.length() > 0) { f.setError(err); return; }
                dlg.dismiss(); showFiles();
            }
        });
    }

    private void renameGenericDialog(final String rel) {
        String old = rel.substring(rel.lastIndexOf('/') + 1);
        final EditText f = Ui.field(this, "New name", old);
        FrameLayout box = new FrameLayout(this); box.setPadding(Ui.dp(22), Ui.dp(8), Ui.dp(22), 0); box.addView(f);
        final AlertDialog dlg = new AlertDialog.Builder(this, Ui.dialogTheme()).setTitle("Rename " + old).setView(box)
            .setNegativeButton("Cancel", null).setPositiveButton("Rename", null).create();
        dlg.show();
        dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String err = ProjectTree.rename(JCompilerBridge.getCurrent(), rel, f.getText().toString().trim());
                if (err.length() > 0) { f.setError(err); return; }
                dlg.dismiss(); showFiles();
            }
        });
    }

    private void deleteTreeNode(final String rel, final Runnable refresh) {
        int count = ProjectTree.countBelow(JCompilerBridge.getCurrent(), rel);
        new AlertDialog.Builder(this, Ui.dialogTheme()).setTitle("Delete " + rel + "?")
            .setMessage(count > 1 ? "This removes " + count + " files." : "This cannot be undone.")
            .setNegativeButton("Cancel", null).setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int w) {
                    String err = ProjectTree.delete(JCompilerBridge.getCurrent(), rel);
                    if (err.length() > 0) { toast(err); return; }
                    refresh.run();
                }
            }).show();
    }

    private void copyProjectPath(String rel) {
        String path = JCompilerBridge.getCurrent() == null ? rel : JCompilerBridge.getCurrent().folderName + "/" + rel;
        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("Project path", path));
        toast("Path copied");
    }

    private View fileRow(final String file, final Runnable back) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(Ui.ripple(Ui.rect(Ui.SURFACE, 16, Ui.STROKE)));
        card.setPadding(Ui.dp(14), Ui.dp(12), Ui.dp(10), Ui.dp(10));
        card.setClickable(true);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.addView(Ui.icon(this, R.drawable.ic_description, Ui.ACCENT, 24), Ui.lpMargin(Ui.dp(24), Ui.dp(24), 0, 0, 12, 0));
        LinearLayout mid = new LinearLayout(this);
        mid.setOrientation(LinearLayout.VERTICAL);
        boolean isMain = file.endsWith(JCompilerBridge.getMainClass() + ".java") && (file.length() == JCompilerBridge.getMainClass().length() + 5 || file.charAt(file.length() - JCompilerBridge.getMainClass().length() - 6) == '/');
        TextView t = Ui.label(this, file, 15, Ui.TEXT, true);
        t.setSingleLine(true);
        mid.addView(t);
        mid.addView(Ui.label(this, humanSize(JCompilerBridge.sourceSize(file)) + (isMain ? "  \u00B7  main MIDlet" : ""), 12, Ui.MUTED, false));
        top.addView(mid, Ui.lpWeight(0, Ui.WRAP, 1));
        card.addView(top);

        LinearLayout actions = new LinearLayout(this);
        actions.setGravity(Gravity.END);
        actions.addView(smallAction("Exp", Ui.ACCENT, new Runnable() { public void run() { pickExportFile(file); } }));
        actions.addView(smallAction("Ren", Ui.ACCENT, new Runnable() { public void run() { renameFileDialog(file); } }));
        actions.addView(smallAction("Del", Ui.RED, new Runnable() { public void run() { confirmDeleteFile(file); } }));
        card.addView(actions, Ui.lpMargin(Ui.MATCH, Ui.WRAP, 0, 8, 0, 0));

        onTap(card, new Runnable() { public void run() { showEditor(file); } });
        card.setLayoutParams(Ui.lpMargin(Ui.MATCH, Ui.WRAP, 0, 0, 0, 10));
        return card;
    }

    private View smallAction(String text, int color, final Runnable r) {
        TextView t = Ui.label(this, text, 13, color, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(Ui.dp(16), Ui.dp(8), Ui.dp(16), Ui.dp(8));
        t.setBackground(Ui.ripple(Ui.rect(Ui.SURFACE2, 12, 0)));
        t.setClickable(true);
        onTap(t, r);
        t.setLayoutParams(Ui.lpMargin(Ui.WRAP, Ui.WRAP, 8, 0, 0, 0));
        return t;
    }

    private void renameFileDialog(final String file) {
        final String oldPath = file.endsWith(".java") ? file.substring(0, file.length() - 5) : file;
        int slash = Math.max(oldPath.lastIndexOf('/'), oldPath.lastIndexOf('\\'));
        final String oldClass = slash >= 0 ? oldPath.substring(slash + 1) : oldPath;
        final String oldDir = slash >= 0 ? oldPath.substring(0, slash + 1) : "";
        final EditText name = Ui.field(this, "New class name", oldClass);
        FrameLayout box = new FrameLayout(this);
        box.setPadding(Ui.dp(22), Ui.dp(8), Ui.dp(22), 0);
        box.addView(name);
        final AlertDialog dlg = new AlertDialog.Builder(this, Ui.dialogTheme())
            .setTitle("Rename " + file).setMessage("Also renames the class inside the code and every use of it in this project.")
            .setView(box)
            .setNegativeButton("Cancel", null).setPositiveButton("Rename", null).create();
        dlg.show();
        dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String n = name.getText().toString().trim();
                if (n.endsWith(".java")) n = n.substring(0, n.length() - 5);
                String err = JCompilerBridge.renameSourceFile(file, n);
                if (err.length() > 0) { name.setError(err); return; }
                if (openFile.equals(file)) openFile = oldDir + n + ".java";
                dlg.dismiss();
                toast("Renamed to " + n + ".java");
                if (reshow != null) reshow.run();
            }
        });
    }

    private void confirmDeleteFile(final String f) {
        new AlertDialog.Builder(this, Ui.dialogTheme())
            .setTitle("Delete " + f + "?").setMessage("This cannot be undone.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int w) {
                    String err = JCompilerBridge.deleteFile(f);
                    if (err.length() > 0) { toast(err); return; }
                    if (openFile.equals(f)) { openFile = ""; dirty = false; }
                    if (reshow != null) reshow.run();
                }
            }).show();
    }

    private void newFileDialog(final boolean fromFiles) {
        newFileDialogInPackage(JCompilerBridge.getPackageName(), fromFiles);
    }

    private void newFileDialogInPackage(final String initialPackage, final boolean fromFiles) {
        final EditText name = Ui.field(this, "Class name, e.g. GameCanvas", "");
        final EditText pkgF = Ui.field(this, "Package (blank = default package)", initialPackage == null ? "" : initialPackage);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(Ui.dp(22), Ui.dp(8), Ui.dp(22), 0);
        box.addView(name, Ui.lpMargin(Ui.MATCH, Ui.WRAP, 0, 0, 0, 8));
        box.addView(pkgF, Ui.lp(Ui.MATCH, Ui.WRAP));
        final AlertDialog dlg = new AlertDialog.Builder(this, Ui.dialogTheme())
            .setTitle("New source file").setView(box)
            .setNegativeButton("Cancel", null).setPositiveButton("Create", null).create();
        dlg.show();
        dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String n = name.getText().toString().trim();
                if (n.endsWith(".java")) n = n.substring(0, n.length() - 5);
                String bad = JCompilerBridge.validateClassName(n);
                if (bad.length() > 0) { name.setError(bad); return; }
                String pkg = pkgF.getText().toString().trim();
                String pbad = JCompilerBridge.validatePackageName(pkg);
                if (pbad.length() > 0) { pkgF.setError(pbad); return; }
                String path = (pkg.length() > 0 ? pkg.replace('.', '/') + "/" : "") + n + ".java";
                String body = (pkg.length() > 0 ? "package " + pkg + ";\n\n" : "") + "public class " + n + " {\n\n}\n";
                String err = JCompilerBridge.createFile(path, body);
                if (err.length() > 0) { name.setError(err); return; }
                dlg.dismiss();
                saveCurrentIfEditor();
                showEditor(path);
            }
        });
    }

    private void resourcesDialog() {
        final Vector res = JCompilerBridge.listResources();
        if (res.size() == 0) {
            new AlertDialog.Builder(this, Ui.dialogTheme())
                .setTitle("Resources")
                .setMessage("No resources yet. Use \"Import files\".")
                .setPositiveButton("OK", null).show();
            return;
        }
        final String[] items = new String[res.size()];
        for (int i = 0; i < items.length; i++) items[i] = (String) res.elementAt(i);
        new AlertDialog.Builder(this, Ui.dialogTheme())
            .setTitle("Resources (tap to delete)")
            .setItems(items, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int which) {
                    String err = JCompilerBridge.deleteResource(items[which]);
                    toast(err.length() == 0 ? "Deleted " + items[which] : err);
                }
            })
            .setNegativeButton("Close", null).show();
    }

    // ------------------------------------------------------------------
    // 7. EDITOR
    // ------------------------------------------------------------------

    private void showEditor(String file) {
        leaveEditorState();
        inEditor = true;
        consoleOpen = false;
        consoleTab = 0;
        lastProblems = new Vector();
        lastWarnings = new Vector();
        history.clear();
        histPos = -1;

        final Project proj = JCompilerBridge.getCurrent();
        if (proj == null) { showHome(); return; }
        if (!proj.folderName.equals(openTabsProject)) { openTabs.clear(); openTabsProject = proj.folderName; }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);

        // ---- toolbar ----
        ImageView gear = Ui.iconButton(this, R.drawable.ic_settings, Ui.TEXT, new View.OnClickListener() {
            public void onClick(View v) { showProjectSettings(); }
        });
        ImageView build = Ui.iconButton(this, R.drawable.ic_play_arrow, Ui.WHITE, new View.OnClickListener() {
            public void onClick(View v) { runBuild(true); }
        });
        build.setBackground(Ui.ripple(Ui.circle(Ui.ACCENT)));
        build.setContentDescription("Build");
        build.setLayoutParams(Ui.lpMargin(Ui.dp(40), Ui.dp(40), 4, 0, 4, 0));
        final ImageView more = Ui.iconButton(this, R.drawable.ic_more_vert, Ui.TEXT, null);
        more.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { showEditorMenu(more); }
        });
        LinearLayout bar = topBar(proj.displayName(), "", new Runnable() {
            public void run() { saveCurrent(); showHome(); }
        }, gear, build, more);
        gear.setLayoutParams(Ui.lp(Ui.dp(44), Ui.dp(44)));
        more.setLayoutParams(Ui.lp(Ui.dp(44), Ui.dp(44)));
        root.addView(bar, Ui.lp(Ui.MATCH, Ui.WRAP));
        editorTopBar = bar;

        // ---- file tabs ----
        LinearLayout tabWrap = new LinearLayout(this);
        tabWrap.setGravity(Gravity.CENTER_VERTICAL);
        tabWrap.setBackgroundColor(Ui.SURFACE);
        ImageView treeBtn = Ui.iconButton(this, R.drawable.ic_folder_open, Ui.ACCENT, new View.OnClickListener() {
            public void onClick(View v) { if (drawerOpen) closeDrawer(); else openDrawer(); }
        });
        treeBtn.setContentDescription("File tree");
        tabWrap.addView(treeBtn, Ui.lpMargin(Ui.dp(40), Ui.dp(40), 4, 0, 0, 4));
        ImageView filesBtn = Ui.iconButton(this, R.drawable.ic_list, Ui.TEXT, new View.OnClickListener() {
            public void onClick(View v) { showFiles(); }
        });
        tabWrap.addView(filesBtn, Ui.lpMargin(Ui.dp(40), Ui.dp(40), 4, 0, 0, 4));
        ImageView quickBtn = Ui.iconButton(this, R.drawable.ic_search, Ui.TEXT, new View.OnClickListener() {
            public void onClick(View v) { showQuickOpen(); }
        });
        quickBtn.setContentDescription("Go to file");
        tabWrap.addView(quickBtn, Ui.lpMargin(Ui.dp(40), Ui.dp(40), 4, 0, 0, 4));
        HorizontalScrollView tabScroll = new HorizontalScrollView(this);
        tabScroll.setHorizontalScrollBarEnabled(false);
        tabsRow = new LinearLayout(this);
        tabsRow.setPadding(Ui.dp(4), 0, Ui.dp(8), Ui.dp(4));
        tabScroll.addView(tabsRow);
        tabWrap.addView(tabScroll, Ui.lpWeight(0, Ui.WRAP, 1));
        root.addView(tabWrap, Ui.lp(Ui.MATCH, Ui.WRAP));
        editorTabWrap = tabWrap;

        // ---- find / replace bar (hidden until opened) ----
        root.addView(buildFindBar(), Ui.lp(Ui.MATCH, Ui.WRAP));

        // ---- editor ----
        editor = new CodeEditText(this);
        editor.configure(settings.fontSize(), settings.wordWrap(), settings.lineNumbers());
        editor.setFilters(new InputFilter[]{ new AutoIndent() });
        editor.addTextChangedListener(new EditWatcher());
        editor.setScrollHook(new Runnable() {
            public void run() {
                if (editor.length() <= Highlighter.FULL_LIMIT) return;
                handler.removeCallbacks(scrollHighlightRun);
                handler.postDelayed(scrollHighlightRun, 70);
            }
        });
        root.addView(editor, Ui.lpWeight(Ui.MATCH, 0, 1));

        // ---- suggestions + symbols ----
        suggestScroll = new HorizontalScrollView(this);
        suggestScroll.setHorizontalScrollBarEnabled(false);
        suggestScroll.setBackgroundColor(Ui.SURFACE2);
        suggestRow = new LinearLayout(this);
        suggestRow.setGravity(Gravity.CENTER_VERTICAL);
        suggestRow.setPadding(Ui.dp(6), Ui.dp(5), Ui.dp(6), Ui.dp(5));
        suggestScroll.addView(suggestRow);
        suggestScroll.setVisibility(View.GONE);
        root.addView(suggestScroll, Ui.lp(Ui.MATCH, Ui.WRAP));
        root.addView(symbolBar());

        // ---- console ----
        root.addView(console());

        FrameLayout editorWrap = new FrameLayout(this);
        editorWrap.addView(root, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        attachEditorDrawer(editorWrap);

        present(editorWrap, new Runnable() {
            public void run() {
                if (drawerOpen) { closeDrawer(); return; }
                saveCurrent(); showHome();
            }
        }, new Runnable() {
            public void run() { showEditor(openFile); }
        });

        watchKeyboard();

        Vector files = splitNames(JCompilerBridge.listSourceFiles());
        String first = files.size() > 0 ? (String) files.elementAt(0) : "";
        String main = JCompilerBridge.getMainClass() + ".java";
        for (int i = 0; i < files.size(); i++) if (main.equals(files.elementAt(i))) first = main;
        if (file != null && file.length() > 0 && files.contains(file)) first = file;
        if (first.length() > 0) loadFile(first);
        else { openFile = ""; rebuildTabs(); }
        if (pendingEditorInsert != null) {
            final String ins = pendingEditorInsert;
            pendingEditorInsert = null;
            handler.post(new Runnable() { public void run() { insertText(ins); toast("Inserted"); } });
        }
    }

    // ------------------------------------------------------------------
    // colour palette + sprite editor
    // ------------------------------------------------------------------

    private static boolean isImageName(String name) {
        String l = name.toLowerCase();
        return l.endsWith(".png") || l.endsWith(".jpg") || l.endsWith(".jpeg") || l.endsWith(".gif") || l.endsWith(".bmp");
    }

    private ToolHost toolHost(final Runnable back, final boolean fromEditor) {
        return new ToolHost() {
            public Activity activity() { return MainActivity.this; }
            public void toast(String s) { MainActivity.this.toast(s); }
            public void copy(String text) {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("code", text));
            }
            public boolean canInsert() { return fromEditor; }
            public void insertIntoEditor(String text) {
                if (!fromEditor) { copy(text); MainActivity.this.toast("Copied"); return; }
                pendingEditorInsert = text;
                back.run();
            }
            public boolean hasProject() { return JCompilerBridge.getCurrent() != null; }
            public Vector listImageResources() {
                Vector out = new Vector();
                if (JCompilerBridge.getCurrent() == null) return out;
                Vector all = JCompilerBridge.listResources();
                for (int i = 0; i < all.size(); i++) if (isImageName((String) all.elementAt(i))) out.addElement(all.elementAt(i));
                return out;
            }
            public Bitmap loadResBitmap(String rel) {
                Project p = JCompilerBridge.getCurrent();
                if (p == null) return null;
                try {
                    BitmapFactory.Options o = new BitmapFactory.Options();
                    o.inScaled = false;
                    o.inPremultiplied = false;
                    return BitmapFactory.decodeFile(p.resUrl() + rel, o);
                } catch (Throwable t) { return null; }
            }
            public String savePng(String rel, byte[] png) {
                if (JCompilerBridge.getCurrent() != null) return JCompilerBridge.writeResource(rel, png);
                try {
                    File dir = new File(Environment.getExternalStorageDirectory(), "J2MEBuilder/sprites");
                    if (!dir.isDirectory() && !dir.mkdirs()) dir = new File(getExternalFilesDir(null), "sprites");
                    File f = new File(dir, rel);
                    File parent = f.getParentFile();
                    if (parent != null) parent.mkdirs();
                    java.io.FileOutputStream out = new java.io.FileOutputStream(f);
                    try { out.write(png); } finally { out.close(); }
                    return "";
                } catch (Throwable t) { return "Could not save: " + t.getMessage(); }
            }
            public String describeSave(String rel) {
                return JCompilerBridge.getCurrent() != null ? "res/" + rel : "sprites/" + rel;
            }
            public void pickDeviceImage(ImageSink sink) {
                pendingImageSink = sink;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.setType("image/*");
                i.addCategory(Intent.CATEGORY_OPENABLE);
                startActivityForResult(i, REQ_PICK_IMAGE);
            }
            public void pickDeviceImages(ImagesSink sink) {
                pendingImagesSink = sink;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.setType("image/*");
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                startActivityForResult(i, REQ_PICK_IMAGES);
            }
            public void exportToDevice(String fileName, String mime, byte[] data) {
                pendingExportBytes = data;
                Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType(mime);
                i.putExtra(Intent.EXTRA_TITLE, fileName);
                startActivityForResult(i, REQ_EXPORT_SPRITE);
            }
            public void pickDeviceFile(String[] mimes, FileSink sink) {
                pendingFileSink = sink;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.setType("*/*");
                i.addCategory(Intent.CATEGORY_OPENABLE);
                if (mimes != null && mimes.length > 0) i.putExtra(Intent.EXTRA_MIME_TYPES, mimes);
                startActivityForResult(i, REQ_PICK_FILE);
            }
            public Vector listResourcesByExt(String[] exts) {
                Vector out = new Vector();
                if (JCompilerBridge.getCurrent() == null) return out;
                Vector all = JCompilerBridge.listResources();
                for (int i = 0; i < all.size(); i++) {
                    String n = ((String) all.elementAt(i)).toLowerCase();
                    for (int k = 0; k < exts.length; k++) {
                        if (n.endsWith("." + exts[k])) { out.addElement(all.elementAt(i)); break; }
                    }
                }
                return out;
            }
            public byte[] readResource(String rel) {
                Project p = JCompilerBridge.getCurrent();
                if (p == null) return null;
                try {
                    java.io.FileInputStream in = new java.io.FileInputStream(p.resUrl() + rel);
                    return readAll(in);
                } catch (Throwable t) { return null; }
            }
            public boolean hasMicPermission() {
                return android.os.Build.VERSION.SDK_INT < 23
                        || MainActivity.this.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED;
            }
            public void requestMicPermission(Runnable onGranted) {
                pendingMicGranted = onGranted;
                MainActivity.this.requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
            }
            public void openTextComposer() { showMidiStudio(back, fromEditor); }
            public void exit() { back.run(); }
        };
    }

    /** Decodes an image from a content Uri without premultiplying alpha; null on failure. */
    private Bitmap decodeUriBitmap(Uri uri) {
        try {
            InputStream in = getContentResolver().openInputStream(uri);
            try {
                BitmapFactory.Options o = new BitmapFactory.Options();
                o.inScaled = false;
                o.inPremultiplied = false;
                return BitmapFactory.decodeStream(in, null, o);
            } finally { if (in != null) in.close(); }
        } catch (Throwable t) {
            return null;
        }
    }

    private void showColorPalette(final Runnable back, final boolean fromEditor) {
        saveCurrentIfEditor();
        leaveEditorState();
        final ToolHost h = toolHost(back, fromEditor);
        ColorPaletteScreen screen = new ColorPaletteScreen(h);
        present(screen.build(), new Runnable() { public void run() { h.exit(); } }, new Runnable() { public void run() { } });
    }

    private void showAudioStudio(final Runnable back, final boolean fromEditor) {
        saveCurrentIfEditor();
        leaveEditorState();
        final ToolHost h = toolHost(back, fromEditor);
        final AudioStudioScreen screen = new AudioStudioScreen(h);
        audioScreen = screen;
        // 'again' stays empty: rebuilding would throw away the song and recordings
        present(screen.build(), new Runnable() { public void run() { screen.requestExit(); } }, new Runnable() { public void run() { } });
    }

    private void showSpriteEditor(final Runnable back, final boolean fromEditor, final String resRel) {
        saveCurrentIfEditor();
        leaveEditorState();
        final ToolHost h = toolHost(back, fromEditor);
        final SpriteEditorScreen screen = new SpriteEditorScreen(h, resRel);
        // 'again' stays empty: rebuilding the screen would throw away unsaved drawing
        present(screen.build(), new Runnable() { public void run() { screen.requestExit(); } }, new Runnable() { public void run() { } });
    }

    // ------------------------------------------------------------------
    // editor file drawer (swipe in from the left edge, or tap the folder button)
    // ------------------------------------------------------------------

    private LinearLayout drawerPanel, drawerList;
    private EditText drawerSearch;
    private final boolean[] drawerShowRes = {true};
    private final boolean[] drawerShowBuild = {false};
    private View drawerScrim;
    private boolean drawerOpen;
    private boolean drawerAutoExpanded;
    private int drawerWidth;
    private final Vector drawerExpanded = new Vector();

    private void attachEditorDrawer(final FrameLayout wrap) {
        drawerOpen = false;
        drawerAutoExpanded = false;
        drawerExpanded.removeAllElements();
        drawerExpanded.addElement("");
        int screenW = getResources().getDisplayMetrics().widthPixels;
        drawerWidth = Math.min(Ui.dp(300), (int) (screenW * 0.82f));

        drawerScrim = new View(this);
        drawerScrim.setBackgroundColor(0x99000000);
        drawerScrim.setVisibility(View.GONE);
        drawerScrim.setAlpha(0f);
        drawerScrim.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { closeDrawer(); }
        });
        wrap.addView(drawerScrim, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));

        drawerPanel = new LinearLayout(this);
        drawerPanel.setOrientation(LinearLayout.VERTICAL);
        drawerPanel.setBackgroundColor(Ui.SURFACE);
        drawerPanel.setClickable(true);
        drawerPanel.setElevation(Ui.dp(12));
        drawerPanel.setVisibility(View.GONE);
        drawerPanel.setTranslationX(-drawerWidth);

        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setPadding(Ui.dp(14), Ui.dp(10), Ui.dp(2), Ui.dp(4));
        Project pj = JCompilerBridge.getCurrent();
        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        TextView t1 = Ui.label(this, pj != null ? pj.displayName() : "Project", 16, Ui.TEXT, true);
        t1.setSingleLine(true);
        t1.setEllipsize(android.text.TextUtils.TruncateAt.END);
        titles.addView(t1);
        titles.addView(Ui.label(this, "Project files  \u00B7  src, res ...", 11.5f, Ui.MUTED, false));
        head.addView(titles, Ui.lpWeight(0, Ui.WRAP, 1));
        head.addView(Ui.iconButton(this, R.drawable.ic_add, Ui.ACCENT, new View.OnClickListener() {
            public void onClick(View v) { saveCurrent(); showProjectAddMenu(v); }
        }), Ui.lp(Ui.dp(40), Ui.dp(40)));
        head.addView(Ui.iconButton(this, R.drawable.ic_list, Ui.MUTED, new View.OnClickListener() {
            public void onClick(View v) { showDrawerOptions(); }
        }), Ui.lp(Ui.dp(40), Ui.dp(40)));
        head.addView(Ui.iconButton(this, R.drawable.ic_close, Ui.MUTED, new View.OnClickListener() {
            public void onClick(View v) { closeDrawer(); }
        }), Ui.lp(Ui.dp(40), Ui.dp(40)));
        drawerPanel.addView(head, Ui.lp(Ui.MATCH, Ui.WRAP));

        drawerSearch = Ui.field(this, "Search file names...", "");
        drawerSearch.setPadding(Ui.dp(12), Ui.dp(8), Ui.dp(12), Ui.dp(8));
        drawerSearch.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence x, int a1, int b1, int c1) {}
            public void onTextChanged(CharSequence x, int a1, int b1, int c1) {}
            public void afterTextChanged(Editable e) { fillDrawer(); }
        });
        drawerPanel.addView(drawerSearch, Ui.lpMargin(Ui.MATCH, Ui.WRAP, 10, 2, 10, 6));
        drawerPanel.addView(Ui.divider(this));

        ScrollView sv = new ScrollView(this);
        drawerList = new LinearLayout(this);
        drawerList.setOrientation(LinearLayout.VERTICAL);
        drawerList.setPadding(Ui.dp(4), Ui.dp(4), Ui.dp(4), Ui.dp(12));
        sv.addView(drawerList, new FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP));
        drawerPanel.addView(sv, Ui.lpWeight(Ui.MATCH, 0, 1));

        final float[] sx = new float[1];
        drawerPanel.setOnTouchListener(new View.OnTouchListener() {   // swipe left on the panel closes it
            public boolean onTouch(View v, android.view.MotionEvent e) {
                if (e.getAction() == android.view.MotionEvent.ACTION_DOWN) sx[0] = e.getRawX();
                else if (e.getAction() == android.view.MotionEvent.ACTION_MOVE && sx[0] - e.getRawX() > Ui.dp(60)) {
                    closeDrawer();
                    return true;
                }
                return false;
            }
        });
        wrap.addView(drawerPanel, new FrameLayout.LayoutParams(drawerWidth, Ui.MATCH, Gravity.START));

        // invisible strip on the left edge of the code area: drag right to open
        final View edge = new View(this);
        final FrameLayout.LayoutParams elp = new FrameLayout.LayoutParams(Ui.dp(18), Ui.dp(200), Gravity.START | Gravity.TOP);
        elp.topMargin = Ui.dp(110);
        wrap.addView(edge, elp);
        final float[] ex = new float[1];
        edge.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View v, android.view.MotionEvent e) {
                if (e.getAction() == android.view.MotionEvent.ACTION_DOWN) { ex[0] = e.getRawX(); return true; }
                if (e.getAction() == android.view.MotionEvent.ACTION_MOVE && e.getRawX() - ex[0] > Ui.dp(24)) {
                    openDrawer();
                    return true;
                }
                return true;
            }
        });
        if (editor != null) {   // keep the strip over the code area only (not the toolbar / tabs / console)
            editor.addOnLayoutChangeListener(new View.OnLayoutChangeListener() {
                public void onLayoutChange(View v, int l, int t, int r, int b, int ol, int ot, int or, int ob) {
                    if (b - t <= 0) return;
                    elp.topMargin = t;
                    elp.height = b - t;
                    edge.setLayoutParams(elp);
                }
            });
        }
    }

    private void openDrawer() {
        if (drawerPanel == null || drawerOpen) return;
        hideKeyboard();
        fillDrawer();
        drawerOpen = true;
        drawerScrim.setVisibility(View.VISIBLE);
        drawerPanel.setVisibility(View.VISIBLE);
        drawerPanel.animate().translationX(0).setDuration(170).start();
        drawerScrim.animate().alpha(1f).setDuration(170).start();
    }

    private void closeDrawer() {
        if (drawerPanel == null || !drawerOpen) return;
        drawerOpen = false;
        final View panel = drawerPanel, scrim = drawerScrim;
        panel.animate().translationX(-drawerWidth).setDuration(150).start();
        scrim.animate().alpha(0f).setDuration(150).start();
        handler.postDelayed(new Runnable() {
            public void run() {
                if (!drawerOpen) { panel.setVisibility(View.GONE); scrim.setVisibility(View.GONE); }
            }
        }, 170);
    }

    private void fillDrawer() {
        if (drawerList == null) return;
        drawerList.removeAllViews();
        Project p = JCompilerBridge.getCurrent();
        if (p == null) return;
        ProjectTree.Options o = new ProjectTree.Options();
        o.showRes = drawerShowRes[0];
        o.showBuild = drawerShowBuild[0];
        o.showEmpty = true;
        ProjectTree.Node root = ProjectTree.build(p, o);
        if (!drawerAutoExpanded) {
            drawerAutoExpanded = true;
            expandSourceFoldersOnce(root, drawerExpanded);
            for (int i = 0; i < root.children.size(); i++) {      // open res/ (and bin/) one level too
                ProjectTree.Node c = root.children.get(i);
                if (c.kind == ProjectTree.RES && !drawerExpanded.contains(c.path)) drawerExpanded.addElement(c.path);
            }
        }
        String q = drawerSearch == null ? "" : drawerSearch.getText().toString().trim().toLowerCase();
        if (q.length() == 0) {
            renderDrawerNode(root, 0);
        } else {
            Vector hits = new Vector();
            collectDrawerHits(root, q, hits);
            for (int i = 0; i < hits.size(); i++) drawerList.addView(drawerRow((ProjectTree.Node) hits.elementAt(i), 0));
            if (hits.size() == 0) {
                TextView none = Ui.label(this, "No files match \"" + q + "\"", 13, Ui.MUTED, false);
                none.setGravity(Gravity.CENTER);
                none.setPadding(Ui.dp(12), Ui.dp(24), Ui.dp(12), Ui.dp(24));
                drawerList.addView(none, Ui.lp(Ui.MATCH, Ui.WRAP));
            }
        }
    }

    private void collectDrawerHits(ProjectTree.Node n, String q, Vector out) {
        if (n == null) return;
        if (!n.isDir() && n.name.toLowerCase().indexOf(q) >= 0) out.addElement(n);
        for (int i = 0; i < n.children.size(); i++) collectDrawerHits(n.children.get(i), q, out);
    }

    private void showDrawerOptions() {
        final String[] items = {"Expand all", "Collapse all",
            drawerShowRes[0] ? "Hide res folder" : "Show res folder",
            drawerShowBuild[0] ? "Hide build output" : "Show build output",
            "Package manager", "Open full Files screen"};
        new AlertDialog.Builder(this, Ui.dialogTheme()).setTitle("Project files").setItems(items, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface d, int which) {
                if (which == 0) {
                    Project p = JCompilerBridge.getCurrent();
                    if (p != null) {
                        ProjectTree.Options o = new ProjectTree.Options();
                        o.showRes = drawerShowRes[0];
                        o.showBuild = drawerShowBuild[0];
                        drawerExpanded.removeAllElements();
                        collectDirPaths(ProjectTree.build(p, o), drawerExpanded);
                    }
                    fillDrawer();
                } else if (which == 1) {
                    drawerExpanded.removeAllElements();
                    drawerExpanded.addElement("");
                    fillDrawer();
                } else if (which == 2) { drawerShowRes[0] = !drawerShowRes[0]; fillDrawer(); }
                else if (which == 3) { drawerShowBuild[0] = !drawerShowBuild[0]; fillDrawer(); }
                else if (which == 4) { saveCurrent(); closeDrawer(); showPackageManager(); }
                else { closeDrawer(); showFiles(); }
            }
        }).show();
    }

    private void renderDrawerNode(ProjectTree.Node n, int depth) {
        if (n == null) return;
        drawerList.addView(drawerRow(n, depth));
        if (n.isDir() && drawerExpanded.contains(n.path)) {
            for (int i = 0; i < n.children.size(); i++) renderDrawerNode(n.children.get(i), depth + 1);
        }
    }

    private View drawerRow(final ProjectTree.Node n, int depth) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setMinimumHeight(Ui.dp(42));
        row.setPadding(Ui.dp(4 + depth * 14), Ui.dp(2), Ui.dp(0), Ui.dp(2));
        boolean current = n.isJava() && n.srcRel() != null && n.srcRel().equals(openFile);
        row.setBackground(Ui.ripple(Ui.rect(current ? ((Ui.ACCENT & 0x00FFFFFF) | 0x33000000) : 0x00000000, 8, 0)));
        row.setClickable(true);
        boolean open = n.isDir() && drawerExpanded.contains(n.path);
        if (n.isDir()) {
            row.addView(Ui.icon(this, open ? R.drawable.ic_expand_more : R.drawable.ic_chevron_right, Ui.MUTED, 24), Ui.lp(Ui.dp(22), Ui.dp(22)));
        } else {
            row.addView(new Space(this), Ui.lp(Ui.dp(22), Ui.dp(1)));
        }
        int icon = n.isDir() ? (open ? R.drawable.ic_folder_open : R.drawable.ic_folder) : fileIconFor(n.name);
        int tint = n.isJava() ? Ui.ACCENT : (n.kind == ProjectTree.SRC || n.kind == ProjectTree.RES ? Ui.ACCENT : Ui.MUTED);
        row.addView(Ui.icon(this, icon, tint, 24), Ui.lpMargin(Ui.dp(22), Ui.dp(22), 2, 0, 8, 0));
        String label = n.kind == ProjectTree.ROOT ? (n.name.length() == 0 ? "project" : n.name) : n.name;
        LinearLayout txt = new LinearLayout(this);
        txt.setOrientation(LinearLayout.VERTICAL);
        TextView name = Ui.label(this, label, 14, current ? Ui.ACCENT : Ui.TEXT, current || n.isDir());
        name.setSingleLine(true);
        name.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
        txt.addView(name);
        if (!n.isDir() && depth == 0 && n.path.indexOf('/') > 0) {      // search results: show where the file lives
            TextView where = Ui.label(this, ProjectTree.shortPath(n.path), 10.5f, Ui.MUTED, false);
            where.setSingleLine(true);
            where.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
            txt.addView(where);
        }
        row.addView(txt, Ui.lpWeight(0, Ui.WRAP, 1));
        final Runnable refresh = new Runnable() { public void run() { fillDrawer(); } };
        row.addView(Ui.iconButton(this, R.drawable.ic_more_vert, Ui.MUTED, new View.OnClickListener() {
            public void onClick(View v) { saveCurrent(); showTreeContext(n, drawerExpanded, refresh); }
        }), Ui.lp(Ui.dp(38), Ui.dp(38)));
        onTap(row, new Runnable() {
            public void run() {
                if (n.isDir()) {
                    if (drawerExpanded.contains(n.path)) drawerExpanded.removeElement(n.path); else drawerExpanded.addElement(n.path);
                    fillDrawer();
                } else if (n.isJava() && n.srcRel() != null) {
                    if (!n.srcRel().equals(openFile)) { saveCurrent(); loadFile(n.srcRel()); }
                    closeDrawer();
                } else {
                    openProjectFilePreview(n);
                }
            }
        });
        row.setOnLongClickListener(new View.OnLongClickListener() {
            public boolean onLongClick(View v) { saveCurrent(); showTreeContext(n, drawerExpanded, refresh); return true; }
        });
        return row;
    }

    /** Non-Java files from the drawer: images are previewed, small text files can be edited and saved. */
    private void openProjectFilePreview(final ProjectTree.Node n) {
        Project p = JCompilerBridge.getCurrent();
        if (p == null) return;
        File f;
        try { f = ProjectTree.resolve(p, n.path); } catch (IOException e) { toast(e.getMessage()); return; }
        String e = ProjectTree.ext(n.name).toLowerCase();
        if (e.equals("png") || e.equals("jpg") || e.equals("jpeg") || e.equals("gif") || e.equals("bmp")) {
            Bitmap bm = null;
            try {
                BitmapFactory.Options bo = new BitmapFactory.Options();
                bo.inJustDecodeBounds = true;
                BitmapFactory.decodeFile(f.getAbsolutePath(), bo);
                int sample = 1;
                while (bo.outWidth / (sample * 2) >= 600 && bo.outHeight / (sample * 2) >= 600) sample *= 2;
                BitmapFactory.Options o2 = new BitmapFactory.Options();
                o2.inSampleSize = sample;
                bm = BitmapFactory.decodeFile(f.getAbsolutePath(), o2);
                ImageView iv = new ImageView(this);
                iv.setImageBitmap(bm);
                iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
                iv.setAdjustViewBounds(true);
                iv.setPadding(Ui.dp(12), Ui.dp(12), Ui.dp(12), Ui.dp(12));
                new AlertDialog.Builder(this, Ui.dialogTheme())
                    .setTitle(n.name + "  (" + bo.outWidth + "x" + bo.outHeight + ")")
                    .setView(iv)
                    .setPositiveButton("Close", null)
                    .setNeutralButton(n.path.startsWith("res/") ? "Edit sprite" : null, new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface d, int w) {
                            final String keep = openFile;
                            showSpriteEditor(new Runnable() { public void run() { showEditor(keep); } }, true, n.path.substring(4));
                        }
                    })
                    .show();
            } catch (Throwable t) { toast(n.name + "  \u00B7  " + humanSize(n.size)); }
            return;
        }
        if (n.size > 0 && n.size <= 64 * 1024 && (e.equals("txt") || e.equals("properties") || e.equals("xml") || e.equals("json")
                || e.equals("mf") || e.equals("jad") || e.equals("md") || e.equals("csv") || e.length() == 0)) {
            try {
                String text = new String(readAll(new java.io.FileInputStream(f)), "UTF-8");
                final EditText et = new EditText(this);
                et.setText(text);
                et.setTypeface(android.graphics.Typeface.MONOSPACE);
                et.setTextSize(12.5f);
                et.setTextColor(Ui.TEXT);
                et.setBackground(null);
                et.setGravity(Gravity.TOP | Gravity.START);
                et.setHorizontallyScrolling(false);
                et.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
                        | android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS | android.text.InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
                et.setPadding(Ui.dp(16), Ui.dp(10), Ui.dp(16), Ui.dp(10));
                et.setMinLines(8);
                ScrollView sv2 = new ScrollView(this);
                sv2.addView(et, new FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP));
                final File target = f;
                final String original = text;
                new AlertDialog.Builder(this, Ui.dialogTheme())
                    .setTitle("Edit " + n.name)
                    .setView(sv2)
                    .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface d, int w) {
                            String now = et.getText().toString();
                            if (now.equals(original)) { toast("No changes"); return; }
                            try {
                                java.io.FileOutputStream out = new java.io.FileOutputStream(target);
                                try { out.write(now.getBytes("UTF-8")); } finally { out.close(); }
                                toast("Saved " + n.name);
                                if (drawerOpen) fillDrawer();
                            } catch (Throwable t) { toast("Could not save: " + t.getMessage()); }
                        }
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
            } catch (Throwable t) { toast("Could not read " + n.name); }
            return;
        }
        toast(n.name + "  \u00B7  " + humanSize(n.size));
    }

    /** While the keyboard is up, give the code the whole screen: the console is hidden and,
     *  on short screens, the toolbar and file tabs too. The caret is scrolled back into view. */
    private void watchKeyboard() {
        final View decor = getWindow().getDecorView();
        kbListener = new ViewTreeObserver.OnGlobalLayoutListener() {
            public void onGlobalLayout() {
                if (!inEditor || consolePanel == null) return;
                Rect r = new Rect();
                decor.getWindowVisibleDisplayFrame(r);
                int screenH = decor.getRootView().getHeight();
                boolean open = screenH > 0 && (screenH - r.bottom) > screenH * 0.15f;
                if (open != keyboardOpen) {
                    keyboardOpen = open;
                    consolePanel.setVisibility(open ? View.GONE : View.VISIBLE);
                    boolean compact = open && r.height() < Ui.dp(520);
                    if (editorTopBar != null) editorTopBar.setVisibility(compact ? View.GONE : View.VISIBLE);
                    if (editorTabWrap != null) editorTabWrap.setVisibility(compact ? View.GONE : View.VISIBLE);
                    if (editor != null) {
                        editor.setKeyboardOpen(open);
                        handler.postDelayed(new Runnable() {
                            public void run() {
                                if (editor != null && editor.hasFocus()) editor.revealCaret();
                            }
                        }, 120);
                    }
                }
            }
        };
        decor.getViewTreeObserver().addOnGlobalLayoutListener(kbListener);
    }

    private View buildFindBar() {
        findBar = new LinearLayout(this);
        findBar.setOrientation(LinearLayout.VERTICAL);
        findBar.setBackgroundColor(Ui.SURFACE);
        findBar.setPadding(Ui.dp(10), Ui.dp(4), Ui.dp(6), Ui.dp(8));
        findBar.setVisibility(View.GONE);

        LinearLayout r1 = new LinearLayout(this);
        r1.setGravity(Gravity.CENTER_VERTICAL);
        findField = Ui.field(this, "Find", "");
        findField.setPadding(Ui.dp(12), Ui.dp(8), Ui.dp(12), Ui.dp(8));
        findField.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH);
        findField.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            public boolean onEditorAction(TextView v, int actionId, android.view.KeyEvent e) {
                doFind(true);
                return true;
            }
        });
        r1.addView(findField, Ui.lpWeight(0, Ui.WRAP, 1));
        r1.addView(Ui.iconButton(this, R.drawable.ic_expand_less, Ui.TEXT, new View.OnClickListener() {
            public void onClick(View v) { doFind(false); }
        }), Ui.lp(Ui.dp(40), Ui.dp(40)));
        r1.addView(Ui.iconButton(this, R.drawable.ic_expand_more, Ui.TEXT, new View.OnClickListener() {
            public void onClick(View v) { doFind(true); }
        }), Ui.lp(Ui.dp(40), Ui.dp(40)));
        r1.addView(Ui.iconButton(this, R.drawable.ic_close, Ui.MUTED, new View.OnClickListener() {
            public void onClick(View v) { setFindBar(false); }
        }), Ui.lp(Ui.dp(40), Ui.dp(40)));
        findBar.addView(r1);

        LinearLayout r2 = new LinearLayout(this);
        r2.setGravity(Gravity.CENTER_VERTICAL);
        replaceField = Ui.field(this, "Replace with", "");
        replaceField.setPadding(Ui.dp(12), Ui.dp(8), Ui.dp(12), Ui.dp(8));
        r2.addView(replaceField, Ui.lpWeight(0, Ui.WRAP, 1));
        TextView all = Ui.pill(this, "Replace all", 0, Ui.ACCENT, new View.OnClickListener() {
            public void onClick(View v) {
                if (editor == null) return;
                String q = findField.getText().toString();
                if (q.length() == 0) return;
                int n = editor.replaceAll(q, replaceField.getText().toString());
                toast(n == 0 ? "No matches" : "Replaced " + n);
            }
        });
        all.setTextSize(13);
        r2.addView(all, Ui.lpMargin(Ui.WRAP, Ui.WRAP, 6, 0, 4, 0));
        findBar.addView(r2, Ui.lpMargin(Ui.MATCH, Ui.WRAP, 0, 6, 0, 0));
        return findBar;
    }

    private void setFindBar(boolean show) {
        if (findBar == null) return;
        findBar.setVisibility(show ? View.VISIBLE : View.GONE);
        if (show) {
            if (editor != null) {
                int a = editor.getSelectionStart(), b = editor.getSelectionEnd();
                if (a >= 0 && b > a && b - a < 60) findField.setText(editor.getText().subSequence(a, b).toString());
            }
            findField.requestFocus();
        } else {
            hideKeyboard();
            if (editor != null) editor.requestFocus();
        }
    }

    private void doFind(boolean forward) {
        if (editor == null) return;
        String q = findField.getText().toString();
        if (q.length() == 0) return;
        if (!editor.find(q, forward)) toast("Not found");
    }

    private void goToLineDialog() {
        if (editor == null) return;
        final EditText n = Ui.field(this, "1 - " + editor.lineCountLogical(), "");
        n.setInputType(InputType.TYPE_CLASS_NUMBER);
        FrameLayout box = new FrameLayout(this);
        box.setPadding(Ui.dp(22), Ui.dp(8), Ui.dp(22), 0);
        box.addView(n);
        final AlertDialog dlg = new AlertDialog.Builder(this, Ui.dialogTheme())
            .setTitle("Go to line").setView(box)
            .setNegativeButton("Cancel", null).setPositiveButton("Go", null).create();
        dlg.show();
        dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                int line;
                try { line = Integer.parseInt(n.getText().toString().trim()); }
                catch (NumberFormatException e) { n.setError("Enter a number"); return; }
                if (!editor.goToLine(line)) { n.setError("Out of range"); return; }
                dlg.dismiss();
            }
        });
    }

    private View symbolBar() {
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        hs.setBackgroundColor(Ui.SURFACE);
        LinearLayout row = new LinearLayout(this);
        row.setPadding(Ui.dp(6), Ui.dp(4), Ui.dp(6), Ui.dp(4));

        // undo / redo first
        row.addView(symbolIcon(R.drawable.ic_undo, new Runnable() { public void run() { undo(); } }));
        row.addView(symbolIcon(R.drawable.ic_redo, new Runnable() { public void run() { redo(); } }));

        String[] keys = {"TAB", "\u2190", "\u2192", "{", "}", "(", ")", "[", "]", ";", "\"", "'", "=", ".", ",", "<", ">", "+", "-", "*", "/", "!", "&", "|", "_", ":", "?", "@", "#"};
        for (int i = 0; i < keys.length; i++) {
            final String k = keys[i];
            TextView t = Ui.label(this, k, 15, Ui.TEXT, true);
            t.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
            t.setGravity(Gravity.CENTER);
            t.setBackground(Ui.ripple(Ui.rect(Ui.SURFACE2, 8, 0)));
            t.setClickable(true);
            t.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    if (k.equals("TAB")) insertText(tabString());
                    else if (k.equals("\u2190")) moveCaret(-1);
                    else if (k.equals("\u2192")) moveCaret(1);
                    else insertText(k);
                }
            });
            row.addView(t, Ui.lpMargin(k.length() > 1 ? Ui.dp(52) : Ui.dp(40), Ui.dp(38), 3, 0, 3, 0));
        }
        hs.addView(row);
        return hs;
    }

    private View symbolIcon(int res, final Runnable r) {
        ImageView v = new ImageView(this);
        v.setImageResource(res);
        Ui.setTint(v, Ui.TEXT);
        v.setScaleType(ImageView.ScaleType.CENTER);
        v.setBackground(Ui.ripple(Ui.rect(Ui.SURFACE2, 8, 0)));
        v.setClickable(true);
        onTap(v, r);
        v.setLayoutParams(Ui.lpMargin(Ui.dp(40), Ui.dp(38), 3, 0, 3, 0));
        return v;
    }

    private String tabString() {
        return settings.tabSize() == 2 ? "  " : "    ";
    }

    private void moveCaret(int d) {
        if (editor == null) return;
        int p = editor.getSelectionStart() + d;
        p = Math.max(0, Math.min(editor.length(), p));
        editor.setSelection(p);
    }

    private void insertText(String s) {
        if (editor == null) return;
        int a = Math.max(0, editor.getSelectionStart());
        int b = Math.max(0, editor.getSelectionEnd());
        editor.getText().replace(Math.min(a, b), Math.max(a, b), s);
    }

    // ---- console ----

    private View console() {
        consolePanel = new LinearLayout(this);
        consolePanel.setOrientation(LinearLayout.VERTICAL);
        consolePanel.setBackgroundColor(Ui.SURFACE);

        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setPadding(Ui.dp(16), 0, Ui.dp(8), 0);
        head.setClickable(true);
        consoleDot = new View(this);
        consoleDot.setBackground(Ui.circle(Ui.MUTED));
        head.addView(consoleDot, Ui.lpMargin(Ui.dp(8), Ui.dp(8), 0, 0, 10, 0));
        consoleStatus = Ui.label(this, "Output", 13, Ui.TEXT, true);
        consoleStatus.setSingleLine(true);
        head.addView(consoleStatus, Ui.lpWeight(0, Ui.WRAP, 1));
        consoleChevron = Ui.icon(this, R.drawable.ic_expand_less, Ui.MUTED, 24);
        head.addView(consoleChevron, Ui.lp(Ui.dp(40), Ui.dp(40)));
        onTap(head, new Runnable() { public void run() { setConsoleOpen(!consoleOpen); } });
        ((LinearLayout) consolePanel).addView(head, Ui.lp(Ui.MATCH, Ui.dp(40)));

        consoleTabs = new LinearLayout(this);
        consoleTabs.setPadding(Ui.dp(10), 0, Ui.dp(10), Ui.dp(6));
        tabLog = consoleTabView("Log", 0);
        tabProblems = consoleTabView("Errors (0)", 1);
        tabWarnings = consoleTabView("Warnings (0)", 2);
        consoleTabs.addView(tabLog);
        consoleTabs.addView(tabProblems);
        consoleTabs.addView(tabWarnings);
        consoleTabs.setGravity(Gravity.CENTER_VERTICAL);
        consoleTabs.addView(new View(this), Ui.lpWeight(0, 1, 1));
        consoleExpandBtn = Ui.iconButton(this, R.drawable.ic_fullscreen, Ui.MUTED, new View.OnClickListener() {
            public void onClick(View v) { setConsoleExpanded(!consoleExpanded); }
        });
        consoleTabs.addView(consoleExpandBtn, Ui.lp(Ui.dp(36), Ui.dp(36)));
        ImageView copyAll = Ui.iconButton(this, R.drawable.ic_content_copy, Ui.MUTED, new View.OnClickListener() {
            public void onClick(View v) { copyConsoleTab(); }
        });
        consoleTabs.addView(copyAll, Ui.lp(Ui.dp(36), Ui.dp(36)));
        consoleTabs.setVisibility(View.GONE);
        ((LinearLayout) consolePanel).addView(consoleTabs, Ui.lp(Ui.MATCH, Ui.WRAP));

        FrameLayout content = new FrameLayout(this);
        int screenH = getResources().getDisplayMetrics().heightPixels;
        consoleHeightPx = Math.min(Ui.dp(260), Math.max(Ui.dp(150), (int) (screenH * 0.32f)));

        consoleLogScroll = new ScrollView(this);
        consoleBody = Ui.label(this, "Press the play button to build your project.", 12, Ui.MUTED, false);
        consoleBody.setTypeface(Typeface.MONOSPACE);
        consoleBody.setPadding(Ui.dp(16), Ui.dp(4), Ui.dp(16), Ui.dp(14));
        consoleLogScroll.addView(consoleBody);
        content.addView(consoleLogScroll, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));

        consoleListScroll = new ScrollView(this);
        consoleList = new LinearLayout(this);
        consoleList.setOrientation(LinearLayout.VERTICAL);
        consoleList.setPadding(Ui.dp(12), Ui.dp(2), Ui.dp(12), Ui.dp(12));
        consoleListScroll.addView(consoleList);
        consoleListScroll.setVisibility(View.GONE);
        content.addView(consoleListScroll, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        content.setVisibility(View.GONE);
        content.setTag("content");
        ((LinearLayout) consolePanel).addView(content, Ui.lp(Ui.MATCH, consoleHeightPx));

        log = new ConsoleLog(consoleBody, consoleLogScroll);
        log.setAnimate(settings.animatedLog());
        return consolePanel;
    }

    private TextView consoleTabView(String text, final int idx) {
        TextView t = Ui.label(this, text, 12.5f, Ui.MUTED, true);
        t.setPadding(Ui.dp(12), Ui.dp(6), Ui.dp(12), Ui.dp(6));
        t.setClickable(true);
        onTap(t, new Runnable() { public void run() { selectConsoleTab(idx); } });
        t.setLayoutParams(Ui.lpMargin(Ui.WRAP, Ui.WRAP, 0, 0, 6, 0));
        return t;
    }

    private void selectConsoleTab(int idx) {
        consoleTab = idx;
        TextView[] tabs = {tabLog, tabProblems, tabWarnings};
        for (int i = 0; i < tabs.length; i++) {
            boolean on = i == idx;
            int off = i == 1 && lastProblems.size() > 0 ? Ui.RED : (i == 2 && lastWarnings.size() > 0 ? Ui.AMBER : Ui.MUTED);
            tabs[i].setTextColor(on ? (i == 1 ? Ui.RED : (i == 2 ? Ui.AMBER : Ui.ACCENT)) : off);
            tabs[i].setBackground(on ? Ui.rect(i == 1 ? Ui.RED_SOFT : Ui.ACCENT_SOFT, 12, 0) : null);
        }
        consoleLogScroll.setVisibility(idx == 0 ? View.VISIBLE : View.GONE);
        consoleListScroll.setVisibility(idx == 0 ? View.GONE : View.VISIBLE);
        if (idx == 1) fillProblemList();
        if (idx == 2) fillWarningList();
    }

    private View consoleContent() {
        return consolePanel.findViewWithTag("content");
    }

    private void setConsoleOpen(boolean open) {
        consoleOpen = open;
        consoleContent().setVisibility(open ? View.VISIBLE : View.GONE);
        consoleTabs.setVisibility(open ? View.VISIBLE : View.GONE);
        consoleChevron.setRotation(open ? 180f : 0f);
        if (open) selectConsoleTab(consoleTab);
    }

    private void setStatus(int dotColor, String status) {
        consoleDot.setBackground(Ui.circle(dotColor));
        consoleStatus.setText(status);
    }

    private void updateTabCounts() {
        tabProblems.setText("Errors (" + lastProblems.size() + ")");
        tabWarnings.setText("Warnings (" + lastWarnings.size() + ")");
        selectConsoleTabColors();
    }

    private void selectConsoleTabColors() {
        TextView[] tabs = {tabLog, tabProblems, tabWarnings};
        for (int i = 1; i < tabs.length; i++) {
            if (i == consoleTab) continue;
            tabs[i].setTextColor(i == 1 && lastProblems.size() > 0 ? Ui.RED : (i == 2 && lastWarnings.size() > 0 ? Ui.AMBER : Ui.MUTED));
        }
    }

    /** Makes the log panel tall (about 72% of the screen) or back to its normal height. */
    private void setConsoleExpanded(boolean on) {
        consoleExpanded = on;
        View c = consoleContent();
        if (c == null) return;
        int screenH = getResources().getDisplayMetrics().heightPixels;
        ViewGroup.LayoutParams lp = c.getLayoutParams();
        lp.height = on ? (int) (screenH * 0.72f) : consoleHeightPx;
        c.setLayoutParams(lp);
        if (consoleExpandBtn != null) consoleExpandBtn.setImageResource(on ? R.drawable.ic_fullscreen_exit : R.drawable.ic_fullscreen);
        if (on && !consoleOpen) setConsoleOpen(true);
    }

    private void fillProblemList() {
        consoleList.removeAllViews();
        if (lastProblems.size() == 0) {
            consoleList.addView(emptyNote("No errors"));
            return;
        }
        addProblemPage(0);
    }

    /** Builds LIST_PAGE rows at a time so a build with hundreds of errors never freezes the UI. */
    private void addProblemPage(int from) {
        if (from > 0 && consoleList.getChildCount() > 0) consoleList.removeViewAt(consoleList.getChildCount() - 1);   // old "more" row
        int to = Math.min(lastProblems.size(), from + LIST_PAGE);
        for (int i = from; i < to; i++) {
            consoleList.addView(problemRow((JCompilerBridge.Problem) lastProblems.elementAt(i)));
        }
        if (to < lastProblems.size()) {
            final int next = to;
            consoleList.addView(moreRow(lastProblems.size() - to, new Runnable() { public void run() { addProblemPage(next); } }));
        }
    }

    private View moreRow(int left, final Runnable more) {
        TextView t = Ui.label(this, "Show more  (" + left + " left)", 13, Ui.ACCENT, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, Ui.dp(12), 0, Ui.dp(12));
        t.setClickable(true);
        t.setLayoutParams(Ui.lp(Ui.MATCH, Ui.WRAP));
        onTap(t, more);
        return t;
    }

    private void fillWarningList() {
        consoleList.removeAllViews();
        if (lastWarnings.size() == 0) {
            consoleList.addView(emptyNote("No warnings"));
            return;
        }
        addWarningPage(0);
    }

    private void addWarningPage(int from) {
        if (from > 0 && consoleList.getChildCount() > 0) consoleList.removeViewAt(consoleList.getChildCount() - 1);
        int to = Math.min(lastWarnings.size(), from + LIST_PAGE);
        for (int i = from; i < to; i++) consoleList.addView(warningRow((Lint.Warning) lastWarnings.elementAt(i)));
        if (to < lastWarnings.size()) {
            final int next = to;
            consoleList.addView(moreRow(lastWarnings.size() - to, new Runnable() { public void run() { addWarningPage(next); } }));
        }
    }

    private View warningRow(final Lint.Warning w) {
        {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.VERTICAL);
            row.setPadding(Ui.dp(12), Ui.dp(8), Ui.dp(12), Ui.dp(8));
            row.setBackground(Ui.ripple(Ui.rect(Ui.SURFACE2, 12, 0)));
            row.setClickable(true);
            TextView t = Ui.label(this, w.message, 13, Ui.TEXT, false);
            row.addView(t);
            if (w.file != null && w.file.length() > 0) {
                row.addView(Ui.label(this, w.file + (w.line > 0 ? ":" + w.line : ""), 11.5f, Ui.AMBER, true));
                final String f = w.file;
                final int ln = w.line;
                onTap(row, new Runnable() { public void run() { jumpTo(f, ln, false); } });
            }
            row.setOnLongClickListener(new View.OnLongClickListener() {
                public boolean onLongClick(View v) { copyText("warning", warningText(w), "Warning copied"); return true; }
            });
            row.setLayoutParams(Ui.lpMargin(Ui.MATCH, Ui.WRAP, 0, 4, 0, 0));
            return row;
        }
    }

    private View emptyNote(String s) {
        TextView t = Ui.label(this, s, 13, Ui.MUTED, false);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, Ui.dp(24), 0, 0);
        t.setLayoutParams(Ui.lp(Ui.MATCH, Ui.WRAP));
        return t;
    }

    private View problemRow(final JCompilerBridge.Problem p) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(Ui.dp(12), Ui.dp(8), Ui.dp(12), Ui.dp(8));
        row.setBackground(Ui.ripple(Ui.rect(Ui.RED_SOFT, 12, 0)));
        row.setClickable(true);
        String where = p.file.length() > 0 ? p.file + (p.line > 0 ? ":" + p.line + (p.col > 0 ? ":" + p.col : "") : "") : "build";
        if (p.category.length() > 0 && !p.category.equals("Error")) where = where + "   \u00B7   " + p.category;
        row.addView(Ui.label(this, where, 12, Ui.RED, true));
        TextView msg = Ui.label(this, p.message, 13, Ui.TEXT, false);
        row.addView(msg);
        if (p.snippet.length() > 0) {
            TextView sn = Ui.label(this, "> " + p.snippet + (p.caret.length() > 0 ? "\n  " + p.caret : ""), 12, Ui.MUTED, false);
            sn.setTypeface(Typeface.MONOSPACE);
            row.addView(sn);
        }
        if (p.hint.length() > 0) {
            row.addView(Ui.label(this, "Tip: " + p.hint, 12, Ui.AMBER, false), Ui.lpMargin(Ui.MATCH, Ui.WRAP, 0, 4, 0, 0));
        }
        final String missing = Suggest.missingTypeFrom(p.message);
        if (missing != null && p.file.length() > 0) {
            Vector cands = Suggest.candidatesFor(missing, JCompilerBridge.api());
            if (cands.size() > 0) {
                TextView fix = Ui.pill(this, cands.size() == 1
                        ? "Add import " + cands.elementAt(0) : "Add import " + missing + "...", Ui.ACCENT, Ui.WHITE, null);
                fix.setTextSize(12);
                fix.setPadding(Ui.dp(12), Ui.dp(6), Ui.dp(12), Ui.dp(6));
                fix.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) { quickFixImport(p.file, missing); }
                });
                row.addView(fix, Ui.lpMargin(Ui.WRAP, Ui.WRAP, 0, 8, 0, 2));
            }
        }
        if (p.file.length() > 0) {
            final String f = p.file;
            final int ln = p.line;
            onTap(row, new Runnable() { public void run() { jumpTo(f, ln, true); } });
        }
        row.setOnLongClickListener(new View.OnLongClickListener() {
            public boolean onLongClick(View v) { copyText("problem", problemText(p), "Problem copied"); return true; }
        });
        row.setLayoutParams(Ui.lpMargin(Ui.MATCH, Ui.WRAP, 0, 4, 0, 0));
        return row;
    }

    private void quickFixImport(final String file, String simple) {
        final Vector cands = Suggest.candidatesFor(simple, JCompilerBridge.api());
        if (cands.size() == 0) { toast("No API class called " + simple); return; }
        if (cands.size() == 1) { applyImportFix(file, (String) cands.elementAt(0)); return; }
        final String[] items = new String[cands.size()];
        for (int i = 0; i < items.length; i++) items[i] = (String) cands.elementAt(i);
        new AlertDialog.Builder(this, Ui.dialogTheme())
            .setTitle("Which " + simple + "?")
            .setItems(items, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int which) { applyImportFix(file, items[which]); }
            }).show();
    }

    private void applyImportFix(String file, String fq) {
        if (!file.equals(openFile)) { saveCurrent(); loadFile(file); }
        Suggest.Edit e = Suggest.importEdit(editor.getText().toString(), fq);
        if (e == null) { toast("Already imported"); return; }
        selfEdit = true;
        try {
            editor.getText().insert(Math.min(e.offset, editor.length()), e.text);
        } finally {
            selfEdit = false;
        }
        afterProgrammaticEdit();
        editor.setErrorLine(-1);
        toast("Added import " + fq);
    }

    // ---- file tabs ----

    /** Files currently open as tabs (the project tree and Files screen still list everything). */
    private final Vector openTabs = new Vector();
    private String openTabsProject = "";

    private void rebuildTabs() {
        tabsRow.removeAllViews();
        Vector all = splitNames(JCompilerBridge.listSourceFiles());
        if (openFile.length() > 0 && all.contains(openFile) && !openTabs.contains(openFile)) openTabs.addElement(openFile);
        for (int i = openTabs.size() - 1; i >= 0; i--) if (!all.contains(openTabs.elementAt(i))) openTabs.removeElementAt(i);
        final boolean closable = openTabs.size() > 1;
        for (int i = 0; i < openTabs.size(); i++) {
            final String f = (String) openTabs.elementAt(i);
            boolean on = f.equals(openFile);
            LinearLayout tab = new LinearLayout(this);
            tab.setGravity(Gravity.CENTER_VERTICAL);
            tab.setBackground(Ui.ripple(Ui.rect(on ? Ui.ACCENT_SOFT : Ui.SURFACE2, 14, 0)));
            tab.setClickable(true);
            tab.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) { saveCurrent(); loadFile(f); }
            });
            TextView t = Ui.label(this, f, 13, on ? Ui.ACCENT : Ui.MUTED, on);
            t.setPadding(Ui.dp(14), Ui.dp(8), closable ? Ui.dp(4) : Ui.dp(14), Ui.dp(8));
            tab.addView(t);
            if (closable) {
                TextView x = Ui.label(this, "\u00D7", 17, Ui.MUTED, false);
                x.setPadding(Ui.dp(6), Ui.dp(4), Ui.dp(12), Ui.dp(6));
                x.setClickable(true);
                x.setContentDescription("Close " + f);
                x.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) { closeTab(f); }
                });
                tab.addView(x);
            }
            tabsRow.addView(tab, Ui.lpMargin(Ui.WRAP, Ui.WRAP, 0, 0, 6, 0));
        }
        TextView add = Ui.label(this, "+  New file", 13, Ui.TEXT, false);
        add.setPadding(Ui.dp(14), Ui.dp(8), Ui.dp(14), Ui.dp(8));
        add.setBackground(Ui.ripple(Ui.rect(0, 14, Ui.STROKE)));
        add.setClickable(true);
        onTap(add, new Runnable() { public void run() { newFileDialog(false); } });
        tabsRow.addView(add);
        updateSubtitle();
    }

    private void closeTab(String f) {
        int idx = openTabs.indexOf(f);
        if (idx < 0 || openTabs.size() <= 1) return;
        boolean wasCurrent = f.equals(openFile);
        if (wasCurrent) saveCurrent();
        openTabs.removeElementAt(idx);
        if (wasCurrent) loadFile((String) openTabs.elementAt(Math.min(idx, openTabs.size() - 1)));
        else rebuildTabs();
    }

    private void updateSubtitle() {
        if (subtitle == null) return;
        subtitle.setText(openFile.length() > 0 ? openFile + (dirty ? "  \u2022" : "") : "no files");
    }

    private void loadFile(String name) {
        openFile = name;
        loading = true;
        try {
            editor.setText(JCompilerBridge.readFile(name));
            highlightNow();
            editor.setSelection(0);
            editor.setErrorLine(-1);
        } finally {
            loading = false;
        }
        if (editor.length() > Highlighter.FULL_LIMIT) handler.postDelayed(highlightRun, 150);   // once the layout exists
        dirty = false;
        history.clear();
        histPos = -1;
        pushSnapshot();
        clearSuggestions();
        rebuildTabs();
    }

    private boolean saveCurrent() {
        if (!inEditor || editor == null || openFile.length() == 0 || !dirty) return true;
        String err = JCompilerBridge.writeFile(openFile, editor.getText().toString());
        if (err.length() > 0) { toast(err); return false; }
        dirty = false;
        updateSubtitle();
        scheduleLiveCheck();
        return true;
    }

    /** Jump to file:line. withError paints the error highlight. */
    private void jumpTo(String file, int line, boolean withError) {
        if (file.length() > 0 && !file.equals(openFile)) { saveCurrent(); loadFile(file); }
        if (editor == null) return;
        editor.setErrorLine(withError ? line : -1);
        if (line >= 1) {
            hideKeyboard();
            editor.goToLine(line);
        }
    }

    // ---- undo / redo ----

    private void pushSnapshot() {
        if (editor == null || undoing) return;
        String cur = editor.getText().toString();
        if (histPos >= 0 && histPos < history.size() && history.get(histPos).equals(cur)) return;
        while (history.size() > histPos + 1) history.remove(history.size() - 1);
        history.add(cur);
        int cap = cur.length() > 60000 ? 25 : 80;   // big files: fewer full-text snapshots (memory)
        while (history.size() > cap) history.remove(0);
        histPos = history.size() - 1;
    }

    private void applySnapshot(String text) {
        undoing = true;
        loading = true;
        try {
            int sel = Math.min(editor.getSelectionStart(), text.length());
            editor.setText(text);
            highlightNow();
            editor.setSelection(Math.max(0, sel));
        } finally {
            loading = false;
            undoing = false;
        }
        dirty = true;
        updateSubtitle();
        clearSuggestions();
    }

    private void undo() {
        if (editor == null) return;
        handler.removeCallbacks(snapshotRun);
        pushSnapshot();
        if (histPos <= 0) { toast("Nothing to undo"); return; }
        histPos--;
        applySnapshot(history.get(histPos));
    }

    private void redo() {
        if (editor == null) return;
        if (histPos >= history.size() - 1) { toast("Nothing to redo"); return; }
        histPos++;
        applySnapshot(history.get(histPos));
    }

    // ---- suggestions ----

    private void clearSuggestions() {
        if (suggestScroll == null) return;
        suggestRow.removeAllViews();
        suggestScroll.setVisibility(View.GONE);
    }

    private void refreshSuggestions() {
        if (editor == null || !settings.suggestions() || !editor.hasFocus() || loading) {
            clearSuggestions();
            return;
        }
        int caret = editor.getSelectionStart();
        if (caret != editor.getSelectionEnd()) { clearSuggestions(); return; }
        Vector items;
        try {
            String full = editor.getText().toString();
            if (full.length() > 60000) {
                // big file: look for names in a window around the caret, not in the whole 4000+ lines
                int a = Math.max(0, full.lastIndexOf('\n', Math.max(0, caret - 20000)) + 1);
                int b = Math.min(full.length(), caret + 20000);
                items = Suggest.suggest(full.substring(a, b), caret - a, JCompilerBridge.api());
                for (int i = 0; i < items.size(); i++) {
                    Suggest.Item it = (Suggest.Item) items.elementAt(i);
                    it.from += a;
                    it.to += a;
                }
            } else {
                items = Suggest.suggest(full, caret, JCompilerBridge.api());
            }
            // "close ) } ]" for brackets that are opened before the caret and never closed
            Vector cl = Suggest.closers(full, caret);
            if (cl.size() > 0) {
                boolean inWord = caret > 0 && Character.isJavaIdentifierPart(full.charAt(caret - 1));
                Vector merged = new Vector();
                if (!inWord) for (int i = 0; i < cl.size(); i++) merged.addElement(cl.elementAt(i));
                for (int i = 0; i < items.size(); i++) merged.addElement(items.elementAt(i));
                if (inWord) for (int i = 0; i < cl.size(); i++) merged.addElement(cl.elementAt(i));
                items = merged;
            }
        } catch (RuntimeException | StackOverflowError ex) {
            clearSuggestions();
            return;
        }
        suggestRow.removeAllViews();
        if (items.size() == 0) { suggestScroll.setVisibility(View.GONE); return; }
        for (int i = 0; i < items.size(); i++) {
            final Suggest.Item it = (Suggest.Item) items.elementAt(i);
            int color = it.kind == 5 ? Ui.RED : (it.kind == 1 ? Ui.AMBER : (it.kind == 2 ? Ui.GREEN : (it.kind == 3 ? Ui.MUTED : Ui.ACCENT)));
            TextView chip = Ui.label(this, it.label, 13.5f, color, true);
            chip.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
            chip.setPadding(Ui.dp(12), Ui.dp(6), Ui.dp(12), Ui.dp(6));
            chip.setBackground(Ui.ripple(Ui.rect(Ui.SURFACE, 12, Ui.STROKE)));
            chip.setClickable(true);
            chip.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) { applySuggestion(it); }
            });
            suggestRow.addView(chip, Ui.lpMargin(Ui.WRAP, Ui.WRAP, 0, 0, 6, 0));
        }
        suggestScroll.scrollTo(0, 0);
        suggestScroll.setVisibility(View.VISIBLE);
    }

    private void applySuggestion(Suggest.Item it) {
        if (editor == null) return;
        Editable e = editor.getText();
        if (it.from < 0 || it.to > e.length() || it.from > it.to) { clearSuggestions(); return; }
        Suggest.Edit imp = it.importFqcn != null ? Suggest.importEdit(e.toString(), it.importFqcn) : null;
        selfEdit = true;
        try {
            e.replace(it.from, it.to, it.insert);
            int caret = it.from + it.insert.length() - it.caretBack;
            if (imp != null) {
                int delta = it.insert.length() - (it.to - it.from);
                if (imp.offset <= it.from) {
                    e.insert(imp.offset, imp.text);
                    caret += imp.text.length();
                } else {
                    e.insert(Math.min(imp.offset + delta, e.length()), imp.text);
                }
            }
            editor.setSelection(Math.max(0, Math.min(caret, e.length())));
        } finally {
            selfEdit = false;
        }
        afterProgrammaticEdit();
        clearSuggestions();
    }

    private void afterProgrammaticEdit() {
        dirty = true;
        updateSubtitle();
        handler.removeCallbacks(highlightRun);
        handler.postDelayed(highlightRun, 120);
        handler.removeCallbacks(snapshotRun);
        handler.postDelayed(snapshotRun, 400);
        if (settings.autoSave()) {
            handler.removeCallbacks(autoSaveRun);
            handler.postDelayed(autoSaveRun, 1800);
        }
    }

    // ---- typing helpers ----

    /** Watches typing: highlight, history, auto-save, brackets, suggestions. */
    private class EditWatcher implements TextWatcher {
        int lastStart, lastBefore, lastCount;

        public void beforeTextChanged(CharSequence s, int a, int b, int c) {}

        public void onTextChanged(CharSequence s, int start, int before, int count) {
            lastStart = start;
            lastBefore = before;
            lastCount = count;
        }

        public void afterTextChanged(Editable e) {
            try {
                afterChanged(e);
            } catch (RuntimeException ex) {
                selfEdit = false;   // a helper failed: keep the text, never close the app
            }
        }

        private void afterChanged(Editable e) {
            if (loading || selfEdit || editor == null) return;
            dirty = true;
            updateSubtitle();
            if (editor.getErrorLine() > 0) editor.setErrorLine(-1);
            smartTyping(e);
            handler.removeCallbacks(highlightRun);
            handler.postDelayed(highlightRun, 250);
            handler.removeCallbacks(snapshotRun);
            handler.postDelayed(snapshotRun, 500);
            if (settings.autoSave()) {
                handler.removeCallbacks(autoSaveRun);
                handler.postDelayed(autoSaveRun, 1800);
            }
            handler.removeCallbacks(suggestRun);
            handler.postDelayed(suggestRun, e.length() > 60000 ? 320 : 140);
        }

        private void smartTyping(Editable e) {
            if (lastCount != 1 || lastBefore != 0) return;
            int pos = lastStart;
            if (pos < 0 || pos >= e.length()) return;
            char ch = e.charAt(pos);
            selfEdit = true;
            try {
                if (ch == '\n') {
                    // Enter between { and } -> open a blank indented line and keep } below
                    if (settings.autoIndent() && pos > 0 && e.charAt(pos - 1) == '{') {
                        int after = pos + 1;
                        int k = after;
                        while (k < e.length() && (e.charAt(k) == ' ' || e.charAt(k) == '\t')) k++;
                        if (k < e.length() && e.charAt(k) == '}') {
                            String base = baseIndent(e, pos);
                            e.insert(k, "\n" + base);
                            editor.setSelection(after + countIndent(e, after));
                        }
                    }
                    return;
                }
                if (!settings.autoPair()) {
                    dedentBrace(e, pos, ch);
                    return;
                }
                char next = pos + 1 < e.length() ? e.charAt(pos + 1) : '\n';
                if (ch == ')' || ch == ']' || ch == '}' || ch == '"' || ch == '\'') {
                    boolean quote = ch == '"' || ch == '\'';
                    if (next == ch && (!quote || pairedBefore(e, pos))) {
                        // typed the closer that is already there -> just step over it
                        e.delete(pos, pos + 1);
                        editor.setSelection(pos + 1);
                        return;
                    }
                }
                if (ch == '(' || ch == '[' || ch == '{') {
                    if (next == '\n' || next == ' ' || next == ')' || next == ']' || next == '}' || next == ';' || next == ',') {
                        e.insert(pos + 1, String.valueOf(ch == '(' ? ')' : (ch == '[' ? ']' : '}')));
                        editor.setSelection(pos + 1);
                    }
                    return;
                }
                if (ch == '"' || ch == '\'') {
                    char prev = pos > 0 ? e.charAt(pos - 1) : ' ';
                    boolean wordBefore = Character.isLetterOrDigit(prev) || prev == '\\';
                    boolean closerNext = next == '\n' || next == ' ' || next == ')' || next == ']' || next == ';' || next == ',' || next == '}';
                    if (!wordBefore && closerNext) {
                        e.insert(pos + 1, String.valueOf(ch));
                        editor.setSelection(pos + 1);
                    }
                    return;
                }
                dedentBrace(e, pos, ch);
            } finally {
                selfEdit = false;
            }
        }

        private boolean pairedBefore(Editable e, int pos) {
            // quote at pos closes a string opened earlier on this line when the count before it is odd
            int ls = pos;
            while (ls > 0 && e.charAt(ls - 1) != '\n') ls--;
            char q = e.charAt(pos);
            int n = 0;
            for (int i = ls; i < pos; i++) if (e.charAt(i) == q && (i == 0 || e.charAt(i - 1) != '\\')) n++;
            return n % 2 == 1;
        }

        private void dedentBrace(Editable e, int pos, char ch) {
            if (ch != '}') return;
            int ls = pos;
            while (ls > 0 && e.charAt(ls - 1) != '\n') ls--;
            for (int i = ls; i < pos; i++) if (e.charAt(i) != ' ') return;
            int tab = settings.tabSize();
            if (pos - ls >= tab) {
                e.delete(pos - tab, pos);
                editor.setSelection(pos - tab + 1);
            }
        }

        private String baseIndent(Editable e, int newlinePos) {
            int ls = newlinePos - 1;
            while (ls > 0 && e.charAt(ls - 1) != '\n') ls--;
            int k = ls;
            while (k < newlinePos && (e.charAt(k) == ' ' || e.charAt(k) == '\t')) k++;
            return e.subSequence(ls, k).toString();
        }

        private int countIndent(Editable e, int lineStart) {
            int k = lineStart;
            while (k < e.length() && (e.charAt(k) == ' ' || e.charAt(k) == '\t')) k++;
            return k - lineStart;
        }
    }

    /** Keeps the previous line's indentation on Enter, and adds a level after '{'. */
    private class AutoIndent implements InputFilter {
        public CharSequence filter(CharSequence src, int s, int e, Spanned dest, int ds, int de) {
            if (!settings.autoIndent()) return null;
            if (e - s == 1 && src.charAt(s) == '\n') {
                int ls = ds;
                while (ls > 0 && dest.charAt(ls - 1) != '\n') ls--;
                int k = ls;
                while (k < ds && (dest.charAt(k) == ' ' || dest.charAt(k) == '\t')) k++;
                String indent = dest.subSequence(ls, k).toString();
                int p = ds - 1;
                while (p >= ls && dest.charAt(p) == ' ') p--;
                if (p >= ls && dest.charAt(p) == '{') indent = indent + tabString();
                return "\n" + indent;
            }
            return null;
        }
    }

    // ------------------------------------------------------------------
    // 8. BUILD (auto-opening, typed log, problems + warnings)
    // ------------------------------------------------------------------

    private final Runnable dotsRun = new Runnable() {
        int n = 0;
        public void run() {
            if (!building || consoleStatus == null || !inEditor) return;
            n = (n + 1) % 4;
            StringBuilder sb = new StringBuilder("Building");
            for (int i = 0; i < n; i++) sb.append('.');
            consoleStatus.setText(sb.toString());
            handler.postDelayed(this, 350);
        }
    };

    private void runBuild(final boolean makeJar) {
        if (building || editor == null) return;
        if (!saveCurrent()) return;
        hideKeyboard();
        handler.removeCallbacks(liveCheckRun);
        building = true;
        final String projName = JCompilerBridge.getCurrent().folderName;
        final int obfLevel = JCompilerBridge.getObfuscation();

        log.setAnimate(settings.animatedLog());
        log.clear();
        lastProblems = new Vector();
        lastWarnings = new Vector();
        updateTabCounts();
        consoleBody.setTextIsSelectable(false);
        consoleTab = 0;
        if (settings.autoOpenLog() || consoleOpen) {
            setConsoleOpen(true);
            selectConsoleTab(0);
        }
        setStatus(Ui.AMBER, "Building");
        handler.removeCallbacks(dotsRun);
        handler.postDelayed(dotsRun, 350);
        log.add(makeJar ? "Starting build process..." : "Starting compile...", Ui.TEXT);

        new Thread(new Runnable() {
            public void run() {
                final JCompilerBridge.BuildResult r = JCompilerBridge.compileAll(makeJar, new JCompilerBridge.Progress() {
                    public void step(final String text, final int level) {
                        runOnUiThread(new Runnable() {
                            public void run() {
                                if (log == null || !building) return;
                                int col = level == JCompilerBridge.L_OK ? Ui.GREEN : level == JCompilerBridge.L_WARN ? Ui.AMBER
                                        : level == JCompilerBridge.L_MUTED ? Ui.MUTED : level == JCompilerBridge.L_ERR ? Ui.RED : Ui.TEXT;
                                log.add(text, col);
                            }
                        });
                    }
                });
                runOnUiThread(new Runnable() {
                    public void run() { showBuildResult(r, makeJar, projName, obfLevel); }
                });
            }
        }).start();
    }

    private void showBuildResult(final JCompilerBridge.BuildResult r, final boolean makeJar,
                                 String projName, int obfLevel) {
        building = false;
        handler.removeCallbacks(dotsRun);
        recordBuild(projName, r, makeJar);
        if (editor == null || log == null) return;

        final int warnCount = r.warnings.size();
        final int probCount = r.problems.size();
        // the steps (reading sources, libraries, compiling, preverify, packaging) were streamed into the log while building;
        // here come the problems, with the offending line, a ^^^ marker and a "how to fix" tip for each.
        if (r.problems.size() > 0 && !r.ok) {
            int shownErr = 0;
            for (int i = 0; i < r.problems.size() && shownErr < 8; i++) {
                JCompilerBridge.Problem p = (JCompilerBridge.Problem) r.problems.elementAt(i);
                String where = p.file.length() > 0 ? p.file + ":" + p.line + (p.col > 0 ? ":" + p.col : "") + "  " : "";
                String cat = p.category.length() > 0 && !p.category.equals("Error") ? "[" + p.category + "] " : "";
                log.add(where + cat + p.message, Ui.RED);
                if (p.snippet.length() > 0) log.add("    > " + p.snippet, Ui.MUTED);
                if (p.caret.length() > 0) log.add("      " + p.caret, Ui.RED);
                if (p.hint.length() > 0) log.add("    Tip: " + p.hint, Ui.AMBER);
                shownErr++;
            }
            if (r.problems.size() > shownErr) log.add("... and " + (r.problems.size() - shownErr) + " more (see the Problems tab)", Ui.MUTED);
        }

        // warnings (first few in the log, all of them under "Warnings")
        int shownW = 0;
        for (int i = 0; i < r.warnings.size() && shownW < 6; i++) {
            Lint.Warning w = (Lint.Warning) r.warnings.elementAt(i);
            log.add("warning: " + (w.file.length() > 0 ? w.file + ":" + w.line + "  " : "") + w.message, Ui.AMBER);
            shownW++;
        }
        if (r.warnings.size() > shownW) log.add("... and " + (r.warnings.size() - shownW) + " more warnings", Ui.MUTED);

        if (r.ok) {
            log.add(makeJar ? "BUILD SUCCEEDED!" : "COMPILE SUCCEEDED!", Ui.GREEN);
            String report = r.classCount + (r.classCount == 1 ? " class" : " classes") + "  \u00B7  "
                    + (Math.round(r.millis / 100f) / 10f) + " s" + (r.reused ? " (cached)" : "");
            if (makeJar && r.jarBytes > 0) report = humanSize(r.jarBytes) + " jar  \u00B7  " + report;
            log.add("Report: " + report, Ui.TEXT);
            if (makeJar && r.jarBytes > 0) {
                String limit = jarLimitNote(r.jarBytes);
                if (limit != null) log.add(limit, Ui.AMBER);
            }
            if (makeJar && r.jarPath.length() > 0) log.add("Output: " + r.jarPath, Ui.TEXT);
            if (makeJar && settings.autoOpenEmulator() && r.jarPath.length() > 0) {
                final File jarToOpen = new File(r.jarPath);
                log.add("Opening " + jarToOpen.getName() + " in emulator...", Ui.TEXT);
                handler.postDelayed(new Runnable() {
                    public void run() { openInEmulator(jarToOpen); }
                }, 700);
            }
            if (makeJar && settings.copyToDownloads()) {
                if (!hasStoragePermission()) {
                    log.add("Tip: allow storage permission in Settings to copy into Download.", Ui.AMBER);
                } else {
                    String res = JCompilerBridge.copyToDownloads();
                    if (res.startsWith("OK:")) log.add("File copied to: " + res.substring(3), Ui.TEXT);
                    else log.add("Copy to Download failed: " + res.substring(4), Ui.AMBER);
                }
            }
        } else {
            log.add("BUILD FAILED!   warning (" + warnCount + ")   problems (" + probCount + ")", Ui.RED);
            if (r.buildTips.size() > 0) {
                log.add("How to fix:", Ui.AMBER);
                for (int i = 0; i < r.buildTips.size(); i++) log.add("  " + (i + 1) + ". " + r.buildTips.elementAt(i), Ui.AMBER);
            }
        }

        final JCompilerBridge.BuildResult res = r;
        log.addAction(new Runnable() {
            public void run() {
                if (editor == null) return;
                lastProblems = res.problems;
                lastWarnings = res.warnings;
                updateTabCounts();
                if (res.ok) {
                    String s = makeJar ? "Build succeeded" : "Compiled OK";
                    s += res.reused ? "  \u00B7  cached" : "  \u00B7  " + (Math.round(res.millis / 100f) / 10f) + " s";
                    if (makeJar && res.jarBytes > 0) s += "  \u00B7  " + humanSize(res.jarBytes);
                    if (warnCount > 0) s += "  \u00B7  warning (" + warnCount + ")";
                    setStatus(Ui.GREEN, s);
                } else {
                    String s;
                    if (res.problems.size() == 1 && res.file.length() > 0) s = "Error in " + res.file + " line " + res.line;
                    else s = "Build failed  \u00B7  warning (" + warnCount + ")  problems (" + probCount + ")";
                    setStatus(Ui.RED, s);
                    if (res.file.length() > 0 && res.line > 0) {
                        // open the failing file and mark the line
                        jumpTo(res.file, res.line, true);
                    }
                    // errors and warnings live in their own tabs: show the Errors tab as soon as a build fails
                    if (res.problems.size() > 0) { if (!consoleOpen) setConsoleOpen(true); selectConsoleTab(1); }
                }
                consoleBody.setTextIsSelectable(true);
                if (consoleTab == 1) fillProblemList();
                if (consoleTab == 2) fillWarningList();
            }
        });
    }

    // ------------------------------------------------------------------
    // 9. EDITOR MENU
    // ------------------------------------------------------------------

    private android.widget.PopupWindow menuWindow;

    private void dismissMenu() {
        if (menuWindow != null) {
            try { menuWindow.dismiss(); } catch (Exception ignored) { }
            menuWindow = null;
        }
    }

    private static final class MenuEntry {
        final String id, section, title, sub;
        final int icon;
        final Runnable action;
        MenuEntry(String id, String section, int icon, String title, String sub, Runnable action) {
            this.id = id; this.section = section; this.icon = icon; this.title = title; this.sub = sub; this.action = action;
        }
    }

    private void menuSection(LinearLayout col, String title) {
        TextView t = Ui.label(this, title.toUpperCase(), 10.5f, Ui.MUTED, true);
        t.setLetterSpacing(0.1f);
        t.setPadding(Ui.dp(12), Ui.dp(12), Ui.dp(12), Ui.dp(4));
        col.addView(t);
    }

    private void menuRow(LinearLayout col, final MenuEntry e) {
        LinearLayout row = Ui.tile(this, e.icon, e.title, e.sub, null);
        row.setPadding(Ui.dp(8), Ui.dp(7), Ui.dp(8), Ui.dp(7));
        LinearLayout.LayoutParams bp = (LinearLayout.LayoutParams) row.getChildAt(0).getLayoutParams();
        bp.width = Ui.dp(34);
        bp.height = Ui.dp(34);
        bp.rightMargin = Ui.dp(12);
        ((TextView) ((LinearLayout) row.getChildAt(1)).getChildAt(0)).setTextSize(14.5f);
        row.setBackground(Ui.ripple(Ui.rect(0x00000000, 12, 0)));
        row.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                android.content.SharedPreferences use = getSharedPreferences("menuuse", MODE_PRIVATE);
                use.edit().putInt(e.id, use.getInt(e.id, 0) + 1).apply();
                dismissMenu();
                handler.post(e.action);
            }
        });
        col.addView(row, Ui.lp(Ui.MATCH, Ui.WRAP));
    }

    /** Opens a tool screen from the editor and comes back to the same file afterwards. */
    private void openToolFromEditor(final int which) {
        saveCurrent();
        final String back = openFile;
        Runnable again = new Runnable() { public void run() { showEditor(back); } };
        switch (which) {
            case 0: showLibraries(again, true); break;
            case 1: showAudioStudio(again, true); break;
            case 2: showColorPalette(again, true); break;
            case 3: showSpriteEditor(again, true, null); break;
            default: showAppSettings(again); break;
        }
    }

    private java.util.ArrayList<MenuEntry> menuEntries() {
        java.util.ArrayList<MenuEntry> l = new java.util.ArrayList<MenuEntry>();
        l.add(new MenuEntry("compile", "Build", R.drawable.ic_code, "Compile only", "Check the code, no .jar", new Runnable() {
            public void run() { runBuild(false); }
        }));
        l.add(new MenuEntry("clean", "Build", R.drawable.ic_refresh, "Clean rebuild", "Ignore the cache, recompile everything", new Runnable() {
            public void run() { JCompilerBridge.invalidateBuildCache(); runBuild(true); }
        }));
        l.add(new MenuEntry("export", "Build", R.drawable.ic_file_upload, "Export JAR + JAD\u2026", "Save the build to a folder", new Runnable() {
            public void run() { pickExportFolder(); }
        }));
        l.add(new MenuEntry("emulator", "Build", R.drawable.ic_open_in_new, "Open JAR in emulator",
                JCompilerBridge.jarExists() ? "Run the last build" : "Build first", new Runnable() {
            public void run() {
                if (!saveCurrent()) return;
                if (JCompilerBridge.jarExists()) openInEmulator(new File(JCompilerBridge.getCurrent().jarUrl()));
                else toast("Nothing to open yet - tap Build first");
            }
        }));
        l.add(new MenuEntry("find", "Editor", R.drawable.ic_search, "Find & replace", "In this file", new Runnable() {
            public void run() { setFindBar(findBar == null || findBar.getVisibility() != View.VISIBLE); }
        }));
        l.add(new MenuEntry("findall", "Editor", R.drawable.ic_search, "Find in project", "Search every .java file", new Runnable() {
            public void run() { showProjectSearch(); }
        }));
        l.add(new MenuEntry("quickopen", "Editor", R.drawable.ic_description, "Go to file\u2026", "Open a file by name", new Runnable() {
            public void run() { showQuickOpen(); }
        }));
        l.add(new MenuEntry("line", "Editor", R.drawable.ic_list, "Go to line", null, new Runnable() {
            public void run() { goToLineDialog(); }
        }));
        l.add(new MenuEntry("format", "Editor", R.drawable.ic_wrap_text, "Format code", "Re-indent the open file", new Runnable() {
            public void run() { formatCode(); }
        }));
        l.add(new MenuEntry("save", "Editor", R.drawable.ic_save, "Save", null, new Runnable() {
            public void run() { if (saveCurrent()) toast("Saved"); }
        }));
        l.add(new MenuEntry("files", "Project", R.drawable.ic_folder, "Files", "Browse src/ and res/", new Runnable() {
            public void run() { showFiles(); }
        }));
        l.add(new MenuEntry("newfile", "Project", R.drawable.ic_add, "New file", null, new Runnable() {
            public void run() { newFileDialog(false); }
        }));
        l.add(new MenuEntry("libs", "Project", R.drawable.ic_layers, "Libraries", "Add J2ME .jar files", new Runnable() {
            public void run() { openToolFromEditor(0); }
        }));
        l.add(new MenuEntry("projset", "Project", R.drawable.ic_settings, "Project settings", "Name, version, JAD, obfuscation", new Runnable() {
            public void run() { showProjectSettings(); }
        }));
        l.add(new MenuEntry("audio", "Tools", R.drawable.ic_graphic_eq, "Audio Studio", "Piano roll, MIDI, recorder", new Runnable() {
            public void run() { openToolFromEditor(1); }
        }));
        l.add(new MenuEntry("color", "Tools", R.drawable.ic_palette, "Color palette", "Pick a color, copy the code", new Runnable() {
            public void run() { openToolFromEditor(2); }
        }));
        l.add(new MenuEntry("sprite", "Tools", R.drawable.ic_image, "Sprite editor", "Draw and edit PNG sprites", new Runnable() {
            public void run() { openToolFromEditor(3); }
        }));
        l.add(new MenuEntry("appset", "App", R.drawable.ic_smartphone, "App settings", "Theme, editor, build options", new Runnable() {
            public void run() { openToolFromEditor(4); }
        }));
        return l;
    }

    /** Fills the menu list: "Quick access" (most used) when the search box is empty, then the sections. */
    private void fillMenuList(LinearLayout list, String query, java.util.ArrayList<MenuEntry> all) {
        list.removeAllViews();
        String q = query.trim().toLowerCase();
        if (q.length() == 0) {
            final android.content.SharedPreferences use = getSharedPreferences("menuuse", MODE_PRIVATE);
            java.util.ArrayList<MenuEntry> freq = new java.util.ArrayList<MenuEntry>();
            for (int i = 0; i < all.size(); i++) if (use.getInt(all.get(i).id, 0) >= 2) freq.add(all.get(i));
            java.util.Collections.sort(freq, new java.util.Comparator<MenuEntry>() {
                public int compare(MenuEntry a, MenuEntry b) { return use.getInt(b.id, 0) - use.getInt(a.id, 0); }
            });
            if (freq.size() > 0) {
                menuSection(list, "Quick access");
                for (int i = 0; i < freq.size() && i < 3; i++) menuRow(list, freq.get(i));
            }
        }
        String lastSection = null;
        int shown = 0;
        for (int i = 0; i < all.size(); i++) {
            MenuEntry e = all.get(i);
            if (q.length() > 0 && e.title.toLowerCase().indexOf(q) < 0
                    && (e.sub == null || e.sub.toLowerCase().indexOf(q) < 0)
                    && e.section.toLowerCase().indexOf(q) < 0) continue;
            if (!e.section.equals(lastSection)) { menuSection(list, e.section); lastSection = e.section; }
            menuRow(list, e);
            shown++;
        }
        if (shown == 0) {
            TextView none = Ui.label(this, "No matching action", 13, Ui.MUTED, false);
            none.setPadding(Ui.dp(12), Ui.dp(16), Ui.dp(12), Ui.dp(16));
            list.addView(none);
        }
    }

    private void showEditorMenu(View anchor) {
        dismissMenu();
        final java.util.ArrayList<MenuEntry> entries = menuEntries();
        final LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(Ui.dp(6), Ui.dp(6), Ui.dp(6), Ui.dp(8));

        // header: project name + version
        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.VERTICAL);
        head.setPadding(Ui.dp(12), Ui.dp(8), Ui.dp(12), Ui.dp(8));
        Project cur = JCompilerBridge.getCurrent();
        head.addView(Ui.label(this, cur != null ? cur.displayName() : "Project", 16, Ui.TEXT, true));
        String ver = JCompilerBridge.getVersion();
        String main = JCompilerBridge.getMainClass();
        String sub = (ver.length() > 0 ? "v" + ver : "") + (ver.length() > 0 && main.length() > 0 ? "  \u00B7  " : "") + main;
        if (sub.length() > 0) {
            TextView st = Ui.label(this, sub, 12, Ui.MUTED, false);
            st.setPadding(0, Ui.dp(2), 0, 0);
            head.addView(st);
        }
        col.addView(head);

        // search field
        final EditText search = Ui.field(this, "Search actions\u2026", "");
        search.setTextSize(14);
        search.setPadding(Ui.dp(12), Ui.dp(9), Ui.dp(12), Ui.dp(9));
        col.addView(search, Ui.lpMargin(Ui.MATCH, Ui.WRAP, 6, 0, 6, 2));

        final LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        col.addView(list, Ui.lp(Ui.MATCH, Ui.WRAP));
        fillMenuList(list, "", entries);

        final ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        sv.setOverScrollMode(View.OVER_SCROLL_NEVER);
        sv.addView(col);
        sv.setBackground(Ui.rect(Ui.SURFACE, 18, Ui.STROKE));
        sv.setClipToOutline(true);

        final FrameLayout shell = new FrameLayout(this);
        final int m = Ui.dp(10);
        shell.setPadding(m, m, m, m);
        shell.addView(sv, new FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP));

        final int width = Math.min(Ui.dp(290), getResources().getDisplayMetrics().widthPixels - Ui.dp(16));
        final int maxH = (int) (getResources().getDisplayMetrics().heightPixels * 0.78f);
        shell.measure(View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
        int height = Math.min(shell.getMeasuredHeight(), maxH);

        final android.widget.PopupWindow w = new android.widget.PopupWindow(shell, width, height, true);
        w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0));
        w.setOutsideTouchable(true);
        w.setInputMethodMode(android.widget.PopupWindow.INPUT_METHOD_NEEDED);
        w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        w.setElevation(Ui.dp(14));
        w.setOnDismissListener(new android.widget.PopupWindow.OnDismissListener() {
            public void onDismiss() { menuWindow = null; }
        });
        menuWindow = w;

        // typing in the search box filters the list and shrinks the window to fit
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            public void onTextChanged(CharSequence s, int a, int b, int c) {}
            public void afterTextChanged(Editable e) {
                fillMenuList(list, e.toString(), entries);
                shell.measure(View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY),
                        View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
                try { w.update(width, Math.min(shell.getMeasuredHeight(), maxH)); } catch (RuntimeException ignored) { }
            }
        });

        sv.setPivotX(width - m * 2);
        sv.setPivotY(0);
        sv.setAlpha(0f);
        sv.setScaleX(0.92f);
        sv.setScaleY(0.92f);
        w.showAsDropDown(anchor, Ui.dp(8), -Ui.dp(6), Gravity.END);
        sv.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(140)
                .setInterpolator(new android.view.animation.DecelerateInterpolator()).start();
    }

    // ------------------------------------------------------------------
    // 9a. LIVE CHECK, FORMAT, PROJECT SEARCH, QUICK OPEN, BUILD STATS
    // ------------------------------------------------------------------

    private boolean liveRunning = false;
    private final Runnable liveCheckRun = new Runnable() {
        public void run() { startLiveCheck(); }
    };

    /** Called after every successful save: compile quietly a moment later. */
    private void scheduleLiveCheck() {
        if (!inEditor || settings == null || !settings.autoCheck()) return;
        handler.removeCallbacks(liveCheckRun);
        handler.postDelayed(liveCheckRun, 1500);
    }

    private void startLiveCheck() {
        if (!inEditor || editor == null || building || liveRunning || dirty || !settings.autoCheck()) return;
        if (JCompilerBridge.getCurrent() == null) return;
        liveRunning = true;
        new Thread(new Runnable() {
            public void run() {
                final JCompilerBridge.BuildResult[] box = new JCompilerBridge.BuildResult[1];
                try {
                    box[0] = JCompilerBridge.checkProject();
                } catch (Throwable t) {
                    box[0] = null;
                }
                runOnUiThread(new Runnable() {
                    public void run() {
                        liveRunning = false;
                        if (box[0] != null) applyLiveResult(box[0]);
                    }
                });
            }
        }).start();
    }

    private void applyLiveResult(JCompilerBridge.BuildResult r) {
        if (!inEditor || editor == null || building || consoleDot == null) return;
        lastProblems = r.problems;
        lastWarnings = r.warnings;
        updateTabCounts();
        if (r.ok) {
            if (editor.getErrorLine() > 0 && !dirty) editor.setErrorLine(-1);
            setStatus(Ui.GREEN, "No errors" + (r.warnings.size() > 0 ? "  \u00B7  warning (" + r.warnings.size() + ")" : ""));
        } else {
            String s;
            if (r.problems.size() == 1 && r.file.length() > 0) s = "Error in " + r.file + " line " + r.line;
            else s = "Errors  \u00B7  problems (" + r.problems.size() + ")";
            setStatus(Ui.RED, s);
            // red line in the editor, only if the user has not typed again since
            if (!dirty && r.file.equals(openFile) && r.line > 0) editor.setErrorLine(r.line);
        }
        if (consoleTab == 1) fillProblemList();
        if (consoleTab == 2) fillWarningList();
    }

    private void formatCode() {
        if (editor == null || openFile.length() == 0) return;
        String src = editor.getText().toString();
        String res = CodeFormatter.format(src, tabString());
        if (res.equals(src)) { toast("Already formatted"); return; }
        if (!CodeFormatter.sameCode(src, res)) { toast("Format cancelled: it would change the code"); return; }
        int line = editor.logicalLineOf(Math.max(0, editor.getSelectionStart()));
        pushSnapshot();
        selfEdit = true;
        try {
            editor.getText().replace(0, editor.length(), res);
        } finally {
            selfEdit = false;
        }
        afterProgrammaticEdit();
        editor.goToLine(line);
        toast("Formatted");
    }

    private void showQuickOpen() {
        saveCurrent();
        final Vector all = splitNames(JCompilerBridge.listSourceFiles());
        final EditText q = Ui.field(this, "File name", "");
        final LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        ScrollView sc = new ScrollView(this);
        sc.addView(list);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(Ui.dp(20), Ui.dp(8), Ui.dp(20), 0);
        box.addView(q, Ui.lp(Ui.MATCH, Ui.WRAP));
        box.addView(sc, Ui.lpMargin(Ui.MATCH, Ui.dp(300), 0, 8, 0, 0));
        final AlertDialog dlg = new AlertDialog.Builder(this, Ui.dialogTheme())
                .setTitle("Go to file").setView(box).setNegativeButton("Close", null).create();
        dlg.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE
                | WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        final Runnable[] refresh = new Runnable[1];
        refresh[0] = new Runnable() {
            public void run() {
                list.removeAllViews();
                String s = q.getText().toString().trim().toLowerCase();
                int shown = 0;
                for (int pass = 0; pass < 3; pass++) {
                    for (int i = 0; i < all.size() && shown < 60; i++) {
                        final String f = (String) all.elementAt(i);
                        String lo = f.toLowerCase();
                        String base = lo.substring(lo.lastIndexOf('/') + 1);
                        int score;
                        if (s.length() == 0) score = 0;
                        else if (base.startsWith(s)) score = 0;
                        else if (lo.indexOf(s) >= 0) score = 1;
                        else if (subsequence(s, base)) score = 2;
                        else continue;
                        if (score != pass) continue;
                        boolean cur = f.equals(openFile);
                        TextView t = Ui.label(MainActivity.this, f, 14.5f, cur ? Ui.ACCENT : Ui.TEXT, cur);
                        t.setPadding(Ui.dp(12), Ui.dp(11), Ui.dp(12), Ui.dp(11));
                        t.setBackground(Ui.ripple(Ui.rect(cur ? Ui.ACCENT_SOFT : 0x00000000, 10, 0)));
                        t.setClickable(true);
                        t.setOnClickListener(new View.OnClickListener() {
                            public void onClick(View v) {
                                dlg.dismiss();
                                if (!f.equals(openFile)) { saveCurrent(); loadFile(f); }
                            }
                        });
                        list.addView(t, Ui.lp(Ui.MATCH, Ui.WRAP));
                        shown++;
                    }
                }
                if (shown == 0) {
                    TextView none = Ui.label(MainActivity.this, "No file matches", 13, Ui.MUTED, false);
                    none.setPadding(Ui.dp(12), Ui.dp(12), Ui.dp(12), Ui.dp(12));
                    list.addView(none);
                }
            }
        };
        q.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            public void onTextChanged(CharSequence s, int a, int b, int c) {}
            public void afterTextChanged(Editable e) { refresh[0].run(); }
        });
        refresh[0].run();
        dlg.show();
        q.requestFocus();
    }

    /** True if every char of `needle` appears in `hay` in the same order. */
    private static boolean subsequence(String needle, String hay) {
        int j = 0;
        for (int i = 0; i < hay.length() && j < needle.length(); i++) if (hay.charAt(i) == needle.charAt(j)) j++;
        return j == needle.length();
    }

    private void showProjectSearch() {
        saveCurrent();
        final EditText q = Ui.field(this, "Search in all files", "");
        final TextView info = Ui.label(this, "Type at least 2 characters", 12, Ui.MUTED, false);
        info.setPadding(Ui.dp(4), Ui.dp(8), 0, Ui.dp(6));
        final LinearLayout results = new LinearLayout(this);
        results.setOrientation(LinearLayout.VERTICAL);
        ScrollView rs = new ScrollView(this);
        rs.addView(results);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(Ui.dp(20), Ui.dp(8), Ui.dp(20), 0);
        box.addView(q, Ui.lp(Ui.MATCH, Ui.WRAP));
        box.addView(info);
        box.addView(rs, Ui.lp(Ui.MATCH, Ui.dp(320)));
        final AlertDialog dlg = new AlertDialog.Builder(this, Ui.dialogTheme())
                .setTitle("Find in project").setView(box).setNegativeButton("Close", null).create();
        dlg.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE
                | WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        final int[] gen = new int[1];
        q.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            public void onTextChanged(CharSequence s, int a, int b, int c) {}
            public void afterTextChanged(Editable e) {
                final String needle = e.toString();
                final int g = ++gen[0];
                handler.postDelayed(new Runnable() {
                    public void run() {
                        if (g == gen[0]) searchProject(needle, g, gen, results, info, dlg);
                    }
                }, 250);
            }
        });
        if (editor != null) {
            int a = editor.getSelectionStart(), b = editor.getSelectionEnd();
            if (a >= 0 && b > a && b - a < 60) {
                String sel = editor.getText().subSequence(a, b).toString();
                if (sel.indexOf('\n') < 0) q.setText(sel);
            }
        }
        dlg.show();
        q.requestFocus();
        q.setSelection(q.length());
    }

    private void searchProject(final String needle, final int g, final int[] gen, final LinearLayout results,
                               final TextView info, final AlertDialog dlg) {
        if (needle.trim().length() < 2) {
            results.removeAllViews();
            info.setText("Type at least 2 characters");
            return;
        }
        info.setText("Searching\u2026");
        new Thread(new Runnable() {
            public void run() {
                // each entry: {file} = file header, {file, Integer line, String text, Integer matchAt} = hit
                final java.util.ArrayList<Object[]> rows = new java.util.ArrayList<Object[]>();
                final String lo = needle.toLowerCase();
                int total = 0, fileCount = 0;
                boolean capped = false;
                Vector files = splitNames(JCompilerBridge.listSourceFiles());
                for (int fi = 0; fi < files.size() && !capped; fi++) {
                    if (g != gen[0]) return;
                    String f = (String) files.elementAt(fi);
                    String src = JCompilerBridge.readFile(f);
                    if (src == null) continue;
                    String[] lines = src.split("\n", -1);
                    boolean any = false;
                    for (int i = 0; i < lines.length; i++) {
                        int at = lines[i].toLowerCase().indexOf(lo);
                        if (at < 0) continue;
                        if (!any) { rows.add(new Object[]{f}); any = true; fileCount++; }
                        String ln = lines[i];
                        int lead = 0;
                        while (lead < ln.length() && (ln.charAt(lead) == ' ' || ln.charAt(lead) == '\t')) lead++;
                        String text = ln.substring(lead);
                        int mAt = Math.max(0, at - lead);
                        if (text.length() > 110) {
                            int from = Math.max(0, mAt - 30);
                            text = (from > 0 ? "\u2026" : "") + text.substring(from, Math.min(text.length(), from + 110));
                            mAt = mAt - from + (from > 0 ? 1 : 0);
                        }
                        rows.add(new Object[]{f, Integer.valueOf(i + 1), text, Integer.valueOf(mAt)});
                        total++;
                        if (total >= 300) { capped = true; break; }
                    }
                }
                final int ftotal = total, ffiles = fileCount;
                final boolean fcapped = capped;
                runOnUiThread(new Runnable() {
                    public void run() {
                        if (g != gen[0]) return;
                        renderSearchResults(rows, needle.length(), ftotal, ffiles, fcapped, results, info, dlg);
                    }
                });
            }
        }).start();
    }

    private void renderSearchResults(java.util.ArrayList<Object[]> rows, int needleLen, int total, int fileCount,
                                     boolean capped, LinearLayout results, TextView info, final AlertDialog dlg) {
        results.removeAllViews();
        if (total == 0) { info.setText("No results"); return; }
        info.setText(total + (capped ? "+" : "") + (total == 1 ? " result" : " results") + " in " + fileCount
                + (fileCount == 1 ? " file" : " files"));
        for (int i = 0; i < rows.size(); i++) {
            Object[] row = rows.get(i);
            final String f = (String) row[0];
            if (row.length == 1) {
                int n = 0;
                for (int k = i + 1; k < rows.size() && rows.get(k).length > 1; k++) n++;
                TextView h = Ui.label(this, f + "  \u00B7  " + n, 12.5f, Ui.ACCENT, true);
                h.setPadding(Ui.dp(4), Ui.dp(12), Ui.dp(4), Ui.dp(4));
                results.addView(h);
                continue;
            }
            final int line = ((Integer) row[1]).intValue();
            String text = (String) row[2];
            int mAt = ((Integer) row[3]).intValue();
            String prefix = line + "   ";
            android.text.SpannableString sp = new android.text.SpannableString(prefix + text);
            sp.setSpan(new android.text.style.ForegroundColorSpan(Ui.MUTED), 0, prefix.length(),
                    android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            int s0 = Math.min(sp.length(), prefix.length() + mAt);
            int s1 = Math.min(sp.length(), s0 + needleLen);
            if (s1 > s0) sp.setSpan(new android.text.style.BackgroundColorSpan(Ui.ACCENT_SELECT), s0, s1,
                    android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            TextView t = Ui.label(this, "", 12.5f, Ui.TEXT, false);
            t.setTypeface(Typeface.MONOSPACE);
            t.setText(sp);
            t.setSingleLine(true);
            t.setEllipsize(android.text.TextUtils.TruncateAt.END);
            t.setPadding(Ui.dp(8), Ui.dp(9), Ui.dp(8), Ui.dp(9));
            t.setBackground(Ui.ripple(Ui.rect(0x00000000, 8, 0)));
            t.setClickable(true);
            t.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    dlg.dismiss();
                    jumpTo(f, line, false);
                }
            });
            results.addView(t, Ui.lp(Ui.MATCH, Ui.WRAP));
        }
    }

    // ---- build report + per-project build status (shown on the home cards) ----

    private void recordBuild(String proj, JCompilerBridge.BuildResult r, boolean makeJar) {
        try {
            getSharedPreferences("buildstat", MODE_PRIVATE).edit()
                    .putBoolean("ok_" + proj, r.ok)
                    .putBoolean("jarkind_" + proj, makeJar)
                    .putLong("t_" + proj, System.currentTimeMillis())
                    .putLong("ms_" + proj, r.millis)
                    .putLong("jar_" + proj, r.jarBytes)
                    .putInt("cls_" + proj, r.classCount)
                    .putInt("err_" + proj, r.problems.size())
                    .apply();
        } catch (RuntimeException ignored) { }
    }

    /** Heads-up when a .jar is bigger than many J2ME phones accept; null when the size is fine. */
    private static String jarLimitNote(long bytes) {
        long kb = bytes / 1024;
        if (bytes > 1024 * 1024) return "Warning: the jar is " + kb + " KB - over 1 MB, most J2ME phones will refuse to install it.";
        if (bytes > 512 * 1024) return "Warning: the jar is " + kb + " KB - over 512 KB, many phones and emulator profiles will not accept it.";
        if (bytes > 256 * 1024) return "Heads-up: the jar is " + kb + " KB - some phones limit a jar to 256 KB.";
        if (bytes > 128 * 1024) return "Heads-up: the jar is " + kb + " KB - older phones often accept 128 KB at most.";
        if (bytes > 64 * 1024) return "Note: the jar is " + kb + " KB - very old phones accept only 64 KB.";
        return null;
    }

    private String friendlyDate(long ts) {
        java.util.Calendar now = java.util.Calendar.getInstance();
        java.util.Calendar then = java.util.Calendar.getInstance();
        then.setTimeInMillis(ts);
        java.util.Locale loc = java.util.Locale.getDefault();
        String time = new java.text.SimpleDateFormat("HH:mm", loc).format(new java.util.Date(ts));
        boolean sameYear = now.get(java.util.Calendar.YEAR) == then.get(java.util.Calendar.YEAR);
        int diff = now.get(java.util.Calendar.DAY_OF_YEAR) - then.get(java.util.Calendar.DAY_OF_YEAR);
        if (sameYear && diff == 0) return "Today, " + time;
        if (sameYear && diff == 1) return "Yesterday, " + time;
        return new java.text.SimpleDateFormat(sameYear ? "d MMM" : "d MMM yyyy", loc).format(new java.util.Date(ts)) + ", " + time;
    }

    /** Newest modification time of any .java file under dir (a few levels deep). */
    private static long newestSource(File dir, int depth) {
        long best = 0;
        File[] kids = dir.listFiles();
        if (kids == null || depth > 5) return 0;
        for (int i = 0; i < kids.length; i++) {
            if (kids[i].isDirectory()) best = Math.max(best, newestSource(kids[i], depth + 1));
            else if (kids[i].getName().endsWith(".java")) best = Math.max(best, kids[i].lastModified());
        }
        return best;
    }

    // ------------------------------------------------------------------
    // 9b. EMULATOR HAND-OFF + ABOUT
    // ------------------------------------------------------------------

    private void openInEmulator(File jar) {
        String err = EmulatorLauncher.open(this, jar, settings.emulatorPkg());
        if (err != null) {
            toast("Emulator: " + err);
            if (log != null) log.add("Emulator: " + err, Ui.AMBER);
        }
    }

    /** Lists the installed apps that can open a .jar; the pick is remembered in the settings. */
    private void chooseEmulator() {
        final java.util.List<ResolveInfo> apps = EmulatorLauncher.installed(this);
        if (apps.isEmpty()) {
            new AlertDialog.Builder(this, Ui.dialogTheme())
                    .setTitle("No emulator found")
                    .setMessage("Install a J2ME emulator such as J2ME Loader, then come back here. "
                            + "Until then, Auto-open uses the Android app chooser.")
                    .setPositiveButton("OK", null).show();
            return;
        }
        final String[] names = new String[apps.size() + 1];
        names[0] = "Ask every time (Android chooser)";
        PackageManager pm = getPackageManager();
        for (int i = 0; i < apps.size(); i++) names[i + 1] = apps.get(i).loadLabel(pm).toString();
        new AlertDialog.Builder(this, Ui.dialogTheme())
                .setTitle("Emulator app")
                .setItems(names, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int which) {
                        settings.setEmulatorPkg(which == 0 ? "" : apps.get(which - 1).activityInfo.packageName);
                        if (reshow != null) reshow.run();
                    }
                }).show();
    }

    /** "1.0 (1)": version name plus build number, as shown on the splash and in About. */
    private String versionLabel() {
        try {
            android.content.pm.PackageInfo pi = getPackageManager().getPackageInfo(getPackageName(), 0);
            return pi.versionName + " (" + pi.versionCode + ")";
        } catch (Exception e) {
            return versionName();
        }
    }

    private String versionName() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception e) {
            return "";
        }
    }

    /** The app's own launcher icon (adaptive or PNG), or null if it cannot be loaded. */
    private ImageView appIconView() {
        try {
            Drawable d = getPackageManager().getApplicationIcon(getApplicationInfo());
            ImageView v = new ImageView(this);
            v.setImageDrawable(d);
            v.setScaleType(ImageView.ScaleType.FIT_CENTER);
            return v;
        } catch (Exception e) {
            android.util.Log.w("J2MEBuilder", "cannot load app icon", e);
            return null;
        }
    }

    private void openUrl(String url) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Exception e) {
            toast("No browser found for " + url);
        }
    }

    private View linkTile(int icon, String title, final String url) {
        LinearLayout t = Ui.tile(this, icon, title, url.replace("https://", ""),
                Ui.icon(this, R.drawable.ic_open_in_new, Ui.MUTED, 24));
        onTap(t, new Runnable() { public void run() { openUrl(url); } });
        t.setOnLongClickListener(new View.OnLongClickListener() {
            public boolean onLongClick(View v) {
                copyText("link", url, "Link copied");
                return true;
            }
        });
        // The link's real icon: use the saved copy; download it once when online.
        try {
            final ImageView iv = (ImageView) ((FrameLayout) t.getChildAt(0)).getChildAt(0);
            Bitmap saved = FaviconCache.cached(this, url);
            if (saved != null) {
                setLinkIcon(iv, saved);
            } else if (FaviconCache.isOnline(this)) {
                final Context ctx = getApplicationContext();
                new Thread(new Runnable() {
                    public void run() {
                        final Bitmap bm = FaviconCache.download(ctx, url);
                        if (bm != null) runOnUiThread(new Runnable() {
                            public void run() { setLinkIcon(iv, bm); }
                        });
                    }
                }).start();
            }
        } catch (Throwable ignore) { }
        return t;
    }

    private void setLinkIcon(ImageView iv, Bitmap bm) {
        iv.setColorFilter(null);
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        iv.setPadding(Ui.dp(8), Ui.dp(8), Ui.dp(8), Ui.dp(8));
        iv.setImageBitmap(bm);
    }

    private void copyText(String label, String text, String done) {
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) { cm.setPrimaryClip(ClipData.newPlainText(label, text)); toast(done); }
        } catch (Exception e) { toast("Could not copy"); }
    }

    private String problemText(JCompilerBridge.Problem p) {
        StringBuilder sb = new StringBuilder();
        if (p.file.length() > 0) sb.append(p.file).append(p.line > 0 ? ":" + p.line : "").append("  ");
        sb.append(p.message);
        if (p.snippet.length() > 0) sb.append("\n> ").append(p.snippet);
        if (p.hint.length() > 0) sb.append("\nhint: ").append(p.hint);
        return sb.toString();
    }

    private String warningText(Lint.Warning w) {
        return (w.file != null && w.file.length() > 0 ? w.file + (w.line > 0 ? ":" + w.line : "") + "  " : "") + w.message;
    }

    /** Copies whatever the open console tab shows (Log / Problems / Warnings). */
    private void copyConsoleTab() {
        StringBuilder sb = new StringBuilder();
        if (consoleTab == 0) {
            sb.append(consoleBody.getText());
        } else if (consoleTab == 1) {
            for (int i = 0; i < lastProblems.size(); i++) {
                if (i > 0) sb.append("\n\n");
                sb.append(problemText((JCompilerBridge.Problem) lastProblems.elementAt(i)));
            }
        } else {
            for (int i = 0; i < lastWarnings.size(); i++) {
                if (i > 0) sb.append("\n");
                sb.append(warningText((Lint.Warning) lastWarnings.elementAt(i)));
            }
        }
        if (sb.length() == 0) { toast("Nothing to copy"); return; }
        copyText("build output", sb.toString(), consoleTab == 0 ? "Log copied" : consoleTab == 1 ? "Problems copied" : "Warnings copied");
    }

    /** assets/vendor.png (150x150) shown in About; replace that file to change the logo. Null when missing. */
    private ImageView vendorLogoView() {
        try {
            java.io.InputStream in = getAssets().open("vendor.png");
            Bitmap bm;
            try { bm = BitmapFactory.decodeStream(in); } finally { in.close(); }
            if (bm == null) return null;
            ImageView v = new ImageView(this);
            v.setImageBitmap(bm);
            v.setScaleType(ImageView.ScaleType.FIT_CENTER);
            v.setContentDescription("Vendor logo");
            return v;
        } catch (Throwable t) {
            return null;
        }
    }

    private void showAbout(final Runnable back) {
        saveCurrentIfEditor();
        leaveEditorState();
        LinearLayout[] pg = page(topBar("About", "Developer", back), 16);
        LinearLayout body = pg[1];

        // app identity
        LinearLayout idCard = Ui.card(this);
        idCard.setGravity(Gravity.CENTER_HORIZONTAL);
        idCard.setPadding(Ui.dp(16), Ui.dp(22), Ui.dp(16), Ui.dp(20));
        ImageView ic = appIconView();
        if (ic != null) idCard.addView(ic, Ui.lpMargin(Ui.dp(72), Ui.dp(72), 0, 0, 0, 10));
        idCard.addView(Ui.label(this, "J2ME Builder IDE", 20, Ui.TEXT, true));
        TextView ver = Ui.label(this, "Version " + versionLabel() + " \u00B7 MIDP 2.0 / CLDC 1.1", 12.5f, Ui.MUTED, false);
        ver.setPadding(0, Ui.dp(2), 0, 0);
        idCard.addView(ver);
        body.addView(idCard);

        // developer
        body.addView(Ui.section(this, "Developer"));
        LinearLayout dev = Ui.card(this);
        ImageView vendorImg = vendorLogoView();
        if (vendorImg != null) {
            dev.setGravity(Gravity.CENTER_HORIZONTAL);
            dev.addView(vendorImg, Ui.lpMargin(Ui.dp(96), Ui.dp(96), 0, 10, 0, 6));
        }
        dev.addView(Ui.tile(this, R.drawable.ic_code, "DASH ANIMATION V2", "Developer of J2ME Builder IDE", null));
        body.addView(dev);

        // links
        body.addView(Ui.section(this, "Links"));
        LinearLayout links = Ui.card(this);
        links.addView(linkTile(R.drawable.ic_code, "GitHub", "https://github.com/Dahmalahi/"));
        links.addView(Ui.divider(this));
        links.addView(linkTile(R.drawable.ic_play_circle, "YouTube", "https://www.youtube.com/@dash______animationv2"));
        links.addView(Ui.divider(this));
        links.addView(linkTile(R.drawable.ic_language, "Website", "https://david2me.free.nf/"));
        links.addView(Ui.divider(this));
        links.addView(linkTile(R.drawable.ic_send, "Telegram", "https://t.me/javagameuploader240_320"));
        body.addView(links);
        TextView hint = Ui.label(this, "Tap to open \u00B7 long-press to copy the link", 11.5f, Ui.MUTED, false);
        hint.setPadding(Ui.dp(6), Ui.dp(10), 0, 0);
        body.addView(hint);

        present(pg[0], back, new Runnable() { public void run() { showAbout(back); } });
    }

    // ------------------------------------------------------------------
    // 10. IMPORT / EXPORT through the system file picker
    // ------------------------------------------------------------------

    /** Import a project: from a ZIP file or from a whole folder. */
    private void pickImportProjectZip() {
        final String[] items = {"Project ZIP file", "Project folder"};
        new AlertDialog.Builder(this, Ui.dialogTheme()).setTitle("Import project").setItems(items, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface d, int which) {
                if (which == 0) pickImportProjectZipFile(); else pickImportFolder(false);
            }
        }).show();
    }

    private void pickImportProjectZipFile() {
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("application/zip");
        try { startActivityForResult(i,REQ_IMPORT_PROJECT); } catch(Exception e){ toast("No file picker available: "+e.getMessage()); }
    }

    /** Opens the system folder picker. into=false: the folder becomes a new project; true: it is merged into the open one. */
    private void pickImportFolder(boolean into) {
        if (into && !saveCurrent()) return;
        try {
            startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), into ? REQ_IMPORT_FOLDER_INTO : REQ_IMPORT_FOLDER);
        } catch (Exception e) {
            toast("No folder picker available: " + e.getMessage());
        }
    }

    /** Reads the whole folder tree (off the UI thread), then imports it. */
    private void importFolderAsync(final Uri tree, final boolean into) {
        toast("Reading folder...");
        new Thread(new Runnable() {
            public void run() {
                final Vector entries = new Vector();
                String err = "";
                String nm = "";
                try {
                    String rootId = DocumentsContract.getTreeDocumentId(tree);
                    nm = treeName(tree, rootId);
                    walkTree(tree, rootId, "", entries, new int[] { 0 });
                    if (entries.size() == 0) err = "The folder is empty";
                    else err = into ? JCompilerBridge.importFolderIntoProject(entries)
                                    : JCompilerBridge.importProjectFolder(entries, nm);
                } catch (Throwable t) {
                    err = "Folder import failed: " + t.getMessage();
                }
                final String fe = err;
                runOnUiThread(new Runnable() {
                    public void run() {
                        if (fe.length() > 0) { toast(fe); return; }
                        String info = JCompilerBridge.lastImportInfo.length() > 0 ? JCompilerBridge.lastImportInfo : "Folder imported";
                        toast(info);
                        if (into) {
                            if (inEditor) { if (openFile.length() > 0) loadFile(openFile); showFiles(); }
                        } else {
                            showOpenProject();
                        }
                    }
                });
            }
        }).start();
    }

    private String treeName(Uri tree, String docId) {
        Cursor c = null;
        try {
            c = getContentResolver().query(DocumentsContract.buildDocumentUriUsingTree(tree, docId),
                    new String[] { DocumentsContract.Document.COLUMN_DISPLAY_NAME }, null, null, null);
            if (c != null && c.moveToFirst() && c.getString(0) != null) return c.getString(0);
        } catch (Exception ignore) {
        } finally {
            if (c != null) c.close();
        }
        int colon = docId.lastIndexOf(':');
        String s = colon >= 0 ? docId.substring(colon + 1) : docId;
        int sl = s.lastIndexOf('/');
        return sl >= 0 ? s.substring(sl + 1) : s;
    }

    /** Collects every file below docId as Object[]{relative path, isDirectory, bytes}; junk folders are not even opened. */
    private void walkTree(Uri tree, String docId, String prefix, Vector out, int[] count) throws IOException {
        Uri kids = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId);
        Vector ids = new Vector(), names = new Vector(), dirs = new Vector();
        Cursor c = getContentResolver().query(kids, new String[] {
                DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE }, null, null, null);
        if (c == null) return;
        try {
            while (c.moveToNext()) {
                ids.addElement(c.getString(0));
                names.addElement(c.getString(1));
                dirs.addElement(Boolean.valueOf(DocumentsContract.Document.MIME_TYPE_DIR.equals(c.getString(2))));
            }
        } finally {
            c.close();
        }
        for (int i = 0; i < ids.size(); i++) {
            String id = (String) ids.elementAt(i);
            String rel = prefix + names.elementAt(i);
            if (((Boolean) dirs.elementAt(i)).booleanValue()) {
                if (JCompilerBridge.importSkipsPath(rel + "/")) continue;
                out.addElement(new Object[] { rel + "/", Boolean.TRUE, new byte[0] });
                walkTree(tree, id, rel + "/", out, count);
            } else {
                if (JCompilerBridge.importSkipsPath(rel)) continue;
                if (++count[0] > 6000) throw new IOException("the folder has more than 6000 files");
                InputStream in = getContentResolver().openInputStream(DocumentsContract.buildDocumentUriUsingTree(tree, id));
                if (in == null) continue;
                try {
                    out.addElement(new Object[] { rel, Boolean.FALSE, readAll(in) });
                } finally {
                    try { in.close(); } catch (IOException ignore) { }
                }
            }
        }
    }

    /** Opens the system picker and remembers the exact res/ subfolder that receives the files. */
    private void pickImportFiles() {
        pickImportFiles("");
    }

    private void pickImportFiles(String targetResDir) {
        pendingResourceDir = targetResDir == null ? "" : targetResDir.replace('\\', '/');
        while (pendingResourceDir.startsWith("/")) pendingResourceDir = pendingResourceDir.substring(1);
        while (pendingResourceDir.endsWith("/")) pendingResourceDir = pendingResourceDir.substring(0, pendingResourceDir.length() - 1);
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        try {
            startActivityForResult(i, REQ_IMPORT);
        } catch (Exception e) {
            toast("No file picker available: " + e.getMessage());
        }
    }

    private void pickExportFolder() {
        if (!saveCurrent()) return;
        if (!JCompilerBridge.jarExists()) {
            toast("Nothing to export yet - tap Build first");
            return;
        }
        try {
            startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), REQ_EXPORT);
        } catch (Exception e) {
            toast("No folder picker available: " + e.getMessage());
        }
    }

    /** Exports ONE .java file under exactly its own name (octet-stream, so no .zip / .txt is added). */
    private void pickExportFile(String file) {
        saveCurrentIfEditor();
        pendingExportFile = file;
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/octet-stream");
        i.putExtra(Intent.EXTRA_TITLE, file);
        try {
            startActivityForResult(i, REQ_EXPORT_FILE);
        } catch (Exception e) {
            toast("No file picker available: " + e.getMessage());
        }
    }

    private void pickExportZip() {
        saveCurrentIfEditor();
        Project p = JCompilerBridge.getCurrent();
        if (p == null) return;
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/zip");
        i.putExtra(Intent.EXTRA_TITLE, p.folderName + ".zip");
        try {
            startActivityForResult(i, REQ_EXPORT_ZIP);
        } catch (Exception e) {
            toast("No file picker available: " + e.getMessage());
        }
    }

    @Override
    protected void onActivityResult(int req, int result, Intent data) {
        super.onActivityResult(req, result, data);
        if (result != RESULT_OK || data == null) return;
        if (req == REQ_IMPORT_PROJECT) {
            try {
                byte[] z=readAll(getContentResolver().openInputStream(data.getData()));
                String name=displayName(data.getData());
                if(name.toLowerCase().endsWith(".zip")) name=name.substring(0,name.length()-4);
                String err=JCompilerBridge.importProjectZip(z,name);
                if(err.length()>0) toast(err); else { toast(JCompilerBridge.lastImportInfo.length()>0 ? JCompilerBridge.lastImportInfo : "Project imported"); showOpenProject(); }
            } catch(Exception e){ toast("Project import failed: "+e.getMessage()); }
        } else if (req == REQ_IMPORT_FOLDER || req == REQ_IMPORT_FOLDER_INTO) {
            if (data.getData() != null) importFolderAsync(data.getData(), req == REQ_IMPORT_FOLDER_INTO);
        } else if (req == REQ_IMPORT) {
            int count = 0;
            ClipData clip = data.getClipData();
            if (clip != null) {
                for (int i = 0; i < clip.getItemCount(); i++) if (importOne(clip.getItemAt(i).getUri(), pendingResourceDir)) count++;
            } else if (data.getData() != null) {
                if (importOne(data.getData(), pendingResourceDir)) count++;
            }
            toast("Imported " + count + (count == 1 ? " file" : " files")
                    + (pendingResourceDir.length() == 0 ? " into res/" : " into res/" + pendingResourceDir + "/"));
            pendingResourceDir = "";
            if (inEditor) showFiles();
        } else if (req == REQ_PICK_IMAGE) {
            ToolHost.ImageSink sink = pendingImageSink;
            pendingImageSink = null;
            if (sink != null && data.getData() != null) sink.onImage(decodeUriBitmap(data.getData()), displayName(data.getData()));
        } else if (req == REQ_PICK_IMAGES) {
            ToolHost.ImagesSink sinks = pendingImagesSink;
            pendingImagesSink = null;
            if (sinks != null) {
                ArrayList<Uri> uris = new ArrayList<Uri>();
                ClipData clip = data.getClipData();
                if (clip != null) {
                    for (int i = 0; i < clip.getItemCount() && i < 96; i++) uris.add(clip.getItemAt(i).getUri());
                } else if (data.getData() != null) {
                    uris.add(data.getData());
                }
                ArrayList<Bitmap> bmps = new ArrayList<Bitmap>();
                ArrayList<String> names = new ArrayList<String>();
                for (int i = 0; i < uris.size(); i++) {
                    Bitmap b = decodeUriBitmap(uris.get(i));
                    if (b != null) { bmps.add(b); names.add(displayName(uris.get(i))); }
                }
                sinks.onImages(bmps, names);
            }
        } else if (req == REQ_PICK_FILE) {
            ToolHost.FileSink sink = pendingFileSink;
            pendingFileSink = null;
            if (sink != null && data.getData() != null) {
                try {
                    File[] old = getCacheDir().listFiles();
                    if (old != null) for (int i = 0; i < old.length; i++) if (old[i].getName().startsWith("picked_")) old[i].delete();
                    String name = displayName(data.getData());
                    File f = new File(getCacheDir(), "picked_" + System.currentTimeMillis());
                    InputStream in = getContentResolver().openInputStream(data.getData());
                    java.io.FileOutputStream fo = new java.io.FileOutputStream(f);
                    try {
                        byte[] buf = new byte[16384];
                        int n;
                        while ((n = in.read(buf)) > 0) fo.write(buf, 0, n);
                    } finally {
                        fo.close();
                        in.close();
                    }
                    sink.onFile(f, name);
                } catch (Exception e) { toast("Cannot open file: " + e.getMessage()); }
            }
        } else if (req == REQ_EXPORT_SPRITE) {
            byte[] bytes = pendingExportBytes;
            pendingExportBytes = null;
            if (bytes != null && data.getData() != null) {
                try {
                    java.io.OutputStream out = getContentResolver().openOutputStream(data.getData());
                    try { out.write(bytes); } finally { if (out != null) out.close(); }
                    toast("Exported " + humanSize(bytes.length));
                } catch (Throwable t) { toast("Export failed: " + t.getMessage()); }
            }
        } else if (req == REQ_EXPORT) {
            exportTo(data.getData());
        } else if (req == REQ_ICON) {
            if (data.getData() != null) onIconPicked(data.getData());
        } else if (req == REQ_EXPORT_FILE) {
            Uri dst = data.getData();
            if (pendingMidiBytes != null) { byte[] b=pendingMidiBytes; pendingMidiBytes=null; writeTo(dst,b,"MIDI exported"); return; }
            byte[] bytes = JCompilerBridge.sourceBytes(pendingExportFile);
            if (dst == null || bytes == null) { toast("Could not export " + pendingExportFile); return; }
            writeTo(dst, bytes, "Exported " + pendingExportFile);
        } else if (req == REQ_LIB) {
            importLibrary(data.getData());
        } else if (req == REQ_MIDI_OPEN) {
            try {
                File f = new File(getCacheDir(), "open.mid");
                java.io.FileOutputStream fo = new java.io.FileOutputStream(f);
                fo.write(readAll(getContentResolver().openInputStream(data.getData())));
                fo.close();
                if (startMidi(f.getAbsolutePath())) toast("Playing");
            } catch (Exception e) { toast("Cannot open file: " + e.getMessage()); }
        } else if (req == REQ_EXPORT_ZIP) {
            Uri dst = data.getData();
            byte[] zip = JCompilerBridge.projectZip();
            if (dst == null || zip == null) { toast("Could not export the project"); return; }
            writeTo(dst, zip, "Project exported");
        }
    }

    private void writeTo(Uri dst, byte[] bytes, String okMessage) {
        OutputStream out = null;
        try {
            out = getContentResolver().openOutputStream(dst, "wt");
            if (out == null) throw new IOException("cannot open destination");
            out.write(bytes);
            out.flush();
            toast(okMessage);
        } catch (Exception e) {
            toast("Export failed: " + e.getMessage());
        } finally {
            if (out != null) try { out.close(); } catch (IOException ignore) { }
        }
    }

    private boolean importOne(Uri uri, String targetResDir) {
        String name = displayName(uri);
        try {
            byte[] bytes = readAll(getContentResolver().openInputStream(uri));
            if (name.toLowerCase().endsWith(".java")) {
                // Java imports remain source imports; resource imports are explicitly placed under res/.
                String err = JCompilerBridge.writeFile(name, new String(bytes, "UTF-8"));
                if (err.length() > 0) { toast(err); return false; }
                if (name.equals(openFile) && inEditor) { loadFile(name); }
            } else {
                String rel = targetResDir == null || targetResDir.length() == 0
                        ? name : targetResDir + "/" + name;
                String err = JCompilerBridge.writeResource(rel, bytes);
                if (err.length() > 0) { toast(err); return false; }
            }
            return true;
        } catch (Exception e) {
            toast("Could not import " + name + ": " + e.getMessage());
            return false;
        }
    }

    /** Backward-compatible import into res/ root. */
    private boolean importOne(Uri uri) {
        return importOne(uri, "");
    }

    private String displayName(Uri uri) {
        String name = null;
        Cursor c = null;
        try {
            c = getContentResolver().query(uri, null, null, null, null);
            if (c != null && c.moveToFirst()) {
                int idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) name = c.getString(idx);
            }
        } catch (Exception ignore) {
        } finally {
            if (c != null) c.close();
        }
        if (name == null || name.length() == 0) {
            name = uri.getLastPathSegment();
            if (name == null) name = "file";
            int s = name.lastIndexOf('/');
            if (s >= 0) name = name.substring(s + 1);
        }
        return name;
    }

    private static byte[] readAll(InputStream in) throws IOException {
        if (in == null) throw new IOException("cannot open file");
        try {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
            return bos.toByteArray();
        } finally {
            in.close();
        }
    }

    private void exportTo(Uri tree) {
        Project p = JCompilerBridge.getCurrent();
        try {
            Uri parent = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree));
            boolean clean = copyOut(parent, p.folderName + ".jar", "application/java-archive", new File(p.jarUrl()));
            File jad = new File(p.jadUrl());
            if (jad.exists()) clean &= copyOut(parent, p.folderName + ".jad", "text/vnd.sun.j2me.app-descriptor", jad);
            toast("Exported " + p.folderName + ".jar and .jad"
                    + (clean ? "" : " (an old file could not be replaced, the new one may have a different name)"));
        } catch (Exception e) {
            toast("Export failed: " + e.getMessage());
        }
    }

    /** Deletes an existing file called exactly `name` in the chosen folder, so the new
     *  export keeps the clean name ("Hello.jar") instead of becoming "Hello (1).jar". */
    private boolean deleteExisting(Uri parent, String name) {
        boolean ok = true;
        Cursor c = null;
        try {
            Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(parent,
                    DocumentsContract.getDocumentId(parent));
            c = getContentResolver().query(children, new String[]{
                    DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME}, null, null, null);
            if (c == null) return true;
            while (c.moveToNext()) {
                if (name.equals(c.getString(1))) {
                    Uri old = DocumentsContract.buildDocumentUriUsingTree(parent, c.getString(0));
                    try {
                        if (!DocumentsContract.deleteDocument(getContentResolver(), old)) ok = false;
                    } catch (Exception e) {
                        android.util.Log.w("J2MEBuilder", "export: cannot delete old " + name, e);
                        ok = false;
                    }
                }
            }
        } catch (Exception e) {
            android.util.Log.w("J2MEBuilder", "export: cannot list folder for " + name, e);
            ok = false;
        } finally {
            if (c != null) c.close();
        }
        return ok;
    }

    /** @return true if the file was written under exactly `name` (no old copy left in the way) */
    private boolean copyOut(Uri parent, String name, String mime, File src) throws IOException {
        boolean clean = deleteExisting(parent, name);
        Uri dst = DocumentsContract.createDocument(getContentResolver(), parent, mime, name);
        if (dst == null) throw new IOException("could not create " + name);
        OutputStream out = getContentResolver().openOutputStream(dst);
        InputStream in = new FileInputStream(src);
        try {
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        } finally {
            in.close();
            if (out != null) out.close();
        }
        return clean;
    }
}
