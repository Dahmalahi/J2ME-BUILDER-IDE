package com.dashers.j2mebuilderide.compiler;

/**
 * Thrown for any lex/parse/semantic/codegen failure. Carries a line number
 * so the on-device editor can jump to / highlight the offending line.
 */
public class CompileError extends Exception {
    public int line;

    /** 1-based column of the error start / end on that line (0 = unknown). */
    public int col, endCol;

    /** Optional actionable follow-up ("move X to its own file", etc). Null if none. */
    public String hint;

    /** Which project source file this error came from. Only ever set by
     *  Compiler.compileProject (multi-file project compiles); stays null
     *  for the single-file Compiler.compile/compileUnit entry points, so
     *  existing callers see no behavior change. */
    public String fileName;

    /** Every error found in one compile pass (CompileError objects, each with
     *  fileName/line set). Null when only this single error is known. */
    public java.util.Vector all;

    public CompileError(String message, int line) {
        this(message, line, null);
    }

    public CompileError(String message, int line, String hint) {
        super(message);
        this.line = line;
        this.hint = hint;
    }

    public String toString() {
        String s = (fileName != null ? fileName + " " : "") + "line " + line + ": " + getMessage();
        if (hint != null) s = s + " (" + hint + ")";
        return s;
    }

    /**
     * Returns the 1-based source line's text (trimmed, \r stripped), or ""
     * if out of range. Lets the UI show the offending line next to the
     * line number instead of making the user go count lines themselves.
     */
    public static String sourceLine(String source, int line) {
        if (source == null || line <= 0) return "";
        int cur = 1;
        int start = 0;
        int len = source.length();
        for (int i = 0; i <= len; i++) {
            if (i == len || source.charAt(i) == '\n') {
                if (cur == line) {
                    String s = source.substring(start, i);
                    if (s.length() > 0 && s.charAt(s.length() - 1) == '\r') {
                        s = s.substring(0, s.length() - 1);
                    }
                    return s.trim();
                }
                cur++;
                start = i + 1;
            }
        }
        return "";
    }

    /**
     * Returns the 0-based character offset in `source` where the given
     * 1-based line begins, or -1 if the line doesn't exist. This gives the
     * on-device editor something concrete to jump the caret to; see
     * JCompilerMIDlet.jumpEditorToLine().
     */
    public static int lineStartOffset(String source, int line) {
        if (source == null || line <= 0) return -1;
        if (line == 1) return 0;
        int cur = 1;
        int len = source.length();
        for (int i = 0; i < len; i++) {
            if (source.charAt(i) == '\n') {
                cur++;
                if (cur == line) return i + 1;
            }
        }
        return -1;
    }
}