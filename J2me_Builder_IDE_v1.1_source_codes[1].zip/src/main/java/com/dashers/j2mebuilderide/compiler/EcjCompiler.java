package com.dashers.j2mebuilderide.compiler;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
import java.util.Vector;

import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

/** Embedded ECJ backend. No javac/ECJ process is spawned. */
public final class EcjCompiler {
    private static byte[] cachedApiJar;
    private EcjCompiler() {}

    public static synchronized void initApi(InputStream in) throws IOException {
        if (cachedApiJar != null || in == null) return;
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] b = new byte[8192]; int n;
        while ((n = in.read(b)) != -1) out.write(b, 0, n);
        cachedApiJar = out.toByteArray();
    }

    private static boolean present;
    private static boolean disabled;      // ECJ is on the classpath but cannot run on this device
    private static String note;           // one-shot message for the build log

    /** Message about ECJ falling back to the built-in compiler (returned once, then cleared). */
    public static synchronized String takeNote() { String n = note; note = null; return n; }
    private static ClassLoader loader;   // null = app class loader (ECJ packaged in the APK)
    private static Runnable locator;     // finds a user-supplied dexed ECJ at compile time

    /** Class loader that can see ECJ (e.g. a DexClassLoader over a user-supplied dexed jar). */
    public static synchronized void setClassLoader(ClassLoader cl) { loader = cl; present = false; disabled = false; }

    /** Called when ECJ isn't visible yet; may install a class loader via setClassLoader(). */
    public static synchronized void setLocator(Runnable r) { locator = r; }

    /** True when the ECJ classes can be loaded (packaged in the APK, or from a loader set by the locator). */
    public static synchronized boolean isAvailable() {
        if (present && !disabled) return true;
        if (!disabled && probe()) { present = true; return true; }
        if (locator != null) {
            try { locator.run(); } catch (Throwable ignore) { }   // a new loader clears 'disabled'
            if (!disabled && probe()) { present = true; return true; }
        }
        return false;
    }

    private static boolean probe() {
        try { cls("org.eclipse.jdt.internal.compiler.Compiler"); return true; }
        catch (Throwable t) { return false; }
    }

    public static boolean isInitialized() { return cachedApiJar != null && isAvailable(); }

    public static Compiler.ProjectResult compileProject(Compiler.ProjectFile[] files, File[] libraries) throws CompileError {
        if (cachedApiJar == null) throw new CompileError("Embedded J2ME API is not initialized", 0);
        return compileProject(files, new ByteArrayInputStream(cachedApiJar), libraries);
    }

    static Class cls(String n) throws ClassNotFoundException {
        return loader == null ? Class.forName(n) : Class.forName(n, true, loader);
    }

    private static Object getStatic(Class c, String field) throws Exception { return c.getField(field).get(null); }

    private static Runnable fallback;     // switches to the bundled, resource-complete ECJ
    private static boolean usedFallback;

    /** Called once if ECJ from the APK fails to start; should call setClassLoader() with a loader that works. */
    public static synchronized void setFallback(Runnable r) { fallback = r; }

    public static com.dashers.j2mebuilderide.compiler.Compiler.ProjectResult compileProject(
            com.dashers.j2mebuilderide.compiler.Compiler.ProjectFile[] files, InputStream apiJar, File[] libraries) throws CompileError {
        if (files == null) throw new CompileError("No source files", 0);
        if (!isAvailable()) throw new CompileError("ECJ library (ecj-mini.jar) is not packaged in this build", 0);
        byte[] api;
        try {
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            byte[] b = new byte[8192];
            int n;
            while ((n = apiJar.read(b)) != -1) bo.write(b, 0, n);
            api = bo.toByteArray();
        } catch (java.io.IOException e) {
            throw new CompileError("Cannot read J2ME API: " + e.getMessage(), 0);
        }
        // Starting ECJ can fail on slow / low-memory phones (old Android, first dex load, class-init
        // errors that poison the loader). Retry with a FRESH class loader before giving up.
        final int MAX_TRIES = 3;
        StringBuffer history = new StringBuffer();
        for (int attempt = 1; attempt <= MAX_TRIES; attempt++) {
            try {
                return compileOnce(files, api, libraries);
            } catch (EcjStartupError e) {
                if (history.length() > 0) history.append("  ||  ");
                String em = e.getMessage();
                history.append("try ").append(attempt).append(": ").append(em.length() > 260 ? em.substring(0, 260) + "..." : em);
                if (attempt == MAX_TRIES) break;
                Runnable fb;
                synchronized (EcjCompiler.class) { fb = fallback; }
                if (fb != null) {
                    try { fb.run(); } catch (Throwable ignore) { }   // new DexClassLoader (re-extracts the dex on later tries)
                }
                System.gc();
                try { Thread.sleep(300L * attempt); } catch (InterruptedException ie) { Thread.currentThread().interrupt(); }
            }
        }
        return builtIn(files, "ECJ failed after " + MAX_TRIES + " tries. " + history);
    }

    /** ECJ cannot run here (e.g. it needs Java APIs this Android version lacks): use the built-in compiler. */
    private static com.dashers.j2mebuilderide.compiler.Compiler.ProjectResult builtIn(
            com.dashers.j2mebuilderide.compiler.Compiler.ProjectFile[] files, String why) throws CompileError {
        synchronized (EcjCompiler.class) {
            disabled = true;
            present = false;
            String shortWhy = why.length() > 900 ? why.substring(0, 900) + "..." : why;
            note = "ECJ could not start on this device, built-in compiler used instead. " + shortWhy;
        }
        return com.dashers.j2mebuilderide.compiler.Compiler.compileProject(files);
    }

    /** ECJ itself failed (not a problem in the user's code). */
    private static final class EcjStartupError extends Exception {
        EcjStartupError(String m) { super(m); }
    }

    private static String describe(Throwable t) {
        while ((t instanceof InvocationTargetException || t instanceof ExceptionInInitializerError)
                && (t instanceof InvocationTargetException ? ((InvocationTargetException) t).getCause() : ((ExceptionInInitializerError) t).getCause()) != null) {
            t = t instanceof InvocationTargetException ? ((InvocationTargetException) t).getCause() : ((ExceptionInInitializerError) t).getCause();
        }
        StringBuffer sb = new StringBuffer();
        sb.append("ECJ backend internal error: ").append(t.getClass().getName());
        if (t.getMessage() != null) sb.append(": ").append(t.getMessage());
        StackTraceElement[] st = t.getStackTrace();
        for (int i = 0; st != null && i < st.length && i < 6; i++) sb.append(" | at ").append(st[i]);
        Throwable c = t.getCause();
        if (c != null && c != t) {
            sb.append(" | caused by ").append(c.getClass().getName());
            if (c.getMessage() != null) sb.append(": ").append(c.getMessage());
            StackTraceElement[] cs = c.getStackTrace();
            for (int i = 0; cs != null && i < cs.length && i < 3; i++) sb.append(" | at ").append(cs[i]);
        }
        return sb.toString();
    }

    private static com.dashers.j2mebuilderide.compiler.Compiler.ProjectResult compileOnce(
            com.dashers.j2mebuilderide.compiler.Compiler.ProjectFile[] files, byte[] apiBytes, File[] libraries)
            throws CompileError, EcjStartupError {
        InputStream apiJar = new ByteArrayInputStream(apiBytes);
        J2meNameEnvironment env = null;
        try {
            env = new J2meNameEnvironment(apiJar);
            if (libraries != null) {
                for (int i = 0; i < libraries.length; i++) {
                    if (libraries[i] == null || !libraries[i].isFile()) continue;
                    env.addJar(libraries[i]);
                }
            }

            final com.dashers.j2mebuilderide.compiler.Compiler.ProjectResult result = new com.dashers.j2mebuilderide.compiler.Compiler.ProjectResult();
            final Vector names = new Vector();
            final Vector origins = new Vector();
            final Vector bytes = new Vector();
            final Vector problems = new Vector();

            Class cUnit = cls("org.eclipse.jdt.internal.compiler.env.ICompilationUnit");
            Object units = Array.newInstance(cUnit, files.length);
            for (int i = 0; i < files.length; i++) Array.set(units, i, unitProxy(cUnit, files[i]));

            Class cOpts = cls("org.eclipse.jdt.internal.compiler.impl.CompilerOptions");
            Object defOpts = cOpts.newInstance();
            Map optionsMap = new HashMap((Map) cOpts.getMethod("getMap", new Class[0]).invoke(defOpts, new Object[0]));
            // ECJ's CLI no longer exposes these old levels, but its compiler
            // still understands them internally after the embedded build's
            // minimum-version guard is lowered to JDK 1.2.
            optionsMap.put(getStatic(cOpts, "OPTION_Source"), "1.8");
            optionsMap.put(getStatic(cOpts, "OPTION_Compliance"), "1.8");
            optionsMap.put(getStatic(cOpts, "OPTION_TargetPlatform"), "1.2");
            optionsMap.put(getStatic(cOpts, "OPTION_Encoding"), "UTF-8");
            optionsMap.put(getStatic(cOpts, "OPTION_Process_Annotations"), "disabled");
            optionsMap.put(getStatic(cOpts, "OPTION_GenerateClassFiles"), getStatic(cOpts, "GENERATE"));
            Object options = cOpts.getConstructor(new Class[] { Map.class }).newInstance(new Object[] { optionsMap });
            try { cOpts.getField("verbose").setBoolean(options, false); } catch (Exception ignore) {}

            Class cReq = cls("org.eclipse.jdt.internal.compiler.ICompilerRequestor");
            Object requestor = Proxy.newProxyInstance(cReq.getClassLoader(), new Class[] { cReq }, new InvocationHandler() {
                public Object invoke(Object proxy, Method m, Object[] a) throws Throwable {
                    if (!m.getName().equals("acceptResult")) return null;
                    Object r = a[0];
                    Class rc = r.getClass();
                    Object[] ps = (Object[]) rc.getMethod("getProblems", new Class[0]).invoke(r, new Object[0]);
                    if (ps != null) {
                        for (int i = 0; i < ps.length; i++) {
                            if (ps[i] == null) continue;
                            Boolean isErr = (Boolean) ps[i].getClass().getMethod("isError", new Class[0]).invoke(ps[i], new Object[0]);
                            if (isErr.booleanValue()) problems.addElement(ps[i]);
                        }
                    }
                    Boolean hasErrors = (Boolean) rc.getMethod("hasErrors", new Class[0]).invoke(r, new Object[0]);
                    Object[] cf = (Object[]) rc.getMethod("getClassFiles", new Class[0]).invoke(r, new Object[0]);
                    if (hasErrors.booleanValue() || cf == null) return null;
                    char[] fn = (char[]) rc.getMethod("getFileName", new Class[0]).invoke(r, new Object[0]);
                    for (int i = 0; i < cf.length; i++) {
                        Class cc = cf[i].getClass();
                        char[][] cn = (char[][]) cc.getMethod("getCompoundName", new Class[0]).invoke(cf[i], new Object[0]);
                        StringBuffer n = new StringBuffer();
                        for (int k = 0; k < cn.length; k++) {
                            if (k > 0) n.append('.');
                            n.append(cn[k]);
                        }
                        names.addElement(n.toString());
                        origins.addElement(new String(fn));
                        bytes.addElement(cc.getMethod("getBytes", new Class[0]).invoke(cf[i], new Object[0]));
                    }
                    return null;
                }
            });

            Class cEcj = cls("org.eclipse.jdt.internal.compiler.Compiler");
            Object policy = cls("org.eclipse.jdt.internal.compiler.DefaultErrorHandlingPolicies")
                    .getMethod("proceedWithAllProblems", new Class[0]).invoke(null, new Object[0]);
            Object factory = cls("org.eclipse.jdt.internal.compiler.problem.DefaultProblemFactory").newInstance();
            Constructor ctor = null;
            Constructor[] cs = cEcj.getConstructors();
            for (int i = 0; i < cs.length; i++) {
                Class[] p = cs[i].getParameterTypes();
                if (p.length == 5 && p[0].getName().endsWith("INameEnvironment")
                        && p[2] == cOpts && p[3] == cReq) { ctor = cs[i]; break; }
            }
            if (ctor == null) throw new NoSuchMethodException("org.eclipse.jdt.internal.compiler.Compiler(5 args)");
            Object ecj = ctor.newInstance(new Object[] { env.asNameEnvironment(), policy, options, requestor, factory });
            try {
                cEcj.getMethod("compile", new Class[] { units.getClass() }).invoke(ecj, new Object[] { units });
            } catch (InvocationTargetException ite) {
                throw ite.getCause() == null ? ite : ite.getCause();
            }

            if (problems.size() > 0) throw toCompileError(problems, files);

            result.names = new String[names.size()];
            result.fileNames = new String[names.size()];
            result.classBytes = new byte[names.size()][];
            for (int i = 0; i < names.size(); i++) {
                result.names[i] = (String) names.elementAt(i);
                result.fileNames[i] = (String) origins.elementAt(i);
                result.classBytes[i] = (byte[]) bytes.elementAt(i);
            }
            return result;
        } catch (CompileError e) {
            throw e;
        } catch (Throwable t) {
            throw new EcjStartupError(describe(t));
        } finally {
            if (env != null) env.cleanup();
        }
    }

    private static CompileError toCompileError(Vector problems, com.dashers.j2mebuilderide.compiler.Compiler.ProjectFile[] files) throws Exception {
        Vector list = new Vector();
        for (int i = 0; i < problems.size() && i < 60; i++) {
            Object p = problems.elementAt(i);
            Class pc = p.getClass();
            char[] f = (char[]) pc.getMethod("getOriginatingFileName", new Class[0]).invoke(p, new Object[0]);
            String file = f == null ? null : new String(f);
            int line = ((Integer) pc.getMethod("getSourceLineNumber", new Class[0]).invoke(p, new Object[0])).intValue();
            String msg = (String) pc.getMethod("getMessage", new Class[0]).invoke(p, new Object[0]);
            CompileError ce = new CompileError(msg, line);
            ce.fileName = file;
            try {
                int start = ((Integer) pc.getMethod("getSourceStart", new Class[0]).invoke(p, new Object[0])).intValue();
                int end = ((Integer) pc.getMethod("getSourceEnd", new Class[0]).invoke(p, new Object[0])).intValue();
                String src = sourceOf(files, file);
                if (src != null && start >= 0 && start < src.length()) {
                    int ls = src.lastIndexOf('\n', start - 1) + 1;
                    int le = src.indexOf('\n', start);
                    if (le < 0) le = src.length();
                    ce.col = start - ls + 1;
                    ce.endCol = Math.max(ce.col, Math.min(end, le - 1) - ls + 1);
                }
            } catch (Throwable ignore) { }
            list.addElement(ce);
        }
        CompileError first = (CompileError) list.elementAt(0);
        first.all = list;
        return first;
    }

    private static String sourceOf(com.dashers.j2mebuilderide.compiler.Compiler.ProjectFile[] files, String name) {
        if (name == null) return null;
        for (int i = 0; i < files.length; i++) if (name.equals(files[i].fileName)) return files[i].source;
        return null;
    }

    private static Object unitProxy(Class iface, final com.dashers.j2mebuilderide.compiler.Compiler.ProjectFile f) {
        return Proxy.newProxyInstance(iface.getClassLoader(), new Class[] { iface }, new InvocationHandler() {
            public Object invoke(Object proxy, Method m, Object[] a) {
                String n = m.getName();
                if (n.equals("getContents")) return f.source == null ? new char[0] : f.source.toCharArray();
                if (n.equals("getMainTypeName")) return mainTypeName(f);
                if (n.equals("getPackageName")) return packageName(f);
                if (n.equals("getFileName")) return (f.fileName == null ? "Source.java" : f.fileName).toCharArray();
                if (n.equals("hashCode")) return Integer.valueOf(System.identityHashCode(proxy));
                if (n.equals("equals")) return Boolean.valueOf(proxy == a[0]);
                if (n.equals("toString")) return "Unit(" + f.fileName + ")";
                if (m.getReturnType() == boolean.class) return Boolean.FALSE;
                return null;
            }
        });
    }

    private static char[] mainTypeName(com.dashers.j2mebuilderide.compiler.Compiler.ProjectFile f) {
        String n = f.fileName == null ? "Source" : f.fileName;
        int slash = Math.max(n.lastIndexOf('/'), n.lastIndexOf('\\'));
        if (slash >= 0) n = n.substring(slash + 1);
        int dot = n.lastIndexOf('.');
        if (dot > 0) n = n.substring(0, dot);
        return n.toCharArray();
    }

    private static char[][] packageName(com.dashers.j2mebuilderide.compiler.Compiler.ProjectFile f) {
        String n = f.fileName == null ? "" : f.fileName;
        int slash = Math.max(n.lastIndexOf('/'), n.lastIndexOf('\\'));
        if (slash < 0) return null;
        String p = n.substring(0, slash);
        if (p.length() == 0) return null;
        String[] a = p.split("/");
        char[][] out = new char[a.length][];
        for (int i = 0; i < a.length; i++) out[i] = a[i].toCharArray();
        return out;
    }
}
