package com.dashers.j2mebuilderide.compiler;

/**
 * A single lexical token. CLDC 1.1 compatible (no enums, no generics).
 */
public class Token {
    // ---- token type constants ----
    public static final int EOF = 0;
    public static final int IDENT = 1;
    public static final int INT_LIT = 2;
    public static final int STRING_LIT = 3;
    public static final int KEYWORD = 4;
    public static final int OP = 5;      // operators / punctuation
    /** Floating-point literal (float or double). Which one is recorded in numKind. */
    public static final int FLOAT_LIT = 6;

    /** For INT_LIT / FLOAT_LIT: which Java literal type the token is. */
    public static final int NUM_INT = 0, NUM_LONG = 1, NUM_FLOAT = 2, NUM_DOUBLE = 3;

    public int type;
    public String text;     // raw text (identifier name, keyword text, operator text)
    public int intValue;    // valid when type == INT_LIT and numKind == NUM_INT (also char literals)
    public boolean syncMod;  // preceded by the 'synchronized' method modifier (removed by the parser's pre-pass)
    public boolean isChar;  // INT_LIT that was written as a char literal 'x'
    public int numKind;     // NUM_INT (default), NUM_LONG, NUM_FLOAT or NUM_DOUBLE
    // Exactly one of the next three is meaningful, selected by numKind.
    public long longValue;     // INT_LIT with numKind == NUM_LONG
    public float floatValue;   // FLOAT_LIT with numKind == NUM_FLOAT
    public double doubleValue; // FLOAT_LIT with numKind == NUM_DOUBLE
    /** Decimal literal 2147483648 / 9223372036854775808L: legal only as the operand of unary minus. */
    public boolean minLit;
    public String strValue; // valid when type == STRING_LIT (unescaped)
    public int line;

    public Token(int type, String text, int line) {
        this.type = type;
        this.text = text;
        this.line = line;
    }

    public boolean isOp(String s) {
        return type == OP && text.equals(s);
    }

    public boolean isKeyword(String s) {
        return type == KEYWORD && text.equals(s);
    }

    public String toString() {
        return "Token[" + type + ",'" + text + "',line=" + line + "]";
    }
}
