package com.dashers.j2mebuilderide.compiler;

/** Unchecked: thrown from low-level emitters (CodeBuffer, ConstPool) and converted to CompileError in Compiler. */
public class MethodTooLargeException extends RuntimeException {
    public MethodTooLargeException(String message) { super(message); }
}
