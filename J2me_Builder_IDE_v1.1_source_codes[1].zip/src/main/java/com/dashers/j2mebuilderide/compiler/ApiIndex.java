package com.dashers.j2mebuilderide.compiler;

import java.util.Vector;
import java.util.Hashtable;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.IOException;

/**
 * Loads and queries the api_index_core.txt linking index (built offline
 * by build_api_index.py from the real MIDP/CLDC API stub sources). Gives
 * the compiler real class hierarchy, method signatures, and field
 * descriptors for the platform API, so `import`, `new`, `extends`, and
 * calls into javax.microedition.* actually resolve to correct bytecode
 * instead of being unsupported.
 *
 * File format (tab-separated, one record per line):
 *   C  fqcn  kind(class|interface)  superFqcn|-  iface1,iface2|-  flags
 *   F  name  descriptor  flags  constValue|-
 *   N  paramDescriptors  flags        (constructor)
 *   M  name  paramDescriptors  returnDescriptor  flags
 * F/N/M lines belong to the most recently seen C line.
 *
 * flags bitmask: 1=public 2=protected 4=private 8=static 16=final
 *                32=abstract 64=interface
 */
public class ApiIndex {

    static final int FLAG_STATIC = 8;
    static final int FLAG_ABSTRACT = 32;
    static final int FLAG_INTERFACE = 64;

    static class ClassInfo {
        String fqcn;
        boolean isInterface;
        String superFqcn;      // null if none (Object, or an interface)
        Vector interfaces = new Vector(); // Strings
        Vector fields = new Vector();     // FieldInfo
        Vector methods = new Vector();    // MethodInfo
        Vector ctors = new Vector();      // CtorInfo
    }
    static class FieldInfo {
        String name, desc; int flags; String constValue;
    }
    static class MethodInfo {
        String name, paramDesc, returnDesc; int flags;
    }
    static class CtorInfo {
        String paramDesc; int flags;
    }

    private Hashtable classes = new Hashtable(); // fqcn -> ClassInfo
    /** Per-build extra classes (user library jars). Never mixes into `classes`. */
    private Hashtable overlay = new Hashtable();

    /** Replaces the per-build library classes; pass null or empty to clear. */
    public void setOverlay(Hashtable fqcnToInfo) {
        overlay = fqcnToInfo == null ? new Hashtable() : fqcnToInfo;
    }

    /** Parses one .class file and adds it to a library overlay table. Returns the fqcn or null. */
    public static String indexClassInto(Hashtable table, byte[] classBytes) {
        try {
            ClassInfo ci = ClassFileIndexer.parse(classBytes);
            if (ci == null) return null;
            table.put(ci.fqcn, ci);
            return ci.fqcn;
        } catch (IOException e) {
            return null;
        } catch (RuntimeException e) {
            return null;
        }
    }

    /** Adds a class from the bundled J2ME API (jar or decompressed assets/j2me/api) to the
     *  built-in index when api_index_core.txt does not already describe it. Returns true if added. */
    public boolean addBuiltinIfAbsent(byte[] classBytes) {
        try {
            ClassInfo ci = ClassFileIndexer.parse(classBytes);
            if (ci == null || classes.containsKey(ci.fqcn)) return false;
            classes.put(ci.fqcn, ci);
            return true;
        } catch (IOException e) {
            return false;
        } catch (RuntimeException e) {
            return false;
        }
    }

    /** True when the bundled index (not a user jar) knows this class. */
    public boolean hasBuiltin(String fqcn) { return classes.containsKey(fqcn); }

    /** All built-in class names (fully qualified), unsorted. */
    public java.util.Enumeration builtinNames() { return classes.keys(); }

    public static ApiIndex load(InputStream in) throws IOException {
        ApiIndex idx = new ApiIndex();
        InputStreamReader isr = new InputStreamReader(in, "UTF-8");
        StringBuffer buf = new StringBuffer();
        int c;
        while ((c = isr.read()) != -1) buf.append((char) c);
        String all = buf.toString();

        ClassInfo cur = null;
        int pos = 0, len = all.length();
        while (pos < len) {
            int nl = all.indexOf('\n', pos);
            if (nl < 0) nl = len;
            String line = all.substring(pos, nl);
            pos = nl + 1;
            if (line.length() > 0 && line.charAt(line.length() - 1) == '\r') {
                line = line.substring(0, line.length() - 1);
            }
            if (line.length() == 0) continue;
            String[] f = split(line, '\t');
            if (f[0].equals("C")) {
                cur = new ClassInfo();
                cur.fqcn = f[1];
                cur.isInterface = "interface".equals(f[2]);
                cur.superFqcn = "-".equals(f[3]) ? null : f[3];
                if (!"-".equals(f[4])) {
                    String[] ifaces = split(f[4], ',');
                    for (int i = 0; i < ifaces.length; i++) cur.interfaces.addElement(ifaces[i]);
                }
                idx.classes.put(cur.fqcn, cur);
            } else if (f[0].equals("F") && cur != null) {
                FieldInfo fi = new FieldInfo();
                fi.name = f[1]; fi.desc = f[2]; fi.flags = Integer.parseInt(f[3]);
                fi.constValue = f.length > 4 && !"-".equals(f[4]) ? f[4] : null;
                cur.fields.addElement(fi);
            } else if (f[0].equals("N") && cur != null) {
                CtorInfo ci = new CtorInfo();
                ci.paramDesc = f.length > 1 ? f[1] : "";
                ci.flags = f.length > 2 ? Integer.parseInt(f[2]) : 1;
                cur.ctors.addElement(ci);
            } else if (f[0].equals("M") && cur != null) {
                MethodInfo mi = new MethodInfo();
                mi.name = f[1];
                mi.paramDesc = f.length > 2 ? f[2] : "";
                mi.returnDesc = f.length > 3 ? f[3] : "V";
                mi.flags = f.length > 4 ? Integer.parseInt(f[4]) : 1;
                cur.methods.addElement(mi);
            }
        }
        return idx;
    }

    private static String[] split(String s, char sep) {
        Vector parts = new Vector();
        int start = 0;
        for (int i = 0; i <= s.length(); i++) {
            if (i == s.length() || s.charAt(i) == sep) {
                parts.addElement(s.substring(start, i));
                start = i + 1;
            }
        }
        String[] out = new String[parts.size()];
        for (int i = 0; i < out.length; i++) out[i] = (String) parts.elementAt(i);
        return out;
    }

    // ---- read-only queries used by the editor (autocomplete / quick-fix) ----

    /** Classes that exist in the index only as obfuscated or internal helpers. */
    private static final String[] HIDDEN = {
        "FDBigInt", "FloatingDecimal", "EventQueue", "LcduiEventAccessor", "LcduiEvents", "MMCImp",
        "MMHelperImpl", "ImageGraphics", "ImmutableImage", "MutableImage", "ListItem", "DeviceCaps",
        "GameDeviceCaps", "TaskQueue", "TimerThread", "VectorEnumerator", "HashtableEntry",
        "EventThread", "MIDletProxy", "MIDletStateMapImpl", "IsolatedMIDletImpl", "Main", "DataConverter"
    };

    /** Public, user-facing class names (fully qualified), sorted. */
    public Vector classNames() {
        Vector out = new Vector();
        Vector all = new Vector();
        java.util.Enumeration en0 = classes.keys();
        while (en0.hasMoreElements()) all.addElement(en0.nextElement());
        en0 = overlay.keys();
        while (en0.hasMoreElements()) all.addElement(en0.nextElement());
        java.util.Enumeration en = all.elements();
        while (en.hasMoreElements()) {
            String fq = (String) en.nextElement();
            int dot = fq.lastIndexOf('.');
            String simple = dot < 0 ? fq : fq.substring(dot + 1);
            if (simple.length() < 2) continue;
            boolean hide = false;
            for (int i = 0; i < HIDDEN.length; i++) if (HIDDEN[i].equals(simple)) { hide = true; break; }
            if (fq.equals("javax.microedition.rms.File")) hide = true;
            if (!hide) out.addElement(fq);
        }
        java.util.Collections.sort(out);
        return out;
    }

    /** One field or method that can be offered after a '.'. */
    public static class Member {
        public String name;
        public boolean method;
        public boolean hasParams;
        public boolean isStatic;
    }

    /** Public fields/methods of a class and everything it extends/implements. */
    public Vector members(String fqcn) {
        Vector out = new Vector();
        Vector seenKeys = new Vector();
        Vector visited = new Vector();
        Vector queue = new Vector();
        queue.addElement(fqcn);
        while (queue.size() > 0) {
            String cur = (String) queue.elementAt(0);
            queue.removeElementAt(0);
            if (visited.contains(cur)) continue;
            visited.addElement(cur);
            ClassInfo ci = get(cur);
            if (ci == null) continue;
            for (int i = 0; i < ci.fields.size(); i++) {
                FieldInfo f = (FieldInfo) ci.fields.elementAt(i);
                if ((f.flags & 1) == 0 || f.name.startsWith("<")) continue;
                String key = "F" + f.name;
                if (seenKeys.contains(key)) continue;
                seenKeys.addElement(key);
                Member m = new Member();
                m.name = f.name;
                m.isStatic = (f.flags & FLAG_STATIC) != 0;
                out.addElement(m);
            }
            for (int i = 0; i < ci.methods.size(); i++) {
                MethodInfo mi = (MethodInfo) ci.methods.elementAt(i);
                if ((mi.flags & 3) == 0 || mi.name.startsWith("<")) continue; // public or protected
                if ((mi.flags & 1) == 0) continue;                              // callers only see public
                String key = "M" + mi.name;
                Member existing = null;
                if (seenKeys.contains(key)) {
                    for (int k = 0; k < out.size(); k++) {
                        Member o = (Member) out.elementAt(k);
                        if (o.method && o.name.equals(mi.name)) { existing = o; break; }
                    }
                } else {
                    seenKeys.addElement(key);
                }
                if (existing != null) {
                    if (mi.paramDesc.length() > 0) existing.hasParams = true;
                    continue;
                }
                Member m = new Member();
                m.name = mi.name;
                m.method = true;
                m.hasParams = mi.paramDesc.length() > 0;
                m.isStatic = (mi.flags & FLAG_STATIC) != 0;
                out.addElement(m);
            }
            if (ci.superFqcn != null) queue.addElement(ci.superFqcn);
            for (int i = 0; i < ci.interfaces.size(); i++) queue.addElement(ci.interfaces.elementAt(i));
        }
        if (!visited.contains("java.lang.Object") && has("java.lang.Object")) {
            Vector more = members("java.lang.Object");
            for (int i = 0; i < more.size(); i++) {
                Member m = (Member) more.elementAt(i);
                boolean dup = false;
                for (int k = 0; k < out.size(); k++) {
                    Member o = (Member) out.elementAt(k);
                    if (o.method == m.method && o.name.equals(m.name)) { dup = true; break; }
                }
                if (!dup) out.addElement(m);
            }
        }
        return out;
    }

    public boolean has(String fqcn) {
        return classes.containsKey(fqcn) || overlay.containsKey(fqcn);
    }

    public ClassInfo get(String fqcn) {
        ClassInfo ci = (ClassInfo) classes.get(fqcn);
        return ci != null ? ci : (ClassInfo) overlay.get(fqcn);
    }

    public boolean isInterface(String fqcn) {
        ClassInfo ci = get(fqcn);
        return ci != null && ci.isInterface;
    }

    /** direct superclass fqcn, or null (meaning java.lang.Object, or none for interfaces). */
    public String superOf(String fqcn) {
        ClassInfo ci = get(fqcn);
        return ci != null ? ci.superFqcn : null;
    }

    public Vector interfacesOf(String fqcn) {
        ClassInfo ci = get(fqcn);
        return ci != null ? ci.interfaces : new Vector();
    }

    /** parses "Ljava/lang/String;III" style param descriptor blob into individual descriptors. */
    static Vector splitParamDescriptors(String blob) {
        Vector out = new Vector();
        int i = 0, n = blob.length();
        while (i < n) {
            int s = i;
            while (i < n && blob.charAt(i) == '[') i++;
            char c = blob.charAt(i);
            if (c == 'L') {
                int semi = blob.indexOf(';', i);
                i = semi + 1;
            } else {
                i++;
            }
            out.addElement(blob.substring(s, i));
        }
        return out;
    }

    static class Found {
        String declaringClass;
        MethodInfo method;
        CtorInfo ctor;
    }

    /** BFS up the superclass+interface chain (starting at fqcn) for a method matching name+argCount. */
    public Found findMethod(String fqcn, String name, int argCount) {
        Vector visited = new Vector();
        Vector queue = new Vector();
        queue.addElement(fqcn);
        while (queue.size() > 0) {
            String cur = (String) queue.elementAt(0);
            queue.removeElementAt(0);
            if (cur == null || visited.contains(cur)) continue;
            visited.addElement(cur);
            ClassInfo ci = get(cur);
            if (ci != null) {
                for (int i = 0; i < ci.methods.size(); i++) {
                    MethodInfo mi = (MethodInfo) ci.methods.elementAt(i);
                    if (mi.name.equals(name) && splitParamDescriptors(mi.paramDesc).size() == argCount) {
                        Found found = new Found();
                        found.declaringClass = cur;
                        found.method = mi;
                        return found;
                    }
                }
                if (ci.superFqcn != null) queue.addElement(ci.superFqcn);
                for (int i = 0; i < ci.interfaces.size(); i++) queue.addElement(ci.interfaces.elementAt(i));
            } else if (!"java.lang.Object".equals(cur)) {
                queue.addElement("java.lang.Object");
            }
        }
        return null;
    }

    public Found findConstructor(String fqcn, int argCount) {
        Vector all = findAllConstructors(fqcn, argCount);
        return all.size() > 0 ? (Found) all.elementAt(0) : null;
    }

    public Vector findAllConstructors(String fqcn, int argCount) {
        Vector results = new Vector();
        ClassInfo ci = get(fqcn);
        if (ci == null) return results;
        for (int i = 0; i < ci.ctors.size(); i++) {
            CtorInfo c = (CtorInfo) ci.ctors.elementAt(i);
            if (splitParamDescriptors(c.paramDesc).size() == argCount) {
                Found f = new Found();
                f.declaringClass = fqcn;
                f.ctor = c;
                results.addElement(f);
            }
        }
        return results;
    }

    /** all methods matching name+argCount anywhere in the superclass/interface chain (for overload disambiguation). */
    public Vector findAllMethods(String fqcn, String name, int argCount) {
        Vector results = new Vector();
        Vector visited = new Vector();
        Vector queue = new Vector();
        queue.addElement(fqcn);
        while (queue.size() > 0) {
            String cur = (String) queue.elementAt(0);
            queue.removeElementAt(0);
            if (cur == null || visited.contains(cur)) continue;
            visited.addElement(cur);
            ClassInfo ci = get(cur);
            if (ci != null) {
                for (int i = 0; i < ci.methods.size(); i++) {
                    MethodInfo mi = (MethodInfo) ci.methods.elementAt(i);
                    if (mi.name.equals(name) && splitParamDescriptors(mi.paramDesc).size() == argCount) {
                        Found found = new Found();
                        found.declaringClass = cur;
                        found.method = mi;
                        results.addElement(found);
                    }
                }
                if (ci.superFqcn != null) queue.addElement(ci.superFqcn);
                for (int i = 0; i < ci.interfaces.size(); i++) queue.addElement(ci.interfaces.elementAt(i));
            } else if (!"java.lang.Object".equals(cur)) {
                queue.addElement("java.lang.Object");
            }
        }
        return results;
    }

    public static class FieldFound {
        String declaringClass;
        FieldInfo field;
    }

    public FieldFound findField(String fqcn, String name) {
        Vector visited = new Vector();
        Vector queue = new Vector();
        queue.addElement(fqcn);
        while (queue.size() > 0) {
            String cur = (String) queue.elementAt(0);
            queue.removeElementAt(0);
            if (cur == null || visited.contains(cur)) continue;
            visited.addElement(cur);
            ClassInfo ci = get(cur);
            if (ci != null) {
                for (int i = 0; i < ci.fields.size(); i++) {
                    FieldInfo fi = (FieldInfo) ci.fields.elementAt(i);
                    if (fi.name.equals(name)) {
                        FieldFound found = new FieldFound();
                        found.declaringClass = cur;
                        found.field = fi;
                        return found;
                    }
                }
                if (ci.superFqcn != null) queue.addElement(ci.superFqcn);
                for (int i = 0; i < ci.interfaces.size(); i++) queue.addElement(ci.interfaces.elementAt(i));
            }
        }
        return null;
    }

    /** true if `sub` is sub == sup, or sub's superclass/interface chain reaches sup ("java.lang.Object" always matches). */
    public boolean isAssignableClass(String sub, String sup) {
        if (sub == null) return false;
        if (sub.equals(sup) || "java.lang.Object".equals(sup)) return true;
        Vector visited = new Vector();
        Vector queue = new Vector();
        queue.addElement(sub);
        while (queue.size() > 0) {
            String cur = (String) queue.elementAt(0);
            queue.removeElementAt(0);
            if (cur == null || visited.contains(cur)) continue;
            visited.addElement(cur);
            if (cur.equals(sup)) return true;
            ClassInfo ci = get(cur);
            if (ci != null) {
                if (ci.superFqcn != null) queue.addElement(ci.superFqcn);
                for (int i = 0; i < ci.interfaces.size(); i++) queue.addElement(ci.interfaces.elementAt(i));
            }
        }
        return false;
    }
}
