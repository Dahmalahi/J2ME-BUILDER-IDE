package com.dashers.j2mebuilderide.compiler;

import java.util.Vector;
import java.util.Hashtable;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;

/**
 * JVM constant pool builder with de-duplication. Entries are 1-indexed
 * per the class file spec (index 0 is reserved/unused).
 */
public class ConstPool {

    // tags
    static final int UTF8 = 1;
    static final int INTEGER = 3;
    static final int FLOAT = 4;
    static final int LONG = 5;
    static final int DOUBLE = 6;
    static final int CLASS = 7;
    static final int STRING = 8;
    static final int FIELDREF = 9;
    static final int METHODREF = 10;
    static final int NAME_AND_TYPE = 12;
    static final int INTERFACE_METHODREF = 11;

    private Vector entries = new Vector(); // each: Object[] {tag, ...}
    private Hashtable utf8Cache = new Hashtable();     // String -> Integer index
    private Hashtable classCache = new Hashtable();    // String name -> Integer index
    private Hashtable natCache = new Hashtable();      // "name:desc" -> Integer index
    private Hashtable fieldrefCache = new Hashtable(); // "class.name:desc" -> Integer index
    private Hashtable methodrefCache = new Hashtable();// "class.name:desc" -> Integer index
    private Hashtable ifaceMethodrefCache = new Hashtable(); // "class.name:desc" -> Integer index
    private Hashtable stringCache = new Hashtable();   // value -> Integer index
    private Hashtable intCache = new Hashtable();      // Integer value -> Integer index
    private Hashtable floatCache = new Hashtable();    // Integer raw float bits -> Integer index
    private Hashtable longCache = new Hashtable();     // Long value -> Integer index
    private Hashtable doubleCache = new Hashtable();   // Long (raw IEEE bits) -> Integer index

    public ConstPool() {
        entries.addElement(null); // index 0 placeholder
    }

    private int add(Object[] entry) {
        entries.addElement(entry);
        return entries.size() - 1;
    }

    public int utf8(String s) {
        Integer cached = (Integer) utf8Cache.get(s);
        if (cached != null) return cached.intValue();
        int idx = add(new Object[]{new Integer(UTF8), s});
        utf8Cache.put(s, new Integer(idx));
        return idx;
    }

    public int classInfo(String internalName) {
        Integer cached = (Integer) classCache.get(internalName);
        if (cached != null) return cached.intValue();
        int nameIdx = utf8(internalName);
        int idx = add(new Object[]{new Integer(CLASS), new Integer(nameIdx)});
        classCache.put(internalName, new Integer(idx));
        return idx;
    }

    public int nameAndType(String name, String desc) {
        String key = name + ":" + desc;
        Integer cached = (Integer) natCache.get(key);
        if (cached != null) return cached.intValue();
        int n = utf8(name);
        int d = utf8(desc);
        int idx = add(new Object[]{new Integer(NAME_AND_TYPE), new Integer(n), new Integer(d)});
        natCache.put(key, new Integer(idx));
        return idx;
    }

    public int fieldref(String className, String name, String desc) {
        String key = className + "." + name + ":" + desc;
        Integer cached = (Integer) fieldrefCache.get(key);
        if (cached != null) return cached.intValue();
        int c = classInfo(className);
        int nt = nameAndType(name, desc);
        int idx = add(new Object[]{new Integer(FIELDREF), new Integer(c), new Integer(nt)});
        fieldrefCache.put(key, new Integer(idx));
        return idx;
    }

    public int methodref(String className, String name, String desc) {
        String key = className + "." + name + ":" + desc;
        Integer cached = (Integer) methodrefCache.get(key);
        if (cached != null) return cached.intValue();
        int c = classInfo(className);
        int nt = nameAndType(name, desc);
        int idx = add(new Object[]{new Integer(METHODREF), new Integer(c), new Integer(nt)});
        methodrefCache.put(key, new Integer(idx));
        return idx;
    }

    public int interfaceMethodref(String className, String name, String desc) {
        String key = className + "." + name + ":" + desc;
        Integer cached = (Integer) ifaceMethodrefCache.get(key);
        if (cached != null) return cached.intValue();
        int c = classInfo(className);
        int nt = nameAndType(name, desc);
        int idx = add(new Object[]{new Integer(INTERFACE_METHODREF), new Integer(c), new Integer(nt)});
        ifaceMethodrefCache.put(key, new Integer(idx));
        return idx;
    }

    public int stringConst(String value) {
        Integer cached = (Integer) stringCache.get(value);
        if (cached != null) return cached.intValue();
        int u = utf8(value);
        int idx = add(new Object[]{new Integer(STRING), new Integer(u)});
        stringCache.put(value, new Integer(idx));
        return idx;
    }

    public int integerConst(int value) {
        Integer key = new Integer(value);
        Integer cached = (Integer) intCache.get(key);
        if (cached != null) return cached.intValue();
        int idx = add(new Object[]{new Integer(INTEGER), key});
        intCache.put(key, new Integer(idx));
        return idx;
    }

    /** CONSTANT_Long. Occupies TWO constant pool slots (JVMS 4.4.5): the entry at the
     *  returned index, and an unusable placeholder (null in `entries`) at index+1. */
    public int longConst(long value) {
        Long key = new Long(value);
        Integer cached = (Integer) longCache.get(key);
        if (cached != null) return cached.intValue();
        int idx = add(new Object[]{new Integer(LONG), key});
        entries.addElement(null); // the unusable second slot
        longCache.put(key, new Integer(idx));
        return idx;
    }

    /** CONSTANT_Double (two slots, like longConst). Cached by raw IEEE-754 bits so
     *  0.0 and -0.0 -- and distinct NaN payloads -- stay distinct constants. */
    public int doubleConst(double value) {
        Long bits = new Long(Double.doubleToLongBits(value));
        Integer cached = (Integer) doubleCache.get(bits);
        if (cached != null) return cached.intValue();
        int idx = add(new Object[]{new Integer(DOUBLE), bits});
        entries.addElement(null); // the unusable second slot
        doubleCache.put(bits, new Integer(idx));
        return idx;
    }

    /** CONSTANT_Float (one slot). Cached by raw bits, like doubleConst. */
    public int floatConst(float value) {
        Integer bits = new Integer(Float.floatToIntBits(value));
        Integer cached = (Integer) floatCache.get(bits);
        if (cached != null) return cached.intValue();
        int idx = add(new Object[]{new Integer(FLOAT), bits});
        floatCache.put(bits, new Integer(idx));
        return idx;
    }

    public int size() {
        return entries.size();
    }

    // ---------------- read accessors (used by StackMapGen to inspect refs
    // already emitted into the pool by CodeGen, and to mint the extra
    // CONSTANT_Class entries a StackMap attribute needs for array/uninitialized
    // verification types that CodeGen itself never had a reason to intern). ----

    public int tagAt(int idx) {
        if (entries.elementAt(idx) == null) return 0; // unusable second slot of a long/double
        return ((Integer) ((Object[]) entries.elementAt(idx))[0]).intValue();
    }

    /** UTF8 entry's string value. */
    public String utf8At(int idx) {
        return (String) ((Object[]) entries.elementAt(idx))[1];
    }

    /** CLASS (or STRING) entry's referenced UTF8 value -- both share the
     *  {tag, utf8Idx} shape, so this doubles as "string constant's value". */
    public String classNameAt(int idx) {
        Object[] e = (Object[]) entries.elementAt(idx);
        return utf8At(((Integer) e[1]).intValue());
    }

    /** {name, desc} for a NAME_AND_TYPE entry. */
    private String[] nameAndTypeAt(int idx) {
        Object[] e = (Object[]) entries.elementAt(idx);
        return new String[]{utf8At(((Integer) e[1]).intValue()), utf8At(((Integer) e[2]).intValue())};
    }

    /** Declaring class's internal name for a FIELDREF/METHODREF/INTERFACE_METHODREF entry. */
    public String classOfRef(int idx) {
        Object[] e = (Object[]) entries.elementAt(idx);
        return classNameAt(((Integer) e[1]).intValue());
    }

    /** Member name for a FIELDREF/METHODREF/INTERFACE_METHODREF entry. */
    public String nameOfRef(int idx) {
        Object[] e = (Object[]) entries.elementAt(idx);
        return nameAndTypeAt(((Integer) e[2]).intValue())[0];
    }

    /** Field/method descriptor for a FIELDREF/METHODREF/INTERFACE_METHODREF entry. */
    public String descOfRef(int idx) {
        Object[] e = (Object[]) entries.elementAt(idx);
        return nameAndTypeAt(((Integer) e[2]).intValue())[1];
    }

    public void writeTo(DataOutputStream out) throws IOException {
        if (entries.size() > 65535) {
            throw new MethodTooLargeException("constant pool too large: " + entries.size() + " entries (limit 65535)");
        }
        out.writeShort(entries.size()); // constant_pool_count = count+1, entries already has index0 placeholder
        for (int i = 1; i < entries.size(); i++) {
            Object[] e = (Object[]) entries.elementAt(i);
            if (e == null) continue; // second slot of a long/double: counted in the pool size, never written
            int tag = ((Integer) e[0]).intValue();
            out.writeByte(tag);
            switch (tag) {
                case UTF8: {
                    String s = (String) e[1];
                    out.writeUTF(s);
                    break;
                }
                case CLASS: {
                    out.writeShort(((Integer) e[1]).intValue());
                    break;
                }
                case STRING: {
                    out.writeShort(((Integer) e[1]).intValue());
                    break;
                }
                case FIELDREF:
                case METHODREF:
                case INTERFACE_METHODREF: {
                    out.writeShort(((Integer) e[1]).intValue());
                    out.writeShort(((Integer) e[2]).intValue());
                    break;
                }
                case NAME_AND_TYPE: {
                    out.writeShort(((Integer) e[1]).intValue());
                    out.writeShort(((Integer) e[2]).intValue());
                    break;
                }
                case INTEGER: {
                    out.writeInt(((Integer) e[1]).intValue());
                    break;
                }
                case FLOAT: {
                    out.writeInt(((Integer) e[1]).intValue()); // already the raw IEEE bits
                    break;
                }
                case LONG:
                case DOUBLE: {
                    out.writeLong(((Long) e[1]).longValue()); // already the raw bits for DOUBLE
                    break;
                }
            }
        }
    }
}