package com.dashers.j2mebuilderide.compiler;

import java.util.Vector;

/**
 * AST node definitions for the supported Java subset, plus the type
 * encoding used everywhere a "type" is needed.
 *
 * Source level: Java 1.4 (minus the pieces listed under "NOT supported").
 * Bytecode target: class file 45.3 with the CLDC 1.1 "StackMap" attribute
 * (unchanged -- see ClassWriter/StackMapGen).
 *
 * Type codes:
 *   0        VOID
 *   1        INT             (also byte/short/char: they live in int-width
 *                              slots and are only distinguished for array
 *                              element storage -- unchanged from before)
 *   2        BOOLEAN
 *   3        STRING          (sugar for java.lang.String, kept as its
 *                              own code for backward compatibility with
 *                              existing codegen that special-cases it)
 *   4        LONG            (first-class 2-word primitive)
 *   5        DOUBLE          (first-class 2-word primitive)
 *   6        FLOAT           (first-class 1-word primitive)
 *  -1        NULL literal marker (assignable to any reference type)
 *  >=100     reference type: 100 + index into refNames (dotted FQCN)
 *
 * long, float and double are ordinary types now: they can be locals,
 * fields, parameters, return values, array elements and operands. The
 * earlier restriction that confined LONG/DOUBLE to a discarded
 * call-statement result) is gone. T.wordSize() is the single source of
 * truth for how many operand-stack words / local slots a type occupies.
 *
 * Supported extensions over the original Java 1.4 subset include erased generics,
 * enhanced for, enums, annotations (ignored), inner/anonymous classes, varargs,
 * static imports, var, and autoboxing/unboxing. The type code VAR is a temporary
 * local-inference marker resolved during code generation.
 *
 * refNames is reset once per compile by Compiler.compile() so repeated
 * compiles in the same JVM/device session don't leak state.
 */
final class T {
    static final int VOID = 0;
    static final int INT = 1;
    static final int BOOLEAN = 2;
    static final int STRING = 3;
    static final int LONG = 4;
    static final int DOUBLE = 5;
    static final int FLOAT = 6;
    static final int VAR = 7; // local-variable inference placeholder; resolved during code generation
    static final int NULLT = -1;
    static final int REF_BASE = 100;

    private static Vector refNames = new Vector(); // index i -> dotted FQCN for type (REF_BASE+i)

    static void resetTypes() {
        refNames = new Vector();
    }

    /** Returns (creating if needed) the type code for a reference to dottedClassName. */
    static int refType(String dottedClassName) {
        if ("java.lang.String".equals(dottedClassName)) return STRING;
        for (int i = 0; i < refNames.size(); i++) {
            if (dottedClassName.equals(refNames.elementAt(i))) return REF_BASE + i;
        }
        refNames.addElement(dottedClassName);
        return REF_BASE + (refNames.size() - 1);
    }

    static boolean isRef(int t) {
        return t == STRING || t == NULLT || t >= REF_BASE;
    }

    /** dotted FQCN for a reference type code, or null if not a reference type. */
    static String className(int t) {
        if (t == STRING) return "java.lang.String";
        if (t >= REF_BASE) return (String) refNames.elementAt(t - REF_BASE);
        return null;
    }

    static String name(int t) {
        if (t == VOID) return "void";
        if (t == INT) return "int";
        if (t == BOOLEAN) return "boolean";
        if (t == LONG) return "long";
        if (t == DOUBLE) return "double";
        if (t == FLOAT) return "float";
        if (t == VAR) return "var";
        if (t == NULLT) return "null";
        String c = className(t);
        return c != null ? c : "?";
    }

    /** JVM type descriptor for a type code. */
    static String desc(int t) {
        if (t == VOID) return "V";
        if (t == INT) return "I";
        if (t == BOOLEAN) return "Z";
        if (t == LONG) return "J";
        if (t == DOUBLE) return "D";
        if (t == FLOAT) return "F";
        if (t == STRING) return "Ljava/lang/String;";
        String c = className(t);
        if (c == null) return "?";
        if (c.startsWith("[")) return c; // array types are stored pre-encoded as raw JVM descriptors
        return "L" + c.replace('.', '/') + ";";
    }

    /** JVM stack/local-variable word count for a type code: 2 for long/double, 1 for
     *  everything else (int, boolean, float, all reference types). This is the single
     *  source of truth -- every push()/pop()/slot allocation in CodeGen goes through it. */
    static int wordSize(int t) {
        return (t == LONG || t == DOUBLE) ? 2 : 1;
    }

    /** true for the JVM primitive types this compiler can hold in a variable
     *  (int/boolean/long/double/float; byte/short/char are INT here). */
    static boolean isPrimitive(int t) {
        return t == INT || t == BOOLEAN || t == LONG || t == DOUBLE || t == FLOAT;
    }

    /** true for the numeric primitives (everything primitive except boolean). */
    static boolean isNumeric(int t) {
        return t == INT || t == LONG || t == DOUBLE || t == FLOAT;
    }

    /** true if a value of primitive type `from` may be implicitly converted to
     *  primitive type `to` (JLS 5.1.2 widening: int -> long -> float -> double;
     *  byte/short/char are INT here so byte->short->int and char->int are
     *  already covered by the INT == INT case). Same type is trivially legal.
     *  boolean never widens to or from anything. Narrowing (long->int,
     *  double->float, ...) is NOT legal here -- it needs an explicit cast. */
    static boolean widen(int from, int to) {
        if (from == to) return isPrimitive(from);
        if (!isNumeric(from) || !isNumeric(to)) return false;
        switch (from) {
            case INT:   return to == LONG || to == FLOAT || to == DOUBLE;
            case LONG:  return to == FLOAT || to == DOUBLE;
            case FLOAT: return to == DOUBLE;
            default:    return false;
        }
    }

    static boolean isArray(int t) {
        String c = className(t);
        return c != null && c.startsWith("[");
    }

    /** For an array type code, the JVM descriptor of its element type (e.g. "[I" -> "I", "[Ljava/lang/String;" -> "Ljava/lang/String;"). */
    static String arrayElemDesc(int t) {
        String c = className(t);
        return (c != null && c.startsWith("[")) ? c.substring(1) : null;
    }
}

// ---------------- top level ----------------
class ImportDecl {
    String path;          // normal import: type/package; static import: owning class
    boolean wildcard;     // normal package wildcard or static wildcard
    boolean isStatic;     // import static ...
    String memberName;    // static single-member import, null for static wildcard
}

class ClassNode {
    String name;              // dotted FQCN (package-qualified if the file declared a package)
    String packageName = "";  // dotted package name, "" if none
    String superName;         // dotted FQCN, defaults to "java.lang.Object"
    Vector interfaces = new Vector(); // dotted FQCNs
    Vector imports = new Vector();    // ImportDecl
    Vector fields = new Vector();  // FieldNode
    Vector methods = new Vector(); // MethodNode (includes constructors, flagged isConstructor)
    boolean isInterface;       // "interface Foo { ... }" -- every method is implicitly
                               // public+abstract (no body); cannot be `new`'d; superName
                               // is unused (interfaces don't extend a class) and `interfaces`
                               // holds any interfaces this one extends, same field reused.
    boolean isAbstract;        // "abstract class Foo { ... }" -- may declare abstract methods
                               // (no body) alongside concrete ones; cannot be `new`'d directly.
    Vector initBlocks = new Vector(); // InitBlock
    String simpleName = "";   // name as written (no package, no Outer$)
    String outerName;         // FQCN of the lexically enclosing class for nested/anonymous classes, else null
    boolean hasOuterThis;     // inner (non-static) or anonymous-in-instance-context: has a this$0 field + leading ctor param
    boolean isAnon;           // anonymous class (named Outer$1, Outer$2 ...)
    String anonBase;          // anonymous: the class or interface named after 'new'
    boolean anonFinalized;    // anonymous: constructor parameters completed by CodeGen
    Vector capturedNames = new Vector();  // anonymous: enclosing locals copied in (field val$name)
    boolean isEnum;
    String sourceFile;        // which project source file this class was parsed from; null for
                               // single-file compiles (Compiler.compile/compileUnit), set by
                               // Compiler.compileProject so cross-file errors can be attributed.
}

/** an initializer block: "static { ... }" or "{ ... }" at class level. pos = number of fields declared before it. */
class InitBlock {
    boolean isStatic;
    int pos;
    BlockStmt body;
}

class FieldNode {
    boolean charTyped;
    int type;
    String name;
    boolean isStatic;
    boolean isFinal;
    boolean isPrivate; // declared 'private' (used only by the obfuscator)
    boolean isSynthetic; // compiler-generated (e.g. $assertionsDisabled); ClassWriter marks it
                         // ACC_SYNTHETIC|ACC_FINAL and not ACC_PUBLIC
    Expr init; // may be null
    int line;
}

class ParamNode {
    boolean charTyped;
    boolean isSynthField; // synthetic ctor parameter (this$0, val$x, $name ...) copied into the field of the same name
    boolean isVarargs;    // 'T... name'
    int type;
    String name;
    boolean isFinal;
}

class MethodNode {
    String name;
    boolean returnsChar;
    boolean returnIsTypeVar; // generic: declared to return a type variable (erased to its bound)
    int returnType;
    boolean isStatic;
    boolean isPrivate; // declared 'private' (used only by the obfuscator)
    boolean isConstructor;
    boolean isSynchronized; // declared 'synchronized' (ACC_SYNCHRONIZED)
    boolean isVarargs;      // last parameter is 'T... name'
    boolean isStrict;    // declared 'strictfp' (parsed; ClassWriter sets ACC_STRICT)
    boolean isAbstract;  // true for an interface method or an explicitly-`abstract`
                          // class method -- both are declared with no body ("...);" instead
                          // of "...) { ... }"). body is null iff isAbstract is true; every
                          // other method always has a real (possibly empty) BlockStmt body.
    Vector params = new Vector(); // ParamNode
    BlockStmt body; // null only when isAbstract
    int line;
}

// ---------------- statements ----------------
abstract class Stmt {
    int line;
}

class BlockStmt extends Stmt {
    boolean noScope; // true for a synthetic group ("int a, b;") whose declarations belong to the enclosing scope
    Vector stmts = new Vector(); // Stmt
}

class VarDeclStmt extends Stmt {
    boolean charTyped;
    int type;
    String name;
    boolean isFinal;
    Expr init; // may be null
}

class IfStmt extends Stmt {
    Expr cond;
    Stmt thenS;
    Stmt elseS; // may be null
}

class WhileStmt extends Stmt {
    Expr cond;
    Stmt body;
}

class ForStmt extends Stmt {
    Stmt init;   // VarDeclStmt or ExprStmt, may be null
    Expr cond;   // may be null (treated as true)
    Stmt update; // ExprStmt, may be null
    Stmt body;
}

class ReturnStmt extends Stmt {
    Expr value; // may be null
}

class ExprStmt extends Stmt {
    Expr expr;
}
/** super(args) as the first statement of a constructor -- resolved against
 *  the superclass's real constructors, not the class's own. */
class SuperCallStmt extends Stmt {
    Vector args = new Vector(); // Expr
}

/** this(args); as the first statement of a constructor. */
class ThisCallStmt extends Stmt {
    Vector args = new Vector(); // Expr
}

/** for (Type v : expr) body -- expr is an array or a java.util.Vector. */
class ForEachStmt extends Stmt {
    int varType;
    String varName;
    boolean isFinal;
    Expr iterable;
    Stmt body;
}

/** synchronized (lock) { body } */
class SyncStmt extends Stmt {
    Expr lock;
    BlockStmt body;
}

/** compiler-generated: monitorexit on the lock kept in the hidden local `slotVar`. */
class MonitorExitStmt extends Stmt {
    String slotVar;
}

class BreakStmt extends Stmt { String label; /* null = innermost loop/switch */ }
class ContinueStmt extends Stmt { String label; /* null = innermost loop */ }

/** label: body  (one or more labels stacked on the same statement) */
class LabeledStmt extends Stmt {
    Vector labels = new Vector(); // String
    Stmt body;
}

/** do { body } while (cond); -- body always runs at least once; `continue`
 *  jumps to the condition check (not back to the top of the body). */
class DoWhileStmt extends Stmt {
    Stmt body;
    Expr cond;
}

/** One "case VALUE:" or "default:" label plus the statements that follow it,
 *  up to (not including) the next label or the end of the switch. Multiple
 *  labels sharing one block ("case 1: case 2: foo(); break;") are two
 *  SwitchCase entries in source order, the first with an empty stmts list --
 *  codegen relies on that natural fall-through instead of grouping labels. */
class SwitchCase {
    Vector values = new Vector(); // Expr (IntLit for plain literals, any int expression otherwise); empty (unused) when isDefault
    boolean isDefault;
    Vector stmts = new Vector();  // Stmt
}

/** switch (selector) { case ...: ...; default: ...; } -- selector and case
 *  labels must be int (char literals are already lexed as int constants).
 *  Cases fall through by default, matching Java; use 'break' to exit. */
class SwitchStmt extends Stmt {
    Expr selector;
    Vector cases = new Vector(); // SwitchCase
}

class CatchClause {
    String exFqcn;   // dotted FQCN of the caught exception type
    String varName;
    BlockStmt body;
}

/** try { ... } catch (...) {...}* finally {...}? -- see CodeGen for the
 *  limitations of the finally implementation (inlined at normal/catch exit
 *  and on an exception escaping the try block; NOT re-run on an early
 *  return/break/continue out of the try or a catch body). */
class TryStmt extends Stmt {
    BlockStmt tryBlock;
    Vector catches = new Vector(); // CatchClause
    BlockStmt finallyBlock; // may be null
}

class ThrowStmt extends Stmt {
    Expr value;
}

/** assert cond; / assert cond : message; -- see CodeGen.genAssert for the
 *  emitted shape and the $assertionsDisabled initialization strategy. */
class AssertStmt extends Stmt {
    Expr cond;
    Expr message; // may be null
}

// ---------------- expressions ----------------
abstract class Expr {
    boolean charTyped;     // statically a char (char literal, (char) cast, char variable/field/array element, char-returning call)
    int line;
    int resolvedType = -1; // filled in by Resolver/CodeGen
    boolean typed;         // true once CodeGen has computed this node's type (resolvedType valid,
                           // since -1 is also the NULL type marker); lets CodeGen ask for an
                           // operand's type before emitting it without re-walking the subtree
}

class IntLit extends Expr {
    int value;
    boolean isChar; // written as a char literal; lets overload resolution choose append(char) over append(int)
}

/** 123L / 0xFFL */
class LongLit extends Expr {
    long value;
}

/** 1.5f */
class FloatLit extends Expr {
    float value;
}

/** 1.5 / 1.5d */
class DoubleLit extends Expr {
    double value;
}

class BoolLit extends Expr {
    boolean value;
}

class StrLit extends Expr {
    String value;
}

class NullLit extends Expr {}

class NameExpr extends Expr {
    String name;
}

class ThisExpr extends Expr {}

/** compiler-generated: the zero value of a type (0 / 0L / 0.0 / null). */
class DefaultValueExpr extends Expr {
    int type;
    DefaultValueExpr(int type) { this.type = type; }
}

/** compiler-inserted unboxing of a wrapper-typed operand (Integer -> int, ...). */
class UnboxExpr extends Expr {
    Expr operand;
}

/** Outer.this, or the implicit enclosing instance passed to an inner class's constructor. */
class OuterThisExpr extends Expr {
    String className; // FQCN of the enclosing class whose instance is wanted
}

/** obj.field or ClassName.STATIC_FIELD (qualifier is a single identifier for now). */
class FieldAccessExpr extends Expr {
    String qualifier;
    String name;
}

/** new ClassName(args) */
class NewExpr extends Expr {
    Expr outerInstance; // outer.new Inner(...)
    String className; // as written (simple or dotted), resolved by CodeGen
    Vector args = new Vector(); // Expr
}

class BinaryExpr extends Expr {
    String op; // "+","-","*","/","%","==","!=","<","<=",">",">=","&&","||"
    Expr left;
    Expr right;
}

class UnaryExpr extends Expr {
    String op; // "!" or "-"
    Expr operand;
}

class AssignExpr extends Expr {
    String target;   // variable/field name being assigned
    String op;       // "=","+=","-=","*=","/=","%="
    Expr value;
}

class CallExpr extends Expr {
    String qualifier; // e.g. "System.out", "form", "Display", or null for local call
    String name;      // method name ("println","print", or user/API method)
    Vector args = new Vector(); // Expr
}

class IncDecExpr extends Expr {
    Expr target;    // non-null for obj.field++ / a[i]++ (FieldAccessExpr, ChainFieldExpr or ArrayAccessExpr); name unused then
    String name;
    String op;      // "++" or "--"
    boolean prefix;
}

/** new <elemType>[sizeExpr] -- single-dimension array creation. */
class NewArrayExpr extends Expr {
    Vector extraDims; // Expr sizes of further dimensions for new T[a][b]...; null/empty for 1-D
    String elemDesc; // JVM descriptor of the element type: "I","Z","B","Ljava/lang/String;","Lfoo/Bar;"
    Expr size;
}

/** arrayExpr[indexExpr] read. */
class ArrayAccessExpr extends Expr {
    Expr array;
    Expr index;
}

/** (TargetType) operand -- reference-type cast, or (int)/(long)/(float)/(double)/
 *  (byte)/(short)/(char) primitive cast. For a primitive cast primitiveCast is true,
 *  targetFqcn is null and targetType/targetDesc ("I","J","F","D","B","S","C") say
 *  what to convert to. */
class CastExpr extends Expr {
    String targetFqcn;
    boolean primitiveCast;
    int targetType;     // T.* code, valid when primitiveCast
    String targetDesc;  // single-char JVM descriptor, valid when primitiveCast
    Expr operand;
}

/** arrayExpr[indexExpr] = valueExpr (only plain "=" is supported for array elements). */
class ArrayAssignExpr extends Expr {
    String op = "=";  // "=" or a compound operator such as "+=" / "<<="
    Expr array;
    Expr index;
    Expr value;
}

/** operand instanceof TargetType -- targetFqcn is already resolved (imports/siblings/API)
 *  by the parser, same as CastExpr.targetFqcn. */
class InstanceOfExpr extends Expr {
    Expr operand;
    String targetFqcn;
}
/** receiver.name(args) where the receiver is an arbitrary expression (a call result,
 *  a cast, a parenthesized expression, an array element, a string literal, 'new X()' ...). */
class ChainCallExpr extends Expr {
    Expr target;
    String name;
    Vector args = new Vector(); // Expr
}

/** receiver.name where the receiver is an arbitrary expression (also array.length). */
class ChainFieldExpr extends Expr {
    Expr target;
    String name;
}

/** lhs op value where lhs is a FieldAccessExpr or ChainFieldExpr (this.x = 1, a.b.c += 2,
 *  Other.COUNT = 3, foo().bar = 4). op is "=" or a compound operator. */
class FieldAssignExpr extends Expr {
    Expr lhs;
    String op;
    Expr value;
}

/** cond ? a : b */
class CondExpr extends Expr {
    Expr cond;
    Expr a;
    Expr b;
}

/** {e1, e2, ...} array initializer; elemDesc is the JVM element descriptor (set by the parser
 *  from the declared type, or from 'new T[]{...}'). */
class ArrayInitExpr extends Expr {
    String elemDesc;
    Vector elems = new Vector(); // Expr
}
