package com.dashers.j2mebuilderide.compiler;

import java.util.Vector;
import java.util.Hashtable;

/**
 * Registry of every top-level class declared in the same source file,
 * used by CodeGen alongside ApiIndex so one class can reference another
 * sibling class's constructors/fields/methods and superclass/interface
 * chains can cross freely between local classes and the platform API
 * (a local class extending a local class extending a platform class,
 * etc).
 *
 * Built in a pass over all ClassNodes *before* any codegen happens, so
 * forward references within the file work: class A can call `new B()`
 * even if B is declared later in the same file.
 *
 * Query methods mirror ApiIndex's shape on purpose (same method names,
 * same ApiIndex.Found/FieldFound result types) so CodeGen's lookup call
 * sites can do "check locals, then fall back to api" with a uniform
 * pattern instead of two divergent APIs.
 */
public class LocalClassTable {

    private Hashtable byName = new Hashtable(); // simple name -> ClassNode
    private ApiIndex api; // for chain walks that leave local classes and enter the platform API

    public LocalClassTable(Vector classNodes, ApiIndex api) {
        this.api = api;
        for (int i = 0; i < classNodes.size(); i++) {
            ClassNode c = (ClassNode) classNodes.elementAt(i);
            byName.put(c.name, c);
        }
    }

    /** every user-declared varargs method with this name, across all local classes. */
    public Vector varargsMethods(String name) {
        Vector r = new Vector();
        java.util.Enumeration en = byName.elements();
        while (en.hasMoreElements()) {
            ClassNode c = (ClassNode) en.nextElement();
            for (int i = 0; i < c.methods.size(); i++) {
                MethodNode m = (MethodNode) c.methods.elementAt(i);
                if (m.isVarargs && !m.isConstructor && m.name.equals(name)) r.addElement(m);
            }
        }
        return r;
    }

    public boolean has(String fqcn) {
        return byName.containsKey(fqcn);
    }

    public ClassNode get(String fqcn) {
        return (ClassNode) byName.get(fqcn);
    }

    public boolean isInterface(String fqcn) {
        ClassNode c = get(fqcn);
        return c != null && c.isInterface;
    }

    public boolean isAbstract(String fqcn) {
        ClassNode c = get(fqcn);
        return c != null && (c.isAbstract || c.isInterface);
    }

    /** direct superclass fqcn (defaults to "java.lang.Object" per ClassNode.superName), or null if unknown. */
    public String superOf(String fqcn) {
        ClassNode c = get(fqcn);
        return c != null ? c.superName : null;
    }

    public Vector interfacesOf(String fqcn) {
        ClassNode c = get(fqcn);
        return c != null ? c.interfaces : new Vector();
    }

    /** BFS up the superclass+interface chain -- starting at a local class, but
     *  freely continuing into the platform API once the chain leaves local classes
     *  -- for a method matching name+argCount. */
    public ApiIndex.Found findMethod(String fqcn, String name, int argCount) {
        Vector all = findAllMethods(fqcn, name, argCount);
        return all.size() > 0 ? (ApiIndex.Found) all.elementAt(0) : null;
    }

    public Vector findAllMethods(String fqcn, String name, int argCount) {
        Vector results = new Vector();
        Vector visited = new Vector();
        Vector queue = new Vector();
        queue.addElement(fqcn);
        while (queue.size() > 0) {
            String cur = (String) queue.elementAt(0);
            queue.removeElementAt(0);
            if (cur == null || visited.contains(cur)) continue;
            visited.addElement(cur);
            ClassNode c = get(cur);
            if (c != null) {
                for (int i = 0; i < c.methods.size(); i++) {
                    MethodNode m = (MethodNode) c.methods.elementAt(i);
                    if (m.isConstructor) continue;
                    if (m.name.equals(name) && m.params.size() == argCount) {
                        ApiIndex.Found found = new ApiIndex.Found();
                        found.declaringClass = cur;
                        found.method = toMethodInfo(m);
                        results.addElement(found);
                    }
                }
                queue.addElement(c.superName);
                for (int i = 0; i < c.interfaces.size(); i++) queue.addElement(c.interfaces.elementAt(i));
            } else if (api != null && api.has(cur)) {
                // chain has left local classes and entered the platform API --
                // let ApiIndex's own BFS take over the rest of the search from here.
                Vector apiResults = api.findAllMethods(cur, name, argCount);
                for (int i = 0; i < apiResults.size(); i++) results.addElement(apiResults.elementAt(i));
            }
            // if cur is neither a local class nor a known API class, it's an
            // unresolved type -- CodeGen will already have reported that error
            // earlier when the type itself was resolved, so just skip it here.
        }
        return results;
    }

    public ApiIndex.Found findConstructor(String fqcn, int argCount) {
        Vector all = findAllConstructors(fqcn, argCount);
        return all.size() > 0 ? (ApiIndex.Found) all.elementAt(0) : null;
    }

    public Vector findAllConstructors(String fqcn, int argCount) {
        Vector results = new Vector();
        ClassNode c = get(fqcn);
        if (c == null || c.isInterface) return results; // interfaces have no <init> at all, real or synthesized
        boolean sawExplicitCtor = false;
        for (int i = 0; i < c.methods.size(); i++) {
            MethodNode m = (MethodNode) c.methods.elementAt(i);
            if (!m.isConstructor) continue;
            sawExplicitCtor = true;
            if (m.params.size() == argCount) {
                ApiIndex.Found found = new ApiIndex.Found();
                found.declaringClass = fqcn;
                found.ctor = toCtorInfo(m);
                results.addElement(found);
            }
        }
        // a class with no explicit constructor at all gets an implicit public
        // no-arg one (mirrors Compiler.compile's own default-ctor synthesis).
        if (!sawExplicitCtor && argCount == 0) {
            ApiIndex.Found found = new ApiIndex.Found();
            found.declaringClass = fqcn;
            ApiIndex.CtorInfo ci = new ApiIndex.CtorInfo();
            ci.paramDesc = "";
            ci.flags = 1;
            found.ctor = ci;
            results.addElement(found);
        }
        return results;
    }

    public ApiIndex.FieldFound findField(String fqcn, String name) {
        Vector visited = new Vector();
        Vector queue = new Vector();
        queue.addElement(fqcn);
        while (queue.size() > 0) {
            String cur = (String) queue.elementAt(0);
            queue.removeElementAt(0);
            if (cur == null || visited.contains(cur)) continue;
            visited.addElement(cur);
            ClassNode c = get(cur);
            if (c != null) {
                for (int i = 0; i < c.fields.size(); i++) {
                    FieldNode f = (FieldNode) c.fields.elementAt(i);
                    if (f.name.equals(name)) {
                        ApiIndex.FieldFound found = new ApiIndex.FieldFound();
                        found.declaringClass = cur;
                        found.field = toFieldInfo(f);
                        return found;
                    }
                }
                queue.addElement(c.superName);
                for (int i = 0; i < c.interfaces.size(); i++) queue.addElement(c.interfaces.elementAt(i));
            } else if (api != null && api.has(cur)) {
                return api.findField(cur, name);
            }
        }
        return null;
    }

    /** true if `sub` is sub == sup, or sub's superclass/interface chain (crossing
     *  freely between local classes and the platform API) reaches sup. */
    public boolean isAssignableClass(String sub, String sup) {
        if (sub == null) return false;
        if (sub.equals(sup) || "java.lang.Object".equals(sup)) return true;
        Vector visited = new Vector();
        Vector queue = new Vector();
        queue.addElement(sub);
        while (queue.size() > 0) {
            String cur = (String) queue.elementAt(0);
            queue.removeElementAt(0);
            if (cur == null || visited.contains(cur)) continue;
            visited.addElement(cur);
            if (cur.equals(sup)) return true;
            ClassNode c = get(cur);
            if (c != null) {
                queue.addElement(c.superName);
                for (int i = 0; i < c.interfaces.size(); i++) queue.addElement(c.interfaces.elementAt(i));
            } else if (api != null && api.has(cur)) {
                if (api.isAssignableClass(cur, sup)) return true;
            }
        }
        return false;
    }

    // ---- ClassNode member -> ApiIndex.*Info adapters ----
    // (ApiIndex.Found/FieldFound/MethodInfo/CtorInfo/FieldInfo are plain data
    // holders with no ties back to ApiIndex itself, so local AST nodes can be
    // wrapped in them directly and flow through CodeGen's existing "Found"
    // handling code unchanged, whether the hit came from here or from ApiIndex.)

    private ApiIndex.MethodInfo toMethodInfo(MethodNode m) {
        ApiIndex.MethodInfo mi = new ApiIndex.MethodInfo();
        mi.name = m.name;
        mi.paramDesc = paramDescBlob(m.params);
        mi.returnDesc = T.desc(m.returnType);
        // flags bitmask matches ApiIndex's documented format: 1=public 8=static 32=abstract
        mi.flags = 1 | (m.isStatic ? 8 : 0) | (m.isAbstract ? 32 : 0) | (m.returnIsTypeVar ? 0x4000 : 0);
        return mi;
    }

    private ApiIndex.CtorInfo toCtorInfo(MethodNode m) {
        ApiIndex.CtorInfo ci = new ApiIndex.CtorInfo();
        ci.paramDesc = paramDescBlob(m.params);
        ci.flags = 1; // public
        return ci;
    }

    private ApiIndex.FieldInfo toFieldInfo(FieldNode f) {
        ApiIndex.FieldInfo fi = new ApiIndex.FieldInfo();
        fi.name = f.name;
        fi.desc = T.desc(f.type);
        fi.flags = f.isStatic ? 9 : 1; // public [| static]
        fi.constValue = null;
        return fi;
    }

    private String paramDescBlob(Vector params) {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < params.size(); i++) {
            ParamNode p = (ParamNode) params.elementAt(i);
            sb.append(T.desc(p.type));
        }
        return sb.toString();
    }
}
