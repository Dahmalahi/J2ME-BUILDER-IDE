package com.dashers.j2mebuilderide.compiler;

import java.util.Vector;
import java.util.Hashtable;

/**
 * Generates JVM bytecode for one method body from its AST.
 * Also does lightweight type checking/resolution as it walks the tree
 * (this compiler has no separate semantic-analysis pass; it's folded
 * into codegen to keep the file count down for an on-device compiler).
 *
 * As of the import/class/new/extends upgrade, this also resolves calls
 * and field access against the real MIDP/CLDC API (via ApiIndex) so
 * user code can genuinely `extends MIDlet`, `new Form(...)`, and call
 * into javax.microedition.* -- not just user-defined static methods.
 *
 * Java 1.4 source level, CLDC 1.1 bytecode target:
 *  - long, float and double are first-class (locals, fields, parameters,
 *    returns, array elements, arithmetic, comparisons, casts, string
 *    concatenation). long/double occupy TWO operand-stack words and TWO
 *    local slots; T.wordSize() is the single source of truth and every
 *    push()/pop()/slot allocation below goes through it.
 *  - Binary numeric promotion is done by asking for each operand's type
 *    BEFORE emitting it (typeOf(), which dry-runs and caches) so the left
 *    operand can be converted the moment it has been emitted, instead of
 *    reaching under the right operand on the stack.
 *  - byte/short/char still share T.INT. Truncation happens at explicit
 *    casts ((byte) x -> I2B, (short) -> I2S, (char) -> I2C) and at array
 *    stores (BASTORE/SASTORE/CASTORE), not at plain assignment -- identical
 *    to the pre-1.4 behavior, so existing programs keep their bytecode.
 *  - assert: see genAssert. A synthetic static final boolean
 *    $assertionsDisabled is added to each class that uses assert and is
 *    initialized in <clinit> from the system property "j2me.assertions"
 *    (assertions are ON only when it equals "true"; CLDC devices return
 *    null for unknown properties, so they default to OFF, like java -da).
 *    The thrown type is java.lang.Error, not AssertionError: CLDC 1.1 has no
 *    AssertionError, and a class that mentions a missing Throwable subclass
 *    fails verification on the device even if the assertion never fires.
 *  - Supported: inner/local/anonymous classes, enums (including constant bodies),
 *    enhanced for, varargs, erased generics, static imports, var, and boxing/unboxing.
 *  - Remaining deliberate gaps: local interfaces/enums, native implementation semantics,
 *    try-with-resources, and lambdas (which require lowering to CLDC-compatible bytecode).
 */
public class CodeGen {

    // opcodes used
    static final int NOP = 0x00, ACONST_NULL = 0x01;
    static final int ICONST_M1 = 0x02, ICONST_0 = 0x03, ICONST_1 = 0x04;
    static final int BIPUSH = 0x10, SIPUSH = 0x11, LDC = 0x12, LDC_W = 0x13;
    static final int ILOAD = 0x15, ALOAD = 0x19;
    static final int ILOAD_0 = 0x1a, ALOAD_0 = 0x2a;
    static final int ISTORE = 0x36, ASTORE = 0x3a;
    static final int ISTORE_0 = 0x3b, ASTORE_0 = 0x4b;
    static final int POP = 0x57, POP2 = 0x58, DUP = 0x59;
    static final int IADD = 0x60, ISUB = 0x64, IMUL = 0x68, IDIV = 0x6c, IREM = 0x70;
    static final int INEG = 0x74;
    static final int ISHL = 0x78, ISHR = 0x7a, IUSHR = 0x7c;
    static final int IAND = 0x7e, IOR = 0x80, IXOR = 0x82;
    static final int IINC = 0x84;
    static final int I2L = 0x85, I2D = 0x87;
    static final int IF_ICMPEQ = 0x9f, IF_ICMPNE = 0xa0, IF_ICMPLT = 0xa1,
                      IF_ICMPGE = 0xa2, IF_ICMPGT = 0xa3, IF_ICMPLE = 0xa4;
    static final int IF_ACMPEQ = 0xa5, IF_ACMPNE = 0xa6;
    static final int IFEQ = 0x99, IFNE = 0x9a, IFNULL = 0xc6, IFNONNULL = 0xc7;
    static final int GOTO = 0xa7;
    static final int RETURN = 0xb1, IRETURN = 0xac, ARETURN = 0xb0;
    static final int GETSTATIC = 0xb2, PUTSTATIC = 0xb3, GETFIELD = 0xb4, PUTFIELD = 0xb5;
    static final int INVOKEVIRTUAL = 0xb6, INVOKESPECIAL = 0xb7, INVOKESTATIC = 0xb8, INVOKEINTERFACE = 0xb9;
    static final int MULTIANEWARRAY = 0xc5;
    static final int MONITORENTER = 0xc2, MONITOREXIT = 0xc3;
    static final int NEW = 0xbb, NEWARRAY = 0xbc, ANEWARRAY = 0xbd, ARRAYLENGTH = 0xbe, ATHROW = 0xbf;
    static final int CHECKCAST = 0xc0;
    static final int IALOAD = 0x2e, BALOAD = 0x33, CALOAD = 0x34, SALOAD = 0x35, AALOAD = 0x32;
    static final int IASTORE = 0x4f, BASTORE = 0x54, CASTORE = 0x55, SASTORE = 0x56, AASTORE = 0x53;
    static final int T_BOOLEAN = 4, T_CHAR = 5, T_INT = 10, T_SHORT = 9;
    static final int INSTANCEOF = 0xc1;

    // ---- opcodes added for the Java 1.4 level (long/float/double, assert) ----
    static final int LCONST_0 = 0x09, LCONST_1 = 0x0a;
    static final int FCONST_0 = 0x0b, FCONST_1 = 0x0c, FCONST_2 = 0x0d;
    static final int DCONST_0 = 0x0e, DCONST_1 = 0x0f;
    static final int LDC2_W = 0x14;
    static final int LLOAD = 0x16, FLOAD = 0x17, DLOAD = 0x18;
    static final int LLOAD_0 = 0x1e, FLOAD_0 = 0x22, DLOAD_0 = 0x26;
    static final int LALOAD = 0x2f, FALOAD = 0x30, DALOAD = 0x31;
    static final int LSTORE = 0x37, FSTORE = 0x38, DSTORE = 0x39;
    static final int LSTORE_0 = 0x3f, FSTORE_0 = 0x43, DSTORE_0 = 0x47;
    static final int LASTORE = 0x50, FASTORE = 0x51, DASTORE = 0x52;
    static final int DUP2 = 0x5c, DUP2_X1 = 0x5d, DUP2_X2 = 0x5e;
    // arithmetic: the L/F/D opcode is the I opcode + 1/2/3 (IADD=0x60 -> LADD=0x61, FADD=0x62, DADD=0x63)
    static final int LADD = 0x61, FADD = 0x62, DADD = 0x63;
    static final int LSUB = 0x65, FSUB = 0x66, DSUB = 0x67;
    static final int LMUL = 0x69, FMUL = 0x6a, DMUL = 0x6b;
    static final int LDIV = 0x6d, FDIV = 0x6e, DDIV = 0x6f;
    static final int LREM = 0x71, FREM = 0x72, DREM = 0x73;
    static final int LNEG = 0x75, FNEG = 0x76, DNEG = 0x77;
    static final int LSHL = 0x79, LSHR = 0x7b, LUSHR = 0x7d;
    static final int LAND = 0x7f, LOR = 0x81, LXOR = 0x83;
    static final int I2F = 0x86;
    static final int L2I = 0x88, L2F = 0x89, L2D = 0x8a;
    static final int F2I = 0x8b, F2L = 0x8c, F2D = 0x8d;
    static final int D2I = 0x8e, D2L = 0x8f, D2F = 0x90;
    static final int I2B = 0x91, I2C = 0x92, I2S = 0x93;
    static final int LCMP = 0x94, FCMPL = 0x95, FCMPG = 0x96, DCMPL = 0x97, DCMPG = 0x98;
    static final int IFLT = 0x9b, IFGE = 0x9c, IFGT = 0x9d, IFLE = 0x9e;
    static final int LRETURN = 0xad, FRETURN = 0xae, DRETURN = 0xaf;
    static final int T_FLOAT = 6, T_DOUBLE = 7, T_LONG = 11, T_BYTE = 8;

    ConstPool cp;
    ClassNode cls;
    ApiIndex api;
    LocalClassTable locals; // sibling top-level classes declared in the same file; may be null (treated as empty)
    String internalClassName;
    int selfType; // T type code representing "instance of the class being compiled"

    public CodeGen(ConstPool cp, ClassNode cls, ApiIndex api) {
        this(cp, cls, api, null);
    }

    public CodeGen(ConstPool cp, ClassNode cls, ApiIndex api, LocalClassTable locals) {
        this.cp = cp;
        this.cls = cls;
        this.api = api;
        this.locals = locals;
        this.internalClassName = internalNameFor(cls.name);
        this.selfType = T.refType(cls.name);
    }

    // ---------------- local-or-platform lookup helpers ----------------
    // Every lookup CodeGen needs (method/ctor/field resolution, chain walks for
    // isAssignableClass/isInterface/has) checks sibling classes declared in this
    // same file first, then falls back to the platform ApiIndex. This is the one
    // seam that makes cross-class references between top-level classes in one
    // file work throughout the rest of this file, which otherwise only ever
    // talks to `api`.

    private boolean hasAny(String fqcn) {
        if (locals != null && locals.has(fqcn)) return true;
        return api.has(fqcn);
    }

    private boolean isInterfaceAny(String fqcn) {
        if (locals != null && locals.has(fqcn)) return locals.isInterface(fqcn);
        return api.isInterface(fqcn);
    }

    /** true if fqcn cannot be `new`'d directly: an interface (local or platform) or
     *  a class (local or platform) explicitly declared 'abstract'. */
    private boolean isAbstractAny(String fqcn) {
        if (locals != null && locals.has(fqcn)) return locals.isAbstract(fqcn);
        ApiIndex.ClassInfo ci = api.get(fqcn);
        return ci != null && ci.isInterface; // platform API index doesn't currently carry a class-level abstract flag
    }

    private ApiIndex.Found findMethodAny(String fqcn, String name, int argCount) {
        if (locals != null && locals.has(fqcn)) return locals.findMethod(fqcn, name, argCount);
        return api.findMethod(fqcn, name, argCount);
    }

    private Vector findAllMethodsAny(String fqcn, String name, int argCount) {
        if (locals != null && locals.has(fqcn)) return locals.findAllMethods(fqcn, name, argCount);
        return api.findAllMethods(fqcn, name, argCount);
    }

    private ApiIndex.Found findConstructorAny(String fqcn, int argCount) {
        if (locals != null && locals.has(fqcn)) return locals.findConstructor(fqcn, argCount);
        return api.findConstructor(fqcn, argCount);
    }

    private Vector findAllConstructorsAny(String fqcn, int argCount) {
        if (locals != null && locals.has(fqcn)) return locals.findAllConstructors(fqcn, argCount);
        return api.findAllConstructors(fqcn, argCount);
    }

    private ApiIndex.FieldFound findFieldAny(String fqcn, String name) {
        if (locals != null && locals.has(fqcn)) return locals.findField(fqcn, name);
        return api.findField(fqcn, name);
    }

    /** true if a value of class `sub` may be used where `sup` is expected, crossing
     *  freely between local classes (in this file) and the platform API. */
    private boolean isAssignableClassAny(String sub, String sup) {
        if (sub == null) return false;
        if (sub.equals(sup) || "java.lang.Object".equals(sup)) return true;
        if (locals != null && locals.has(sub)) return locals.isAssignableClass(sub, sup);
        return api.isAssignableClass(sub, sup);
    }

    static String internalNameFor(String dottedFqcn) {
        return dottedFqcn.replace('.', '/');
    }

    // ---- descriptors ----
    static String desc(int type) {
        return T.desc(type);
    }

    String methodDesc(MethodNode m) {
        StringBuffer sb = new StringBuffer("(");
        for (int i = 0; i < m.params.size(); i++) {
            ParamNode p = (ParamNode) m.params.elementAt(i);
            sb.append(desc(p.type));
        }
        sb.append(")");
        sb.append(desc(m.returnType));
        return sb.toString();
    }

    private MethodNode findMethod(String name, int argCount) {
        for (int i = 0; i < cls.methods.size(); i++) {
            MethodNode m = (MethodNode) cls.methods.elementAt(i);
            if (m.isConstructor) continue;
            if (m.name.equals(name) && m.params.size() == argCount) return m;
        }
        return null;
    }

    /** All overloads declared directly on the class currently being generated. */
    private Vector findOwnMethods(String name, int argCount) {
        Vector out = new Vector();
        for (int i = 0; i < cls.methods.size(); i++) {
            MethodNode m = (MethodNode) cls.methods.elementAt(i);
            if (!m.isConstructor && m.name.equals(name) && m.params.size() == argCount) out.addElement(m);
        }
        return out;
    }

    /** Selects one user-defined overload using the same conversion rules as JAR/API methods. */
    private MethodNode pickOwnMethod(Vector candidates, Vector args, int line) throws CompileError {
        if (candidates.size() == 0) return null;
        if (candidates.size() == 1) return (MethodNode) candidates.elementAt(0);
        int[] argTypes = dryRunArgTypes(args);
        boolean[] isCh = new boolean[argTypes.length];
        for (int i = 0; i < isCh.length; i++) isCh[i] = isCharExpr((Expr) args.elementAt(i));
        for (int pass = 0; pass < 4; pass++) {
            for (int i = 0; i < candidates.size(); i++) {
                MethodNode m = (MethodNode) candidates.elementAt(i);
                Vector pds = ApiIndex.splitParamDescriptors(paramDescBlob(m.params));
                if (pass == 0 && !charKindsMatch(pds, argTypes, isCh)) continue;
                if (paramsMatch(pds, argTypes, pass >= 2, pass == 3, isCh)) return m;
            }
        }
        throw new CompileError("no applicable overload of '" + ((MethodNode)candidates.elementAt(0)).name + "' for the supplied arguments", line);
    }

    private String paramDescBlob(Vector params) {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < params.size(); i++) sb.append(T.desc(((ParamNode) params.elementAt(i)).type));
        return sb.toString();
    }

    private FieldNode findField(String name) {
        for (int i = 0; i < cls.fields.size(); i++) {
            FieldNode f = (FieldNode) cls.fields.elementAt(i);
            if (f.name.equals(name)) return f;
        }
        return null;
    }

    private ApiIndex.FieldFound findStaticImportedField(String name) {
        for (int i = 0; i < cls.imports.size(); i++) {
            ImportDecl id = (ImportDecl) cls.imports.elementAt(i);
            if (!id.isStatic) continue;
            if (!id.wildcard && !name.equals(id.memberName)) continue;
            ApiIndex.FieldFound ff = findFieldAny(id.path, name);
            if (ff != null && (ff.field.flags & ApiIndex.FLAG_STATIC) != 0) return ff;
        }
        return null;
    }

    private ApiIndex.Found findStaticImportedMethod(String name, Vector args, int line) throws CompileError {
        Vector all = new Vector();
        for (int i = 0; i < cls.imports.size(); i++) {
            ImportDecl id = (ImportDecl) cls.imports.elementAt(i);
            if (!id.isStatic) continue;
            if (!id.wildcard && !name.equals(id.memberName)) continue;
            Vector cands = findAllMethodsAny(id.path, name, args.size());
            for (int k = 0; k < cands.size(); k++) {
                ApiIndex.Found f = (ApiIndex.Found) cands.elementAt(k);
                if ((f.method.flags & ApiIndex.FLAG_STATIC) != 0) all.addElement(f);
            }
        }
        return all.size() == 0 ? null : pickOverload(all, args, line);
    }

    private boolean isSelfType(int t) {
        return t == selfType;
    }

    /** dotted FQCN a class-typed value's chain search should start at (self resolves to its declared superclass). */
    private String chainStartFor(int t) {
        if (isSelfType(t)) return cls.superName;
        return T.className(t);
    }

    // ---------------- name resolution (mirrors Parser's import-aware resolver) ----------------

    private String resolveSimpleClassName(String simple) {
        if (simple.indexOf('.') >= 0) {
            if (hasAny(simple)) return simple;
            // Outer.Inner (or Outer.Inner.Deeper) -> Outer$Inner
            int dot = simple.indexOf('.');
            String head = resolveSimpleClassName(simple.substring(0, dot));
            if (head != null) {
                String cand = head + "$" + simple.substring(dot + 1).replace('.', '$');
                if (locals != null && locals.has(cand)) return cand;
            }
            return null;
        }
        if (locals != null) { // nested classes visible from here: members of this class and of every enclosing class
            for (ClassNode c = cls; c != null; c = c.outerName != null ? locals.get(c.outerName) : null) {
                String cand = c.name + "$" + simple;
                if (locals.has(cand)) return cand;
            }
        }
        for (int i = 0; i < cls.imports.size(); i++) {
            ImportDecl id = (ImportDecl) cls.imports.elementAt(i);
            if (!id.wildcard && (id.path.endsWith("." + simple) || id.path.equals(simple))) {
                String imported = id.path;
                if (api.has(imported) || (locals != null && locals.has(imported))) return imported;
                int last = imported.lastIndexOf('.');
                if (last > 0) {
                    String nested = imported.substring(0, last) + "$" + imported.substring(last + 1);
                    if (api.has(nested) || (locals != null && locals.has(nested))) return nested;
                }
                return imported;
            }
        }
        if (locals != null && locals.has(simple)) return simple; // sibling class in this same file
        for (int i = 0; i < cls.imports.size(); i++) {
            ImportDecl id = (ImportDecl) cls.imports.elementAt(i);
            if (id.wildcard) {
                String cand = id.path + "." + simple;
                if (api.has(cand)) return cand;
            }
        }
        if (api.has("java.lang." + simple)) return "java.lang." + simple;
        return null;
    }

    // ---------------- per-method state ----------------
    private CodeBuffer code;
    private MethodNode curMethod;
    private Hashtable localSlot;   // name -> Integer slot
    private Hashtable localType;   // name -> Integer type
    private Hashtable localChar = new Hashtable(); // names of locals/params declared 'char'
    private boolean lastCallChar;   // the call just generated returns char
    private boolean genericPending; // the value just generated came from a generic (type-variable) return
    private Hashtable localFinal;  // name -> present (Boolean.TRUE) if declared final
    private int nextSlot;
    private int maxLocals;
    private int curStack, maxStack;
    private boolean usesAssert; // set by genAssert; Compiler.compileOneClass then emits <clinit> init

    /** true if any method of this class contained an assert statement (so the class
     *  now carries a synthetic $assertionsDisabled field that <clinit> must initialize). */
    public boolean usesAssert() { return usesAssert; }

    private static class LoopFrame {
        Vector breakPatches = new Vector();    // Integer positions needing patch to end-pc
        Vector continuePatches = new Vector(); // Integer positions needing patch to continue-target
        boolean isSwitch;                      // true for a switch frame: 'break' targets it directly,
                                                // but 'continue' must skip past it to the nearest loop frame
        boolean isLabelBlock;                  // frame of a labeled non-loop statement: only 'break label' targets it
        Vector labels;                         // String labels attached to this frame (may be null)
        LoopFrame() {
            labels = pendingLabels;
            pendingLabels = null;
        }
        boolean hasLabel(String l) { return labels != null && labels.contains(l); }
    }
    /** labels of the LabeledStmt being generated; consumed by the next LoopFrame created. */
    private static Vector pendingLabels;
    private Vector loopStack = new Vector();
    private Vector tryStack = new Vector(); // TryFrame, innermost last
    private int hiddenCounter;

    /** exception table entries accumulated for the method currently being generated: each is int[]{startPc,endPc,handlerPc,catchTypeCpIndex(0=any)} */
    private Vector exceptionTable;

    /** Exception table for the most recently generated method (genMethodCode/genExplicitConstructorCode/genConstructorCode/genClinitCode). */
    public Vector lastExceptionTable() { return exceptionTable; }

    public byte[] genMethodCode(MethodNode m, int[] outMaxStack, int[] outMaxLocals) throws CompileError {
        code = new CodeBuffer();
        curMethod = m;
        localSlot = new Hashtable();
        localType = new Hashtable();
        localFinal = new Hashtable(); localChar = new Hashtable();
        curStack = 0; maxStack = 0;
        loopStack = new Vector();
        tryStack = new Vector();
        exceptionTable = new Vector();

        nextSlot = 0;
        if (!m.isStatic) {
            localSlot.put("this", new Integer(nextSlot));
            localType.put("this", new Integer(selfType));
            nextSlot++;
        }
        for (int i = 0; i < m.params.size(); i++) {
            ParamNode p = (ParamNode) m.params.elementAt(i);
            if (localSlot.containsKey(p.name)) throw new CompileError("duplicate parameter '" + p.name + "'", m.line);
            localSlot.put(p.name, new Integer(nextSlot));
            localType.put(p.name, new Integer(p.type));
            if (p.isFinal) localFinal.put(p.name, Boolean.TRUE);
            if (p.charTyped) localChar.put(p.name, Boolean.TRUE);
            nextSlot += T.wordSize(p.type); // long/double parameters take two slots (second one stays Top)
        }
        maxLocals = nextSlot;

        genBlock(m.body);

        // implicit return for void methods that fall off the end
        if (m.returnType == T.VOID) {
            emit(RETURN);
        } else {
            // if body may fall through without return, emit a safe default
            // (a well-formed program always returns explicitly; this just
            // guarantees a verifiable method if it doesn't)
            if (m.returnType == T.INT || m.returnType == T.BOOLEAN) {
                emit(ICONST_0);
                push(1);
                emit(IRETURN);
                pop(1);
            } else if (m.returnType == T.LONG) {
                emit(LCONST_0); push(2); emit(LRETURN); pop(2);
            } else if (m.returnType == T.FLOAT) {
                emit(FCONST_0); push(1); emit(FRETURN); pop(1);
            } else if (m.returnType == T.DOUBLE) {
                emit(DCONST_0); push(2); emit(DRETURN); pop(2);
            } else {
                emit(ACONST_NULL);
                push(1);
                emit(ARETURN);
                pop(1);
            }
        }

        outMaxStack[0] = maxStack;
        outMaxLocals[0] = maxLocals;
        return code.toByteArray();
    }

    /** Always-generated no-arg constructor: super() + instance field initializers. Used only when the user wrote no explicit constructor. */
    public byte[] genConstructorCode(int[] outMaxStack, int[] outMaxLocals) throws CompileError {
        code = new CodeBuffer();
        curMethod = null;
        localSlot = new Hashtable();
        localType = new Hashtable();
        localFinal = new Hashtable(); localChar = new Hashtable();
        localSlot.put("this", new Integer(0));
        localType.put("this", new Integer(selfType));
        nextSlot = 1;
        maxLocals = 1;
        curStack = 0; maxStack = 0;
        loopStack = new Vector();
        tryStack = new Vector();
        exceptionTable = new Vector();

        genDefaultSuperCall(0);

        genFieldInitializers();
        emit(RETURN);

        outMaxStack[0] = maxStack;
        outMaxLocals[0] = maxLocals;
        return code.toByteArray();
    }

    /** Generates code for a user-written constructor: super(...) (explicit if the
     *  body starts with one, otherwise the superclass's no-arg constructor) +
     *  field initializers + the rest of the user's body. */
    public byte[] genExplicitConstructorCode(MethodNode m, int[] outMaxStack, int[] outMaxLocals) throws CompileError {
        code = new CodeBuffer();
        curMethod = m; // returnType is T.VOID, so ReturnStmt handling in genStmt works unchanged
        localSlot = new Hashtable();
        localType = new Hashtable();
        localFinal = new Hashtable(); localChar = new Hashtable();
        curStack = 0; maxStack = 0;
        loopStack = new Vector();
        tryStack = new Vector();
        exceptionTable = new Vector();

        nextSlot = 0;
        localSlot.put("this", new Integer(nextSlot));
        localType.put("this", new Integer(selfType));
        nextSlot++;
        for (int i = 0; i < m.params.size(); i++) {
            ParamNode p = (ParamNode) m.params.elementAt(i);
            if (localSlot.containsKey(p.name)) throw new CompileError("duplicate parameter '" + p.name + "'", m.line);
            localSlot.put(p.name, new Integer(nextSlot));
            localType.put(p.name, new Integer(p.type));
            if (p.isFinal) localFinal.put(p.name, Boolean.TRUE);
            if (p.charTyped) localChar.put(p.name, Boolean.TRUE);
            nextSlot += T.wordSize(p.type); // long/double parameters take two slots (second one stays Top)
        }
        maxLocals = nextSlot;

        int bodyStart = 0;
        Vector stmts = m.body.stmts;
        if (stmts.size() > 0 && stmts.elementAt(0) instanceof ThisCallStmt) {
            // this(...): delegate to another constructor of this class, which does the
            // super call, the synthetic-field stores and the field initializers itself
            ThisCallStmt tc = (ThisCallStmt) stmts.elementAt(0);
            Vector args = new Vector();
            for (int i = 0; i < m.params.size(); i++) { // forward the synthetic leading params (this$0)
                ParamNode p = (ParamNode) m.params.elementAt(i);
                if (!p.isSynthField || p.name.startsWith("val$")) break;
                args.addElement(nm(p.name, tc.line));
            }
            for (int i = 0; i < tc.args.size(); i++) args.addElement(tc.args.elementAt(i));
            for (int i = 0; i < m.params.size(); i++) { // forward captured variables (local classes)
                ParamNode p = (ParamNode) m.params.elementAt(i);
                if (p.isSynthField && p.name.startsWith("val$")) args.addElement(nm(p.name, tc.line));
            }
            Vector cands = findAllConstructorsAny(cls.name, args.size());
            if (cands.size() == 0) throw new CompileError("no constructor of " + cls.name + " takes " + tc.args.size() + " argument(s) for this(...)", tc.line);
            ApiIndex.Found found = pickOverload(cands, args, tc.line);
            emit(ALOAD_0); push(1);
            Vector pds = ApiIndex.splitParamDescriptors(found.ctor.paramDesc);
            genArgsRaw(pds, args, tc.line);
            int mi = cp.methodref(internalClassName, "<init>", "(" + found.ctor.paramDesc + ")V");
            emit(INVOKESPECIAL); code.u2(mi);
            pop(paramWordCount(pds) + 1);
            for (int i = 1; i < stmts.size(); i++) genStmt((Stmt) stmts.elementAt(i));
            emit(RETURN);
            outMaxStack[0] = maxStack;
            outMaxLocals[0] = maxLocals;
            return code.toByteArray();
        }
        if (stmts.size() > 0 && stmts.elementAt(0) instanceof SuperCallStmt) {
            SuperCallStmt sc = (SuperCallStmt) stmts.elementAt(0);
            genExplicitSuperCall(sc.args, sc.line);
            bodyStart = 1;
        } else {
            genDefaultSuperCall(m.line);
        }

        // synthetic parameters (this$0, val$x, enum $name/$ordinal) are copied into their fields
        for (int i = 0; i < m.params.size(); i++) {
            ParamNode p = (ParamNode) m.params.elementAt(i);
            if (!p.isSynthField) continue;
            emit(ALOAD_0); push(1);
            loadSlot(((Integer) localSlot.get(p.name)).intValue(), p.type);
            emit(PUTFIELD); code.u2(cp.fieldref(internalClassName, p.name, desc(p.type)));
            pop(1 + T.wordSize(p.type));
        }

        genFieldInitializers();
        for (int i = bodyStart; i < stmts.size(); i++) {
            genStmt((Stmt) stmts.elementAt(i));
        }
        emit(RETURN);

        outMaxStack[0] = maxStack;
        outMaxLocals[0] = maxLocals;
        return code.toByteArray();
    }

    /** this()+invokespecial to the superclass's no-arg constructor. Requires
     *  one to actually exist on the superclass (not every MIDP base class has
     *  one -- e.g. GameCanvas only has a 1-arg constructor -- in which case
     *  the user must write an explicit super(...) as the first statement of
     *  their own constructor instead). */
    private void genDefaultSuperCall(int line) throws CompileError {
        ClassNode supNode = locals != null ? locals.get(cls.superName) : null;
        if (supNode != null && (supNode.hasOuterThis || supNode.capturedNames.size() > 0)) {
            genExplicitSuperCall(new Vector(), line); // inner superclass: its hidden ctor params must be passed
            return;
        }
        if (findConstructorAny(cls.superName, 0) == null) {
            throw new CompileError("class " + cls.name + " must declare a constructor that calls " +
                    "an explicit super(...): superclass " + cls.superName +
                    " has no accessible no-arg constructor", line);
        }
        emit(ALOAD_0); push(1);
        int ctor = cp.methodref(internalNameFor(cls.superName), "<init>", "()V");
        emit(INVOKESPECIAL); code.u2(ctor); pop(1);
    }

    /** If the superclass is an inner (or capturing local) class, its constructor takes hidden
     *  leading/trailing parameters (this$0, val$x...). Builds the full argument list for the
     *  super(...) call: enclosing instance, the user's arguments, then captured variables. */
    private Vector withSuperHiddenArgs(Vector userArgs, int line) throws CompileError {
        ClassNode sup = locals != null ? locals.get(cls.superName) : null;
        if (sup == null || !(sup.hasOuterThis || sup.capturedNames.size() > 0)) return userArgs;
        // an anonymous class's explicit args were already extended by finalizeAnon -- but it
        // adds only user args, so the same rule applies to it
        Vector out = new Vector();
        if (sup.hasOuterThis) {
            // The instance of sup's enclosing class, found by walking this$0 links starting from
            // our own this$0 constructor parameter (the field is not assigned until after super()).
            if (!localSlot.containsKey("this$0")) {
                throw new CompileError("no enclosing instance of " + sup.outerName + " is in scope to construct the superclass "
                        + cls.superName + " (" + cls.name + " is not an inner class)", line);
            }
            Expr path = nm("this$0", line);
            ClassNode c = locals.get(cls.outerName);
            while (c != null && !(c.name.equals(sup.outerName) || locals.isAssignableClass(c.name, sup.outerName))) {
                if (!c.hasOuterThis || c.outerName == null) { c = null; break; }
                ChainFieldExpr cf = new ChainFieldExpr();
                cf.line = line; cf.target = path; cf.name = "this$0";
                path = cf;
                c = locals.get(c.outerName);
            }
            if (c == null && !(cls.outerName.equals(sup.outerName) || locals.isAssignableClass(cls.outerName, sup.outerName))) {
                throw new CompileError("no enclosing instance of " + sup.outerName + " is in scope to construct the superclass " + cls.superName, line);
            }
            out.addElement(path);
        }
        for (int i = 0; i < userArgs.size(); i++) out.addElement(userArgs.elementAt(i));
        for (int i = 0; i < sup.capturedNames.size(); i++) {
            String cn = (String) sup.capturedNames.elementAt(i);
            if (localSlot.containsKey("val$" + cn)) out.addElement(nm("val$" + cn, line));
            else if (localSlot.containsKey(cn)) out.addElement(nm(cn, line));
            else out.addElement(new DefaultValueExpr(typeOfCaptured(sup, i)));
        }
        return out;
    }

    /** aload_0 + args + invokespecial to a real, overload-resolved superclass
     *  constructor, for an explicit "super(args);" as a constructor's first statement. */
    private void genExplicitSuperCall(Vector userArgs, int line) throws CompileError {
        Vector argExprs = withSuperHiddenArgs(userArgs, line);
        Vector ctorCands = findAllConstructorsAny(cls.superName, argExprs.size());
        if (ctorCands.size() == 0) {
            throw new CompileError("no constructor found on superclass " + cls.superName +
                    " with " + argExprs.size() + " argument(s) for this super(...) call", line);
        }
        ApiIndex.Found found = pickOverload(ctorCands, argExprs, line);
        emit(ALOAD_0); push(1);
        Vector paramDescs = ApiIndex.splitParamDescriptors(found.ctor.paramDesc);
        genArgsRaw(paramDescs, argExprs, line);
        String mdesc = "(" + found.ctor.paramDesc + ")V";
        int idx = cp.methodref(internalNameFor(cls.superName), "<init>", mdesc);
        emit(INVOKESPECIAL); code.u2(idx);
        pop(paramWordCount(paramDescs) + 1);
    }

    private void genInitBlocks(int pos, boolean isStatic) throws CompileError {
        for (int k = 0; k < cls.initBlocks.size(); k++) {
            InitBlock ib = (InitBlock) cls.initBlocks.elementAt(k);
            if (ib.isStatic == isStatic && ib.pos == pos) genBlock(ib.body);
        }
    }

    private void genFieldInitializers() throws CompileError {
        for (int i = 0; i <= cls.fields.size(); i++) {
            genInitBlocks(i, false);
            if (i == cls.fields.size()) break;
            FieldNode f = (FieldNode) cls.fields.elementAt(i);
            if (f.isStatic || f.init == null) continue;
            emit(ALOAD_0); push(1);
            int t = genExpr(f.init);
            coerce(f.type, t, f.line, f.name);
            int idx = cp.fieldref(internalClassName, f.name, desc(f.type));
            emit(PUTFIELD); code.u2(idx); pop(1 + T.wordSize(f.type));
        }
    }

    /** Static initializer for static fields declared with an initializer. */
    public byte[] genClinitCode(int[] outMaxStack, int[] outMaxLocals) throws CompileError {
        code = new CodeBuffer();
        curMethod = null;
        localSlot = new Hashtable();
        localType = new Hashtable();
        localFinal = new Hashtable(); localChar = new Hashtable();
        nextSlot = 0;
        maxLocals = 0;
        curStack = 0; maxStack = 0;
        loopStack = new Vector();
        tryStack = new Vector();
        exceptionTable = new Vector();

        MethodNode cm = new MethodNode();
        cm.name = "<clinit>"; cm.isStatic = true; cm.returnType = T.VOID;
        curMethod = cm;
        if (usesAssert) genAssertionsDisabledInit();
        for (int i = 0; i <= cls.fields.size(); i++) {
            genInitBlocks(i, true);
            if (i == cls.fields.size()) break;
            FieldNode f = (FieldNode) cls.fields.elementAt(i);
            if (!f.isStatic || f.init == null) continue;
            int t = genExpr(f.init);
            coerce(f.type, t, f.line, f.name);
            int idx = cp.fieldref(internalClassName, f.name, desc(f.type));
            emit(PUTSTATIC); code.u2(idx); pop(T.wordSize(f.type));
        }
        emit(RETURN);

        outMaxStack[0] = maxStack;
        outMaxLocals[0] = maxLocals;
        return code.toByteArray();
    }

    private void push(int n) {
        curStack += n;
        if (curStack > maxStack) maxStack = curStack;
    }
    private void pop(int n) {
        curStack -= n;
        if (curStack < 0) curStack = 0;
    }

    private void emit(int op) { code.u1(op); }

    // ---------------- statements ----------------

    private void genBlock(BlockStmt b) throws CompileError {
        if (b.noScope) { // "int a, b;" -- the declarations belong to the enclosing scope
            for (int i = 0; i < b.stmts.size(); i++) genStmt((Stmt) b.stmts.elementAt(i));
            return;
        }
        pushScope();
        try {
            for (int i = 0; i < b.stmts.size(); i++) {
                genStmt((Stmt) b.stmts.elementAt(i));
            }
        } finally {
            popScope();
        }
    }

    // ---- block scoping of local variables ----
    // A variable's name is visible from its declaration to the end of the enclosing
    // block / for statement / switch body, and can be declared again afterwards
    // ("for (int i...) {} for (int i...) {}" works). Slots are NOT reused: every
    // variable keeps its own slot, which keeps the StackMap frames trivially valid.
    private Vector scopeStack = new Vector(); // Vector of Vector(String names declared in that scope)

    private void pushScope() { scopeStack.addElement(new Vector()); }

    private void popScope() {
        Vector names = (Vector) scopeStack.elementAt(scopeStack.size() - 1);
        scopeStack.removeElementAt(scopeStack.size() - 1);
        for (int i = 0; i < names.size(); i++) {
            Object n = names.elementAt(i);
            localSlot.remove(n); localType.remove(n); localFinal.remove(n); localChar.remove(n);
        }
    }

    private void genStmt(Stmt s) throws CompileError {
        if (s instanceof BlockStmt) { genBlock((BlockStmt) s); return; }

        if (s instanceof VarDeclStmt) {
            VarDeclStmt v = (VarDeclStmt) s;
            if (localSlot.containsKey(v.name)) throw new CompileError("variable '" + v.name + "' already declared", v.line);
            if (v.type == T.VAR) {
                if (v.init == null) throw new CompileError("'var' requires an initializer", v.line);
                int inferred = typeOf(v.init);
                if (inferred == T.NULLT || inferred == T.VOID || inferred == T.VAR) {
                    throw new CompileError("cannot infer a variable type from this initializer", v.line);
                }
                v.type = inferred;
                v.charTyped = v.init.charTyped;
            }
            int slot = nextSlot;
            nextSlot += T.wordSize(v.type); // long/double: two slots
            if (nextSlot > 255) throw new CompileError("too many local variables (the 8-bit local slot limit is 255; long and double take two slots each)", v.line);
            if (nextSlot > maxLocals) maxLocals = nextSlot;
            localSlot.put(v.name, new Integer(slot));
            localType.put(v.name, new Integer(v.type));
            if (v.isFinal) localFinal.put(v.name, Boolean.TRUE);
            if (v.charTyped) localChar.put(v.name, Boolean.TRUE);
            if (scopeStack.size() > 0) ((Vector) scopeStack.elementAt(scopeStack.size() - 1)).addElement(v.name);
            if (v.init != null) {
                int t = genExpr(v.init);
                coerce(v.type, t, v.line, v.name);
                storeSlot(slot, v.type);
            }
            return;
        }

        if (s instanceof ExprStmt) {
            ExprStmt e = (ExprStmt) s;
            int t = genExpr(e.expr);
            // An expression statement's value is discarded. A long/double result
            // occupies 2 stack words, so it must be dropped with POP2, not POP; using
            // POP would leave one word behind and corrupt the stack for the rest of
            // the method (the verifier and StackMapGen both see the real shape).
            if (t != T.VOID) {
                if (T.wordSize(t) == 2) { emit(POP2); pop(2); }
                else { emit(POP); pop(1); }
            }
            return;
        }

        if (s instanceof IfStmt) {
            IfStmt f = (IfStmt) s;
            f.cond = unb(f.cond);
            int t = genExpr(f.cond);
            if (t != T.BOOLEAN) throw new CompileError("if condition must be boolean", f.line);
            int jf = emitJumpPlaceholder(IFEQ); // if false -> else/end
            pop(1);
            genStmt(f.thenS);
            if (f.elseS != null) {
                int jend = emitJumpPlaceholder(GOTO);
                patchJumpHere(jf);
                genStmt(f.elseS);
                patchJumpHere(jend);
            } else {
                patchJumpHere(jf);
            }
            return;
        }

        if (s instanceof WhileStmt) {
            WhileStmt w = (WhileStmt) s;
            w.cond = unb(w.cond);
            int startPc = code.pc();
            int t = genExpr(w.cond);
            if (t != T.BOOLEAN) throw new CompileError("while condition must be boolean", w.line);
            int jf = emitJumpPlaceholder(IFEQ);
            pop(1);
            LoopFrame frame = new LoopFrame();
            loopStack.addElement(frame);
            genStmt(w.body);
            loopStack.removeElementAt(loopStack.size() - 1);
            patchContinues(frame, startPc);
            emitGoto(startPc);
            patchJumpHere(jf);
            patchBreaks(frame);
            return;
        }

        if (s instanceof ForStmt) {
            ForStmt fr = (ForStmt) s;
            pushScope();
            if (fr.init != null) genStmt(fr.init);
            int startPc = code.pc();
            int jf = -1;
            if (fr.cond != null) {
                fr.cond = unb(fr.cond);
                int t = genExpr(fr.cond);
                if (t != T.BOOLEAN) throw new CompileError("for condition must be boolean", fr.line);
                jf = emitJumpPlaceholder(IFEQ);
                pop(1);
            }
            LoopFrame frame = new LoopFrame();
            loopStack.addElement(frame);
            genStmt(fr.body);
            int updatePc = code.pc();
            patchContinues(frame, updatePc);
            if (fr.update != null) genStmt(fr.update);
            loopStack.removeElementAt(loopStack.size() - 1);
            emitGoto(startPc);
            if (jf >= 0) patchJumpHere(jf);
            patchBreaks(frame);
            popScope();
            return;
        }

        if (s instanceof ReturnStmt) {
            ReturnStmt r = (ReturnStmt) s;
            if (curMethod.returnType == T.VOID) {
                if (r.value != null) throw new CompileError("cannot return a value from a void method", r.line);
                if (needsUnwind(0)) emitUnwind(0);
                emit(RETURN);
            } else {
                if (r.value == null) throw new CompileError("missing return value", r.line);
                int t = genExpr(r.value);
                coerce(curMethod.returnType, t, r.line, "return");
                int rtype = curMethod.returnType;
                if (needsUnwind(0)) {
                    int tmp = allocTempSlot(T.wordSize(rtype));
                    storeSlot(tmp, rtype);
                    emitUnwind(0);
                    loadSlot(tmp, rtype);
                }
                if (rtype == T.INT || rtype == T.BOOLEAN) {
                    emit(IRETURN);
                } else if (rtype == T.LONG) {
                    emit(LRETURN);
                } else if (rtype == T.FLOAT) {
                    emit(FRETURN);
                } else if (rtype == T.DOUBLE) {
                    emit(DRETURN);
                } else {
                    emit(ARETURN);
                }
                pop(T.wordSize(rtype));
            }
            return;
        }

        if (s instanceof LabeledStmt) {
            genLabeled((LabeledStmt) s);
            return;
        }

        if (s instanceof BreakStmt) {
            String lbl = ((BreakStmt) s).label;
            int idx = -1;
            for (int i = loopStack.size() - 1; i >= 0; i--) {
                LoopFrame f = (LoopFrame) loopStack.elementAt(i);
                if (lbl != null ? f.hasLabel(lbl) : !f.isLabelBlock) { idx = i; break; }
            }
            if (idx < 0) {
                if (lbl != null) throw new CompileError("undefined label: " + lbl, s.line);
                throw new CompileError("'break' outside of a loop", s.line);
            }
            LoopFrame frame = (LoopFrame) loopStack.elementAt(idx);
            if (needsUnwind(idx + 1)) emitUnwind(idx + 1);
            int j = emitJumpPlaceholder(GOTO);
            frame.breakPatches.addElement(new Integer(j));
            return;
        }

        if (s instanceof ContinueStmt) {
            // 'continue' targets the nearest enclosing LOOP (or the loop carrying the label),
            // skipping over any switch / labeled-block frames in between.
            String lbl = ((ContinueStmt) s).label;
            LoopFrame frame = null;
            int frameIdx = -1;
            for (int i = loopStack.size() - 1; i >= 0; i--) {
                LoopFrame f = (LoopFrame) loopStack.elementAt(i);
                if (lbl != null) {
                    if (f.hasLabel(lbl)) {
                        if (f.isSwitch || f.isLabelBlock) throw new CompileError("not a loop label: " + lbl, s.line);
                        frame = f; frameIdx = i; break;
                    }
                } else if (!f.isSwitch && !f.isLabelBlock) { frame = f; frameIdx = i; break; }
            }
            if (frame == null) {
                if (lbl != null) throw new CompileError("undefined label: " + lbl, s.line);
                throw new CompileError("'continue' outside of a loop", s.line);
            }
            if (needsUnwind(frameIdx + 1)) emitUnwind(frameIdx + 1);
            int j = emitJumpPlaceholder(GOTO);
            frame.continuePatches.addElement(new Integer(j));
            return;
        }

        if (s instanceof DoWhileStmt) {
            DoWhileStmt dw = (DoWhileStmt) s;
            int startPc = code.pc();
            LoopFrame frame = new LoopFrame();
            loopStack.addElement(frame);
            genStmt(dw.body);
            int condPc = code.pc();
            patchContinues(frame, condPc); // continue re-checks the condition, doesn't skip it
            dw.cond = unb(dw.cond);
            int t = genExpr(dw.cond);
            if (t != T.BOOLEAN) throw new CompileError("do-while condition must be boolean", dw.line);
            emit(IFNE);
            int pos = code.reserveU2();
            pop(1);
            code.patchBranch(pos, pos - 1, startPc);
            loopStack.removeElementAt(loopStack.size() - 1);
            patchBreaks(frame);
            return;
        }

        if (s instanceof SwitchStmt) {
            pushScope();
            genSwitch((SwitchStmt) s);
            popScope();
            return;
        }

        if (s instanceof ThrowStmt) {
            ThrowStmt th = (ThrowStmt) s;
            int t = genExpr(th.value);
            if (!T.isRef(t) || T.isArray(t)) throw new CompileError("'throw' requires a Throwable operand", s.line);
            emit(ATHROW); pop(1);
            return;
        }

        if (s instanceof TryStmt) {
            genTry((TryStmt) s);
            return;
        }

        if (s instanceof AssertStmt) {
            genAssert((AssertStmt) s);
            return;
        }

        if (s instanceof ForEachStmt) { genForEach((ForEachStmt) s); return; }
        if (s instanceof SyncStmt) { genSync((SyncStmt) s); return; }
        if (s instanceof MonitorExitStmt) {
            int slot = ((Integer) localSlot.get(((MonitorExitStmt) s).slotVar)).intValue();
            loadSlot(slot, T.refType("java.lang.Object"));
            emit(MONITOREXIT); pop(1);
            return;
        }
        if (s instanceof ThisCallStmt) {
            throw new CompileError("this(...) must be the first statement of a constructor", s.line);
        }

        throw new CompileError("unsupported statement", s.line);
    }

    /**
     * try/catch/finally. Catch handlers are straightforward (real JVM exception
     * table entries). "finally" is approximated: every path that completes the
     * try block or a catch block normally (falls through) converges on one
     * shared copy of the finally code at the end of the construct, so it runs
     * exactly once per normal exit; a catch-all(Throwable) handler wraps the
     * whole construct to run finally once more and re-throw for the
     * exception-escapes path. This covers the common cleanup-on-the-way-out
     * pattern (closing streams/connections) but does NOT re-run the finally
     * block for an early return/break/continue taken from inside the try or a
     * catch body, and does not run finally for an exception thrown from
     * inside a catch body itself (the catch-all only wraps the try block) --
     * those jump/throw straight out.
     */
    // ---------------- enhanced for / synchronized ----------------

    private NameExpr nm(String n, int line) { NameExpr e = new NameExpr(); e.name = n; e.line = line; return e; }

    private VarDeclStmt vd(int type, String name, Expr init, int line) {
        VarDeclStmt v = new VarDeclStmt(); v.type = type; v.name = name; v.init = init; v.line = line; return v;
    }

    /** for (T v : array) / for (T v : vector) is rewritten to an indexed for loop. */
    private void genForEach(ForEachStmt fe) throws CompileError {
        int line = fe.line;
        int it = typeOf(fe.iterable);
        int n = hiddenCounter++;
        String arr = "$fe" + n, idx = "$fi" + n;
        ForStmt fs = new ForStmt();
        fs.line = line;
        BlockStmt init = new BlockStmt();
        init.line = line; init.noScope = true;
        BlockStmt inner = new BlockStmt();
        inner.line = line;
        BinaryExpr cond = new BinaryExpr();
        cond.op = "<"; cond.line = line; cond.left = nm(idx, line);
        if (T.isArray(it)) {
            init.stmts.addElement(vd(it, arr, fe.iterable, line));
            init.stmts.addElement(vd(T.INT, idx, intLit(0, line), line));
            ChainFieldExpr len = new ChainFieldExpr();
            len.line = line; len.target = nm(arr, line); len.name = "length";
            cond.right = len;
            ArrayAccessExpr el = new ArrayAccessExpr();
            el.line = line; el.array = nm(arr, line); el.index = nm(idx, line);
            VarDeclStmt v = vd(fe.varType, fe.varName, el, line);
            v.isFinal = fe.isFinal;
            inner.stmts.addElement(v);
        } else if (T.isRef(it) && it != T.NULLT && !T.isArray(it)
                && isAssignableClassAny(isSelfType(it) ? cls.name : T.className(it), "java.util.Vector")) {
            init.stmts.addElement(vd(it, arr, fe.iterable, line));
            init.stmts.addElement(vd(T.INT, idx, intLit(0, line), line));
            ChainCallExpr size = new ChainCallExpr();
            size.line = line; size.target = nm(arr, line); size.name = "size";
            cond.right = size;
            ChainCallExpr get = new ChainCallExpr();
            get.line = line; get.target = nm(arr, line); get.name = "elementAt"; get.args.addElement(nm(idx, line));
            Expr val = get;
            if (!T.isRef(fe.varType)) throw new CompileError("cannot iterate a Vector with a primitive loop variable ('" + fe.varName + "'); use an Integer/Long... and unbox it explicitly", line);
            if (fe.varType != T.refType("java.lang.Object")) {
                CastExpr ce = new CastExpr();
                ce.line = line; ce.targetFqcn = T.className(fe.varType); ce.operand = get;
                val = ce;
            }
            VarDeclStmt v = vd(fe.varType, fe.varName, val, line);
            v.isFinal = fe.isFinal;
            inner.stmts.addElement(v);
        } else {
            throw new CompileError("'for (x : y)' needs an array or a java.util.Vector (found " + T.name(it) + ")", line);
        }
        inner.stmts.addElement(fe.body);
        fs.init = init;
        fs.cond = cond;
        IncDecExpr inc = new IncDecExpr();
        inc.line = line; inc.name = idx; inc.op = "++"; inc.prefix = false;
        ExprStmt us = new ExprStmt(); us.line = line; us.expr = inc;
        fs.update = us;
        fs.body = inner;
        genStmt(fs);
    }

    private IntLit intLit(int v, int line) { IntLit l = new IntLit(); l.value = v; l.line = line; return l; }

    private void genSync(SyncStmt ss) throws CompileError {
        int t = genExpr(ss.lock);
        if (!T.isRef(t) || t == T.NULLT) throw new CompileError("'synchronized' needs an object", ss.line);
        String hidden = "$lock" + (hiddenCounter++);
        int slot = allocTempSlot();
        int objT = T.refType("java.lang.Object");
        localSlot.put(hidden, new Integer(slot));
        localType.put(hidden, new Integer(objT));
        storeSlot(slot, objT);
        loadSlot(slot, objT);
        emit(MONITORENTER); pop(1);
        TryStmt ts = new TryStmt();
        ts.line = ss.line;
        ts.tryBlock = ss.body;
        BlockStmt fin = new BlockStmt();
        fin.line = ss.line;
        MonitorExitStmt me = new MonitorExitStmt();
        me.line = ss.line; me.slotVar = hidden;
        fin.stmts.addElement(me);
        ts.finallyBlock = fin;
        genTry(ts);
        localSlot.remove(hidden); localType.remove(hidden);
    }

    private static class TryFrame {
        BlockStmt fin;          // finally block or null
        int loopDepth;          // loopStack.size() when the try started
        Vector gaps = new Vector(); // int[]{startPc,endPc}: inlined finally copies that must NOT be protected
    }

    private boolean needsUnwind(int minLoopDepth) {
        for (int i = tryStack.size() - 1; i >= 0; i--) {
            TryFrame f = (TryFrame) tryStack.elementAt(i);
            if (f.loopDepth < minLoopDepth) break;
            if (f.fin != null) return true;
        }
        return false;
    }

    /** Inlines (innermost first) the finally blocks of every try that an early return / break /
     *  continue leaves. minLoopDepth: only tries opened at loop depth >= it are left by the jump. */
    private void emitUnwind(int minLoopDepth) throws CompileError {
        int top = tryStack.size();
        for (int i = top - 1; i >= 0; i--) {
            TryFrame f = (TryFrame) tryStack.elementAt(i);
            if (f.loopDepth < minLoopDepth) break;
            if (f.fin == null) continue;
            Vector saved = new Vector();
            for (int k = i; k < top; k++) saved.addElement(tryStack.elementAt(k));
            tryStack.setSize(i);       // code inside this copy must not unwind itself again
            int a = code.pc();
            genBlock(f.fin);
            int b = code.pc();
            for (int k = 0; k < saved.size(); k++) {
                ((TryFrame) saved.elementAt(k)).gaps.addElement(new int[]{a, b});
                tryStack.addElement(saved.elementAt(k));
            }
        }
    }

    /** exception-table entries for [s,e) minus the frame's gaps. */
    private void addRanges(int s, int e, Vector gaps, int handler, int type) {
        Vector g = new Vector();
        for (int i = 0; i < gaps.size(); i++) {
            int[] x = (int[]) gaps.elementAt(i);
            int k = g.size();
            while (k > 0 && ((int[]) g.elementAt(k - 1))[0] > x[0]) k--;
            g.insertElementAt(x, k);
        }
        int cur = s;
        for (int i = 0; i < g.size(); i++) {
            int[] x = (int[]) g.elementAt(i);
            if (x[1] <= cur || x[0] >= e) continue;
            if (x[0] > cur) exceptionTable.addElement(new int[]{cur, x[0], handler, type});
            if (x[1] > cur) cur = x[1];
        }
        if (cur < e) exceptionTable.addElement(new int[]{cur, e, handler, type});
    }

    /**
     * try/catch/finally. The finally block is inlined: at the normal end of the try and of every
     * catch, in a catch-all handler (exception escaping the try block OR a catch body: run finally,
     * rethrow), and before every return / break / continue that leaves the try (see emitUnwind).
     * Inlined copies are excluded from the ranges the try's own handlers protect.
     */
    private void genTry(TryStmt ts) throws CompileError {
        TryFrame fr = new TryFrame();
        fr.fin = ts.finallyBlock;
        fr.loopDepth = loopStack.size();
        tryStack.addElement(fr);

        int startPc = code.pc();
        genBlock(ts.tryBlock);
        int tryEndPc = code.pc();

        Vector endJumps = new Vector();
        int j0 = emitJumpPlaceholder(GOTO);
        endJumps.addElement(new Integer(j0));

        Vector pending = new Vector();    // int[]{handlerPc, catchType} per catch clause
        Vector bodyRanges = new Vector(); // int[]{start,end} of each catch body (for the catch-all)
        for (int i = 0; i < ts.catches.size(); i++) {
            CatchClause cc = (CatchClause) ts.catches.elementAt(i);
            int handlerPc = code.pc();
            int catchType = cp.classInfo(internalNameFor(cc.exFqcn));
            pending.addElement(new int[]{handlerPc, catchType});

            int exType = T.refType(cc.exFqcn);
            int slot = allocTempSlot();
            push(1); // the JVM pushes the exception ref on entry to the handler
            localSlot.put(cc.varName, new Integer(slot));
            localType.put(cc.varName, new Integer(exType));
            storeSlot(slot, exType);

            genBlock(cc.body);

            localSlot.remove(cc.varName);
            localType.remove(cc.varName);

            bodyRanges.addElement(new int[]{handlerPc, code.pc()});
            int j = emitJumpPlaceholder(GOTO);
            endJumps.addElement(new Integer(j));
        }
        tryStack.removeElementAt(tryStack.size() - 1);

        for (int i = 0; i < pending.size(); i++) {
            int[] pd = (int[]) pending.elementAt(i);
            addRanges(startPc, tryEndPc, fr.gaps, pd[0], pd[1]);
        }

        if (ts.finallyBlock != null) {
            // catch-all handler: run finally, then rethrow
            int handlerPc = code.pc();
            addRanges(startPc, tryEndPc, fr.gaps, handlerPc, 0);
            for (int i = 0; i < bodyRanges.size(); i++) {
                int[] br = (int[]) bodyRanges.elementAt(i);
                addRanges(br[0], br[1], fr.gaps, handlerPc, 0);
            }
            int slot = allocTempSlot();
            push(1);
            storeSlot(slot, T.refType("java.lang.Throwable"));
            genBlock(ts.finallyBlock);
            loadSlot(slot, T.refType("java.lang.Throwable"));
            emit(ATHROW); pop(1);
        }

        for (int i = 0; i < endJumps.size(); i++) {
            patchJumpHere(((Integer) endJumps.elementAt(i)).intValue());
        }
        if (ts.finallyBlock != null) {
            genBlock(ts.finallyBlock); // normal fall-through path also runs the finally block
        }
    }

    /**
     * switch (selector) { case V1: ...; case V2: ...; default: ...; }
     *
     * Compiled as a straight-line chain of "load selector; push V; if_icmpeq -> caseStart"
     * comparisons (a lookupswitch/tableswitch opcode would be more compact, but this
     * reuses the same jump-placeholder machinery as every other branch in this file
     * instead of hand-building a padded, pc-aligned jump table). Falls through from
     * one case's statements into the next's exactly like real bytecode for a switch
     * would, since case bodies are simply emitted back-to-back in source order --
     * this is also how "case 1: case 2: foo(); break;" (two labels, one shared body)
     * works: the first case's statement list is empty, so its comparison jumps to a
     * pc that immediately precedes the second case's code.
     */
    private void genSwitch(SwitchStmt sw) throws CompileError {
        sw.selector = unb(sw.selector);
        int st = genExpr(sw.selector);
        String enumCls = null;
        if (T.isRef(st) && st != T.NULLT && !T.isArray(st)) {
            String sc = T.className(st);
            ClassNode en = locals != null ? locals.get(sc) : null;
            if (en != null && en.isEnum) {
                // switch over an enum: select on ordinal()
                enumCls = sc;
                emit(INVOKEVIRTUAL); code.u2(cp.methodref(internalNameFor(sc), "ordinal", "()I"));
                st = T.INT; // pops the reference, pushes the int: net stack unchanged
            }
        }
        if (st != T.INT) throw new CompileError("switch selector must be an int (or char) or an enum", sw.line);
        int selSlot = allocTempSlot();
        storeSlot(selSlot, T.INT);

        int nCases = sw.cases.size();
        Vector[] labelJumps = new Vector[nCases]; // per-case list of Integer placeholder positions
        int defaultIndex = -1;
        Hashtable seenValues = new Hashtable(); // Integer value -> Boolean.TRUE, duplicate-label check
        for (int i = 0; i < nCases; i++) {
            SwitchCase sc = (SwitchCase) sw.cases.elementAt(i);
            labelJumps[i] = new Vector();
            if (sc.isDefault) {
                if (defaultIndex != -1) throw new CompileError("duplicate 'default' label in switch", sw.line);
                defaultIndex = i;
                continue;
            }
            for (int k = 0; k < sc.values.size(); k++) {
                Expr lab = (Expr) sc.values.elementAt(k);
                loadSlot(selSlot, T.INT);
                if (lab instanceof IntLit) {
                    Integer val = new Integer(((IntLit) lab).value);
                    if (seenValues.containsKey(val)) throw new CompileError("duplicate case label " + val, sw.line);
                    seenValues.put(val, Boolean.TRUE);
                    emitIntConst(val.intValue()); push(1);
                } else {
                    if (enumCls != null && lab instanceof NameExpr) {
                        // case RED:  ->  Color.RED.ordinal()
                        FieldAccessExpr cf = new FieldAccessExpr();
                        cf.line = lab.line; cf.qualifier = enumCls; cf.name = ((NameExpr) lab).name;
                        ChainCallExpr oc = new ChainCallExpr();
                        oc.line = lab.line; oc.target = cf; oc.name = "ordinal";
                        lab = oc;
                    }
                    // constant name / Canvas.FIRE / KEY + 1 ...: evaluated and compared at run time
                    int lt = genExpr(lab);
                    if (lt != T.INT) throw new CompileError("'case' label must be an int or char expression", lab.line);
                }
                int j = emitJumpPlaceholder(IF_ICMPEQ);
                pop(2);
                labelJumps[i].addElement(new Integer(j));
            }
        }
        // none of the case labels matched -- jump to 'default' if there is one, else past the switch
        int toDefaultOrEnd = emitJumpPlaceholder(GOTO);

        LoopFrame frame = new LoopFrame();
        frame.isSwitch = true;
        loopStack.addElement(frame);

        int defaultTargetPc = -1;
        for (int i = 0; i < nCases; i++) {
            SwitchCase sc = (SwitchCase) sw.cases.elementAt(i);
            int herePc = code.pc();
            for (int k = 0; k < labelJumps[i].size(); k++) {
                int pos = ((Integer) labelJumps[i].elementAt(k)).intValue();
                code.patchBranch(pos, pos - 1, herePc);
            }
            if (sc.isDefault) defaultTargetPc = herePc;
            for (int j2 = 0; j2 < sc.stmts.size(); j2++) {
                genStmt((Stmt) sc.stmts.elementAt(j2));
            }
        }
        int endPc = code.pc();
        code.patchBranch(toDefaultOrEnd, toDefaultOrEnd - 1, defaultIndex != -1 ? defaultTargetPc : endPc);

        loopStack.removeElementAt(loopStack.size() - 1);
        patchBreaks(frame);
    }

    private void genLabeled(LabeledStmt ls) throws CompileError {
        for (int i = 0; i < loopStack.size(); i++) {
            LoopFrame f = (LoopFrame) loopStack.elementAt(i);
            for (int k = 0; k < ls.labels.size(); k++) {
                if (f.hasLabel((String) ls.labels.elementAt(k)))
                    throw new CompileError("label '" + ls.labels.elementAt(k) + "' is already defined", ls.line);
            }
        }
        Stmt b = ls.body;
        boolean framed = b instanceof WhileStmt || b instanceof ForStmt || b instanceof DoWhileStmt
                || b instanceof ForEachStmt || b instanceof SwitchStmt;
        if (framed) {
            // the loop/switch creates its own LoopFrame and picks the labels up
            pendingLabels = ls.labels;
            try {
                genStmt(b);
            } finally {
                pendingLabels = null;
            }
            return;
        }
        // labeled block / if / expression statement: only 'break label' can leave it
        pendingLabels = ls.labels;
        LoopFrame frame = new LoopFrame();
        frame.isLabelBlock = true;
        loopStack.addElement(frame);
        genStmt(b);
        loopStack.removeElementAt(loopStack.size() - 1);
        patchBreaks(frame);
    }

    private void patchBreaks(LoopFrame frame) {
        int endPc = code.pc();
        for (int i = 0; i < frame.breakPatches.size(); i++) {
            int pos = ((Integer) frame.breakPatches.elementAt(i)).intValue();
            code.patchBranch(pos, pos - 1, endPc);
        }
    }

    private void patchContinues(LoopFrame frame, int targetPc) {
        for (int i = 0; i < frame.continuePatches.size(); i++) {
            int pos = ((Integer) frame.continuePatches.elementAt(i)).intValue();
            code.patchBranch(pos, pos - 1, targetPc);
        }
    }

    /** emits opcode + 2-byte placeholder offset; returns position of the offset bytes */
    private int emitJumpPlaceholder(int opcode) {
        emit(opcode);
        return code.reserveU2();
    }

    private void patchJumpHere(int offsetPos) {
        code.patchBranch(offsetPos, offsetPos - 1, code.pc());
    }

    private void emitGoto(int targetPc) {
        emit(GOTO);
        int pos = code.reserveU2();
        code.patchBranch(pos, pos - 1, targetPc);
    }

    private void storeSlot(int slot, int type) {
        int base, wide, shortBase;
        if (T.isRef(type)) { base = ASTORE; shortBase = ASTORE_0; }
        else if (type == T.LONG) { base = LSTORE; shortBase = LSTORE_0; }
        else if (type == T.FLOAT) { base = FSTORE; shortBase = FSTORE_0; }
        else if (type == T.DOUBLE) { base = DSTORE; shortBase = DSTORE_0; }
        else { base = ISTORE; shortBase = ISTORE_0; }
        if (slot <= 3) emit(shortBase + slot); else { emit(base); code.u1(slot); }
        pop(T.wordSize(type));
    }

    private void loadSlot(int slot, int type) {
        int base, shortBase;
        if (T.isRef(type)) { base = ALOAD; shortBase = ALOAD_0; }
        else if (type == T.LONG) { base = LLOAD; shortBase = LLOAD_0; }
        else if (type == T.FLOAT) { base = FLOAD; shortBase = FLOAD_0; }
        else if (type == T.DOUBLE) { base = DLOAD; shortBase = DLOAD_0; }
        else { base = ILOAD; shortBase = ILOAD_0; }
        if (slot <= 3) emit(shortBase + slot); else { emit(base); code.u1(slot); }
        push(T.wordSize(type));
    }

    /** allocates a fresh one-word local slot for compiler-internal temporaries (never reused/freed). */
    private int allocTempSlot() {
        return allocTempSlot(1);
    }

    /** allocates `words` (1 or 2) consecutive local slots for a temporary. */
    private int allocTempSlot(int words) {
        int slot = nextSlot;
        nextSlot += words;
        if (nextSlot > maxLocals) maxLocals = nextSlot;
        return slot;
    }


    // ---------------- autoboxing / unboxing ----------------
    // Boxing uses the wrapper constructors (CLDC 1.1 has no Integer.valueOf(int)); unboxing uses xxxValue().

    /** {fqcn, primitive descriptor, unbox method} per wrapper class. */
    private static final String[][] BOX = {
        {"java.lang.Integer", "I", "intValue"}, {"java.lang.Short", "S", "shortValue"},
        {"java.lang.Byte", "B", "byteValue"}, {"java.lang.Character", "C", "charValue"},
        {"java.lang.Long", "J", "longValue"}, {"java.lang.Float", "F", "floatValue"},
        {"java.lang.Double", "D", "doubleValue"}, {"java.lang.Boolean", "Z", "booleanValue"}
    };
    private boolean lastCharTyped; // the expression most recently generated is of type char

    /** index into BOX if `t` is a wrapper class type, else -1. */
    private int boxIndex(int t) {
        if (!T.isRef(t) || t == T.NULLT || T.isArray(t)) return -1;
        String n = T.className(t);
        if (n == null) return -1;
        for (int i = 0; i < BOX.length; i++) if (BOX[i][0].equals(n)) return i;
        return -1;
    }

    private static int boxPrim(int idx) {
        char d = BOX[idx][1].charAt(0);
        if (d == 'J') return T.LONG;
        if (d == 'F') return T.FLOAT;
        if (d == 'D') return T.DOUBLE;
        if (d == 'Z') return T.BOOLEAN;
        return T.INT;
    }

    /** natural wrapper for a primitive of type `prim` (char-ness distinguishes Character from Integer). */
    private static int boxIdxForPrim(int prim, boolean isChar) {
        if (prim == T.INT) return isChar ? 3 : 0;
        if (prim == T.LONG) return 4;
        if (prim == T.FLOAT) return 5;
        if (prim == T.DOUBLE) return 6;
        if (prim == T.BOOLEAN) return 7;
        return -1;
    }

    /** [..., wrapper] -> [..., prim]; returns the primitive type. */
    private int emitUnbox(int idx) {
        String cn = BOX[idx][0].replace('.', '/');
        int mi = cp.methodref(cn, BOX[idx][2], "()" + BOX[idx][1]);
        emit(INVOKEVIRTUAL); code.u2(mi);
        int prim = boxPrim(idx);
        pop(1); push(T.wordSize(prim));
        return prim;
    }

    /** [..., prim] -> [..., wrapper]  (new W(v), done on the stack without a temp local). */
    private void emitBox(int idx) {
        int prim = boxPrim(idx);
        String cn = BOX[idx][0].replace('.', '/');
        int ci = cp.classInfo(cn);
        int mi = cp.methodref(cn, "<init>", "(" + BOX[idx][1] + ")V");
        emit(NEW); code.u2(ci); push(1);               // [v, W]
        if (T.wordSize(prim) == 1) {
            emit(DUP_X1); push(1);                      // [W, v, W]
            emit(SWAP);                                 // [W, W, v]
        } else {
            emit(DUP_X2); push(1);                      // [W, v, W]
            emit(DUP_X2); push(1);                      // [W, W, v, W]
            emit(POP); pop(1);                          // [W, W, v]
        }
        emit(INVOKESPECIAL); code.u2(mi);
        pop(T.wordSize(prim) + 1);                      // [W]
    }

    /** Wraps `e` in an UnboxExpr when its static type is a wrapper class. */
    private Expr unb(Expr e) throws CompileError {
        if (e instanceof UnboxExpr) return e;
        if (boxIndex(typeOf(e)) < 0) return e;
        UnboxExpr u = new UnboxExpr();
        u.line = e.line; u.operand = e;
        return u;
    }

    /** Boxing conversion of the primitive on top of the stack to reference type `target`; false if not possible. */
    private boolean tryBox(int target, int value, int line) throws CompileError {
        if (target == T.NULLT || T.isArray(target)) return false;
        String tn = isSelfType(target) ? cls.name : T.className(target);
        if (tn == null) return false;
        int ti = boxIndex(target);
        if (ti >= 0) {
            int pt = boxPrim(ti);
            if (value == pt) { emitBox(ti); return true; }
            return false;
        }
        int ni = boxIdxForPrim(value, lastCharTyped);
        if (ni < 0 || !isAssignableFqcn(BOX[ni][0], tn)) return false;
        emitBox(ni);
        return true;
    }

    /** Unboxing conversion of the wrapper on top of the stack to primitive `target`; false if not possible. */
    private boolean tryUnbox(int target, int value, int line) throws CompileError {
        int vi = boxIndex(value);
        if (vi >= 0) {
            int u = boxPrim(vi);
            if (u != target && !T.widen(u, target)) return false;
            emitUnbox(vi);
            if (u != target) emitConv(u, target);
            return true;
        }
        if (genericPending && value == T.refType("java.lang.Object")) {
            // value typed by a generic type variable (Vector<Integer>.elementAt): cast to the wrapper, then unbox
            int ni = boxIdxForPrim(target, false);
            if (ni < 0) return false;
            emit(CHECKCAST); code.u2(cp.classInfo(BOX[ni][0].replace('.', '/')));
            emitUnbox(ni);
            genericPending = false;
            return true;
        }
        return false;
    }

    private void checkAssignable(int target, int value, int line, String what) throws CompileError {
        if (target == value) return;
        if (T.isRef(target) && value == T.NULLT) return;
        if (T.isPrimitive(target) && T.isPrimitive(value) && T.widen(value, target)) return; // implicit widening
        if (T.isRef(target) && T.isRef(value) && value != T.NULLT) {
            String vFqcn = isSelfType(value) ? cls.name : T.className(value);
            String tFqcn = isSelfType(target) ? cls.name : T.className(target);
            if (vFqcn != null && tFqcn != null && isAssignableFqcn(vFqcn, tFqcn)) return;
        }
        String hint = null;
        if ((T.isPrimitive(target) && T.isRef(value)) || (T.isRef(target) && T.isPrimitive(value))) {
            hint = "boxing only converts between a primitive and its own wrapper class (e.g. int <-> Integer, "
                 + "long <-> Long); write '4L' for a Long or cast explicitly";
        } else if (T.isNumeric(target) && T.isNumeric(value)) {
            hint = "narrowing needs an explicit cast, e.g. (" + T.name(target) + ") value";
        }
        throw new CompileError("cannot assign " + T.name(value) + " to " + T.name(target) + " ('" + what + "')", line, hint);
    }

    /** checkAssignable + the conversion opcode for an implicit primitive widening.
     *  The value of type `value` is already on top of the stack. Same-type and
     *  reference assignments emit nothing, so all pre-1.4 code is byte-for-byte unchanged. */
    private void coerce(int target, int value, int line, String what) throws CompileError {
        if (genericPending && T.isRef(target) && !T.isArray(target) && value == T.refType("java.lang.Object")
                && target != value && target != T.NULLT) {
            // generic erasure: the value came from a method declared to return a type variable
            int ci = cp.classInfo(internalNameFor(isSelfType(target) ? cls.name : T.className(target)));
            emit(CHECKCAST); code.u2(ci);
            genericPending = false;
            return;
        }
        if (T.isRef(target) && T.isPrimitive(value) && value != T.VOID) {
            if (tryBox(target, value, line)) return;
        } else if (T.isPrimitive(target) && T.isRef(value) && value != T.NULLT) {
            if (tryUnbox(target, value, line)) return;
        }
        checkAssignable(target, value, line, what);
        if (target != value && T.isNumeric(target) && T.isNumeric(value)) emitConv(value, target);
    }

    /** Emits the JVM conversion opcode between two numeric types (widening OR narrowing)
     *  and fixes up the stack accounting. INT here also covers byte/short/char. */
    private void emitConv(int from, int to) {
        if (from == to) return;
        int op;
        switch (from) {
            case T.INT:    op = (to == T.LONG) ? I2L : (to == T.FLOAT) ? I2F : I2D; break;
            case T.LONG:   op = (to == T.INT) ? L2I : (to == T.FLOAT) ? L2F : L2D; break;
            case T.FLOAT:  op = (to == T.INT) ? F2I : (to == T.LONG) ? F2L : F2D; break;
            default:       op = (to == T.INT) ? D2I : (to == T.LONG) ? D2L : D2F; break; // DOUBLE
        }
        emit(op);
        pop(T.wordSize(from));
        push(T.wordSize(to));
    }

    /** Binary numeric promotion (JLS 5.6.2) for two numeric operand types. */
    private static int promote(int a, int b) {
        if (a == T.DOUBLE || b == T.DOUBLE) return T.DOUBLE;
        if (a == T.FLOAT || b == T.FLOAT) return T.FLOAT;
        if (a == T.LONG || b == T.LONG) return T.LONG;
        return T.INT;
    }

    /** 0..3 offset of the L/F/D variant of an I-opcode: INT=0, LONG=1, FLOAT=2, DOUBLE=3. */
    private static int kindOffset(int t) {
        return t == T.LONG ? 1 : t == T.FLOAT ? 2 : t == T.DOUBLE ? 3 : 0;
    }

    /** DUP for a value of the given type (DUP or DUP2); accounts for the extra words. */
    private void emitDup(int type) {
        int ws = T.wordSize(type);
        emit(ws == 2 ? DUP2 : DUP);
        push(ws);
    }

    /** Evaluates `e` and converts the result to the numeric type `to` (widening only). */
    private int genExprAs(Expr e, int to) throws CompileError {
        int t = genExpr(e);
        if (t != to && T.isNumeric(t) && T.isNumeric(to)) emitConv(t, to);
        return to;
    }

    /** Type of an expression WITHOUT emitting it (dry run, cached on the node).
     *  Needed for binary numeric promotion: the left operand must be converted
     *  right after it is emitted, i.e. before the right operand's type is known
     *  from actually generating it. Literals and plain locals skip the dry run. */
    private int typeOf(Expr e) throws CompileError {
        if (e.typed) return e.resolvedType;
        if (e instanceof IntLit) { e.charTyped = ((IntLit) e).isChar; return T.INT; }
        if (e instanceof LongLit) return T.LONG;
        if (e instanceof FloatLit) return T.FLOAT;
        if (e instanceof DoubleLit) return T.DOUBLE;
        if (e instanceof BoolLit) return T.BOOLEAN;
        if (e instanceof StrLit) return T.STRING;
        if (e instanceof NameExpr && localType.containsKey(((NameExpr) e).name)) {
            e.charTyped = localChar.containsKey(((NameExpr) e).name);
            return ((Integer) localType.get(((NameExpr) e).name)).intValue();
        }
        CodeBuffer savedCode = code;
        int savedStack = curStack, savedMax = maxStack;
        int savedNextSlot = nextSlot, savedMaxLocals = maxLocals;
        code = new CodeBuffer();
        try {
            return genExpr(e); // genExpr caches the type on the node
        } finally {
            code = savedCode;
            curStack = savedStack; maxStack = savedMax;
            nextSlot = savedNextSlot; maxLocals = savedMaxLocals;
        }
    }

    /** true if a value of class `sub` may be used where `sup` is expected. */
    private boolean isAssignableFqcn(String sub, String sup) {
        if (sub.equals(sup) || "java.lang.Object".equals(sup)) return true;
        if (sub.equals(cls.name)) {
            if (cls.superName.equals(sup)) return true;
            if (cls.interfaces.contains(sup)) return true;
            if (isAssignableClassAny(cls.superName, sup)) return true;
            for (int i = 0; i < cls.interfaces.size(); i++) {
                if (isAssignableClassAny((String) cls.interfaces.elementAt(i), sup)) return true;
            }
            return false;
        }
        return isAssignableClassAny(sub, sup);
    }
    // ---------------- expressions ----------------
    // returns the resolved type of the pushed value (T.* constant), or -1 for 'null'

    private int genExpr(Expr e) throws CompileError {
        lastCallChar = false;
        int t = genExpr0(e);
        e.resolvedType = t;
        e.typed = true;
        e.charTyped = computeCharTyped(e, t);
        lastCharTyped = e.charTyped;
        if (!(e instanceof CallExpr || e instanceof ChainCallExpr || e instanceof FieldAccessExpr || e instanceof ChainFieldExpr)) genericPending = false;
        return t;
    }

    private boolean computeCharTyped(Expr e, int t) {
        if (t != T.INT) return false;
        if (e instanceof IntLit) return ((IntLit) e).isChar;
        if (e instanceof CastExpr) return ((CastExpr) e).primitiveCast && "C".equals(((CastExpr) e).targetDesc);
        if (e instanceof NameExpr) {
            String n = ((NameExpr) e).name;
            if (localSlot.containsKey(n)) return localChar.containsKey(n);
            FieldNode f = findField(n);
            return f != null && f.charTyped;
        }
        if (e instanceof FieldAccessExpr) {
            FieldAccessExpr fa = (FieldAccessExpr) e;
            if (fa.qualifier.equals("this")) { FieldNode f = findField(fa.name); return f != null && f.charTyped; }
            return false;
        }
        if (e instanceof ArrayAccessExpr) {
            ArrayAccessExpr ae = (ArrayAccessExpr) e;
            return ae.array.typed && T.isArray(ae.array.resolvedType) && "C".equals(T.arrayElemDesc(ae.array.resolvedType));
        }
        if (e instanceof CondExpr) return ((CondExpr) e).a.charTyped && ((CondExpr) e).b.charTyped;
        if (e instanceof UnboxExpr) { int ot = ((UnboxExpr) e).operand.resolvedType; return boxIndex(ot) == 3; }
        if (e instanceof CallExpr || e instanceof ChainCallExpr) return lastCallChar;
        return false;
    }

    private int genExpr0(Expr e) throws CompileError {
        if (e instanceof LongLit) {
            emitLongConst(((LongLit) e).value);
            push(2);
            return T.LONG;
        }
        if (e instanceof FloatLit) {
            emitFloatConst(((FloatLit) e).value);
            push(1);
            return T.FLOAT;
        }
        if (e instanceof DoubleLit) {
            emitDoubleConst(((DoubleLit) e).value);
            push(2);
            return T.DOUBLE;
        }
        if (e instanceof IntLit) {
            int v = ((IntLit) e).value;
            emitIntConst(v);
            push(1);
            return T.INT;
        }
        if (e instanceof BoolLit) {
            emit(((BoolLit) e).value ? ICONST_1 : ICONST_0);
            push(1);
            return T.BOOLEAN;
        }
        if (e instanceof StrLit) {
            String v = ((StrLit) e).value;
            int idx = cp.stringConst(v);
            ldc(idx);
            push(1);
            return T.STRING;
        }
        if (e instanceof NullLit) {
            emit(ACONST_NULL);
            push(1);
            return T.NULLT;
        }
        if (e instanceof UnboxExpr) {
            int ot = genExpr(((UnboxExpr) e).operand);
            int bi = boxIndex(ot);
            if (bi < 0) throw new CompileError("cannot unbox " + T.name(ot), e.line);
            return emitUnbox(bi);
        }
        if (e instanceof ThisExpr) {
            if (curMethod != null && curMethod.isStatic) throw new CompileError("'this' is not available in a static context", e.line);
            emit(ALOAD_0); push(1);
            return selfType;
        }
        if (e instanceof NameExpr) {
            return genNameLoad(((NameExpr) e).name, e.line);
        }
        if (e instanceof FieldAccessExpr) {
            return genFieldAccess((FieldAccessExpr) e);
        }
        if (e instanceof NewExpr) {
            return genNew((NewExpr) e);
        }
        if (e instanceof AssignExpr) {
            return genAssign((AssignExpr) e);
        }
        if (e instanceof IncDecExpr) {
            return genIncDec((IncDecExpr) e);
        }
        if (e instanceof UnaryExpr) {
            return genUnary((UnaryExpr) e);
        }
        if (e instanceof BinaryExpr) {
            return genBinary((BinaryExpr) e);
        }
        if (e instanceof CallExpr) {
            return genCall((CallExpr) e);
        }
        if (e instanceof NewArrayExpr) {
            return genNewArray((NewArrayExpr) e);
        }
        if (e instanceof ArrayAccessExpr) {
            return genArrayAccess((ArrayAccessExpr) e);
        }
        if (e instanceof ArrayAssignExpr) {
            return genArrayAssign((ArrayAssignExpr) e);
        }
        if (e instanceof CastExpr) {
            return genCast((CastExpr) e);
        }
        if (e instanceof InstanceOfExpr) {
            return genInstanceOf((InstanceOfExpr) e);
        }
        if (e instanceof OuterThisExpr) return genOuterInstance(((OuterThisExpr) e).className, e.line);
        if (e instanceof DefaultValueExpr) { genDefaultValue(((DefaultValueExpr) e).type); return ((DefaultValueExpr) e).type; }
        if (e instanceof ChainCallExpr) return genChainCall((ChainCallExpr) e);
        if (e instanceof ChainFieldExpr) return genChainField((ChainFieldExpr) e);
        if (e instanceof FieldAssignExpr) return genFieldAssign((FieldAssignExpr) e);
        if (e instanceof CondExpr) return genCond((CondExpr) e);
        if (e instanceof ArrayInitExpr) return genArrayInit((ArrayInitExpr) e);
        throw new CompileError("unsupported expression", e.line);
    }

    /** operand instanceof TargetType -- pops the reference, pushes boolean 0/1. */
    private int genInstanceOf(InstanceOfExpr ie) throws CompileError {
        int ot = genExpr(ie.operand);
        if (!T.isRef(ot)) throw new CompileError("'instanceof' requires a reference-type operand", ie.line);
        int classIdx = cp.classInfo(internalNameFor(ie.targetFqcn));
        emit(INSTANCEOF); code.u2(classIdx); // net 0: pops the ref, pushes a boolean
        return T.BOOLEAN;
    }

    /** (TargetType) operand -- reference cast: evaluates the operand, emits CHECKCAST
     *  against the target class, and re-types the expression as the target (the operand
     *  must already be a reference). Primitive cast ((int) f, (long) i, (byte) x ...):
     *  converts between any two numeric types with the JVM conversion opcodes; narrowing
     *  to byte/short/char goes through int and then I2B/I2S/I2C, matching javac
     *  ((byte) someDouble == D2I then I2B). */
    private int genCast(CastExpr e) throws CompileError {
        if (e.primitiveCast) {
            e.operand = unb(e.operand);
            int ot = genExpr(e.operand);
            if (!T.isNumeric(ot)) {
                throw new CompileError("cannot cast " + T.name(ot) + " to " + T.name(e.targetType), e.line);
            }
            int via = e.targetType; // INT for byte/short/char
            emitConv(ot, via);
            char d = e.targetDesc.charAt(0);
            if (d == 'B') emit(I2B);
            else if (d == 'S') emit(I2S);
            else if (d == 'C') emit(I2C);
            return e.targetType;
        }
        int operandType = genExpr(e.operand);
        if (!T.isRef(operandType)) {
            // (Integer) 5, (Object) 5: boxing cast
            if (T.isPrimitive(operandType) && tryBox(T.refType(e.targetFqcn), operandType, e.line)) return T.refType(e.targetFqcn);
            throw new CompileError("cannot cast a primitive value to " + e.targetFqcn, e.line);
        }
        int classIdx = cp.classInfo(internalNameFor(e.targetFqcn));
        emit(CHECKCAST); code.u2(classIdx); // net 0: pops+pushes the same reference
        return T.refType(e.targetFqcn);
    }

    private int genNewArray(NewArrayExpr n) throws CompileError {
        if (n.extraDims != null && n.extraDims.size() > 0) {
            // new T[a][b][]... -> multianewarray with every given dimension size
            int dims = 1 + n.extraDims.size();
            if (genExpr(n.size) != T.INT) throw new CompileError("array size must be an int", n.line);
            for (int i = 0; i < n.extraDims.size(); i++) {
                if (genExpr((Expr) n.extraDims.elementAt(i)) != T.INT) throw new CompileError("array size must be an int", n.line);
            }
            StringBuffer d = new StringBuffer();
            for (int i = 0; i < dims; i++) d.append('[');
            d.append(n.elemDesc);
            int classIdx = cp.classInfo(d.toString());
            emit(MULTIANEWARRAY); code.u2(classIdx); code.u1(dims);
            pop(dims); push(1);
            return T.refType(d.toString());
        }
        n.size = unb(n.size);
        int st = genExpr(n.size);
        if (st != T.INT) throw new CompileError("array size must be an int", n.line);
        String elemDesc = n.elemDesc;
        if (elemDesc.equals("I")) { emit(NEWARRAY); code.u1(T_INT); }
        else if (elemDesc.equals("Z")) { emit(NEWARRAY); code.u1(T_BOOLEAN); }
        else if (elemDesc.equals("B")) { emit(NEWARRAY); code.u1(8 /* T_BYTE */); }
        else if (elemDesc.equals("C")) { emit(NEWARRAY); code.u1(T_CHAR); }
        else if (elemDesc.equals("S")) { emit(NEWARRAY); code.u1(T_SHORT); }
        else if (elemDesc.equals("J")) { emit(NEWARRAY); code.u1(T_LONG); }
        else if (elemDesc.equals("F")) { emit(NEWARRAY); code.u1(T_FLOAT); }
        else if (elemDesc.equals("D")) { emit(NEWARRAY); code.u1(T_DOUBLE); }
        else {
            String cname = elemDesc.startsWith("L") ? elemDesc.substring(1, elemDesc.length() - 1) : elemDesc;
            int classIdx = cp.classInfo(cname);
            emit(ANEWARRAY); code.u2(classIdx);
        }
        return T.refType("[" + elemDesc);
    }

    private int elemLoadOpcodeFor(String elemDesc) throws CompileError {
        if (elemDesc.equals("I")) return IALOAD;
        if (elemDesc.equals("Z") || elemDesc.equals("B")) return BALOAD;
        if (elemDesc.equals("C")) return CALOAD;
        if (elemDesc.equals("S")) return SALOAD;
        if (elemDesc.equals("J")) return LALOAD;
        if (elemDesc.equals("F")) return FALOAD;
        if (elemDesc.equals("D")) return DALOAD;
        if (elemDesc.startsWith("L") || elemDesc.startsWith("[")) return AALOAD;
        throw new CompileError("unsupported array element type", 0);
    }

    private int elemStoreOpcodeFor(String elemDesc) throws CompileError {
        if (elemDesc.equals("I")) return IASTORE;
        if (elemDesc.equals("Z") || elemDesc.equals("B")) return BASTORE;
        if (elemDesc.equals("C")) return CASTORE;
        if (elemDesc.equals("S")) return SASTORE;
        if (elemDesc.equals("J")) return LASTORE;
        if (elemDesc.equals("F")) return FASTORE;
        if (elemDesc.equals("D")) return DASTORE;
        if (elemDesc.startsWith("L") || elemDesc.startsWith("[")) return AASTORE;
        throw new CompileError("unsupported array element type", 0);
    }

    private int genArrayAccess(ArrayAccessExpr ae) throws CompileError {
        int at = genExpr(ae.array);
        if (!T.isArray(at)) throw new CompileError("'[' applied to a non-array value", ae.line);
        ae.index = unb(ae.index);
        int it = genExpr(ae.index);
        if (it != T.INT) throw new CompileError("array index must be an int", ae.line);
        String elemDesc = T.arrayElemDesc(at);
        emit(elemLoadOpcodeFor(elemDesc));
        int et = jvmDescToType(elemDesc);
        pop(2); push(T.wordSize(et)); // arrayref+index(2 words) -> value(1 or 2 words)
        return et;
    }

    private int genArrayAssign(ArrayAssignExpr aa) throws CompileError {
        if (!aa.op.equals("=")) {
            int at0 = typeOf(aa.array);
            if (T.isArray(at0) && boxIndex(jvmDescToType(T.arrayElemDesc(at0))) >= 0) {
                if (!isPureLvalue(aa.array) || !isPureLvalue(aa.index)) throw new CompileError("compound assignment on a boxed array element through a complex expression is not supported", aa.line, "write it as 'a[i] = a[i] + ...'");
                ArrayAccessExpr cur = new ArrayAccessExpr();
                cur.line = aa.line; cur.array = aa.array; cur.index = aa.index;
                ArrayAssignExpr na = new ArrayAssignExpr();
                na.line = aa.line; na.op = "="; na.array = aa.array; na.index = aa.index;
                na.value = binExpr(aa.op.substring(0, aa.op.length() - 1), cur, aa.value, aa.line);
                return genArrayAssign(na);
            }
        }
        int at = genExpr(aa.array);
        if (!T.isArray(at)) throw new CompileError("'[' applied to a non-array value", aa.line);
        aa.index = unb(aa.index);
        int it = genExpr(aa.index);
        if (it != T.INT) throw new CompileError("array index must be an int", aa.line);
        String elemDesc = T.arrayElemDesc(at);
        int elemType = jvmDescToType(elemDesc);
        if (aa.op.equals("=")) {
            int vt = genExpr(aa.value);
            coerce(elemType, vt, aa.line, "array element");
        } else {
            int cws = T.wordSize(elemType);
            emit(DUP2); push(2);                                      // [arr, idx, arr, idx]
            emit(elemLoadOpcodeFor(elemDesc)); pop(2); push(cws);     // [arr, idx, cur]
            genCompoundOp(elemType, aa.op, aa.value, aa.line);        // [arr, idx, new]
            narrowForDesc(elemDesc);
        }
        // stack: [arrayref, index, value] -> dup_x2 -> [value, arrayref, index, value]
        // (a 2-word value needs dup2_x2: value2 = the 2 category-1 words arrayref,index)
        int ews = T.wordSize(elemType);
        emit(ews == 2 ? DUP2_X2 : DUP_X2); push(ews);
        emit(elemStoreOpcodeFor(elemDesc));
        pop(2 + ews); // consumes arrayref,index,value; the dup'd copy remains as the expression's result
        return elemType;
    }

    private void emitIntConst(int v) {
        if (v >= -1 && v <= 5) {
            emit(ICONST_M1 + (v + 1));
        } else if (v >= -128 && v <= 127) {
            emit(BIPUSH); code.u1(v & 0xFF);
        } else if (v >= -32768 && v <= 32767) {
            emit(SIPUSH); code.u2(v & 0xFFFF);
        } else {
            int idx = cp.integerConst(v);
            ldc(idx);
        }
    }

    private void emitLongConst(long v) {
        if (v == 0L) emit(LCONST_0);
        else if (v == 1L) emit(LCONST_1);
        else { emit(LDC2_W); code.u2(cp.longConst(v)); }
    }

    private void emitFloatConst(float v) {
        int bits = Float.floatToIntBits(v);
        if (bits == Float.floatToIntBits(0.0f)) emit(FCONST_0);      // +0.0 only: -0.0 has different bits
        else if (v == 1.0f) emit(FCONST_1);
        else if (v == 2.0f) emit(FCONST_2);
        else ldc(cp.floatConst(v));
    }

    private void emitDoubleConst(double v) {
        long bits = Double.doubleToLongBits(v);
        if (bits == Double.doubleToLongBits(0.0d)) emit(DCONST_0);   // +0.0 only
        else if (v == 1.0d) emit(DCONST_1);
        else { emit(LDC2_W); code.u2(cp.doubleConst(v)); }
    }

    private void ldc(int cpIndex) {
        if (cpIndex <= 255) {
            emit(LDC); code.u1(cpIndex);
        } else {
            emit(LDC_W); code.u2(cpIndex);
        }
    }

    private int genNameLoad(String name, int line) throws CompileError {
        if (localSlot.containsKey(name)) {
            int slot = ((Integer) localSlot.get(name)).intValue();
            int type = ((Integer) localType.get(name)).intValue();
            loadSlot(slot, type);
            return type;
        }
        FieldNode f = findField(name);
        if (f != null) {
            return genFieldLoad(f, line);
        }
        // not declared directly on this class -- maybe inherited from a
        // superclass (local or platform API) via an implicit "this."
        if (curMethod == null || !curMethod.isStatic) {
            ApiIndex.FieldFound ff = findFieldAny(cls.superName, name);
            if (ff != null) {
                emit(ALOAD_0); push(1);
                return genApiFieldRead(cls.superName, name, line);
            }
        }
        // constants of implemented interfaces, used without a qualifier
        for (int i = 0; i < cls.interfaces.size(); i++) {
            String in = (String) cls.interfaces.elementAt(i);
            ApiIndex.FieldFound ff = findFieldAny(in, name);
            if (ff != null && (ff.field.flags & ApiIndex.FLAG_STATIC) != 0) return genApiStaticFieldRead(in, name, line);
        }
        ApiIndex.FieldFound sf = findStaticImportedField(name);
        if (sf != null) return genApiStaticFieldRead(sf.declaringClass, name, line);
        Expr outer = outerFieldExpr(name, line);
        if (outer != null) return genExpr(outer);
        throw new CompileError("undefined name '" + name + "'", line);
    }

    // ---------------- nested / inner / anonymous classes ----------------

    private boolean inStaticMethod() { return curMethod != null && curMethod.isStatic; }

    /** expression for the enclosing instance of this class (this.this$0, or the ctor parameter of that name). */
    private Expr thisOuterRef(int line) {
        if (localSlot.containsKey("this$0")) return nm("this$0", line);
        FieldAccessExpr fa = new FieldAccessExpr();
        fa.line = line; fa.qualifier = "this"; fa.name = "this$0";
        return fa;
    }

    /** An unqualified name that is not a local / own / inherited field: look in the enclosing classes
     *  (static fields, instance fields through this$0, and variables captured by anonymous classes). */
    private Expr outerFieldExpr(String name, int line) {
        if (locals == null) return null;
        boolean inst = !inStaticMethod();
        if (inst && findField("val$" + name) != null) {
            FieldAccessExpr fa = new FieldAccessExpr();
            fa.line = line; fa.qualifier = "this"; fa.name = "val$" + name;
            return fa;
        }
        ClassNode c = cls;
        Expr path = null;
        while (c.outerName != null) {
            ClassNode o = locals.get(c.outerName);
            if (o == null) break;
            boolean instNext = inst && c.hasOuterThis;
            if (instNext) {
                if (path == null) path = thisOuterRef(line);
                else { ChainFieldExpr cf = new ChainFieldExpr(); cf.line = line; cf.target = path; cf.name = "this$0"; path = cf; }
            }
            inst = instNext;
            ApiIndex.FieldFound ff = findFieldAny(o.name, name);
            if (ff != null && (ff.field.flags & ApiIndex.FLAG_STATIC) != 0) {
                FieldAccessExpr fa = new FieldAccessExpr();
                fa.line = line; fa.qualifier = o.name; fa.name = name;
                return fa;
            }
            if (ff != null && inst) {
                ChainFieldExpr cf = new ChainFieldExpr();
                cf.line = line; cf.target = path; cf.name = name;
                return cf;
            }
            if (inst) {
                for (int i = 0; i < o.fields.size(); i++) {
                    if (((FieldNode) o.fields.elementAt(i)).name.equals("val$" + name)) {
                        ChainFieldExpr cf = new ChainFieldExpr();
                        cf.line = line; cf.target = path; cf.name = "val$" + name;
                        return cf;
                    }
                }
            }
            c = o;
        }
        return null;
    }

    /** An unqualified call that is not a method of this class: a method of an enclosing class. */
    private Expr outerCallExpr(CallExpr call) {
        if (locals == null) return null;
        boolean inst = !inStaticMethod();
        ClassNode c = cls;
        Expr path = null;
        while (c.outerName != null) {
            ClassNode o = locals.get(c.outerName);
            if (o == null) break;
            boolean instNext = inst && c.hasOuterThis;
            if (instNext) {
                if (path == null) path = thisOuterRef(call.line);
                else { ChainFieldExpr cf = new ChainFieldExpr(); cf.line = call.line; cf.target = path; cf.name = "this$0"; path = cf; }
            }
            inst = instNext;
            Vector cands = findAllMethodsAny(o.name, call.name, call.args.size());
            if (cands.size() > 0) {
                boolean allStatic = true;
                for (int i = 0; i < cands.size(); i++) {
                    ApiIndex.Found f = (ApiIndex.Found) cands.elementAt(i);
                    if ((f.method.flags & ApiIndex.FLAG_STATIC) == 0) allStatic = false;
                }
                if (allStatic) {
                    CallExpr cc = new CallExpr();
                    cc.line = call.line; cc.qualifier = o.name; cc.name = call.name; cc.args = call.args;
                    return cc;
                }
                if (inst) {
                    ChainCallExpr cc = new ChainCallExpr();
                    cc.line = call.line; cc.target = path; cc.name = call.name; cc.args = call.args;
                    return cc;
                }
                return null;
            }
            c = o;
        }
        return null;
    }

    /** pushes the instance of enclosing class `target` reachable from `this` (this itself, or via this$0 links). */
    private int genOuterInstance(String target, int line) throws CompileError {
        if (inStaticMethod()) throw new CompileError("no enclosing instance of " + target + " is available in a static context", line);
        emit(ALOAD_0); push(1);
        ClassNode c = cls;
        while (!(c.name.equals(target) || locals.isAssignableClass(c.name, target))) {
            if (!c.hasOuterThis || c.outerName == null) throw new CompileError("no enclosing instance of " + target + " is available here", line);
            emit(GETFIELD); code.u2(cp.fieldref(internalNameFor(c.name), "this$0", desc(T.refType(c.outerName))));
            c = locals.get(c.outerName);
            if (c == null) throw new CompileError("no enclosing instance of " + target + " is available here", line);
        }
        return T.refType(c.name.equals(cls.name) ? c.name : c.name);
    }

    /** completes an anonymous class's constructor once the argument types of its 'new' are known. */
    private void finalizeAnon(ClassNode a, Vector userArgs, int line) throws CompileError {
        if (a.anonFinalized) return;
        a.anonFinalized = true;
        MethodNode ctor = null;
        for (int i = 0; i < a.methods.size(); i++) {
            MethodNode m = (MethodNode) a.methods.elementAt(i);
            if (m.isConstructor) ctor = m;
        }
        int at = a.hasOuterThis ? 1 : 0;
        if (userArgs.size() > 0) {
            // an inner/capturing superclass has hidden ctor params around the user's: match with
            // typed placeholders for them, then keep only the user-visible parameter descriptors
            ClassNode sup = locals != null ? locals.get(a.superName) : null;
            Vector matchArgs = userArgs;
            int lead = 0, trail = 0;
            if (sup != null && (sup.hasOuterThis || sup.capturedNames.size() > 0)) {
                matchArgs = new Vector();
                if (sup.hasOuterThis) { lead = 1; matchArgs.addElement(new DefaultValueExpr(T.refType(sup.outerName))); }
                for (int i = 0; i < userArgs.size(); i++) matchArgs.addElement(userArgs.elementAt(i));
                for (int i = 0; i < sup.capturedNames.size(); i++) { trail++; matchArgs.addElement(new DefaultValueExpr(typeOfCaptured(sup, i))); }
            }
            Vector cands = findAllConstructorsAny(a.superName, matchArgs.size());
            if (cands.size() == 0) throw new CompileError("no constructor of " + a.superName + " takes " + userArgs.size() + " argument(s)", line);
            ApiIndex.Found found = pickOverload(cands, matchArgs, line);
            Vector pds = ApiIndex.splitParamDescriptors(found.ctor.paramDesc);
            for (int i = 0; i < lead; i++) pds.removeElementAt(0);
            for (int i = 0; i < trail; i++) pds.removeElementAt(pds.size() - 1);
            SuperCallStmt sc = new SuperCallStmt();
            sc.line = line;
            for (int i = 0; i < pds.size(); i++) {
                ParamNode p = new ParamNode();
                p.name = "$a" + i;
                p.type = jvmDescToType((String) pds.elementAt(i));
                ctor.params.insertElementAt(p, at + i);
                sc.args.addElement(nm(p.name, line));
            }
            ctor.body.stmts.insertElementAt(sc, 0);
        }
    }

    private void genDefaultValue(int type) {
        if (type == T.LONG) { emit(LCONST_0); push(2); }
        else if (type == T.FLOAT) { emit(FCONST_0); push(1); }
        else if (type == T.DOUBLE) { emit(DCONST_0); push(2); }
        else if (T.isRef(type)) { emit(ACONST_NULL); push(1); }
        else { emit(ICONST_0); push(1); }
    }

    /** `new X(args)` for inner (needs the enclosing instance first) and anonymous classes
     *  (outer instance, then the super-constructor args, then the captured variables). */
    private NewExpr rewriteNestedNew(NewExpr n) throws CompileError {
        ClassNode tn = locals != null ? locals.get(n.className) : null;
        if (tn == null || !(tn.isAnon || tn.hasOuterThis || tn.capturedNames.size() > 0)) return n;
        if (tn.isAnon) finalizeAnon(tn, n.args, n.line);
        NewExpr r = new NewExpr();
        r.line = n.line; r.className = n.className;
        if (tn.hasOuterThis) {
            if (tn.isAnon && inStaticMethod()) throw new CompileError("anonymous class created in a static context cannot have an enclosing instance", n.line);
            if (n.outerInstance != null) r.args.addElement(n.outerInstance);
            else {
                OuterThisExpr ot = new OuterThisExpr();
                ot.line = n.line; ot.className = tn.outerName;
                r.args.addElement(ot);
            }
        }
        for (int i = 0; i < n.args.size(); i++) r.args.addElement(n.args.elementAt(i));
        for (int i = 0; i < tn.capturedNames.size(); i++) {
            String cn = (String) tn.capturedNames.elementAt(i);
            if (localSlot.containsKey(cn) || outerFieldExpr(cn, n.line) != null) r.args.addElement(nm(cn, n.line));
            else {
                NullLit dflt = new NullLit(); dflt.line = n.line; // placeholder; replaced by a typed default below
                r.args.addElement(new DefaultValueExpr(typeOfCaptured(tn, i)));
            }
        }
        return r;
    }

    private int typeOfCaptured(ClassNode a, int i) {
        String fname = "val$" + a.capturedNames.elementAt(i);
        for (int k = 0; k < a.fields.size(); k++) {
            FieldNode f = (FieldNode) a.fields.elementAt(k);
            if (f.name.equals(fname)) return f.type;
        }
        return T.INT;
    }

    private int genFieldLoad(FieldNode f, int line) throws CompileError {
        if (f.isStatic) {
            int idx = cp.fieldref(internalClassName, f.name, desc(f.type));
            emit(GETSTATIC); code.u2(idx);
            push(T.wordSize(f.type));
        } else {
            if (curMethod != null && curMethod.isStatic) throw new CompileError("cannot access instance field '" + f.name + "' from a static method", line);
            emit(ALOAD_0); push(1);
            int idx = cp.fieldref(internalClassName, f.name, desc(f.type));
            emit(GETFIELD); code.u2(idx);
            // stack: -1 (obj) + wordSize(value): net 0 for 1-word fields, +1 for long/double
            push(T.wordSize(f.type) - 1);
        }
        return f.type;
    }

    /** true if `qualifier` names an in-scope instance value (this / local var / own field,
     *  including a field inherited from a local or platform-API superclass). */
    private Integer typeOfNameIfInstance(String qualifier) {
        if (qualifier.equals("this")) return new Integer(selfType);
        if (localSlot.containsKey(qualifier)) return (Integer) localType.get(qualifier);
        FieldNode f = findField(qualifier);
        if (f != null) return new Integer(f.type);
        ApiIndex.FieldFound ff = findFieldAny(cls.superName, qualifier);
        if (ff != null) return new Integer(jvmDescToType(ff.field.desc));
        return null;
    }

    private int genFieldAccess(FieldAccessExpr fa) throws CompileError {
        if (fa.qualifier.indexOf('.') >= 0 && resolveSimpleClassName(fa.qualifier) == null) {
            // a.b.c : "a.b" is a value path, not a class name
            Expr q = qualifierToExpr(fa.qualifier, fa.line);
            if (q == null) throw new CompileError("unknown field access target '" + fa.qualifier + "'", fa.line);
            ChainFieldExpr cf = new ChainFieldExpr();
            cf.line = fa.line; cf.target = q; cf.name = fa.name;
            return genChainField(cf);
        }
        Integer instType = typeOfNameIfInstance(fa.qualifier);
        if (instType != null) {
            int t = instType.intValue();
            if (T.isArray(t) && fa.name.equals("length")) {
                genNameLoad(fa.qualifier, fa.line); // push array ref
                emit(ARRAYLENGTH); // net 0
                return T.INT;
            }
            if (isSelfType(t)) {
                FieldNode f = findField(fa.name);
                if (f != null) {
                    if (f.isStatic || fa.qualifier.equals("this")) return genFieldLoad(f, fa.line);
                    // "other.field" where other is ANOTHER instance of this same class: the
                    // receiver must be the qualifier, not an implicit `this` (genFieldLoad
                    // would silently read this.field -- and fail outright in a static method).
                    genNameLoad(fa.qualifier, fa.line);
                    int idx = cp.fieldref(internalClassName, f.name, desc(f.type));
                    emit(GETFIELD); code.u2(idx);
                    push(T.wordSize(f.type) - 1);
                    return f.type;
                }
            }
            genNameLoad(fa.qualifier, fa.line); // push receiver
            return genApiFieldRead(chainStartFor(t), fa.name, fa.line);
        }
        String fqcn = resolveSimpleClassName(fa.qualifier);
        if (fqcn == null) {
            Expr oq = outerFieldExpr(fa.qualifier, fa.line);
            if (oq != null) {
                ChainFieldExpr ocf = new ChainFieldExpr();
                ocf.line = fa.line; ocf.target = oq; ocf.name = fa.name;
                return genChainField(ocf);
            }
            throw new CompileError("unknown field access target '" + fa.qualifier + "'", fa.line);
        }
        return genApiStaticFieldRead(fqcn, fa.name, fa.line);
    }

    private int genApiFieldRead(String startFqcn, String name, int line) throws CompileError {
        ApiIndex.FieldFound ff = findFieldAny(startFqcn, name);
        if (ff == null) throw new CompileError("no field '" + name + "' found on " + startFqcn, line);
        int rt = jvmDescToType(ff.field.desc);
        if ((ff.field.flags & ApiIndex.FLAG_STATIC) != 0) {
            emit(POP); pop(1); // receiver already evaluated for side effects; static field doesn't need it
            int idx = cp.fieldref(internalNameFor(ff.declaringClass), name, ff.field.desc);
            emit(GETSTATIC); code.u2(idx); push(T.wordSize(rt));
        } else {
            int idx = cp.fieldref(internalNameFor(ff.declaringClass), name, ff.field.desc);
            emit(GETFIELD); code.u2(idx);
            // stack: -1 (objectref) + wordSize(rt) (value). GETFIELD on a
            // long/double field pushes 2 words, not the 1 the objectref
            // cost, so this is only a true net-0 for 1-word field types.
            push(T.wordSize(rt) - 1);
        }
        return rt;
    }

    private int genApiStaticFieldRead(String fqcn, String name, int line) throws CompileError {
        ApiIndex.FieldFound ff = findFieldAny(fqcn, name);
        if (ff == null) throw new CompileError("no field '" + name + "' found on " + fqcn, line);
        if ((ff.field.flags & ApiIndex.FLAG_STATIC) == 0) throw new CompileError("field '" + name + "' on " + fqcn + " is not static", line);
        int rt = jvmDescToType(ff.field.desc);
        int idx = cp.fieldref(internalNameFor(ff.declaringClass), name, ff.field.desc);
        emit(GETSTATIC); code.u2(idx); push(T.wordSize(rt));
        return rt;
    }

    /**
     * Parses a single JVM field/return descriptor into a T type code
     * (registering ref types as needed). J, D and F map to their own T codes
     * (LONG, DOUBLE, FLOAT); byte/short/char/int all map to T.INT. Getting
     * the word size right here is what keeps every push()/pop() and local
     * slot index correct -- an API method returning a long that was typed as
     * a 1-word int would silently corrupt the rest of the method.
     */
    private int jvmDescToType(String d) {
        if (d.equals("V")) return T.VOID;
        if (d.equals("I") || d.equals("S") || d.equals("B") || d.equals("C")) return T.INT;
        if (d.equals("F")) return T.FLOAT;
        if (d.equals("Z")) return T.BOOLEAN;
        if (d.equals("J")) return T.LONG;
        if (d.equals("D")) return T.DOUBLE;
        if (d.equals("Ljava/lang/String;")) return T.STRING;
        if (d.startsWith("[")) return T.refType(d); // arrays: stored as raw descriptor, see T.desc()
        if (d.startsWith("L") && d.endsWith(";")) {
            String dotted = d.substring(1, d.length() - 1).replace('/', '.');
            return T.refType(dotted);
        }
        return T.INT; // best-effort fallback for anything else unrecognized
    }

    /**
     * Total JVM stack words occupied by a call's arguments once genArgsRaw
     * has generated them: 2 per J/D parameter, 1 for everything else. (A
     * T.INT argument bound for a J/D parameter has been widened to 2 words by
     * then, so counting the DESCRIPTORS, not the argument expressions, is
     * what matches the stack.) Every pop() after a genArgsRaw call must use
     * this instead of paramDescs.size().
     */
    private int paramWordCount(Vector paramDescs) {
        int n = 0;
        for (int i = 0; i < paramDescs.size(); i++) {
            String pd = (String) paramDescs.elementAt(i);
            n += (pd.equals("J") || pd.equals("D")) ? 2 : 1;
        }
        return n;
    }

    /** Words occupied by a user method's parameters (ParamNode list). */
    private int paramWords(Vector params) {
        int n = 0;
        for (int i = 0; i < params.size(); i++) n += T.wordSize(((ParamNode) params.elementAt(i)).type);
        return n;
    }

    private int genNew(NewExpr n0) throws CompileError {
        NewExpr n = rewriteNestedNew(n0);
        if (isInterfaceAny(n.className)) {
            throw new CompileError("cannot instantiate interface " + n.className, n.line);
        }
        if (isAbstractAny(n.className)) {
            throw new CompileError("cannot instantiate abstract class " + n.className, n.line);
        }
        Vector ctorCands = findAllConstructorsAny(n.className, n.args.size());
        if (ctorCands.size() == 0) {
            throw new CompileError("no constructor found for " + n.className + " with " + n.args.size() + " argument(s) " +
                    "(check the class name/import and argument count)", n.line);
        }
        ApiIndex.Found found = pickOverload(ctorCands, n.args, n.line);
        int classIdx = cp.classInfo(internalNameFor(n.className));
        emit(NEW); code.u2(classIdx); push(1);
        emit(DUP); push(1);
        Vector paramDescs = ApiIndex.splitParamDescriptors(found.ctor.paramDesc);
        genArgsRaw(paramDescs, n.args, n.line);
        String mdesc = "(" + found.ctor.paramDesc + ")V";
        int idx = cp.methodref(internalNameFor(n.className), "<init>", mdesc);
        emit(INVOKESPECIAL); code.u2(idx);
        pop(paramWordCount(paramDescs) + 1);
        return T.refType(n.className);
    }

    static final int SWAP = 0x5f, DUP_X1 = 0x5a, DUP_X2 = 0x5b;

    private int genAssign(AssignExpr a) throws CompileError {
        String name = a.target;
        boolean isLocal = localSlot.containsKey(name);
        FieldNode f = isLocal ? null : findField(name);
        if (!isLocal && f == null) {
            // a field inherited from a superclass (assigned without "this.")
            if ((curMethod == null || !curMethod.isStatic) && findFieldAny(cls.superName, name) != null) {
                FieldAccessExpr lhs = new FieldAccessExpr();
                lhs.line = a.line; lhs.qualifier = "this"; lhs.name = name;
                FieldAssignExpr fa = new FieldAssignExpr();
                fa.line = a.line; fa.lhs = lhs; fa.op = a.op; fa.value = a.value;
                return genFieldAssign(fa);
            }
            Expr oe = outerFieldExpr(name, a.line);
            if (oe instanceof FieldAccessExpr || oe instanceof ChainFieldExpr) {
                FieldAssignExpr fa = new FieldAssignExpr();
                fa.line = a.line; fa.lhs = oe; fa.op = a.op; fa.value = a.value;
                return genFieldAssign(fa);
            }
            throw new CompileError("undefined name '" + name + "'", a.line);
        }
        if (isLocal && localFinal.containsKey(name)) {
            throw new CompileError("cannot assign a value to final variable '" + name + "'", a.line);
        }
        if (f != null && f.isFinal && !(curMethod != null && (curMethod.isConstructor || curMethod.name.equals("<clinit>")))) {
            throw new CompileError("cannot assign a value to final field '" + name + "'", a.line);
        }
        int targetType = isLocal ? ((Integer) localType.get(name)).intValue() : f.type;
        if (!a.op.equals("=") && boxIndex(targetType) >= 0) {
            // Integer i; i += 2  ->  i = i + 2   (unbox, operate, box)
            AssignExpr na = new AssignExpr();
            na.line = a.line; na.target = name; na.op = "=";
            na.value = binExpr(a.op.substring(0, a.op.length() - 1), nm(name, a.line), a.value, a.line);
            return genAssign(na);
        }
        boolean instanceField = (f != null && !f.isStatic);
        int tws = T.wordSize(targetType);

        if (instanceField && curMethod != null && curMethod.isStatic) {
            throw new CompileError("cannot access instance field '" + name + "' from a static method", a.line);
        }

        if (a.op.equals("=")) {
            if (instanceField) { emit(ALOAD_0); push(1); } // objectref first
            int vt = genExpr(a.value);
            coerce(targetType, vt, a.line, name);
        } else {
            if (instanceField) {
                emit(ALOAD_0); push(1);           // [obj]
                emit(DUP); push(1);                // [obj, obj]
                int idx = cp.fieldref(internalClassName, f.name, desc(f.type));
                emit(GETFIELD); code.u2(idx);       // [obj, curval]  (net 0 for 1-word, +1 for 2-word)
                push(tws - 1);
            } else if (f != null) {
                genFieldLoad(f, a.line);            // [curval]
            } else {
                genNameLoad(name, a.line);          // [curval]
            }
            genCompoundOp(targetType, a.op, a.value, a.line); // [newval]
        }

        // store, leaving the assigned value as the expression's result
        if (isLocal) {
            int slot = ((Integer) localSlot.get(name)).intValue();
            emitDup(targetType);
            storeSlot(slot, targetType);
        } else if (f.isStatic) {
            emitDup(targetType);
            int idx = cp.fieldref(internalClassName, f.name, desc(f.type));
            emit(PUTSTATIC); code.u2(idx); pop(tws);
        } else {
            // stack: [obj, value] -> dup_x1 -> [value, obj, value] -> putfield -> [value]
            // (2-word value: dup2_x1)
            emit(tws == 2 ? DUP2_X1 : DUP_X1); push(tws);
            int idx = cp.fieldref(internalClassName, f.name, desc(f.type));
            emit(PUTFIELD); code.u2(idx); pop(1 + tws);
        }
        return targetType;
    }

    /** Stack: [..., cur] (a value of type targetType)  ->  [..., new] for "cur OP= value".
     *  Numeric targets follow JLS 15.26.2 (the result is cast back to the target type);
     *  String supports "+=" only. */
    private void genCompoundOp(int targetType, String op, Expr value, int line) throws CompileError {
        if (targetType == T.STRING) {
            if (!op.equals("+=")) throw new CompileError("only '+=' is allowed on a String", line);
            int vt = genExpr(value);
            genStringConcat(T.STRING, vt, line, false, value.charTyped);
            return;
        }
        if (!T.isNumeric(targetType)) throw new CompileError("compound assignment only supported for numeric types and String '+='", line);
        value = unb(value); // "x += someInteger"
        String arithOp = op.substring(0, op.length() - 1); // strip trailing '=': "<<=" -> "<<", "+=" -> "+", etc.
        boolean isShift = arithOp.equals("<<") || arithOp.equals(">>") || arithOp.equals(">>>");
        boolean isBitwise = arithOp.equals("&") || arithOp.equals("|") || arithOp.equals("^");
        int vt = typeOf(value);
        if (!T.isNumeric(vt)) throw new CompileError("compound assignment requires a numeric operand", line);
        int p; // type the operation is performed in
        if (isShift) {
            if ((targetType != T.INT && targetType != T.LONG) || (vt != T.INT && vt != T.LONG)) {
                throw new CompileError("'" + arithOp + "' requires int or long operands", line);
            }
            p = targetType;
        } else {
            p = promote(targetType, vt);
            if (isBitwise && p != T.INT && p != T.LONG) throw new CompileError("'" + arithOp + "' requires int or long operands", line);
        }
        emitConv(targetType, p);                // no-op when the target already has the operation type
        if (isShift) {
            genExpr(value);
            if (vt == T.LONG) emitConv(T.LONG, T.INT); // shift distance is always an int
            emit(shiftOpcode(arithOp, p)); pop(1);
        } else {
            genExprAs(value, p);
            emitArithOpcode(arithOp, p, line);
        }
        emitConv(p, targetType);                // implicit narrowing cast back (e.g. int += double)
    }

    /** I2B / I2S / I2C when a field or array element has a sub-int descriptor, so that an
     *  updated value wraps like Java ("byte b = 127; b++" -> -128). */
    private void narrowForDesc(String d) {
        if (d.equals("B")) emit(I2B);
        else if (d.equals("S")) emit(I2S);
        else if (d.equals("C")) emit(I2C);
    }

    // ---------------- receivers that are arbitrary expressions ----------------

    private Expr nameOrThis(String n, int line) {
        if (n.equals("this")) { ThisExpr te = new ThisExpr(); te.line = line; return te; }
        NameExpr ne = new NameExpr(); ne.line = line; ne.name = n;
        return ne;
    }

    private static String[] splitDots(String q) {
        Vector v = new Vector();
        int st = 0;
        for (int i = 0; i <= q.length(); i++) {
            if (i == q.length() || q.charAt(i) == '.') { v.addElement(q.substring(st, i)); st = i + 1; }
        }
        String[] r = new String[v.size()];
        for (int i = 0; i < r.length; i++) r[i] = (String) v.elementAt(i);
        return r;
    }

    private static String joinDots(String[] parts, int from, int to) {
        StringBuffer sb = new StringBuffer();
        for (int i = from; i < to; i++) { if (i > from) sb.append('.'); sb.append(parts[i]); }
        return sb.toString();
    }

    /** "a.b.c" where a is a variable/field -> (a.b).c as an expression tree; "Cls.f.g" where Cls is a
     *  class -> Cls.f then .g. Returns null when the path is just a class name. */
    private Expr qualifierToExpr(String q, int line) {
        String[] parts = splitDots(q);
        Expr e;
        int next;
        Expr outerStart = typeOfNameIfInstance(parts[0]) == null && resolveSimpleClassName(parts[0]) == null ? outerFieldExpr(parts[0], line) : null;
        if (typeOfNameIfInstance(parts[0]) != null) {
            e = nameOrThis(parts[0], line);
            next = 1;
        } else if (outerStart != null) {
            e = outerStart;
            next = 1;
        } else {
            e = null; next = 0;
            for (int k = parts.length - 1; k >= 1; k--) { // longest class-name prefix
                String cn = joinDots(parts, 0, k);
                if (resolveSimpleClassName(cn) != null) {
                    FieldAccessExpr fa = new FieldAccessExpr();
                    fa.line = line; fa.qualifier = cn; fa.name = parts[k];
                    e = fa; next = k + 1;
                    break;
                }
            }
            if (e == null) return null;
        }
        for (int i = next; i < parts.length; i++) {
            ChainFieldExpr cf = new ChainFieldExpr();
            cf.line = line; cf.target = e; cf.name = parts[i];
            e = cf;
        }
        return e;
    }

    private void requireObjectReceiver(int t, String what, int line) throws CompileError {
        if (t == T.NULLT) throw new CompileError("cannot " + what + " on 'null'", line);
        if (!T.isRef(t)) throw new CompileError("cannot " + what + " on a " + T.name(t) + " value (it is not an object)", line);
    }

    /** receiver.method(args) for an arbitrary receiver expression. */
    private int genChainCall(ChainCallExpr cc) throws CompileError {
        cc.args = packVarargs(cc.name, cc.args, cc.line);
        int t = genExpr(cc.target); // receiver on the stack
        requireObjectReceiver(t, "call method '" + cc.name + "()'", cc.line);
        if (isSelfType(t)) {
            MethodNode m = pickOwnMethod(findOwnMethods(cc.name, cc.args.size()), cc.args, cc.line);
            if (m != null) {
                if (m.isStatic) { emit(POP); pop(1); }
                genArgsChecked(m.params, cc.args, cc.line);
                int idx = cp.methodref(internalClassName, m.name, methodDesc(m));
                if (m.isStatic) { emit(INVOKESTATIC); code.u2(idx); pop(paramWords(m.params)); }
                else { emit(INVOKEVIRTUAL); code.u2(idx); pop(paramWords(m.params) + 1); }
                if (m.returnType != T.VOID) push(T.wordSize(m.returnType));
                lastCallChar = m.returnsChar;
                genericPending = m.returnIsTypeVar;
                return m.returnType;
            }
        }
        String fq = T.isArray(t) ? "java.lang.Object" : chainStartFor(t);
        Vector cands = findAllMethodsAny(fq, cc.name, cc.args.size());
        if (cands.size() == 0) {
            if (!api.has(fq) && (locals == null || !locals.has(fq))) {
                throw new CompileError("unknown type '" + fq + "' -- is an 'import' for it missing? "
                        + "(needed to resolve the call to '" + cc.name + "')", cc.line);
            }
            throw new CompileError("no method '" + cc.name + "' with " + cc.args.size() + " argument(s) found on " + fq, cc.line);
        }
        ApiIndex.Found found = pickOverload(cands, cc.args, cc.line);
        return genFoundInstanceCall(found, cc.name, cc.args, cc.line);
    }

    /** receiver.field (read) for an arbitrary receiver expression; also array.length. */
    private int genChainField(ChainFieldExpr cf) throws CompileError {
        int t = genExpr(cf.target);
        if (T.isArray(t)) {
            if (cf.name.equals("length")) { emit(ARRAYLENGTH); return T.INT; }
            throw new CompileError("arrays only have the field 'length' (no field '" + cf.name + "')", cf.line);
        }
        requireObjectReceiver(t, "read field '" + cf.name + "'", cf.line);
        if (isSelfType(t)) {
            FieldNode f = findField(cf.name);
            if (f != null) {
                if (f.isStatic) { emit(POP); pop(1); return genFieldLoad(f, cf.line); }
                int idx = cp.fieldref(internalClassName, f.name, desc(f.type));
                emit(GETFIELD); code.u2(idx);
                push(T.wordSize(f.type) - 1);
                return f.type;
            }
        }
        return genApiFieldRead(chainStartFor(t), cf.name, cf.line);
    }

    // ---------------- field l-values: this.x = v, a.b.c += v, Cls.COUNT++ ----------------

    private static class FieldRef {
        String owner;   // internal class name
        String name;
        String desc;
        int type;
        boolean isStatic;
        boolean ownField; // declared in the class being compiled
        boolean isFinal;
    }

    /** Resolves the field named by lhs (FieldAccessExpr or ChainFieldExpr). For an instance field
     *  the receiver reference has been pushed when this returns; for a static field nothing is on the stack. */
    private FieldRef resolveFieldRef(Expr lhs, int line) throws CompileError {
        if (lhs instanceof ChainFieldExpr) {
            ChainFieldExpr cf = (ChainFieldExpr) lhs;
            int t = genExpr(cf.target);
            return finishFieldRef(t, cf.name, line);
        }
        FieldAccessExpr fa = (FieldAccessExpr) lhs;
        if (fa.qualifier.indexOf('.') >= 0 && resolveSimpleClassName(fa.qualifier) == null) {
            Expr q = qualifierToExpr(fa.qualifier, fa.line);
            if (q == null) throw new CompileError("unknown field access target '" + fa.qualifier + "'", fa.line);
            int t = genExpr(q);
            return finishFieldRef(t, fa.name, line);
        }
        if (typeOfNameIfInstance(fa.qualifier) != null) {
            int t = genExpr(nameOrThis(fa.qualifier, fa.line));
            return finishFieldRef(t, fa.name, line);
        }
        String fqcn = resolveSimpleClassName(fa.qualifier);
        if (fqcn == null) {
            Expr oq = outerFieldExpr(fa.qualifier, fa.line);
            if (oq != null) { int ot = genExpr(oq); return finishFieldRef(ot, fa.name, line); }
            throw new CompileError("unknown field access target '" + fa.qualifier + "'", fa.line);
        }
        FieldRef r = new FieldRef();
        if (fqcn.equals(cls.name)) {
            FieldNode f = findField(fa.name);
            if (f == null) throw new CompileError("no field '" + fa.name + "' found on " + fqcn, line);
            if (!f.isStatic) throw new CompileError("field '" + fa.name + "' is not static (use an instance, e.g. this." + fa.name + ")", line);
            r.owner = internalClassName; r.name = f.name; r.desc = desc(f.type); r.type = f.type;
            r.isStatic = true; r.ownField = true; r.isFinal = f.isFinal;
            return r;
        }
        ApiIndex.FieldFound ff = findFieldAny(fqcn, fa.name);
        if (ff == null) throw new CompileError("no field '" + fa.name + "' found on " + fqcn, line);
        if ((ff.field.flags & ApiIndex.FLAG_STATIC) == 0) throw new CompileError("field '" + fa.name + "' on " + fqcn + " is not static", line);
        r.owner = internalNameFor(ff.declaringClass); r.name = fa.name; r.desc = ff.field.desc;
        r.type = jvmDescToType(ff.field.desc); r.isStatic = true;
        return r;
    }

    /** receiver (type t) is on the stack. */
    private FieldRef finishFieldRef(int t, String name, int line) throws CompileError {
        if (T.isArray(t)) throw new CompileError("cannot assign to a field of an array ('" + name + "')", line);
        requireObjectReceiver(t, "access field '" + name + "'", line);
        FieldRef r = new FieldRef();
        if (isSelfType(t)) {
            FieldNode f = findField(name);
            if (f != null) {
                r.owner = internalClassName; r.name = f.name; r.desc = desc(f.type); r.type = f.type;
                r.isStatic = f.isStatic; r.ownField = true; r.isFinal = f.isFinal;
                if (r.isStatic) { emit(POP); pop(1); }
                return r;
            }
        }
        ApiIndex.FieldFound ff = findFieldAny(chainStartFor(t), name);
        if (ff == null) throw new CompileError("no field '" + name + "' found on " + chainStartFor(t), line);
        r.owner = internalNameFor(ff.declaringClass); r.name = name; r.desc = ff.field.desc;
        r.type = jvmDescToType(ff.field.desc);
        r.isStatic = (ff.field.flags & ApiIndex.FLAG_STATIC) != 0;
        if (r.isStatic) { emit(POP); pop(1); }
        return r;
    }

    private void checkFieldWritable(FieldRef r, int line) throws CompileError {
        if (r.isFinal && !(curMethod != null && (curMethod.isConstructor || curMethod.name.equals("<clinit>")))) {
            throw new CompileError("cannot assign a value to final field '" + r.name + "'", line);
        }
    }

    private int genFieldAssign(FieldAssignExpr fa) throws CompileError {
        FieldRef r = resolveFieldRef(fa.lhs, fa.line);
        checkFieldWritable(r, fa.line);
        if (!fa.op.equals("=") && boxIndex(r.type) >= 0) {
            if (!isPureLvalue(fa.lhs)) throw new CompileError("compound assignment on a boxed field through a complex expression is not supported", fa.line, "write it as 'x = x + ...'");
            FieldAssignExpr nf = new FieldAssignExpr();
            nf.line = fa.line; nf.lhs = fa.lhs; nf.op = "=";
            nf.value = binExpr(fa.op.substring(0, fa.op.length() - 1), fa.lhs, fa.value, fa.line);
            return genFieldAssign(nf);
        }
        int tws = T.wordSize(r.type);
        int fidx = cp.fieldref(r.owner, r.name, r.desc);
        if (fa.op.equals("=")) {
            int vt = genExpr(fa.value);
            coerce(r.type, vt, fa.line, r.name);
        } else {
            if (r.isStatic) {
                emit(GETSTATIC); code.u2(fidx); push(tws);                   // [cur]
            } else {
                emit(DUP); push(1);                                           // [obj, obj]
                emit(GETFIELD); code.u2(fidx); push(tws - 1);                 // [obj, cur]
            }
            genCompoundOp(r.type, fa.op, fa.value, fa.line);                  // [.., new]
            narrowForDesc(r.desc);
        }
        if (r.isStatic) {
            emitDup(r.type);
            emit(PUTSTATIC); code.u2(fidx); pop(tws);
        } else {
            emit(tws == 2 ? DUP2_X1 : DUP_X1); push(tws);
            emit(PUTFIELD); code.u2(fidx); pop(1 + tws);
        }
        return r.type;
    }

    /** obj.f++ / --obj.f / Cls.count++ */
    private int genFieldIncDec(Expr lhs, IncDecExpr id) throws CompileError {
        FieldRef r = resolveFieldRef(lhs, id.line);
        checkFieldWritable(r, id.line);
        if (!T.isNumeric(r.type)) throw new CompileError("++/-- only supported for numeric types", id.line);
        int ft = r.type, ws = T.wordSize(ft);
        int fidx = cp.fieldref(r.owner, r.name, r.desc);
        String arith = id.op.equals("++") ? "+" : "-";
        if (r.isStatic) {
            emit(GETSTATIC); code.u2(fidx); push(ws);                 // [old]
            if (!id.prefix) emitDup(ft);                              // post: [old, old]
            emitOne(ft); push(ws);
            emitArithOpcode(arith, ft, id.line);                      // [.., new]
            narrowForDesc(r.desc);
            if (id.prefix) emitDup(ft);                               // pre: [new, new]
            emit(PUTSTATIC); code.u2(fidx); pop(ws);
        } else {
            emit(DUP); push(1);                                       // [obj, obj]
            emit(GETFIELD); code.u2(fidx); push(ws - 1);              // [obj, old]
            if (!id.prefix) { emit(ws == 2 ? DUP2_X1 : DUP_X1); push(ws); } // post: [old, obj, old]
            emitOne(ft); push(ws);
            emitArithOpcode(arith, ft, id.line);                      // [.., obj, new]
            narrowForDesc(r.desc);
            if (id.prefix) { emit(ws == 2 ? DUP2_X1 : DUP_X1); push(ws); }  // pre: [new, obj, new]
            emit(PUTFIELD); code.u2(fidx); pop(1 + ws);               // leaves old (post) or new (pre)
        }
        return ft;
    }

    /** a[i]++ / --a[i] */
    private int genArrayIncDec(ArrayAccessExpr ae, IncDecExpr id) throws CompileError {
        int at = genExpr(ae.array);
        if (!T.isArray(at)) throw new CompileError("'[' applied to a non-array value", ae.line);
        ae.index = unb(ae.index);
        int it = genExpr(ae.index);
        if (it != T.INT) throw new CompileError("array index must be an int", ae.line);
        String elemDesc = T.arrayElemDesc(at);
        int et = jvmDescToType(elemDesc);
        if (!T.isNumeric(et)) throw new CompileError("++/-- only supported for numeric types", id.line);
        int ws = T.wordSize(et);
        emit(DUP2); push(2);                                           // [arr, idx, arr, idx]
        emit(elemLoadOpcodeFor(elemDesc)); pop(2); push(ws);           // [arr, idx, old]
        if (!id.prefix) { emit(ws == 2 ? DUP2_X2 : DUP_X2); push(ws); } // post: [old, arr, idx, old]
        emitOne(et); push(ws);
        emitArithOpcode(id.op.equals("++") ? "+" : "-", et, id.line);  // [.., new]
        narrowForDesc(elemDesc);
        if (id.prefix) { emit(ws == 2 ? DUP2_X2 : DUP_X2); push(ws); } // pre: [new, arr, idx, new]
        emit(elemStoreOpcodeFor(elemDesc)); pop(2 + ws);               // leaves old (post) or new (pre)
        return et;
    }

    // ---------------- cond ? a : b ----------------

    private boolean refAssignable(int target, int value) {
        try { checkAssignable(target, value, 0, "?:"); return true; }
        catch (CompileError e) { return false; }
    }

    private int genCond(CondExpr ce) throws CompileError {
        ce.cond = unb(ce.cond);
        int ct = genExpr(ce.cond);
        if (ct != T.BOOLEAN) throw new CompileError("the condition of '?:' must be boolean", ce.line);
        int jElse = emitJumpPlaceholder(IFEQ);
        pop(1);
        int ta = typeOf(ce.a), tb = typeOf(ce.b);
        if (ta != tb && ((boxIndex(ta) >= 0 && T.isPrimitive(tb)) || (boxIndex(tb) >= 0 && T.isPrimitive(ta)))) {
            // Integer vs int (JLS 15.25): the wrapper operand is unboxed
            ce.a = unb(ce.a); ce.b = unb(ce.b);
            ta = typeOf(ce.a); tb = typeOf(ce.b);
        }
        int rt;
        if (ta == tb) rt = ta;
        else if (T.isNumeric(ta) && T.isNumeric(tb)) rt = promote(ta, tb);
        else if (ta == T.NULLT && T.isRef(tb)) rt = tb;
        else if (tb == T.NULLT && T.isRef(ta)) rt = ta;
        else if ((T.isPrimitive(ta) && T.isRef(tb)) || (T.isRef(ta) && T.isPrimitive(tb))) {
            // primitive vs null / other reference: the primitive is boxed
            int prim = T.isPrimitive(ta) ? ta : tb, other = T.isPrimitive(ta) ? tb : ta;
            int bi = boxIdxForPrim(prim, (T.isPrimitive(ta) ? ce.a : ce.b).charTyped);
            if (bi < 0) throw new CompileError("incompatible operand types for '?:' (" + T.name(ta) + " and " + T.name(tb) + ")", ce.line);
            rt = other == T.NULLT ? T.refType(BOX[bi][0]) : T.refType("java.lang.Object");
        }
        else if (T.isRef(ta) && T.isRef(tb)) {
            if (refAssignable(ta, tb)) rt = ta;
            else if (refAssignable(tb, ta)) rt = tb;
            else rt = T.refType("java.lang.Object");
        } else {
            throw new CompileError("incompatible operand types for '?:' (" + T.name(ta) + " and " + T.name(tb) + ")", ce.line);
        }
        int base = curStack;
        int t1 = genExpr(ce.a);
        condBranchTo(rt, t1, ce.line);
        int jEnd = emitJumpPlaceholder(GOTO);
        curStack = base;
        patchJumpHere(jElse);
        int t2 = genExpr(ce.b);
        condBranchTo(rt, t2, ce.line);
        patchJumpHere(jEnd);
        return rt;
    }

    /** Brings a branch result of type t to the common type rt. For references a CHECKCAST gives both
     *  branches the identical static type, so the StackMap frame at the join point is exact. */
    private void condBranchTo(int rt, int t, int line) throws CompileError {
        if (T.isRef(rt)) {
            if (T.isPrimitive(t)) { coerce(rt, t, line, "?:"); return; }
            if (t != rt && rt != T.NULLT) {
                int ci = cp.classInfo(internalNameFor(isSelfType(rt) ? cls.name : T.className(rt)));
                emit(CHECKCAST); code.u2(ci);
            }
        } else {
            coerce(rt, t, line, "?:");
        }
    }

    // ---------------- {a, b, c} ----------------

    private int genArrayInit(ArrayInitExpr ai) throws CompileError {
        NewArrayExpr na = new NewArrayExpr();
        na.line = ai.line; na.elemDesc = ai.elemDesc;
        IntLit sz = new IntLit(); sz.line = ai.line; sz.value = ai.elems.size();
        na.size = sz;
        int at = genNewArray(na);       // [arr]
        push(1);
        int et = jvmDescToType(ai.elemDesc);
        int ews = T.wordSize(et);
        for (int i = 0; i < ai.elems.size(); i++) {
            emit(DUP); push(1);                       // [arr, arr]
            emitIntConst(i); push(1);                 // [arr, arr, i]
            Expr el = (Expr) ai.elems.elementAt(i);
            int vt = genExpr(el);
            coerce(et, vt, el.line, "array element");
            emit(elemStoreOpcodeFor(ai.elemDesc));
            pop(2 + ews);                             // [arr]
        }
        return at;
    }


    /** true if evaluating `e` twice has no side effects (so "x op= v" may be rewritten as "x = x op v"). */
    private boolean isPureLvalue(Expr e) {
        if (e instanceof NameExpr || e instanceof ThisExpr || e instanceof IntLit || e instanceof FieldAccessExpr) return true;
        if (e instanceof ChainFieldExpr) return isPureLvalue(((ChainFieldExpr) e).target);
        if (e instanceof ArrayAccessExpr) return isPureLvalue(((ArrayAccessExpr) e).array) && isPureLvalue(((ArrayAccessExpr) e).index);
        return false;
    }

    private BinaryExpr binExpr(String op, Expr l, Expr r, int line) {
        BinaryExpr b = new BinaryExpr();
        b.line = line; b.op = op; b.left = l; b.right = r;
        return b;
    }

    /** x++ / --x on an Integer/Long/... variable, field or array element:
     *  rewritten as an assignment "x = x + 1" (the postfix value is recovered by undoing the step). */
    private int genBoxedIncDec(IncDecExpr id) throws CompileError {
        String arith = id.op.equals("++") ? "+" : "-";
        Expr assign;
        if (id.target == null) {
            AssignExpr as = new AssignExpr();
            as.line = id.line; as.target = id.name; as.op = "=";
            as.value = binExpr(arith, nm(id.name, id.line), intLit(1, id.line), id.line);
            assign = as;
        } else {
            if (!isPureLvalue(id.target)) {
                throw new CompileError("'" + id.op + "' on a boxed value through a complex expression is not supported",
                        id.line, "write it as 'x = x " + arith + " 1'");
            }
            Expr value = binExpr(arith, id.target, intLit(1, id.line), id.line);
            if (id.target instanceof ArrayAccessExpr) {
                ArrayAssignExpr aa = new ArrayAssignExpr();
                aa.line = id.line; aa.op = "=";
                aa.array = ((ArrayAccessExpr) id.target).array; aa.index = ((ArrayAccessExpr) id.target).index; aa.value = value;
                assign = aa;
            } else {
                FieldAssignExpr fa = new FieldAssignExpr();
                fa.line = id.line; fa.lhs = id.target; fa.op = "="; fa.value = value;
                assign = fa;
            }
        }
        if (id.prefix) return genExpr(assign);
        return genExpr(binExpr(arith.equals("+") ? "-" : "+", assign, intLit(1, id.line), id.line));
    }

    private int genIncDec(IncDecExpr id) throws CompileError {
        {
            int bt = -1;
            if (id.target != null) bt = typeOf(id.target);
            else if (localSlot.containsKey(id.name)) bt = ((Integer) localType.get(id.name)).intValue();
            else { FieldNode bf = findField(id.name); if (bf != null) bt = bf.type; }
            if (boxIndex(bt) >= 0) return genBoxedIncDec(id);
        }
        if (id.target != null) {
            if (id.target instanceof ArrayAccessExpr) return genArrayIncDec((ArrayAccessExpr) id.target, id);
            return genFieldIncDec(id.target, id);
        }
        if (!localSlot.containsKey(id.name)) {
            FieldNode f = findField(id.name);
            if (f == null) {
                if ((curMethod == null || !curMethod.isStatic) && findFieldAny(cls.superName, id.name) != null) {
                    FieldAccessExpr lhs = new FieldAccessExpr();
                    lhs.line = id.line; lhs.qualifier = "this"; lhs.name = id.name;
                    return genFieldIncDec(lhs, id);
                }
                Expr oe = outerFieldExpr(id.name, id.line);
                if (oe instanceof FieldAccessExpr || oe instanceof ChainFieldExpr) return genFieldIncDec(oe, id);
                throw new CompileError("undefined name '" + id.name + "'", id.line);
            }
            if (!T.isNumeric(f.type)) throw new CompileError("++/-- only supported for numeric types", id.line);
            if (!f.isStatic) {
                if (curMethod != null && curMethod.isStatic) throw new CompileError("cannot access instance field '" + id.name + "' from a static method", id.line);
                FieldAccessExpr lhs = new FieldAccessExpr();
                lhs.line = id.line; lhs.qualifier = "this"; lhs.name = id.name;
                return genFieldIncDec(lhs, id);
            }
            if (f.isFinal && !(curMethod != null && curMethod.isConstructor)) {
                throw new CompileError("cannot assign a value to final field '" + id.name + "'", id.line);
            }
            int idx = cp.fieldref(internalClassName, f.name, desc(f.type));
            int ft = f.type;

            genFieldLoad(f, id.line);                 // [old]
            if (!id.prefix) emitDup(ft);              // post: [old, old]
            emitOne(ft); push(T.wordSize(ft));        // [..., old, 1]
            emitArithOpcode(id.op.equals("++") ? "+" : "-", ft, id.line); // [..., new]  (post: [old,new] / pre: [new])
            if (id.prefix) emitDup(ft);               // pre: [new, new]
            emit(PUTSTATIC); code.u2(idx); pop(T.wordSize(ft)); // consumes top 'new', leaves old (post) or new (pre)
            return ft;
        }
        if (localFinal.containsKey(id.name)) {
            throw new CompileError("cannot assign a value to final variable '" + id.name + "'", id.line);
        }
        int slot = ((Integer) localSlot.get(id.name)).intValue();
        int type = ((Integer) localType.get(id.name)).intValue();
        if (!T.isNumeric(type)) throw new CompileError("++/-- only supported for numeric types", id.line);
        if (type != T.INT) {
            // long/float/double have no IINC: load, (dup for post), +1, (dup for pre), store
            loadSlot(slot, type);                     // [old]
            if (!id.prefix) emitDup(type);            // post: [old, old]
            emitOne(type); push(T.wordSize(type));
            emitArithOpcode(id.op.equals("++") ? "+" : "-", type, id.line);
            if (id.prefix) emitDup(type);             // pre: [new, new]
            storeSlot(slot, type);                    // leaves old (post) or new (pre)
            return type;
        }
        if (!id.prefix) {
            loadSlot(slot, T.INT); // value to leave on stack (post value)
        }
        emit(IINC); code.u1(slot); code.u1(id.op.equals("++") ? 1 : -1);
        if (id.prefix) {
            loadSlot(slot, T.INT); // new value
        }
        return T.INT;
    }

    /** pushes the constant 1 of the given numeric type (caller does the push() accounting). */
    private void emitOne(int type) {
        if (type == T.LONG) emit(LCONST_1);
        else if (type == T.FLOAT) emit(FCONST_1);
        else if (type == T.DOUBLE) emit(DCONST_1);
        else emitIntConst(1);
    }

    private int genUnary(UnaryExpr u) throws CompileError {
        u.operand = unb(u.operand);
        if (u.op.equals("!")) {
            int t = genExpr(u.operand);
            if (t != T.BOOLEAN) throw new CompileError("'!' requires boolean operand", u.line);
            // XOR with 1: iconst_1, ixor  -- but IXOR not declared; use if/else pattern instead for portability
            int jf = emitJumpPlaceholder(IFEQ);
            pop(1);
            emit(ICONST_0); push(1);
            int jend = emitJumpPlaceholder(GOTO);
            patchJumpHere(jf);
            emit(ICONST_1); push(1);
            patchJumpHere(jend);
            return T.BOOLEAN;
        }
        if (u.op.equals("-")) {
            int t = genExpr(u.operand);
            if (!T.isNumeric(t)) throw new CompileError("unary '-' requires a numeric operand", u.line);
            emit(INEG + kindOffset(t)); // INEG/LNEG/FNEG/DNEG: same stack words in and out
            return t;
        }
        if (u.op.equals("+")) {
            int t = genExpr(u.operand);
            if (!T.isNumeric(t)) throw new CompileError("unary '+' requires a numeric operand", u.line);
            return t; // no instruction needed
        }
        if (u.op.equals("~")) {
            int t = genExpr(u.operand);
            if (t == T.INT) {
                emitIntConst(-1); push(1);
                emit(IXOR); pop(1);
                return T.INT;
            }
            if (t == T.LONG) {
                emitIntConst(-1); push(1);
                emit(I2L); push(1);
                emit(LXOR); pop(2);
                return T.LONG;
            }
            throw new CompileError("unary '~' requires an int or long operand", u.line);
        }
        throw new CompileError("unsupported unary operator '" + u.op + "'", u.line);
    }

    private int genBinary(BinaryExpr b) throws CompileError {
        String op = b.op;
        if (op.equals("&&") || op.equals("||")) {
            b.left = unb(b.left); b.right = unb(b.right);
            int lt = genExpr(b.left);
            if (lt != T.BOOLEAN) throw new CompileError("'" + op + "' requires boolean operands", b.line);
            if (op.equals("&&")) {
                int jf = emitJumpPlaceholder(IFEQ); pop(1);
                int rt = genExpr(b.right);
                if (rt != T.BOOLEAN) throw new CompileError("'&&' requires boolean operands", b.line);
                int jend = emitJumpPlaceholder(GOTO);
                patchJumpHere(jf);
                emit(ICONST_0); push(1);
                patchJumpHere(jend);
            } else {
                int jt = emitJumpPlaceholder(IFNE); pop(1);
                int rt = genExpr(b.right);
                if (rt != T.BOOLEAN) throw new CompileError("'||' requires boolean operands", b.line);
                int jend = emitJumpPlaceholder(GOTO);
                patchJumpHere(jt);
                emit(ICONST_1); push(1);
                patchJumpHere(jend);
            }
            return T.BOOLEAN;
        }

        // Operand types are needed BEFORE emission so the left operand can be converted
        // (binary numeric promotion) while it is still the top of the stack.
        int lt = typeOf(b.left);
        int rt = typeOf(b.right);
        if (boxIndex(lt) >= 0 || boxIndex(rt) >= 0) {
            boolean isEq = op.equals("==") || op.equals("!=");
            boolean isConcat = op.equals("+") && (lt == T.STRING || rt == T.STRING);
            // '==' between two wrappers compares references (as in Java); anything else unboxes
            if (!isConcat && (!isEq || T.isPrimitive(lt) || T.isPrimitive(rt))) {
                b.left = unb(b.left); b.right = unb(b.right);
                lt = typeOf(b.left); rt = typeOf(b.right);
            }
        }

        if (op.equals("+") && (lt == T.STRING || rt == T.STRING)) {
            genExpr(b.left);
            genExpr(b.right);
            return genStringConcat(lt, rt, b.line, b.left.charTyped, b.right.charTyped);
        }

        if (op.equals("+") || op.equals("-") || op.equals("*") || op.equals("/") || op.equals("%")) {
            if (!T.isNumeric(lt) || !T.isNumeric(rt)) throw new CompileError("'" + op + "' requires numeric operands", b.line);
            int p = promote(lt, rt);
            genExprAs(b.left, p);
            genExprAs(b.right, p);
            emitArithOpcode(op, p, b.line);
            return p;
        }

        if (op.equals("|") || op.equals("&") || op.equals("^")) {
            if ((lt != T.INT && lt != T.LONG) || (rt != T.INT && rt != T.LONG)) {
                throw new CompileError("'" + op + "' requires int or long operands", b.line);
            }
            int p = promote(lt, rt);
            genExprAs(b.left, p);
            genExprAs(b.right, p);
            emitArithOpcode(op, p, b.line);
            return p;
        }

        if (op.equals("<<") || op.equals(">>") || op.equals(">>>")) {
            // the result type is the (unary-promoted) LEFT operand; the distance is always an int
            if ((lt != T.INT && lt != T.LONG) || (rt != T.INT && rt != T.LONG)) {
                throw new CompileError("'" + op + "' requires int or long operands", b.line);
            }
            genExpr(b.left);
            genExpr(b.right);
            if (rt == T.LONG) emitConv(T.LONG, T.INT);
            emit(shiftOpcode(op, lt)); pop(1);
            return lt;
        }

        if (op.equals("==") || op.equals("!=")) {
            boolean refCompare = T.isRef(lt) || T.isRef(rt);
            if (refCompare) {
                genExpr(b.left);
                genExpr(b.right);
                emitCompareToBoolean(op.equals("==") ? IF_ACMPEQ : IF_ACMPNE);
                return T.BOOLEAN;
            }
            if (lt == T.BOOLEAN || rt == T.BOOLEAN) {
                if (lt != rt) throw new CompileError("cannot compare " + T.name(lt) + " and " + T.name(rt), b.line);
                genExpr(b.left);
                genExpr(b.right);
                emitCompareToBoolean(op.equals("==") ? IF_ICMPEQ : IF_ICMPNE);
                return T.BOOLEAN;
            }
            if (!T.isNumeric(lt) || !T.isNumeric(rt)) throw new CompileError("cannot compare " + T.name(lt) + " and " + T.name(rt), b.line);
            int p = promote(lt, rt);
            genExprAs(b.left, p);
            genExprAs(b.right, p);
            if (p == T.INT) {
                emitCompareToBoolean(op.equals("==") ? IF_ICMPEQ : IF_ICMPNE);
            } else {
                // NaN: fcmpl/dcmpl yield -1 for an unordered pair, so == is false and != is true, as Java requires
                emitWideCompareToBoolean(p, false, op.equals("==") ? IFEQ : IFNE);
            }
            return T.BOOLEAN;
        }

        if (op.equals("<") || op.equals("<=") || op.equals(">") || op.equals(">=")) {
            if (!T.isNumeric(lt) || !T.isNumeric(rt)) throw new CompileError("'" + op + "' requires numeric operands", b.line);
            int p = promote(lt, rt);
            genExprAs(b.left, p);
            genExprAs(b.right, p);
            if (p == T.INT) {
                int cmpOp = op.equals("<") ? IF_ICMPLT : op.equals("<=") ? IF_ICMPLE
                          : op.equals(">") ? IF_ICMPGT : IF_ICMPGE;
                emitCompareToBoolean(cmpOp);
            } else {
                int brOp = op.equals("<") ? IFLT : op.equals("<=") ? IFLE : op.equals(">") ? IFGT : IFGE;
                // NaN must make every ordered comparison false: for < and <= use the cmp*G
                // flavour (unordered -> +1), for > and >= the cmp*L flavour (unordered -> -1).
                boolean g = op.equals("<") || op.equals("<=");
                emitWideCompareToBoolean(p, g, brOp);
            }
            return T.BOOLEAN;
        }

        throw new CompileError("unsupported operator '" + op + "'", b.line);
    }

    /** [.., a, b] (both of numeric type p != INT) -> boolean 0/1.
     *  LCMP / FCMPx / DCMPx collapse the pair to one int, then a one-operand branch decides. */
    private void emitWideCompareToBoolean(int p, boolean nanGreater, int branchOpcode) {
        int cmp = (p == T.LONG) ? LCMP
                : (p == T.FLOAT) ? (nanGreater ? FCMPG : FCMPL)
                : (nanGreater ? DCMPG : DCMPL);
        emit(cmp);
        pop(2 * T.wordSize(p)); push(1);
        emit(branchOpcode);
        int posT = code.reserveU2();
        pop(1);
        emit(ICONST_0); push(1);
        int jend = emitJumpPlaceholder(GOTO);
        code.patchBranch(posT, posT - 1, code.pc());
        emit(ICONST_1); push(1);
        patchJumpHere(jend);
    }

    /**
     * Handles '+' where at least one operand is a String, matching normal Java
     * semantics (int/boolean/long/float/double/String/null all convert).
     * Both operands are already evaluated and sitting on the stack as
     * [..., leftVal, rightVal]; they're spilled to temp locals so they can be
     * read back in the right order once the StringBuffer receiver is pushed
     * underneath them, without re-evaluating (and re-running side effects of)
     * either operand expression. A long/double operand spills into TWO slots.
     */
    private int genStringConcat(int lt, int rt, int line) throws CompileError {
        return genStringConcat(lt, rt, line, false, false);
    }

    private int genStringConcat(int lt, int rt, int line, boolean lchar, boolean rchar) throws CompileError {
        if (lt == T.VOID || rt == T.VOID) {
            throw new CompileError("cannot use a void result in string concatenation", line);
        }
        int rightSlot = allocTempSlot(T.wordSize(rt));
        storeSlot(rightSlot, rt);
        int leftSlot = allocTempSlot(T.wordSize(lt));
        storeSlot(leftSlot, lt);

        int sbClass = cp.classInfo("java/lang/StringBuffer");
        int ctorIdx = cp.methodref("java/lang/StringBuffer", "<init>", "()V");
        emit(NEW); code.u2(sbClass); push(1);
        emit(DUP); push(1);
        emit(INVOKESPECIAL); code.u2(ctorIdx); pop(1);

        loadSlot(leftSlot, lt);
        appendCall(lt, line, lchar);

        loadSlot(rightSlot, rt);
        appendCall(rt, line, rchar);

        int toStringIdx = cp.methodref("java/lang/StringBuffer", "toString", "()Ljava/lang/String;");
        emit(INVOKEVIRTUAL); code.u2(toStringIdx);
        pop(1); push(1);
        return T.STRING;
    }

    /** stack: [..., sb, value] -> [..., sb]. */
    private void appendCall(int type, int line) throws CompileError { appendCall(type, line, false); }

    private void appendCall(int type, int line, boolean isChar) throws CompileError {
        String desc;
        int valueWords = T.wordSize(type);
        if (type == T.INT) desc = isChar ? "(C)Ljava/lang/StringBuffer;" : "(I)Ljava/lang/StringBuffer;";
        else if (type == T.BOOLEAN) desc = "(Z)Ljava/lang/StringBuffer;";
        else if (type == T.LONG) desc = "(J)Ljava/lang/StringBuffer;";
        else if (type == T.FLOAT || type == T.DOUBLE) {
            // CLDC 1.1's StringBuffer has no append(float)/append(double); convert through
            // Float.toString/Double.toString (which CLDC 1.1 does have), then append the String.
            boolean isF = type == T.FLOAT;
            int ts = cp.methodref(isF ? "java/lang/Float" : "java/lang/Double", "toString",
                    isF ? "(F)Ljava/lang/String;" : "(D)Ljava/lang/String;");
            emit(INVOKESTATIC); code.u2(ts);
            pop(valueWords); push(1);
            valueWords = 1;
            desc = "(Ljava/lang/String;)Ljava/lang/StringBuffer;";
        }
        else if (type == T.STRING || type == T.NULLT) desc = "(Ljava/lang/String;)Ljava/lang/StringBuffer;";
        else if (T.isRef(type)) desc = "(Ljava/lang/Object;)Ljava/lang/StringBuffer;"; // StringBuffer.append(Object) calls toString()
        else throw new CompileError("unsupported type in string concatenation", line);
        int idx = cp.methodref("java/lang/StringBuffer", "append", desc);
        emit(INVOKEVIRTUAL); code.u2(idx);
        pop(1 + valueWords); push(1);
    }

    private int shiftOpcode(String op, int type) {
        int base = op.equals("<<") ? ISHL : op.equals(">>") ? ISHR : IUSHR;
        return base + (type == T.LONG ? 1 : 0); // LSHL/LSHR/LUSHR = ISHL/ISHR/IUSHR + 1
    }

    /** Emits the arithmetic/bitwise opcode for `op` at numeric type `t` and fixes the
     *  stack: two operands (2*ws words) collapse to one result (ws words). */
    private void emitArithOpcode(String op, int t, int line) throws CompileError {
        int base = op.equals("+") ? IADD : op.equals("-") ? ISUB : op.equals("*") ? IMUL
                 : op.equals("/") ? IDIV : op.equals("%") ? IREM
                 : op.equals("&") ? IAND : op.equals("|") ? IOR : op.equals("^") ? IXOR
                 : op.equals("<<") ? ISHL : op.equals(">>") ? ISHR : op.equals(">>>") ? IUSHR
                 : -1;
        if (base < 0) throw new CompileError("unsupported arithmetic operator '" + op + "'", line);
        boolean bitwise = op.equals("&") || op.equals("|") || op.equals("^");
        if (bitwise && t != T.INT && t != T.LONG) throw new CompileError("'" + op + "' requires int or long operands", line);
        emit(base + kindOffset(t));
        pop(T.wordSize(t)); // two operands -> one result
    }

    /** consumes two stack values via a 2-operand compare opcode, pushes boolean 0/1 */
    private void emitCompareToBoolean(int cmpOpcode) {
        emit(cmpOpcode);
        int posT = code.reserveU2();
        pop(2);
        emit(ICONST_0); push(1);
        int jend = emitJumpPlaceholder(GOTO);
        code.patchBranch(posT, posT - 1, code.pc());
        emit(ICONST_1); push(1);
        patchJumpHere(jend);
    }

    // ---------------- calls ----------------

    /** f(a, b, c) for a user varargs method f(X x, Y... ys): the trailing arguments are packed into an array. */
    private Vector packVarargs(String name, Vector args, int line) throws CompileError {
        if (locals == null) return args;
        Vector vms = locals.varargsMethods(name);
        for (int v = 0; v < vms.size(); v++) {
            MethodNode vm = (MethodNode) vms.elementAt(v);
            int k = vm.params.size();
            if (args.size() < k - 1) continue;
            ParamNode last = (ParamNode) vm.params.elementAt(k - 1);
            if (args.size() == k) {
                int lt = typeOf((Expr) args.elementAt(k - 1));
                if (lt == T.NULLT || (T.isArray(lt) && T.desc(lt).equals(T.desc(last.type)))) continue; // already an array
            }
            ArrayInitExpr ai = new ArrayInitExpr();
            ai.line = line; ai.elemDesc = T.arrayElemDesc(last.type);
            Vector out = new Vector();
            for (int i = 0; i < k - 1; i++) out.addElement(args.elementAt(i));
            for (int i = k - 1; i < args.size(); i++) ai.elems.addElement(args.elementAt(i));
            out.addElement(ai);
            return out;
        }
        return args;
    }

    private int genCall(CallExpr c) throws CompileError {
        c.args = packVarargs(c.name, c.args, c.line);
        if ("System.out".equals(c.qualifier)) {
            return genSystemOutCall(c);
        }

        if (c.qualifier == null) {
            MethodNode m = pickOwnMethod(findOwnMethods(c.name, c.args.size()), c.args, c.line);
            if (m != null) {
                if (!m.isStatic) {
                    if (curMethod != null && curMethod.isStatic) throw new CompileError("cannot call instance method '" + c.name + "' from a static context", c.line);
                    emit(ALOAD_0); push(1);
                }
                genArgsChecked(m.params, c.args, c.line);
                int idx = cp.methodref(internalClassName, m.name, methodDesc(m));
                if (m.isStatic) {
                    emit(INVOKESTATIC); code.u2(idx);
                    pop(paramWords(m.params));
                } else {
                    emit(INVOKEVIRTUAL); code.u2(idx);
                    pop(paramWords(m.params) + 1);
                }
                if (m.returnType != T.VOID) push(T.wordSize(m.returnType));
                lastCallChar = m.returnsChar;
                genericPending = m.returnIsTypeVar;
                return m.returnType;
            }
            // not a method on this class -- maybe an inherited method (local superclass or platform API)
            // called without an explicit qualifier
            if (curMethod == null || !curMethod.isStatic) {
                Vector cands = findAllMethodsAny(cls.superName, c.name, c.args.size());
                if (cands.size() > 0) {
                    emit(ALOAD_0); push(1);
                    ApiIndex.Found found = pickOverload(cands, c.args, c.line);
                    return genFoundInstanceCall(found, c);
                }
            }
            Expr viaOuter = outerCallExpr(c);
            if (viaOuter != null) return genExpr(viaOuter);
            ApiIndex.Found sf = findStaticImportedMethod(c.name, c.args, c.line);
            if (sf != null) {
                Vector pds = ApiIndex.splitParamDescriptors(sf.method.paramDesc);
                genArgsRaw(pds, c.args, c.line);
                String owner = internalNameFor(sf.declaringClass);
                String md = "(" + sf.method.paramDesc + ")" + sf.method.returnDesc;
                int mi = cp.methodref(owner, c.name, md);
                emit(INVOKESTATIC); code.u2(mi);
                pop(paramWordCount(pds));
                int rt = jvmDescToType(sf.method.returnDesc);
                if (rt != T.VOID) push(T.wordSize(rt));
                lastCallChar = sf.method.returnDesc.equals("C");
                genericPending = (sf.method.flags & 0x4000) != 0;
                return rt;
            }
            throw new CompileError("undefined method '" + c.name + "' with " + c.args.size() + " argument(s)", c.line);
        }

        if ("super".equals(c.qualifier)) {
            if (curMethod != null && curMethod.isStatic) throw new CompileError("cannot call 'super' from a static context", c.line);
            emit(ALOAD_0); push(1);
            Vector superCands = findAllMethodsAny(cls.superName, c.name, c.args.size());
            if (superCands.size() == 0) throw new CompileError("no method '" + c.name + "' with " + c.args.size() + " argument(s) found on superclass " + cls.superName, c.line);
            ApiIndex.Found found = pickOverload(superCands, c.args, c.line);
            Vector paramDescs = ApiIndex.splitParamDescriptors(found.method.paramDesc);
            genArgsRaw(paramDescs, c.args, c.line);
            String owner = internalNameFor(found.declaringClass);
            String mdesc = "(" + found.method.paramDesc + ")" + found.method.returnDesc;
            int idx = cp.methodref(owner, c.name, mdesc);
            emit(INVOKESPECIAL); code.u2(idx);
            pop(paramWordCount(paramDescs) + 1);
            int rt = jvmDescToType(found.method.returnDesc);
            if (rt != T.VOID) push(T.wordSize(rt));
            lastCallChar = found.method.returnDesc.equals("C");
            return rt;
        }

        if (c.qualifier.indexOf('.') >= 0 && resolveSimpleClassName(c.qualifier) == null) {
            // a.b.foo() / Foo.bar.foo() : the qualifier is a value path (fields), not a class name
            Expr q = qualifierToExpr(c.qualifier, c.line);
            if (q != null) {
                ChainCallExpr cc = new ChainCallExpr();
                cc.line = c.line; cc.target = q; cc.name = c.name; cc.args = c.args;
                return genChainCall(cc);
            }
        }

        // qualifier names an in-scope instance (this / local var / own field) -> instance call
        Integer instType = typeOfNameIfInstance(c.qualifier);
        if (instType != null) {
            int t = instType.intValue();
            if (isSelfType(t)) {
                MethodNode m = pickOwnMethod(findOwnMethods(c.name, c.args.size()), c.args, c.line);
                if (m != null) {
                    genNameLoad(c.qualifier, c.line); // push receiver ("this" for the common case)
                    genArgsChecked(m.params, c.args, c.line);
                    int idx = cp.methodref(internalClassName, m.name, methodDesc(m));
                    if (m.isStatic) { emit(INVOKESTATIC); code.u2(idx); pop(paramWords(m.params)); }
                    else { emit(INVOKEVIRTUAL); code.u2(idx); pop(paramWords(m.params) + 1); }
                    if (m.returnType != T.VOID) push(T.wordSize(m.returnType));
                    return m.returnType;
                }
            }
            if (!T.isRef(t) || t == T.NULLT) {
                throw new CompileError("cannot call method '" + c.name + "()' on '" + c.qualifier + "': it is a "
                        + (t == T.NULLT ? "null value" : T.name(t)) + ", not an object", c.line);
            }
            genNameLoad(c.qualifier, c.line); // push receiver
            String instFqcn = chainStartFor(t);
            Vector instCands = findAllMethodsAny(instFqcn, c.name, c.args.size());
            if (instCands.size() == 0) {
                // If the type name itself was never resolved against any import
                // (resolveTypeName's fallthrough returns the raw, unqualified
                // name in that case -- see Parser.resolveTypeName), the real
                // problem usually isn't a missing overload at all: it's a
                // missing `import`. Give that diagnosis when it applies,
                // since "no method found on Graphics" reads as if setColor()
                // simply doesn't exist, when the actual fix is one import line.
                if (!api.has(instFqcn) && (locals == null || !locals.has(instFqcn))) {
                    throw new CompileError("unknown type '" + instFqcn + "' -- is an 'import' for it missing? "
                            + "(needed to resolve the call to '" + c.name + "')", c.line);
                }
                throw new CompileError("no method '" + c.name + "' with " + c.args.size() + " argument(s) found on " + instFqcn, c.line);
            }
            ApiIndex.Found found = pickOverload(instCands, c.args, c.line);
            return genFoundInstanceCall(found, c);
        }

        // otherwise qualifier must name a class -> static call
        String fqcn = resolveSimpleClassName(c.qualifier);
        if (fqcn == null) {
            Expr oq = outerFieldExpr(c.qualifier, c.line);
            if (oq != null) {
                ChainCallExpr occ = new ChainCallExpr();
                occ.line = c.line; occ.target = oq; occ.name = c.name; occ.args = c.args;
                return genChainCall(occ);
            }
            throw new CompileError("unknown call target '" + c.qualifier + "'", c.line);
        }
        Vector staticCands = findAllMethodsAny(fqcn, c.name, c.args.size());
        if (staticCands.size() == 0) throw new CompileError("no method '" + c.name + "' with " + c.args.size() + " argument(s) found on " + fqcn, c.line);
        ApiIndex.Found found = pickOverload(staticCands, c.args, c.line);
        if ((found.method.flags & ApiIndex.FLAG_STATIC) == 0) {
            throw new CompileError("'" + c.name + "' on " + fqcn + " is not a static method (call it on an instance instead)", c.line);
        }
        Vector paramDescs = ApiIndex.splitParamDescriptors(found.method.paramDesc);
        genArgsRaw(paramDescs, c.args, c.line);
        String owner = internalNameFor(found.declaringClass);
        String mdesc = "(" + found.method.paramDesc + ")" + found.method.returnDesc;
        int idx = cp.methodref(owner, c.name, mdesc);
        emit(INVOKESTATIC); code.u2(idx);
        pop(paramWordCount(paramDescs));
        int rt = jvmDescToType(found.method.returnDesc);
        if (rt != T.VOID) push(T.wordSize(rt));
        lastCallChar = found.method.returnDesc.equals("C");
        genericPending = (found.method.flags & 0x4000) != 0;
        return rt;
    }

    /** Assumes the receiver is already pushed on the stack. */
    private int genFoundInstanceCall(ApiIndex.Found found, CallExpr c) throws CompileError {
        return genFoundInstanceCall(found, c.name, c.args, c.line);
    }

    private int genFoundInstanceCall(ApiIndex.Found found, String callName, Vector callArgs, int callLine) throws CompileError {
        CallExpr c = new CallExpr();
        c.name = callName; c.args = callArgs; c.line = callLine;
        boolean isStaticMethod = (found.method.flags & ApiIndex.FLAG_STATIC) != 0;
        if (isStaticMethod) {
            emit(POP); pop(1); // receiver evaluated for side effects only
        }
        Vector paramDescs = ApiIndex.splitParamDescriptors(found.method.paramDesc);
        genArgsRaw(paramDescs, c.args, c.line);
        String owner = internalNameFor(found.declaringClass);
        String mdesc = "(" + found.method.paramDesc + ")" + found.method.returnDesc;
        if (isStaticMethod) {
            int idx = cp.methodref(owner, c.name, mdesc);
            emit(INVOKESTATIC); code.u2(idx);
            pop(paramWordCount(paramDescs));
        } else if (isInterfaceAny(found.declaringClass)) {
            int idx = cp.interfaceMethodref(owner, c.name, mdesc);
            int argWords = paramWordCount(paramDescs);
            emit(INVOKEINTERFACE); code.u2(idx); code.u1(argWords + 1); code.u1(0);
            pop(argWords + 1);
        } else {
            int idx = cp.methodref(owner, c.name, mdesc);
            emit(INVOKEVIRTUAL); code.u2(idx);
            pop(paramWordCount(paramDescs) + 1);
        }
        int rt = jvmDescToType(found.method.returnDesc);
        if (rt != T.VOID) push(T.wordSize(rt));
        lastCallChar = found.method.returnDesc.equals("C");
        genericPending = (found.method.flags & 0x4000) != 0;
        return rt;
    }

    /**
     * Picks the best overload from a set of same-name/same-argcount
     * candidates by looking at each argument expression's type (typeOf) and
     * matching it against each candidate's parameter descriptors. Two passes,
     * like javac's phases: first an exact match on every argument, then a match
     * allowing implicit primitive widening (int -> long/float/double,
     * long -> float/double, float -> double). Falls back to the first
     * candidate if neither pass matches, rather than failing outright, since
     * the index doesn't model every JVM overload rule (genArgsRaw then reports
     * a precise per-argument error if the fallback really doesn't fit).
     */
    private ApiIndex.Found pickOverload(Vector candidates, Vector argExprs, int line) throws CompileError {
        if (candidates.size() == 0) return null;
        if (candidates.size() == 1) return (ApiIndex.Found) candidates.elementAt(0);
        int[] argTypes = dryRunArgTypes(argExprs);
        boolean[] isCh = new boolean[argTypes.length];
        for (int i = 0; i < isCh.length; i++) isCh[i] = isCharExpr((Expr) argExprs.elementAt(i));
        // pass 0: exact incl. char-vs-int (append('c') -> append(char), append(65) -> append(int))
        // pass 1: exact int-family   pass 2: with implicit widening
        // pass 3: boxing / unboxing (Java 5 phase 2)
        for (int pass = 0; pass < 4; pass++) {
            for (int i = 0; i < candidates.size(); i++) {
                ApiIndex.Found f = (ApiIndex.Found) candidates.elementAt(i);
                String pdBlob = f.method != null ? f.method.paramDesc : f.ctor.paramDesc;
                Vector pds = ApiIndex.splitParamDescriptors(pdBlob);
                if (pass == 0 && !charKindsMatch(pds, argTypes, isCh)) continue;
                if (paramsMatch(pds, argTypes, pass >= 2, pass == 3, isCh)) return f;
            }
        }
        return (ApiIndex.Found) candidates.elementAt(0);
    }

    /** true for expressions known to be of type char: char literals, (char) casts. */
    private boolean isCharExpr(Expr e) {
        if (!e.typed) { try { typeOf(e); } catch (CompileError ce) { return false; } }
        return e.charTyped;
    }

    /** every int-family argument must meet a parameter of the right flavour:
     *  char-typed argument <-> 'C', other int argument <-> 'I'. */
    private boolean charKindsMatch(Vector pds, int[] argTypes, boolean[] isCh) {
        if (pds.size() != argTypes.length) return false;
        for (int i = 0; i < argTypes.length; i++) {
            if (argTypes[i] != T.INT) continue;
            String pd = (String) pds.elementAt(i);
            if (primParamType(pd) != T.INT) continue;
            if (isCh[i] ? !pd.equals("C") : !pd.equals("I")) return false;
        }
        return true;
    }

    /** T type a primitive parameter descriptor accepts (byte/short/char/int are all T.INT), or -1 for a reference. */
    private int primParamType(String pd) {
        char c = pd.charAt(0);
        if (c == 'I' || c == 'S' || c == 'B' || c == 'C') return T.INT;
        if (c == 'Z') return T.BOOLEAN;
        if (c == 'J') return T.LONG;
        if (c == 'F') return T.FLOAT;
        if (c == 'D') return T.DOUBLE;
        return -1;
    }

    /** @param allowWidening false = a primitive argument must have exactly the parameter's
     *  type; true = implicit widening (T.widen) is also acceptable. Reference parameters
     *  behave the same in both passes. */
    private boolean paramsMatch(Vector paramDescs, int[] argTypes, boolean allowWidening, boolean allowBoxing, boolean[] isCh) {
        if (paramDescs.size() != argTypes.length) return false;
        for (int i = 0; i < argTypes.length; i++) {
            String pd = (String) paramDescs.elementAt(i);
            int at = argTypes[i];
            int prim = primParamType(pd);
            if (prim >= 0) {
                if (at == prim) continue;
                if (allowBoxing && boxIndex(at) >= 0) {
                    int u = boxPrim(boxIndex(at));
                    if (u == prim || T.widen(u, prim)) continue;
                    return false;
                }
                if (!allowWidening || !T.widen(at, prim)) return false;
            } else if (pd.startsWith("L") || pd.startsWith("[")) {
                if (allowBoxing && T.isPrimitive(at) && pd.startsWith("L")) {
                    String w = pd.substring(1, pd.length() - 1).replace('/', '.');
                    int ni = boxIdxForPrim(at, isCh != null && i < isCh.length && isCh[i]);
                    if (ni >= 0 && isAssignableFqcn(BOX[ni][0], w)) continue;
                    // int literal for Short/Byte/Character parameters
                    if (at == T.INT && (w.equals("java.lang.Short") || w.equals("java.lang.Byte") || w.equals("java.lang.Character"))) continue;
                    return false;
                }
                if (!T.isRef(at)) return false;
                if (at == T.NULLT) continue; // null matches any reference param
                if (pd.startsWith("[")) {
                    String have = isSelfType(at) ? cls.name : T.className(at);
                    if (!pd.equals(have)) return false;
                    continue;
                }
                String want = pd.substring(1, pd.length() - 1).replace('/', '.');
                String have = isSelfType(at) ? cls.name : T.className(at);
                if (have == null) return false;
                if (!(have.equals(want) || isAssignableFqcn(have, want))) return false;
            } else {
                return false;
            }
        }
        return true;
    }

    /** Learns each argument's type without emitting it (see typeOf). */
    private int[] dryRunArgTypes(Vector argExprs) throws CompileError {
        int[] types = new int[argExprs.size()];
        for (int i = 0; i < argExprs.size(); i++) {
            types[i] = typeOf((Expr) argExprs.elementAt(i));
        }
        return types;
    }

    /** generates+type-checks args against user-defined ParamNode list (for calls to this class's own methods);
     *  an argument narrower than its parameter (int -> long, float -> double, ...) is widened in place. */
    private void genArgsChecked(Vector params, Vector argExprs, int line) throws CompileError {
        if (argExprs.size() != params.size()) throw new CompileError("wrong number of arguments", line);
        for (int i = 0; i < argExprs.size(); i++) {
            ParamNode p = (ParamNode) params.elementAt(i);
            int at = genExpr((Expr) argExprs.elementAt(i));
            coerce(p.type, at, line, "argument " + (i + 1));
        }
    }

    /**
     * Generates+checks args against raw JVM param descriptors (for calls into
     * the platform API and into sibling local classes, whose methods are indexed
     * as descriptors too). Each argument is converted to its parameter's type
     * with an implicit primitive widening where Java allows one (int -> long
     * via I2L, int -> float via I2F, long -> double via L2D, ...); a narrowing
     * (long -> int, double -> float) is rejected with a clear error, as is a
     * primitive passed where a reference is expected -- this compiler has no
     * autoboxing, so there is deliberately nothing to convert it with.
     */
    private void genArgsRaw(Vector paramDescs, Vector argExprs, int line) throws CompileError {
        if (argExprs.size() != paramDescs.size()) throw new CompileError("wrong number of arguments", line);
        for (int i = 0; i < argExprs.size(); i++) {
            String pd = (String) paramDescs.elementAt(i);
            int at = genExpr((Expr) argExprs.elementAt(i));
            int prim = primParamType(pd);
            if (prim >= 0) {
                if (at == prim) continue;
                if (T.widen(at, prim)) { emitConv(at, prim); continue; }
                if (T.isRef(at) && tryUnbox(prim, at, line)) continue; // Integer -> int parameter
                throw new CompileError("argument " + (i + 1) + ": expected " + T.name(prim) + ", found " + T.name(at), line);
            } else if ((pd.startsWith("L") || pd.startsWith("[")) && !T.isRef(at)) {
                // int -> Integer / Object parameter
                String want = pd.startsWith("L") ? pd.substring(1, pd.length() - 1).replace('/', '.') : pd;
                if (pd.startsWith("L") && tryBox(T.refType(want), at, line)) continue;
                throw new CompileError("argument " + (i + 1) + ": expected " + want + ", found " + T.name(at), line,
                        "boxing only converts between a primitive and its own wrapper class");
            }
        }
    }

    private int genSystemOutCall(CallExpr c) throws CompileError {
        // System.out : java/io/PrintStream, field 'out' of java/lang/System
        int fieldIdx = cp.fieldref("java/lang/System", "out", "Ljava/io/PrintStream;");
        emit(GETSTATIC); code.u2(fieldIdx); push(1);

        if (!c.name.equals("print") && !c.name.equals("println")) {
            throw new CompileError("System.out only supports print/println", c.line);
        }
        if (c.args.size() == 0) {
            if (!c.name.equals("println")) throw new CompileError("System.out.print requires an argument", c.line);
            int idx = cp.methodref("java/io/PrintStream", "println", "()V");
            emit(INVOKEVIRTUAL); code.u2(idx);
            pop(1);
            return T.VOID;
        }
        if (c.args.size() != 1) throw new CompileError("System.out." + c.name + " takes 0 or 1 argument", c.line);
        Expr argExpr = (Expr) c.args.elementAt(0);
        int at = genExpr(argExpr);
        String argDesc = at == T.INT ? (argExpr.charTyped ? "C" : "I") : at == T.BOOLEAN ? "Z" : at == T.STRING ? "Ljava/lang/String;"
                       : at == T.LONG ? "J" : at == T.FLOAT ? "F" : at == T.DOUBLE ? "D"
                       : (T.isRef(at) && !T.isArray(at)) ? "Ljava/lang/Object;" : null;
        if (argDesc == null) throw new CompileError("unsupported argument type for System.out." + c.name, c.line);
        int idx = cp.methodref("java/io/PrintStream", c.name, "(" + argDesc + ")V");
        emit(INVOKEVIRTUAL); code.u2(idx);
        pop(1 + T.wordSize(at)); // printstream + arg
        return T.VOID;
    }

    // ---------------- assert ----------------

    /** Name of the synthetic flag field added to every class that uses assert. */
    static final String ASSERT_FIELD = "$assertionsDisabled";

    /** Thrown when an assertion fails. java.lang.AssertionError does not exist in CLDC 1.1
     *  (its Throwable hierarchy stops at Error), and a class whose bytecode merely names a
     *  missing Throwable subclass can fail to load at all on the device, so the error type
     *  is plain java.lang.Error -- which CLDC and MIDP both have, with a (String) constructor. */
    static final String ASSERT_ERROR_CLASS = "java/lang/Error";

    private void ensureAssertField() {
        if (usesAssert) return;
        usesAssert = true;
        FieldNode f = new FieldNode();
        f.type = T.BOOLEAN;
        f.name = ASSERT_FIELD;
        f.isStatic = true;
        f.isFinal = true;
        f.isSynthetic = true;
        f.line = 0;
        cls.fields.addElement(f);
    }

    /**
     * assert cond [: message];   emits
     *
     *     getstatic  $assertionsDisabled : Z
     *     ifne       skip
     *     <cond>
     *     ifne       skip
     *     new        java/lang/Error ; dup
     *     [<message> -> String]
     *     invokespecial Error.<init>([Ljava/lang/String;])V
     *     athrow
     *   skip:
     *
     * Unlike javac's Class.desiredAssertionStatus() (absent from CLDC 1.1) the flag is
     * set once in <clinit> from the system property "j2me.assertions" -- see
     * genAssertionsDisabledInit. The condition and message are NOT evaluated when
     * assertions are disabled, exactly as Java specifies.
     */
    private void genAssert(AssertStmt s) throws CompileError {
        ensureAssertField();
        int flagRef = cp.fieldref(internalClassName, ASSERT_FIELD, "Z");
        emit(GETSTATIC); code.u2(flagRef); push(1);
        int jDisabled = emitJumpPlaceholder(IFNE); pop(1);

        s.cond = unb(s.cond);
        int ct = genExpr(s.cond);
        if (ct != T.BOOLEAN) throw new CompileError("assert condition must be boolean", s.line);
        int jOk = emitJumpPlaceholder(IFNE); pop(1);

        int errClass = cp.classInfo(ASSERT_ERROR_CLASS);
        emit(NEW); code.u2(errClass); push(1);
        emit(DUP); push(1);
        if (s.message != null) {
            int mt = genExpr(s.message);
            genToStringForAssert(mt, s.line);
            int ctor = cp.methodref(ASSERT_ERROR_CLASS, "<init>", "(Ljava/lang/String;)V");
            emit(INVOKESPECIAL); code.u2(ctor); pop(2);
        } else {
            int ctor = cp.methodref(ASSERT_ERROR_CLASS, "<init>", "()V");
            emit(INVOKESPECIAL); code.u2(ctor); pop(1);
        }
        emit(ATHROW); pop(1);

        patchJumpHere(jDisabled);
        patchJumpHere(jOk);
    }

    /** value of type t on the stack -> a String on the stack (for the assert detail message). */
    private void genToStringForAssert(int t, int line) throws CompileError {
        if (t == T.STRING) return;
        if (t == T.VOID) throw new CompileError("assert message cannot be void", line);
        int ws = T.wordSize(t);
        int idx;
        if (t == T.FLOAT) idx = cp.methodref("java/lang/Float", "toString", "(F)Ljava/lang/String;");
        else if (t == T.DOUBLE) idx = cp.methodref("java/lang/Double", "toString", "(D)Ljava/lang/String;");
        else if (t == T.INT) idx = cp.methodref("java/lang/String", "valueOf", "(I)Ljava/lang/String;");
        else if (t == T.LONG) idx = cp.methodref("java/lang/String", "valueOf", "(J)Ljava/lang/String;");
        else if (t == T.BOOLEAN) idx = cp.methodref("java/lang/String", "valueOf", "(Z)Ljava/lang/String;");
        else idx = cp.methodref("java/lang/String", "valueOf", "(Ljava/lang/Object;)Ljava/lang/String;");
        emit(INVOKESTATIC); code.u2(idx);
        pop(ws); push(1);
    }

    /** <clinit> prologue: $assertionsDisabled = !"true".equals(System.getProperty("j2me.assertions")) */
    private void genAssertionsDisabledInit() throws CompileError {
        ldc(cp.stringConst("true")); push(1);
        ldc(cp.stringConst("j2me.assertions")); push(1);
        int gp = cp.methodref("java/lang/System", "getProperty", "(Ljava/lang/String;)Ljava/lang/String;");
        emit(INVOKESTATIC); code.u2(gp); // String -> String: net 0
        int eq = cp.methodref("java/lang/String", "equals", "(Ljava/lang/Object;)Z");
        emit(INVOKEVIRTUAL); code.u2(eq); pop(2); push(1); // "true".equals(prop)
        int jEnabled = emitJumpPlaceholder(IFNE); pop(1);
        emit(ICONST_1); push(1);                         // not enabled -> disabled = true
        int jEnd = emitJumpPlaceholder(GOTO);
        patchJumpHere(jEnabled);
        pop(1);
        emit(ICONST_0); push(1);                         // enabled -> disabled = false
        patchJumpHere(jEnd);
        int flagRef = cp.fieldref(internalClassName, ASSERT_FIELD, "Z");
        emit(PUTSTATIC); code.u2(flagRef); pop(1);
    }


}
