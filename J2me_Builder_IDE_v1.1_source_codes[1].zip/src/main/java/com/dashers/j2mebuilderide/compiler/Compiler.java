package com.dashers.j2mebuilderide.compiler;

import java.util.Vector;
import java.io.InputStream;
import java.io.IOException;

/**
 * Facade used by the MIDlet UI: compile(source) -> class file bytes,
 * or throws CompileError with a line number for the editor to highlight.
 *
 * Language level: Java 1.4 by default (SOURCE_1_4) -- long/float/double,
 * numeric casts, assert, strictfp. SOURCE_1_3 makes 'assert' an ordinary
 * identifier again (mirrors javac -source 1.3) for older projects.
 * Also supported: static/inner/local/anonymous classes (Outer.this, outer.new Inner(),
 * captured locals, an inner class extending another inner class), enums (+ switch on enum,
 * values()/valueOf, constants with their own bodies), enhanced for, varargs, generics by
 * erasure (checkcast on assignment), annotations (ignored), synchronized/volatile/transient,
 * this(...) and initializer blocks, labeled break/continue, octal literals and escapes,
 * -2147483648, and autoboxing/unboxing (Integer i = 5; int j = i; i++; i += 2; arithmetic,
 * comparisons, conditions, array indexes, switch selectors, method arguments). Boxing uses
 * the wrapper constructors (new Integer(v)) because CLDC has no valueOf(int).
 * Remaining source-level gaps are documented in the parser/code generator rather than
 * being confused with JAR indexing: Java 8+ constructs that require bytecode features
 * outside the CLDC 1.1 target (notably invokedynamic-based lambdas) still need explicit
 * lowering before they can be emitted safely.
 *
 * Bytecode target is unchanged: class file 45.3 with the CLDC 1.1
 * "StackMap" attribute (not the Java 6 StackMapTable), no invokedynamic.
 * assert compiles to a $assertionsDisabled check initialized from the
 * system property "j2me.assertions" (default: disabled) -- see CodeGen.
 */
public class Compiler {

    /** javac -source 1.3 equivalent: 'assert' is an identifier. */
    public static final int SOURCE_1_3 = 3;
    /** javac -source 1.4 equivalent (the default): 'assert' is a keyword. */
    public static final int SOURCE_1_4 = 4;

    /** Chooses how long/double locals are written in the CLDC StackMap attribute:
     *  true (default) = one verification_type_info per pair, false = (Long/Double, Top).
     *  Flip only if a real CLDC preverifier/VM shows the other form (see tools/PREVERIFY_CHECK.md). */
    public static void setStackMapLongDoubleOneEntry(boolean oneEntry) {
        StackMapGen.setLongDoubleOneEntry(oneEntry);
    }

    private static ApiIndex sharedApi;

    /** Loads the bundled MIDP/CLDC API index once and caches it for the
     *  process lifetime. On Android, prefer initApiIndex(InputStream) --
     *  called once at app startup with a stream opened from
     *  Context.getAssets().open("api_index_core.txt") -- since a raw text
     *  file dropped into a Sketchware Pro project isn't reliably reachable
     *  via classpath getResourceAsStream() the way it was in the original
     *  J2ME build (where api_index_core.txt lived in res/ and got bundled
     *  onto the MIDlet suite's classpath by the J2ME build tooling). This
     *  method still tries getResourceAsStream() first for compatibility
     *  with that original build path (e.g. running the compiler package
     *  standalone/under a normal Gradle build rather than Sketchware),
     *  and only fails if neither that nor a prior initApiIndex() call
     *  provided one. */
    public static ApiIndex apiIndex() throws CompileError {
        if (sharedApi != null) return sharedApi;
        try {
            InputStream in = Compiler.class.getResourceAsStream("/api_index_core.txt");
            if (in == null) {
                throw new CompileError(
                    "internal error: api_index_core.txt not loaded. " +
                    "On Android, call Compiler.initApiIndex(...) once at app " +
                    "startup with a stream from Context.getAssets().open(\"api_index_core.txt\") " +
                    "before compiling anything.", 0);
            }
            sharedApi = ApiIndex.load(in);
            return sharedApi;
        } catch (IOException e) {
            throw new CompileError("internal error loading API index: " + e.getMessage(), 0);
        }
    }

    /** Android entry point: call this once at app startup (e.g. in your
     *  Application subclass or the first Activity's onCreate) with a
     *  stream opened from Context.getAssets().open("api_index_core.txt").
     *  Safe to call more than once -- later calls are ignored once the
     *  index is already loaded, matching apiIndex()'s existing
     *  cache-for-process-lifetime behavior. The caller is still
     *  responsible for closing `in` afterward (ApiIndex.load reads it
     *  fully but does not close it, matching the original J2ME behavior). */
    public static void initApiIndex(InputStream in) throws CompileError {
        if (sharedApi != null || in == null) return;
        try {
            sharedApi = ApiIndex.load(in);
        } catch (IOException e) {
            throw new CompileError("internal error loading API index: " + e.getMessage(), 0);
        }
    }

    /** Result of compiling a whole file: one entry per top-level class, in the
     *  order they were declared (parallel `names`/`classBytes` arrays rather
     *  than a single record type, to keep this CLDC 1.1-friendly). */
    public static class UnitResult {
        public String[] names;
        public byte[][] classBytes;
    }

    /** Backward-compatible single-class entry point: compiles a file and
     *  requires it contain exactly one top-level class. */
    public static byte[] compile(String source) throws CompileError {
        UnitResult r = compileUnit(source);
        if (r.classBytes.length > 1) {
            throw new CompileError("found a second top-level class '" + r.names[1]
                    + "' but this entry point only supports one class per file", 0);
        }
        return r.classBytes[0];
    }

    /** Compiles every top-level class in one source file. Classes in the same
     *  file may reference each other's constructors/fields/methods regardless
     *  of declaration order (see LocalClassTable) -- this is what makes
     *  multiple top-level classes per file actually usable together, rather
     *  than just independently parseable. */
    public static UnitResult compileUnit(String source) throws CompileError {
        return compileUnit(source, SOURCE_1_4);
    }

    public static UnitResult compileUnit(String source, int sourceLevel) throws CompileError {
        ApiIndex api = apiIndex();
        T.resetTypes();

        Lexer lexer = new Lexer(source, sourceLevel);
        Vector tokens = lexer.tokenize();

        Parser parser = new Parser(tokens, api, sourceLevel);
        Vector classNodes = parser.parseCompilationUnit();

        checkNoDuplicateTopLevelClasses(classNodes);
        for (int i = 0; i < classNodes.size(); i++) {
            checkNoDuplicateMembers((ClassNode) classNodes.elementAt(i));
        }

        // Pass 1: register every class's shape (name, super, interfaces, fields,
        // methods, ctors) BEFORE generating code for any of them, so a class
        // declared earlier in the file can still resolve calls/fields/`new` on
        // a sibling declared later.
        LocalClassTable locals = new LocalClassTable(classNodes, api);
        resolveAnonBases(classNodes, locals, api);

        for (int i = 0; i < classNodes.size(); i++) {
            checkAbstractMethodsImplemented((ClassNode) classNodes.elementAt(i), locals);
        }

        // Pass 2: generate bytecode for each class now that the whole file's
        // shape is known.
        String[] names = new String[classNodes.size()];
        byte[][] outBytes = new byte[classNodes.size()][];
        for (int ci = 0; ci < classNodes.size(); ci++) {
            ClassNode cls = (ClassNode) classNodes.elementAt(ci);
            names[ci] = cls.name;
            try {
                outBytes[ci] = checked(cls.name, compileOneClass(cls, api, locals));
            } catch (MethodTooLargeException tl) {
                throw new CompileError(cls.name + ": " + tl.getMessage(), 0);
            }
        }

        UnitResult result = new UnitResult();
        result.names = names;
        result.classBytes = outBytes;
        return result;
    }

    /**
     * A concrete (non-abstract, non-interface) local class must provide a real
     * (non-abstract) body for every abstract method reachable from its
     * superclass chain and every interface it implements (transitively, since
     * an interface may itself extend other interfaces). An abstract local
     * class is exempt -- it's allowed to leave some of them unimplemented for
     * a further subclass to finish.
     *
     * Implementation note: this only sees abstract methods declared on LOCAL
     * classes/interfaces (via LocalClassTable.findAllMethods, which does carry
     * the isAbstract bit -- see LocalClassTable.toMethodInfo) or on PLATFORM
     * classes whose api_index_core.txt entry happens to set flag bit 32. The
     * bundled index was generated before this feature existed and does not
     * currently set that bit for any platform method, so `implements
     * CommandListener` without providing commandAction(...) is NOT caught
     * here -- it still fails, but only later, as a real runtime
     * AbstractMethodError on the device. Only gaps against a user-defined
     * `abstract class`/`interface` are caught at compile time right now.
     */
    private static void checkAbstractMethodsImplemented(ClassNode cls, LocalClassTable locals) throws CompileError {
        if (cls.isInterface || cls.isAbstract) return; // exempt; may legitimately leave methods unimplemented

        Vector chain = new Vector();
        Vector visited = new Vector();
        chain.addElement(cls.superName);
        for (int i = 0; i < cls.interfaces.size(); i++) chain.addElement(cls.interfaces.elementAt(i));

        while (chain.size() > 0) {
            String cur = (String) chain.elementAt(0);
            chain.removeElementAt(0);
            if (cur == null || visited.contains(cur)) continue;
            visited.addElement(cur);
            ClassNode c = locals.get(cur);
            if (c == null) continue; // platform class/interface -- see limitation note above
            for (int i = 0; i < c.methods.size(); i++) {
                MethodNode m = (MethodNode) c.methods.elementAt(i);
                if (!m.isAbstract) continue;
                Vector impls = locals.findAllMethods(cls.name, m.name, m.params.size());
                boolean satisfied = false;
                for (int j = 0; j < impls.size(); j++) {
                    ApiIndex.Found f = (ApiIndex.Found) impls.elementAt(j);
                    if ((f.method.flags & ApiIndex.FLAG_ABSTRACT) == 0) { satisfied = true; break; }
                }
                if (!satisfied) {
                    throw new CompileError("'" + cls.name + "' must be declared abstract or implement "
                            + "abstract method '" + m.name + "' with " + m.params.size()
                            + " parameter(s), inherited from " + cur, 0);
                }
            }
            chain.addElement(c.superName);
            for (int i = 0; i < c.interfaces.size(); i++) chain.addElement(c.interfaces.elementAt(i));
        }
    }

    /** One not-yet-parsed project source file, as read from disk. */
    public static class ProjectFile {
        public String fileName; // e.g. "MyCanvas.java", used only for error attribution
        public String source;
    }

    /** Result of compiling every source file in a project together. Parallel
     *  arrays, one entry per top-level class across ALL files (order:
     *  file order, then declaration order within each file). */
    public static class ProjectResult {
        public String[] fileNames;  // originating .java file for each class
        public String[] names;      // class name
        public byte[][] classBytes;
        /** "Class.member" for every member declared 'private' (used by the obfuscator). */
        public java.util.HashSet privateMembers = new java.util.HashSet();
    }

    /**
     * Compiles every file in a project as ONE linked unit: a class declared
     * in one file can `new`, call, or read a field on a sibling class
     * declared in a *different* file, exactly as if they'd been pasted into
     * a single file (see LocalClassTable). This is what compileUnit cannot
     * do on its own, since it only ever sees one file's classes.
     *
     * Any CompileError thrown -- whether from parsing, duplicate-name
     * checks, or codegen -- has its fileName set to the file that caused
     * it (unless something upstream already set one), so the caller can
     * report "which file, which line" instead of just "which line".
     */
    public static ProjectResult compileProject(ProjectFile[] files) throws CompileError {
        return compileProject(files, SOURCE_1_4);
    }

    /** @param sourceLevel SOURCE_1_3 or SOURCE_1_4 (applied to every file in the project) */
    public static ProjectResult compileProject(ProjectFile[] files, int sourceLevel) throws CompileError {
        ApiIndex api = apiIndex();
        T.resetTypes();

        // Pass 0: parse every file independently -- lexing/parsing is still
        // inherently per-file -- but tag each resulting ClassNode with the
        // file it came from and pour them all into ONE shared Vector, so
        // pass 1 below builds a single project-wide LocalClassTable instead
        // of one scoped to a single file.
        Vector allClassNodes = new Vector();
        Vector parseErrors = new Vector();
        for (int fi = 0; fi < files.length; fi++) {
            ProjectFile pf = files[fi];
            Vector fileClassNodes;
            try {
                Lexer lexer = new Lexer(pf.source, sourceLevel);
                Vector tokens = lexer.tokenize();
                Parser parser = new Parser(tokens, api, sourceLevel);
                fileClassNodes = parser.parseCompilationUnit();
            } catch (CompileError ce) {
                // keep going: report one syntax error per file, not just the first file's
                parseErrors.addElement(attachFile(ce, pf.fileName));
                continue;
            }
            for (int i = 0; i < fileClassNodes.size(); i++) {
                ClassNode c = (ClassNode) fileClassNodes.elementAt(i);
                c.sourceFile = pf.fileName;
                allClassNodes.addElement(c);
            }
        }
        if (parseErrors.size() > 0) throw firstOf(parseErrors);

        // Duplicate top-level class names are checked PROJECT-WIDE here
        // (not just within one file, like compileUnit does) -- two files
        // defining the same class name would otherwise silently collide
        // when Package bundles the .class files into one jar.
        checkNoDuplicateTopLevelClassesAcrossProject(allClassNodes);
        for (int i = 0; i < allClassNodes.size(); i++) {
            ClassNode c = (ClassNode) allClassNodes.elementAt(i);
            try {
                checkNoDuplicateMembers(c);
            } catch (CompileError ce) {
                throw attachFile(ce, c.sourceFile);
            }
        }

        // Pass 1: register every class's shape (name, super, interfaces,
        // fields, methods, ctors) from EVERY file BEFORE generating code for
        // any of them -- this is the actual cross-file fix: one shared
        // LocalClassTable spanning the whole project instead of a fresh one
        // per file, so file order and which-file-declared-what no longer
        // matter for resolving `new`/calls/field access on sibling classes.
        LocalClassTable locals = new LocalClassTable(allClassNodes, api);
        resolveAnonBases(allClassNodes, locals, api);

        for (int i = 0; i < allClassNodes.size(); i++) {
            ClassNode c = (ClassNode) allClassNodes.elementAt(i);
            try {
                checkAbstractMethodsImplemented(c, locals);
            } catch (CompileError ce) {
                throw attachFile(ce, c.sourceFile);
            }
        }

        // Pass 2: generate bytecode for each class now that the whole
        // project's shape is known.
        String[] fileNames = new String[allClassNodes.size()];
        String[] names = new String[allClassNodes.size()];
        byte[][] outBytes = new byte[allClassNodes.size()][];
        Vector genErrors = new Vector();
        for (int ci = 0; ci < allClassNodes.size(); ci++) {
            ClassNode cls = (ClassNode) allClassNodes.elementAt(ci);
            fileNames[ci] = cls.sourceFile;
            names[ci] = cls.name;
            try {
                outBytes[ci] = checked(cls.name, compileOneClass(cls, api, locals));
            } catch (CompileError ce) {
                genErrors.addElement(attachFile(ce, cls.sourceFile));
            } catch (MethodTooLargeException tl) {
                genErrors.addElement(attachFile(new CompileError(cls.name + ": " + tl.getMessage(), 0), cls.sourceFile));
            }
        }
        if (genErrors.size() > 0) throw firstOf(genErrors);

        ProjectResult result = new ProjectResult();
        result.fileNames = fileNames;
        result.names = names;
        result.classBytes = outBytes;
        for (int ci = 0; ci < allClassNodes.size(); ci++) {
            ClassNode cn = (ClassNode) allClassNodes.elementAt(ci);
            for (int k = 0; k < cn.fields.size(); k++) {
                FieldNode f = (FieldNode) cn.fields.elementAt(k);
                if (f.isPrivate) result.privateMembers.add(cn.name.replace('.', '/') + "." + f.name);
            }
            for (int k = 0; k < cn.methods.size(); k++) {
                MethodNode m = (MethodNode) cn.methods.elementAt(k);
                if (m.isPrivate && !m.isConstructor) result.privateMembers.add(cn.name.replace('.', '/') + "." + m.name);
            }
        }
        return result;
    }

    /** An anonymous class 'new X() {...}' extends X, or implements it when X is an interface. */
    private static void resolveAnonBases(Vector nodes, LocalClassTable locals, ApiIndex api) {
        for (int i = 0; i < nodes.size(); i++) {
            ClassNode c = (ClassNode) nodes.elementAt(i);
            if (!c.isAnon) continue;
            ClassNode b = locals.get(c.anonBase);
            boolean iface = b != null ? b.isInterface : (api != null && api.isInterface(c.anonBase));
            if (iface) { c.interfaces.addElement(c.anonBase); c.superName = "java.lang.Object"; }
            else c.superName = c.anonBase;
        }
    }

    /** Throws-ready: the first error, carrying the complete list in .all. */
    private static CompileError firstOf(Vector errors) {
        CompileError first = (CompileError) errors.elementAt(0);
        first.all = errors;
        return first;
    }

    private static CompileError attachFile(CompileError ce, String fileName) {
        if (ce.fileName == null) ce.fileName = fileName;
        return ce;
    }

    private static void checkNoDuplicateTopLevelClassesAcrossProject(Vector classNodes) throws CompileError {
        for (int i = 0; i < classNodes.size(); i++) {
            ClassNode a = (ClassNode) classNodes.elementAt(i);
            for (int j = i + 1; j < classNodes.size(); j++) {
                ClassNode b = (ClassNode) classNodes.elementAt(j);
                if (a.name.equals(b.name)) {
                    CompileError ce = new CompileError("duplicate top-level class name '" + a.name
                            + "' in " + a.sourceFile + " and " + b.sourceFile, 0);
                    ce.fileName = b.sourceFile;
                    throw ce;
                }
            }
        }
    }

    private static boolean verifyOutput = true;

    /** Run the internal class-file verifier on every compiled class (default on). */
    public static void setVerifyOutput(boolean on) { verifyOutput = on; }

    private static byte[] checked(String cls, byte[] bytes) throws CompileError {
        if (!verifyOutput) return bytes;
        ClassVerifier.Result vr = ClassVerifier.verify(bytes);
        if (!vr.ok()) {
            throw new CompileError("internal check failed for class " + cls
                    + " (a compiler bug, not your code):\n" + vr.summary(3), 0);
        }
        return bytes;
    }

    private static byte[] compileOneClass(ClassNode cls, ApiIndex api, LocalClassTable locals) throws CompileError {
        ConstPool cp = new ConstPool();
        CodeGen cg = new CodeGen(cp, cls, api, locals);

        Vector methodCode = new Vector();
        Vector methodMaxStack = new Vector();
        Vector methodMaxLocals = new Vector();
        Vector methodExcTables = new Vector(); // Vector of Vector<int[]{start,end,handler,catchType}>

        int explicitCtors = 0;
        for (int i = 0; i < cls.methods.size(); i++) {
            MethodNode m = (MethodNode) cls.methods.elementAt(i);
            if (m.isAbstract) {
                // no Code attribute at all for an abstract/interface method -- ClassWriter
                // treats a null entry here as "omit the Code attribute", which is required:
                // a classfile with ACC_ABSTRACT set on a method must have zero code.
                methodCode.addElement(null);
                methodMaxStack.addElement(new Integer(0));
                methodMaxLocals.addElement(new Integer(0));
                methodExcTables.addElement(new Vector());
                continue;
            }
            int[] ms = new int[1];
            int[] ml = new int[1];
            byte[] code;
            if (m.isConstructor) {
                explicitCtors++;
                code = cg.genExplicitConstructorCode(m, ms, ml);
            } else {
                code = cg.genMethodCode(m, ms, ml);
            }
            methodCode.addElement(code);
            methodMaxStack.addElement(new Integer(ms[0]));
            methodMaxLocals.addElement(new Integer(ml[0]));
            methodExcTables.addElement(cg.lastExceptionTable());
        }

        // if the user wrote no explicit constructor, emit a default no-arg one
        // (calls super() and runs instance field initializers) -- except on an
        // interface, which can never be instantiated and has no <init> at all.
        if (explicitCtors == 0 && !cls.isInterface) {
            MethodNode ctor = new MethodNode();
            ctor.name = "<init>"; ctor.returnType = T.VOID; ctor.isStatic = false; ctor.isConstructor = true;
            int[] cms = new int[1], cml = new int[1];
            byte[] ctorCode = cg.genConstructorCode(cms, cml);
            cls.methods.addElement(ctor);
            methodCode.addElement(ctorCode);
            methodMaxStack.addElement(new Integer(cms[0]));
            methodMaxLocals.addElement(new Integer(cml[0]));
            methodExcTables.addElement(cg.lastExceptionTable());
        }

        // emit <clinit> only if some static field actually has an initializer
        boolean needsClinit = false;
        for (int i = 0; i < cls.fields.size(); i++) {
            FieldNode f = (FieldNode) cls.fields.elementAt(i);
            if (f.isStatic && f.init != null) { needsClinit = true; break; }
        }
        for (int i = 0; i < cls.initBlocks.size(); i++) if (((InitBlock) cls.initBlocks.elementAt(i)).isStatic) needsClinit = true;
        if (cg.usesAssert()) needsClinit = true; // the $assertionsDisabled initializer lives in <clinit>
        if (needsClinit) {
            MethodNode clinit = new MethodNode();
            clinit.name = "<clinit>"; clinit.returnType = T.VOID; clinit.isStatic = true;
            int[] zms = new int[1], zml = new int[1];
            byte[] clinitCode = cg.genClinitCode(zms, zml);
            cls.methods.addElement(clinit);
            methodCode.addElement(clinitCode);
            methodMaxStack.addElement(new Integer(zms[0]));
            methodMaxLocals.addElement(new Integer(zml[0]));
            methodExcTables.addElement(cg.lastExceptionTable());
        }

        return ClassWriter.write(cls, cp, api, methodCode, methodMaxStack, methodMaxLocals, methodExcTables);
    }

    private static void checkNoDuplicateTopLevelClasses(Vector classNodes) throws CompileError {
        for (int i = 0; i < classNodes.size(); i++) {
            ClassNode a = (ClassNode) classNodes.elementAt(i);
            for (int j = i + 1; j < classNodes.size(); j++) {
                ClassNode b = (ClassNode) classNodes.elementAt(j);
                if (a.name.equals(b.name)) {
                    throw new CompileError("duplicate top-level class name '" + a.name + "' in the same file", 0);
                }
            }
        }
    }

    private static void checkNoDuplicateMembers(ClassNode cls) throws CompileError {
        for (int i = 0; i < cls.fields.size(); i++) {
            FieldNode a = (FieldNode) cls.fields.elementAt(i);
            for (int j = i + 1; j < cls.fields.size(); j++) {
                FieldNode b = (FieldNode) cls.fields.elementAt(j);
                if (a.name.equals(b.name)) {
                    throw new CompileError("duplicate field '" + a.name + "'", b.line);
                }
            }
        }
        for (int i = 0; i < cls.methods.size(); i++) {
            MethodNode a = (MethodNode) cls.methods.elementAt(i);
            if (a.isConstructor) continue;
            for (int j = i + 1; j < cls.methods.size(); j++) {
                MethodNode b = (MethodNode) cls.methods.elementAt(j);
                if (b.isConstructor) continue;
                // Java overloads are distinguished by the erased parameter
                // descriptor, not merely by arity. Same-name/same-arity methods
                // with different parameter types are legal and are resolved by
                // CodeGen.pickOverload().
                if (a.name.equals(b.name) && sameParameterTypes(a, b)) {
                    throw new CompileError("duplicate method '" + a.name + "' with the same parameter types", b.line);
                }
            }
        }
        int ctorCount = 0;
        for (int i = 0; i < cls.methods.size(); i++) {
            MethodNode a = (MethodNode) cls.methods.elementAt(i);
            if (a.isConstructor) ctorCount++;
        }
        for (int i = 0; i < cls.methods.size(); i++) {
            MethodNode a = (MethodNode) cls.methods.elementAt(i);
            if (!a.isConstructor) continue;
            for (int j = i + 1; j < cls.methods.size(); j++) {
                MethodNode b = (MethodNode) cls.methods.elementAt(j);
                if (!b.isConstructor) continue;
                if (sameParameterTypes(a, b)) {
                    throw new CompileError("duplicate constructor with the same parameter types", b.line);
                }
            }
        }
    }
    private static boolean sameParameterTypes(MethodNode a, MethodNode b) {
        if (a.params.size() != b.params.size()) return false;
        for (int i = 0; i < a.params.size(); i++) {
            ParamNode pa = (ParamNode) a.params.elementAt(i);
            ParamNode pb = (ParamNode) b.params.elementAt(i);
            if (!T.desc(pa.type).equals(T.desc(pb.type))) return false;
        }
        return true;
    }

}
