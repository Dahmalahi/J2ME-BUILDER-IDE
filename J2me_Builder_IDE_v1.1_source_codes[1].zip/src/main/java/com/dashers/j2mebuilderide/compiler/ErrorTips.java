package com.dashers.j2mebuilderide.compiler;

import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Turns a compiler message (ECJ wording) into a short category label and a practical "how to fix"
 * tip aimed at J2ME (CLDC/MIDP) projects. Pure Java, no Android classes.
 */
public final class ErrorTips {

    private ErrorTips() { }

    /** Java SE class -> what to use on CLDC/MIDP instead. */
    private static final String[][] SE_TO_J2ME = {
        {"ArrayList", "Vector (addElement / elementAt / size)"},
        {"LinkedList", "Vector"},
        {"List", "Vector"},
        {"Collection", "Vector"},
        {"HashMap", "Hashtable (put / get)"},
        {"Map", "Hashtable"},
        {"TreeMap", "Hashtable"},
        {"HashSet", "Hashtable (use the keys) or Vector"},
        {"Set", "Hashtable (use the keys) or Vector"},
        {"Iterator", "Enumeration (vector.elements() / hashtable.keys())"},
        {"Iterable", "Enumeration"},
        {"StringBuilder", "StringBuffer"},
        {"Scanner", "read bytes from an InputStream and build a String / StringBuffer"},
        {"BufferedReader", "InputStreamReader (reading char by char)"},
        {"BufferedWriter", "OutputStreamWriter"},
        {"File", "javax.microedition.io.file.FileConnection (JSR-75 - add it in Libraries)"},
        {"FileInputStream", "FileConnection.openInputStream() (JSR-75 - add it in Libraries)"},
        {"FileOutputStream", "FileConnection.openOutputStream() (JSR-75 - add it in Libraries)"},
        {"Arrays", "your own loop (java.util.Arrays is not in CLDC; System.arraycopy exists)"},
        {"Collections", "your own loop / Vector methods"},
        {"Objects", "plain null checks"},
        {"Optional", "plain null checks"},
        {"Logger", "System.out.println"},
        {"Socket", "javax.microedition.io.Connector.open(\"socket://host:port\")"},
        {"URL", "javax.microedition.io.Connector.open(\"http://...\")"},
        {"HttpURLConnection", "javax.microedition.io.HttpConnection"},
        {"Properties", "RecordStore or a Hashtable"},
        {"Thread", "java.lang.Thread (check spelling / import)"},
        {"JFrame", "javax.microedition.lcdui.Form or Canvas"},
        {"JPanel", "javax.microedition.lcdui.Canvas"},
        {"Graphics2D", "javax.microedition.lcdui.Graphics"},
        {"BufferedImage", "javax.microedition.lcdui.Image"},
        {"Color", "int colours: g.setColor(0xRRGGBB)"},
        {"Font", "javax.microedition.lcdui.Font.getFont(...)"},
        {"Toast", "Alert (javax.microedition.lcdui.Alert)"},
        {"Context", "not available on J2ME (that is Android)"},
        {"Activity", "javax.microedition.midlet.MIDlet (that is Android)"}
    };

    private static final String[][] STRING_METHODS = {
        {"contains", "use s.indexOf(x) >= 0"},
        {"isEmpty", "use s.length() == 0"},
        {"split", "write a small loop with indexOf / substring"},
        {"format", "build the text with StringBuffer.append(...)"},
        {"join", "build the text with StringBuffer.append(...)"},
        {"matches", "regular expressions are not in CLDC; compare / search manually"},
        {"replaceAll", "regular expressions are not in CLDC; loop with indexOf / substring"},
        {"replaceFirst", "loop with indexOf / substring"},
        {"strip", "use trim()"},
        {"repeat", "append in a loop"},
        {"chars", "loop with charAt(i)"},
        {"equalsIgnoreCase", "check the spelling (it exists in CLDC)"},
        {"compareToIgnoreCase", "compare toLowerCase() strings with compareTo"},
        {"getBytes", "exists - check arguments (String charset name)"}
    };

    private static final Pattern P_TYPE = Pattern.compile("^(.+) cannot be resolved to a type$");
    private static final Pattern P_IMPORT = Pattern.compile("^The import (.+) cannot be resolved$");
    private static final Pattern P_VAR = Pattern.compile("^(.+) cannot be resolved( to a variable)?$");
    private static final Pattern P_NOT_FIELD = Pattern.compile("^(.+) cannot be resolved or is not a field$");
    private static final Pattern P_METHOD_UNDEF = Pattern.compile("^The method (\\w+)\\((.*)\\) is undefined for the type (.+)$");
    private static final Pattern P_METHOD_ARGS = Pattern.compile("^The method (\\w+)\\((.*)\\) in the type (.+) is not applicable for the arguments \\((.*)\\)$");
    private static final Pattern P_CTOR = Pattern.compile("^The constructor (.+) is undefined$");
    private static final Pattern P_INSERT = Pattern.compile("^Syntax error, insert \"(.+)\" to complete (.+)$");
    private static final Pattern P_TOKEN = Pattern.compile("^Syntax error on token\\(?s?\\)?,? \"?(.*?)\"?,? (.+)$");
    private static final Pattern P_MISMATCH = Pattern.compile("^Type mismatch: cannot convert from (.+) to (.+)$");
    private static final Pattern P_UNHANDLED = Pattern.compile("^Unhandled exception type (.+)$");
    private static final Pattern P_OWN_FILE = Pattern.compile("^The public type (.+) must be defined in its own file$");
    private static final Pattern P_PACKAGE = Pattern.compile("^The declared package \"(.*)\" does not match the expected package \"(.*)\"$");
    private static final Pattern P_ABSTRACT = Pattern.compile("^The type (.+) must implement the inherited abstract method (.+)$");

    /** Short label such as "Unknown class", "Syntax error". Never null. */
    public static String category(String m) {
        if (m == null) return "Error";
        if (P_TYPE.matcher(m).matches() || P_IMPORT.matcher(m).matches()) return "Class / import not found";
        if (m.startsWith("Syntax error") || m.indexOf("is not properly closed") >= 0 || m.startsWith("Invalid character")) return "Syntax error";
        if (P_METHOD_UNDEF.matcher(m).matches() || P_CTOR.matcher(m).matches()) return "Method not found";
        if (P_METHOD_ARGS.matcher(m).matches()) return "Wrong arguments";
        if (P_MISMATCH.matcher(m).matches() || m.startsWith("Cannot cast")) return "Type mismatch";
        if (P_UNHANDLED.matcher(m).matches()) return "Unhandled exception";
        if (P_VAR.matcher(m).matches() || P_NOT_FIELD.matcher(m).matches()) return "Name not found";
        if (m.startsWith("Duplicate")) return "Duplicate declaration";
        if (m.indexOf("must return a result") >= 0 || m.indexOf("Void methods cannot return") >= 0) return "Return problem";
        if (m.indexOf("may not have been initialized") >= 0) return "Uninitialized variable";
        if (P_OWN_FILE.matcher(m).matches() || P_PACKAGE.matcher(m).matches()) return "File / package name";
        if (P_ABSTRACT.matcher(m).matches() || m.startsWith("Cannot instantiate")) return "Class structure";
        if (m.indexOf("not visible") >= 0) return "Access problem";
        return "Error";
    }

    private static String simple(String n) {
        n = n.trim();
        int lt = n.indexOf('<');
        if (lt > 0) n = n.substring(0, lt);
        int d = n.lastIndexOf('.');
        return d >= 0 ? n.substring(d + 1) : n;
    }

    private static String seAlternative(String simpleName) {
        for (int i = 0; i < SE_TO_J2ME.length; i++) if (SE_TO_J2ME[i][0].equals(simpleName)) return SE_TO_J2ME[i][1];
        return null;
    }

    /** Practical advice for one compiler message; "" when there is nothing useful to add. */
    public static String tipFor(String m, String codeLine) {
        if (m == null) return "";
        Matcher x;

        x = P_TYPE.matcher(m);
        if (x.matches()) {
            String n = simple(x.group(1));
            String alt = seAlternative(n);
            if (alt != null) return "'" + n + "' does not exist on J2ME (CLDC/MIDP has a much smaller API than Java SE). Use: " + alt + ".";
            return "Class '" + n + "' was not found. Check: (1) spelling and capital letters, (2) the import line at the top, "
                 + "(3) if it comes from a library, add its .jar under Libraries, (4) the class may simply not exist in CLDC/MIDP.";
        }
        x = P_IMPORT.matcher(m);
        if (x.matches()) {
            String imp = x.group(1);
            String n = simple(imp);
            if (imp.startsWith("javax.swing") || imp.startsWith("java.awt"))
                return "Swing / AWT do not exist on J2ME. Use javax.microedition.lcdui (Form, Canvas, Graphics, Image, Command).";
            if (imp.startsWith("java.net") || imp.startsWith("javax.net"))
                return "Use javax.microedition.io.Connector.open(\"http://...\") instead of java.net.";
            if (imp.startsWith("java.nio") || imp.startsWith("java.io.File"))
                return "Files use JSR-75: javax.microedition.io.file.FileConnection. Add the 'File access (JSR-75)' library and import that.";
            if (imp.startsWith("javax.microedition.m3g")) return "M3G (JSR-184) is an optional library: add it under Libraries.";
            if (imp.startsWith("javax.microedition.media")) return "MMAPI (JSR-135) is an optional library: add it under Libraries.";
            if (imp.startsWith("javax.microedition.io.file") || imp.startsWith("javax.microedition.pim")) return "This is an optional JSR library (File/PIM, JSR-75): add it under Libraries.";
            if (imp.startsWith("javax.microedition.location")) return "Location (JSR-179) is an optional library: add it under Libraries.";
            if (imp.startsWith("javax.bluetooth") || imp.startsWith("javax.obex")) return "Bluetooth (JSR-82) is an optional library: add it under Libraries.";
            if (imp.startsWith("com.nokia") || imp.startsWith("com.siemens") || imp.startsWith("com.samsung") || imp.startsWith("com.sun")
                    || imp.startsWith("com.mascotcapule") || imp.startsWith("com.mascotcapsule"))
                return "Vendor API: make sure the vendor library is listed under Libraries, then check the package spelling.";
            String alt = seAlternative(n);
            if (alt != null) return "'" + n + "' is not part of J2ME. Use: " + alt + " (and delete this import).";
            return "Nothing called '" + imp + "' exists in the J2ME API or your libraries. Fix the spelling, add the .jar that contains it under Libraries, or delete the import.";
        }
        x = P_NOT_FIELD.matcher(m);
        if (x.matches()) return "'" + x.group(1) + "' is not a field of that object. Check the name and capital letters, or whether it is a method (needs parentheses).";
        x = P_VAR.matcher(m);
        if (x.matches()) {
            String n = x.group(1);
            return "'" + n + "' is not declared here. Declare it first (e.g. int " + n + " = 0;), check spelling and capital letters, "
                 + "make sure it is inside the same { } block, or import the class if it is a class name.";
        }
        x = P_METHOD_UNDEF.matcher(m);
        if (x.matches()) {
            String name = x.group(1), type = simple(x.group(3));
            if (type.equals("String")) {
                for (int i = 0; i < STRING_METHODS.length; i++) if (STRING_METHODS[i][0].equals(name))
                    return "String." + name + "() is missing in CLDC: " + STRING_METHODS[i][1] + ".";
            }
            return "'" + type + "' has no method " + name + "(" + x.group(2) + ") in the J2ME API (CLDC classes have far fewer methods than Java SE). "
                 + "Check the spelling, the arguments, and the class documentation.";
        }
        x = P_METHOD_ARGS.matcher(m);
        if (x.matches())
            return "'" + x.group(1) + "' exists but not with these arguments. Expected (" + x.group(2) + ") but you passed (" + x.group(4) + "). "
                 + "Fix the number, order or types of the arguments (cast with (int) / (String) if needed).";
        x = P_CTOR.matcher(m);
        if (x.matches()) return "No constructor with those arguments. Check the class's constructors (argument count and types), or use 'new' with the right parameters.";
        x = P_INSERT.matcher(m);
        if (x.matches()) {
            String t = x.group(1);
            if (t.equals(";")) return "A semicolon ';' is missing at the end of this statement - often on the line just above, so check that one too.";
            if (t.equals("}")) return "A closing brace '}' is missing. Count your { and } - every { needs a matching }. Check the end of the file and the method above.";
            if (t.equals(")")) return "A closing parenthesis ')' is missing. Check every '(' has its ')' on this line.";
            if (t.equals("]")) return "A closing bracket ']' is missing.";
            return "Insert '" + t + "' as the message says - the code is incomplete here (look at the end of this line and the previous one).";
        }
        if (m.startsWith("Syntax error")) {
            return "The compiler cannot understand the code at this point. Common causes: a missing ';' or ')' or '}' on this or the previous line, "
                 + "an extra bracket, a misspelled keyword, or code outside a method. Fix the FIRST syntax error first - later ones are often caused by it.";
        }
        x = P_MISMATCH.matcher(m);
        if (x.matches()) {
            String from = x.group(1), to = x.group(2);
            if (to.equals("int") || to.equals("short") || to.equals("byte") || to.equals("char") || to.equals("long"))
                if (from.equals("double") || from.equals("float") || from.equals("long") || from.equals("int"))
                    return "Narrowing needs an explicit cast: write (" + to + ") before the value (data may be lost).";
            if (to.equals("float") && from.equals("double")) return "A decimal literal is a double. Write 1.5f (with f) or cast: (float) value. (CLDC 1.0 has no float/double at all.)";
            if (from.equals("String")) return "A String cannot be assigned to " + to + ". Convert it, e.g. Integer.parseInt(text) for int.";
            if (to.equals("String")) return "Convert to text first: String.valueOf(x) or \"\" + x.";
            if (from.equals("Object")) return "Cast the Object to the right class: (" + to + ") obj.";
            return "The two types are not compatible. Convert the value or change the variable type to " + from + ".";
        }
        if (m.startsWith("Cannot cast from")) return "These two types are unrelated, so the cast is impossible. Check the variable types.";
        x = P_UNHANDLED.matcher(m);
        if (x.matches()) {
            String t = simple(x.group(1));
            return "'" + t + "' must be handled. Wrap the call: try { ... } catch (" + t + " e) { } , or add 'throws " + t + "' to the method. "
                 + (t.equals("InterruptedException") ? "(Thread.sleep() always needs this.)" : t.equals("IOException") ? "(Streams / connections always need this.)" : "");
        }
        x = P_OWN_FILE.matcher(m);
        if (x.matches()) return "A public class must live in a file with the same name: rename the file to " + simple(x.group(1)) + ".java (or rename the class).";
        x = P_PACKAGE.matcher(m);
        if (x.matches()) return "The package line says '" + x.group(1) + "' but the file sits in folder '" + x.group(2)
                 + "'. Move the file to the matching folder under src/, or change the package line.";
        x = P_ABSTRACT.matcher(m);
        if (x.matches()) return "Add the missing method " + x.group(2) + " to " + simple(x.group(1)) + ". "
                 + "MIDlet needs startApp(), pauseApp(), destroyApp(boolean); CommandListener needs commandAction(Command, Displayable); Runnable needs run().";
        if (m.startsWith("Cannot instantiate the type")) return "You cannot use 'new' on an abstract class or interface. Create a subclass / anonymous class that implements it.";
        if (m.startsWith("Duplicate local variable") || m.startsWith("Duplicate field") || m.startsWith("Duplicate method") || m.startsWith("Duplicate parameter"))
            return "The same name is declared twice in the same scope. Rename one of them, or remove the second type keyword (e.g. 'int x' -> 'x') to reuse it.";
        if (m.indexOf("must return a result of type") >= 0) return "Every path of the method must end with 'return value;'. Add a return at the end (and in each branch).";
        if (m.indexOf("Void methods cannot return a value") >= 0) return "The method is 'void': remove the value after 'return', or change the return type.";
        if (m.indexOf("Return type for the method is missing") >= 0) return "A method needs a return type (void / int ...). If this is a constructor, the name must be exactly the class name.";
        if (m.indexOf("may not have been initialized") >= 0) return "Give the variable a starting value where you declare it (e.g. int n = 0;), or assign it on every branch before use.";
        if (m.startsWith("Cannot make a static reference")) return "You are using an instance member from a static method (e.g. main). Create an object first (new X()) or make the member static.";
        if (m.indexOf("is not visible") >= 0 || m.indexOf("is not visible") >= 0) return "That member is private / protected. Make it public, or add a public getter.";
        if (m.startsWith("The final local variable") || m.startsWith("The final field")) return "A 'final' value can be assigned only once. Remove 'final' or assign it only at the declaration.";
        if (m.indexOf("must override or implement a supertype method") >= 0)
            return "Remove the @Override line (annotations are not used on J2ME), or fix the method name / parameters so they match the parent.";
        if (m.indexOf("is not properly closed by a double-quote") >= 0) return "A text literal is missing its closing \" on this line.";
        if (m.startsWith("Invalid character constant")) return "A char literal holds exactly one character: 'a'. Use double quotes \"abc\" for text.";
        if (m.indexOf("indirectly referenced from required .class files") >= 0 || m.startsWith("The type java.lang.Object cannot be resolved")
                || m.startsWith("The type java.lang.String cannot be resolved"))
            return "The J2ME base API (CLDC) could not be read. Check assets/j2me-sdk-api.jar (or assets/j2me/api/) exists in the app, "
                 + "and that a library .jar you added is a J2ME jar, not a Java SE / Android jar.";
        if (m.startsWith("The operator") && m.indexOf("is undefined for the argument type") > 0)
            return "That operator cannot be used with these types (for example '+' on two booleans, or '-' on Strings). Convert the values first.";
        if (m.indexOf("is already defined") >= 0 || m.startsWith("Duplicate class"))
            return "Two classes have the same name in the same package. Rename or delete one of the files.";
        return "";
    }

    /** General "how to fix this build" steps, based on what failed. */
    public static Vector buildTips(Vector problemMessages, String packageMessage, boolean ecjFellBack, int missingLibraries) {
        Vector tips = new Vector();
        boolean sawSource = false;
        for (int i = 0; i < problemMessages.size(); i++) {
            String m = (String) problemMessages.elementAt(i);
            if (m != null && m.length() > 0) sawSource = true;
        }
        String pk = packageMessage == null ? "" : packageMessage;
        if (pk.indexOf("main class") >= 0) tips.addElement("Open Project settings and set the Main class to your MIDlet class (it must extend javax.microedition.midlet.MIDlet).");
        if (pk.indexOf("No .java files") >= 0) tips.addElement("Add a .java file under src/ (Files screen > +).");
        if (pk.indexOf("permission") >= 0 || pk.indexOf("Permission") >= 0) tips.addElement("Allow storage access for the app in Android Settings > Apps > Permissions, then build again.");
        if (missingLibraries > 0) tips.addElement("Some imports need a library: open Libraries and add the matching .jar / JSR, then build again.");
        if (sawSource) {
            tips.addElement("Fix the FIRST error in the list: later errors are often caused by it. Tap an error in Problems to jump to its line.");
            tips.addElement("Build again after each fix; compile-only (menu > Compile only) is faster for checking.");
        }
        if (ecjFellBack) tips.addElement("ECJ could not start on this device, so the simpler built-in compiler was used. Its messages are less detailed; see the amber note above.");
        if (tips.size() == 0) tips.addElement("Open the Problems tab for details; long-press a problem to copy it.");
        return tips;
    }
}
