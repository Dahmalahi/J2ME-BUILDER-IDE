package com.dashers.j2mebuilderide.compiler;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;

/**
 * Reads a compiled .class file and turns its public API (class, super,
 * interfaces, fields, constructors, methods) into the ApiIndex records the
 * compiler links against. Used to load user supplied library .jar files
 * (lib/ folder of a project) so code that calls them compiles.
 */
public final class ClassFileIndexer {
    private ClassFileIndexer() {}

    /** @return the class record, or null for classes that should not be indexed. */
    static ApiIndex.ClassInfo parse(byte[] data) throws IOException {
        DataInputStream in = new DataInputStream(new ByteArrayInputStream(data));
        if (in.readInt() != 0xCAFEBABE) throw new IOException("not a class file");
        in.readUnsignedShort();
        in.readUnsignedShort();
        int n = in.readUnsignedShort();
        String[] utf = new String[n];
        int[] cls = new int[n];
        for (int i = 1; i < n; i++) {
            int tag = in.readUnsignedByte();
            switch (tag) {
                case 1: utf[i] = in.readUTF(); break;
                case 3: case 4: in.readInt(); break;
                case 5: case 6: in.readLong(); i++; break;
                case 7: cls[i] = in.readUnsignedShort(); break;
                case 8: case 16: case 19: case 20: in.readUnsignedShort(); break;
                case 9: case 10: case 11: case 12: case 17: case 18: in.readInt(); break;
                case 15: in.readUnsignedByte(); in.readUnsignedShort(); break;
                default: throw new IOException("bad constant pool tag " + tag);
            }
        }
        int access = in.readUnsignedShort();
        String name = className(utf, cls, in.readUnsignedShort());
        int sup = in.readUnsignedShort();
        if ((access & 0x1000) != 0) return null;           // synthetic helper classes are not source types
        // Do not discard nested ($) or package-private classes here. The index is
        // a class-file catalogue, not a Java access checker. Keeping them lets
        // Outer.Inner and same-package APIs resolve correctly. Access checking is
        // deliberately left to the compiler/linker layer.
        ApiIndex.ClassInfo ci = new ApiIndex.ClassInfo();
        ci.fqcn = name;
        ci.isInterface = (access & 0x0200) != 0;
        ci.superFqcn = (sup == 0 || ci.isInterface) ? null : className(utf, cls, sup);
        if ("java.lang.Object".equals(ci.superFqcn)) ci.superFqcn = null;
        int ni = in.readUnsignedShort();
        for (int i = 0; i < ni; i++) ci.interfaces.addElement(className(utf, cls, in.readUnsignedShort()));

        int nf = in.readUnsignedShort();
        for (int i = 0; i < nf; i++) {
            int fa = in.readUnsignedShort();
            String fname = utf[in.readUnsignedShort()];
            String fdesc = utf[in.readUnsignedShort()];
            skipAttrs(in);
            if ((fa & 0x0002) != 0) continue;                   // private members are not callable
            ApiIndex.FieldInfo fi = new ApiIndex.FieldInfo();
            fi.name = fname; fi.desc = fdesc; fi.flags = flags(fa); fi.constValue = null;
            ci.fields.addElement(fi);
        }
        int nm = in.readUnsignedShort();
        for (int i = 0; i < nm; i++) {
            int ma = in.readUnsignedShort();
            String mname = utf[in.readUnsignedShort()];
            String mdesc = utf[in.readUnsignedShort()];
            skipAttrs(in);
            if ((ma & 0x0002) != 0) continue;                       // private members are not callable
            if ((ma & 0x1040) != 0) continue;               // synthetic / bridge
            int close = mdesc.indexOf(')');
            String params = mdesc.substring(1, close);
            String ret = mdesc.substring(close + 1);
            if (mname.equals("<clinit>")) continue;
            if (mname.equals("<init>")) {
                ApiIndex.CtorInfo c = new ApiIndex.CtorInfo();
                c.paramDesc = params; c.flags = flags(ma);
                ci.ctors.addElement(c);
            } else {
                ApiIndex.MethodInfo m = new ApiIndex.MethodInfo();
                m.name = mname; m.paramDesc = params; m.returnDesc = ret; m.flags = flags(ma);
                ci.methods.addElement(m);
            }
        }
        return ci;
    }

    private static String className(String[] utf, int[] cls, int idx) {
        return utf[cls[idx]].replace('/', '.');
    }

    private static void skipAttrs(DataInputStream in) throws IOException {
        int n = in.readUnsignedShort();
        for (int i = 0; i < n; i++) {
            in.readUnsignedShort();
            int len = in.readInt();
            int left = len;
            while (left > 0) {
                int s = in.skipBytes(left);
                if (s <= 0) throw new IOException("truncated class file");
                left -= s;
            }
        }
    }

    /** class-file access flags -> ApiIndex flag bits. */
    private static int flags(int a) {
        int f = 0;
        if ((a & 0x0001) != 0) f |= 1;
        if ((a & 0x0004) != 0) f |= 2;
        if ((a & 0x0002) != 0) f |= 4;
        if ((a & 0x0008) != 0) f |= 8;
        if ((a & 0x0010) != 0) f |= 16;
        if ((a & 0x0400) != 0) f |= 32;
        return f;
    }
}
