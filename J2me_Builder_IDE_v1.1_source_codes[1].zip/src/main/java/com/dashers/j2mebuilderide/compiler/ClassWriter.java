package com.dashers.j2mebuilderide.compiler;

import java.util.Vector;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;

/**
 * Assembles a JVM class file. Targets class file version 45.3, the
 * version CLDC/MIDP toolchains expect -- deliberately NOT bumped for the
 * Java 1.4 source level: nothing 1.4 adds needs a newer class file (long,
 * float, double, assert and strictfp are all expressible in 45.3), and a
 * higher version would require the Java 6 StackMapTable format. Every method's Code attribute
 * carries a "StackMap" attribute (CLDC 1.1 / JSR 139 preverification
 * format -- see StackMapGen), so output is already preverified and does
 * not need to be run through an external `preverify` tool before
 * installing on real hardware.
 */
public class ClassWriter {

    static final int ACC_PUBLIC = 0x0001;
    static final int ACC_STATIC = 0x0008;
    static final int ACC_SUPER = 0x0020;
    static final int ACC_INTERFACE = 0x0200;
    static final int ACC_ABSTRACT = 0x0400;
    static final int ACC_FINAL = 0x0010;
    static final int ACC_SYNCHRONIZED = 0x0020;
    static final int ACC_STRICT = 0x0800;     // strictfp method
    static final int ACC_SYNTHETIC = 0x1000;  // compiler-generated member ($assertionsDisabled)

    public static byte[] write(ClassNode cls, ConstPool cp, ApiIndex api, Vector methodCode,
                                Vector methodMaxStack, Vector methodMaxLocals, Vector methodExcTables) throws CompileError {
        try {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            DataOutputStream out = new DataOutputStream(bos);

            int thisClass = cp.classInfo(CodeGen.internalNameFor(cls.name));
            int superClass = cp.classInfo(CodeGen.internalNameFor(cls.superName));
            int[] ifaceIdx = new int[cls.interfaces.size()];
            for (int i = 0; i < cls.interfaces.size(); i++) {
                ifaceIdx[i] = cp.classInfo(CodeGen.internalNameFor((String) cls.interfaces.elementAt(i)));
            }

            // pre-touch all name/desc/method/field constant pool entries BEFORE
            // writing constant_pool_count, since writing fields/methods below
            // may otherwise add new entries after the count was already written.
            int[] fieldNameIdx = new int[cls.fields.size()];
            int[] fieldDescIdx = new int[cls.fields.size()];
            for (int i = 0; i < cls.fields.size(); i++) {
                FieldNode f = (FieldNode) cls.fields.elementAt(i);
                fieldNameIdx[i] = cp.utf8(f.name);
                fieldDescIdx[i] = cp.utf8(CodeGen.desc(f.type));
            }
            int codeAttrNameIdx = cp.utf8("Code");
            int stackMapAttrNameIdx = cp.utf8("StackMap");
            int[] methodNameIdx = new int[cls.methods.size()];
            int[] methodDescIdx = new int[cls.methods.size()];
            String[] methodDescStr = new String[cls.methods.size()];
            CodeGen tmpCg = new CodeGen(cp, cls, api);
            for (int i = 0; i < cls.methods.size(); i++) {
                MethodNode m = (MethodNode) cls.methods.elementAt(i);
                methodNameIdx[i] = cp.utf8(m.name);
                methodDescStr[i] = tmpCg.methodDesc(m);
                methodDescIdx[i] = cp.utf8(methodDescStr[i]);
            }

            // Generate each method's StackMap attribute body now, BEFORE
            // cp.writeTo(out) below -- StackMapGen mints extra CONSTANT_Class
            // entries into cp (for array/uninitialized verification types
            // CodeGen itself never had a reason to intern) and those must
            // already be present when the constant pool is serialized.
            // Abstract/interface methods have no code at all (methodCode
            // entry is null -- see Compiler.compileOneClass) and are skipped
            // here entirely: a bodyless method gets no Code attribute and
            // therefore no StackMap attribute either.
            byte[][] stackMapBody = new byte[cls.methods.size()][];
            for (int i = 0; i < cls.methods.size(); i++) {
                MethodNode m = (MethodNode) cls.methods.elementAt(i);
                byte[] code = (byte[]) methodCode.elementAt(i);
                if (code == null) continue; // m.isAbstract -- leave stackMapBody[i] null, unused
                int maxLocals = ((Integer) methodMaxLocals.elementAt(i)).intValue();
                Vector excTable = (methodExcTables != null && i < methodExcTables.size())
                        ? (Vector) methodExcTables.elementAt(i) : null;
                if (excTable == null) excTable = new Vector();
                stackMapBody[i] = StackMapGen.generate(cp, code, excTable, maxLocals,
                        m.isStatic, m.isConstructor, CodeGen.internalNameFor(cls.name), methodDescStr[i]);
            }

            out.writeInt(0xCAFEBABE);
            out.writeShort(3);   // minor
            out.writeShort(45);  // major (CLDC pre-preverify baseline)

            cp.writeTo(out);

            // ACC_SUPER doesn't apply to interfaces (JVM spec: interfaces must NOT set it);
            // an interface classfile also always carries ACC_ABSTRACT alongside ACC_INTERFACE.
            int classFlags = ACC_PUBLIC | (cls.isInterface ? (ACC_INTERFACE | ACC_ABSTRACT)
                                                            : (ACC_SUPER | (cls.isAbstract ? ACC_ABSTRACT : 0)));
            out.writeShort(classFlags);
            out.writeShort(thisClass);
            out.writeShort(superClass);
            out.writeShort(ifaceIdx.length);
            for (int i = 0; i < ifaceIdx.length; i++) out.writeShort(ifaceIdx[i]);

            out.writeShort(cls.fields.size());
            for (int i = 0; i < cls.fields.size(); i++) {
                FieldNode f = (FieldNode) cls.fields.elementAt(i);
                int flags = f.isSynthetic
                        ? (ACC_STATIC | ACC_FINAL | ACC_SYNTHETIC)   // $assertionsDisabled: package-private, static final, synthetic
                        : cls.isInterface ? (ACC_PUBLIC | ACC_STATIC | ACC_FINAL)   // interface constants
                        : (ACC_PUBLIC | (f.isStatic ? ACC_STATIC : 0));
                out.writeShort(flags);
                out.writeShort(fieldNameIdx[i]);
                out.writeShort(fieldDescIdx[i]);
                out.writeShort(0); // attributes_count
            }

            out.writeShort(cls.methods.size());
            for (int i = 0; i < cls.methods.size(); i++) {
                MethodNode m = (MethodNode) cls.methods.elementAt(i);
                byte[] code = (byte[]) methodCode.elementAt(i);

                int flags = m.name.equals("<clinit>") ? ACC_STATIC
                          : (ACC_PUBLIC | (m.isStatic ? ACC_STATIC : 0) | (m.isAbstract ? ACC_ABSTRACT : 0)
                            | (m.isStrict && !m.isAbstract ? ACC_STRICT : 0)
                            | (m.isSynchronized && !m.isAbstract ? ACC_SYNCHRONIZED : 0));
                out.writeShort(flags);
                out.writeShort(methodNameIdx[i]);
                out.writeShort(methodDescIdx[i]);

                if (code == null) {
                    // abstract/interface method: JVM spec requires ACC_ABSTRACT methods to
                    // carry NO Code attribute (and therefore no attributes at all here).
                    out.writeShort(0); // attributes_count
                    continue;
                }

                int maxStack = ((Integer) methodMaxStack.elementAt(i)).intValue();
                int maxLocals = ((Integer) methodMaxLocals.elementAt(i)).intValue();
                Vector excTable = (methodExcTables != null && i < methodExcTables.size())
                        ? (Vector) methodExcTables.elementAt(i) : null;
                int excCount = excTable != null ? excTable.size() : 0;

                out.writeShort(1); // attributes_count (Code)

                byte[] smBody = stackMapBody[i];
                // maxstack+maxlocals+codelen+code+exc_count+exc_table+attr_count+(StackMap attr header+body)
                int codeAttrLen = 2 + 2 + 4 + code.length + 2 + (excCount * 8) + 2 + (2 + 4 + smBody.length);
                out.writeShort(codeAttrNameIdx);
                out.writeInt(codeAttrLen);
                out.writeShort(maxStack);
                out.writeShort(maxLocals);
                out.writeInt(code.length);
                out.write(code);
                out.writeShort(excCount);
                for (int j = 0; j < excCount; j++) {
                    int[] entry = (int[]) excTable.elementAt(j);
                    out.writeShort(entry[0]); // start_pc
                    out.writeShort(entry[1]); // end_pc
                    out.writeShort(entry[2]); // handler_pc
                    out.writeShort(entry[3]); // catch_type (0 = any, i.e. finally)
                }
                out.writeShort(1); // attributes_count (StackMap)
                out.writeShort(stackMapAttrNameIdx);
                out.writeInt(smBody.length);
                out.write(smBody);
            }

            out.writeShort(0); // class attributes_count
            out.flush();
            return bos.toByteArray();
        } catch (IOException e) {
            throw new CompileError("internal error writing class file: " + e.getMessage(), 0);
        }
    }
}