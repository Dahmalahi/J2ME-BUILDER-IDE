package com.dashers.j2mebuilderide.compiler;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Build-time sanity checker for the class files this compiler produces, so a
 * code-generation bug shows up as a build error instead of a VerifyError on
 * a Nokia/MTK phone.
 *
 * It checks, per class: constant-pool structure and cross references; per
 * method: that every instruction decodes, constant-pool operands have the
 * right kind, local-variable indexes fit max_locals, branch/switch/handler
 * targets land on instruction starts, the operand-stack depth is consistent
 * on every path and never exceeds max_stack or goes negative, return
 * instructions match the method's return type, execution cannot fall off the
 * end of the code, and the CLDC "StackMap" attribute has an entry at every
 * branch target and handler whose stack depth matches the code.
 *
 * It is NOT a full type-checking verifier (it does not track reference or
 * primitive types), and it does not replace the preverify comparison on a real
 * phone. Unreachable code is reported as a warning only.
 */
public class ClassVerifier {

    public static class Result {
        public final List<String> errors = new ArrayList<String>();
        public final List<String> warnings = new ArrayList<String>();

        public boolean ok() { return errors.isEmpty(); }

        /** First `max` errors joined by newlines. */
        public String summary(int max) {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < errors.size() && i < max; i++) {
                if (i > 0) sb.append('\n');
                sb.append(errors.get(i));
            }
            if (errors.size() > max) sb.append("\n... and ").append(errors.size() - max).append(" more");
            return sb.toString();
        }
    }

    /** Verify one class file. Never throws; a verifier crash is reported as a warning. */
    public static Result verify(byte[] data) {
        Result r = new Result();
        try {
            new ClassVerifier(data, r).run();
        } catch (Stop s) {
            if (s.getMessage() != null) r.errors.add(s.getMessage());
        } catch (IOException e) {
            r.errors.add("truncated or malformed class file: " + e);
        } catch (RuntimeException e) {
            r.warnings.add("verifier could not finish (" + e + ")");
        }
        return r;
    }

    private static class Stop extends RuntimeException {
        Stop(String m) { super(m); }
    }

    // ------------------------------------------------------------------

    private final byte[] data;
    private final Result r;
    private int cpCount;
    private int[] tag;
    private String[] utf;
    private int[] ca, cb;
    private String thisName = "?";

    private ClassVerifier(byte[] data, Result r) {
        this.data = data;
        this.r = r;
    }

    private void err(String m) {
        r.errors.add(m);
        if (r.errors.size() >= 25) throw new Stop(null);
    }

    private boolean isTag(int idx, int t) {
        return idx > 0 && idx < cpCount && tag[idx] == t;
    }

    private void expect(int idx, int t, String what) {
        if (!isTag(idx, t)) err(thisName + ": bad constant pool reference #" + idx + " for " + what + " (expected tag " + t + ")");
    }

    private String utf8(int idx) {
        return isTag(idx, 1) ? utf[idx] : "?";
    }

    private void run() throws IOException {
        DataInputStream in = new DataInputStream(new ByteArrayInputStream(data));
        if (in.readInt() != 0xCAFEBABE) throw new Stop("not a class file (bad magic number)");
        in.readUnsignedShort();
        in.readUnsignedShort();
        cpCount = in.readUnsignedShort();
        tag = new int[cpCount];
        utf = new String[cpCount];
        ca = new int[cpCount];
        cb = new int[cpCount];
        for (int i = 1; i < cpCount; i++) {
            int t = in.readUnsignedByte();
            tag[i] = t;
            switch (t) {
                case 1: utf[i] = in.readUTF(); break;
                case 3: case 4: in.readInt(); break;
                case 5: case 6: in.readLong(); i++; break;
                case 7: case 8: case 16: case 19: case 20: ca[i] = in.readUnsignedShort(); break;
                case 9: case 10: case 11: case 12: case 17: case 18:
                    ca[i] = in.readUnsignedShort();
                    cb[i] = in.readUnsignedShort();
                    break;
                case 15: in.readUnsignedByte(); ca[i] = in.readUnsignedShort(); break;
                default: throw new Stop("bad constant pool tag " + t + " at #" + i);
            }
        }
        for (int i = 1; i < cpCount; i++) {
            switch (tag[i]) {
                case 7: case 8: expect(ca[i], 1, "name/string of #" + i); break;
                case 9: case 10: case 11:
                    expect(ca[i], 7, "class of member #" + i);
                    expect(cb[i], 12, "name-and-type of member #" + i);
                    break;
                case 12:
                    expect(ca[i], 1, "name of #" + i);
                    expect(cb[i], 1, "descriptor of #" + i);
                    break;
                default: break;
            }
        }
        in.readUnsignedShort(); // access flags
        int thisIdx = in.readUnsignedShort();
        int superIdx = in.readUnsignedShort();
        expect(thisIdx, 7, "this_class");
        if (superIdx != 0) expect(superIdx, 7, "super_class");
        if (isTag(thisIdx, 7)) thisName = utf8(ca[thisIdx]);
        int ic = in.readUnsignedShort();
        for (int i = 0; i < ic; i++) expect(in.readUnsignedShort(), 7, "interface");
        int fc = in.readUnsignedShort();
        for (int i = 0; i < fc; i++) {
            in.readUnsignedShort();
            expect(in.readUnsignedShort(), 1, "field name");
            expect(in.readUnsignedShort(), 1, "field descriptor");
            skipAttributes(in);
        }
        int mc = in.readUnsignedShort();
        for (int i = 0; i < mc; i++) readMethod(in);
        skipAttributes(in);
    }

    private static void skipAttributes(DataInputStream in) throws IOException {
        int n = in.readUnsignedShort();
        for (int i = 0; i < n; i++) {
            in.readUnsignedShort();
            skipFully(in, in.readInt());
        }
    }

    private static void skipFully(DataInputStream in, int len) throws IOException {
        byte[] tmp = new byte[Math.min(Math.max(len, 0), 4096)];
        int left = len;
        while (left > 0) {
            int n = Math.min(left, tmp.length);
            in.readFully(tmp, 0, n);
            left -= n;
        }
    }

    private void readMethod(DataInputStream in) throws IOException {
        int acc = in.readUnsignedShort();
        int nameIdx = in.readUnsignedShort();
        int descIdx = in.readUnsignedShort();
        expect(nameIdx, 1, "method name");
        expect(descIdx, 1, "method descriptor");
        String name = utf8(nameIdx), desc = utf8(descIdx);
        String where = thisName + "." + name + desc;
        boolean abs = (acc & 0x0400) != 0, nat = (acc & 0x0100) != 0, stat = (acc & 0x0008) != 0;
        boolean sawCode = false;
        int n = in.readUnsignedShort();
        for (int i = 0; i < n; i++) {
            String an = utf8(in.readUnsignedShort());
            int len = in.readInt();
            if ("Code".equals(an)) {
                byte[] body = new byte[len];
                in.readFully(body);
                sawCode = true;
                try {
                    new CodeCheck(where, desc, stat, new DataInputStream(new ByteArrayInputStream(body))).run();
                } catch (IOException e) {
                    err(where + ": malformed Code attribute (" + e + ")");
                }
            } else {
                skipFully(in, len);
            }
        }
        if (!sawCode && !abs && !nat) err(where + ": method has no Code attribute");
        if (sawCode && (abs || nat)) err(where + ": abstract/native method must not have Code");
    }

    // ---- descriptors ----

    private static int slotsOf(char c) {
        return c == 'J' || c == 'D' ? 2 : c == 'V' ? 0 : 1;
    }

    private static int argSlots(String d) {
        int i = 1, n = 0;
        while (d.charAt(i) != ')') {
            char c = d.charAt(i);
            if (c == 'L') {
                i = d.indexOf(';', i) + 1;
                n++;
            } else if (c == '[') {
                while (d.charAt(i) == '[') i++;
                if (d.charAt(i) == 'L') i = d.indexOf(';', i) + 1; else i++;
                n++;
            } else {
                n += slotsOf(c);
                i++;
            }
        }
        return n;
    }

    private static char retChar(String d) {
        char c = d.charAt(d.indexOf(')') + 1);
        return c == '[' ? 'L' : c;
    }

    private String memberDesc(int idx) {
        if (idx > 0 && idx < cpCount && (tag[idx] == 9 || tag[idx] == 10 || tag[idx] == 11)) {
            int nat = cb[idx];
            if (isTag(nat, 12)) return utf8(cb[nat]);
        }
        return null;
    }

    // ---- opcode tables ----

    private static final int[] POP = new int[256];
    private static final int[] PUSH = new int[256];
    private static final boolean[] SIMPLE = new boolean[256];

    private static void s(int from, int to, int pop, int push) {
        for (int op = from; op <= to; op++) {
            POP[op] = pop;
            PUSH[op] = push;
            SIMPLE[op] = true;
        }
    }

    static {
        s(0x00, 0x00, 0, 0); s(0x01, 0x08, 0, 1); s(0x09, 0x0a, 0, 2); s(0x0b, 0x0d, 0, 1);
        s(0x0e, 0x0f, 0, 2); s(0x10, 0x13, 0, 1); s(0x14, 0x14, 0, 2);
        s(0x15, 0x15, 0, 1); s(0x16, 0x16, 0, 2); s(0x17, 0x17, 0, 1); s(0x18, 0x18, 0, 2); s(0x19, 0x19, 0, 1);
        s(0x1a, 0x1d, 0, 1); s(0x1e, 0x21, 0, 2); s(0x22, 0x25, 0, 1); s(0x26, 0x29, 0, 2); s(0x2a, 0x2d, 0, 1);
        s(0x2e, 0x2e, 2, 1); s(0x2f, 0x2f, 2, 2); s(0x30, 0x30, 2, 1); s(0x31, 0x31, 2, 2); s(0x32, 0x35, 2, 1);
        s(0x36, 0x36, 1, 0); s(0x37, 0x37, 2, 0); s(0x38, 0x38, 1, 0); s(0x39, 0x39, 2, 0); s(0x3a, 0x3a, 1, 0);
        s(0x3b, 0x3e, 1, 0); s(0x3f, 0x42, 2, 0); s(0x43, 0x46, 1, 0); s(0x47, 0x4a, 2, 0); s(0x4b, 0x4e, 1, 0);
        s(0x4f, 0x4f, 3, 0); s(0x50, 0x50, 4, 0); s(0x51, 0x51, 3, 0); s(0x52, 0x52, 4, 0); s(0x53, 0x56, 3, 0);
        s(0x57, 0x57, 1, 0); s(0x58, 0x58, 2, 0);
        s(0x59, 0x59, 1, 2); s(0x5a, 0x5a, 2, 3); s(0x5b, 0x5b, 3, 4); s(0x5c, 0x5c, 2, 4);
        s(0x5d, 0x5d, 3, 5); s(0x5e, 0x5e, 4, 6); s(0x5f, 0x5f, 2, 2);
        for (int b = 0x60; b <= 0x70; b += 4) {
            s(b, b, 2, 1); s(b + 1, b + 1, 4, 2); s(b + 2, b + 2, 2, 1); s(b + 3, b + 3, 4, 2);
        }
        s(0x74, 0x74, 1, 1); s(0x75, 0x75, 2, 2); s(0x76, 0x76, 1, 1); s(0x77, 0x77, 2, 2);
        s(0x78, 0x78, 2, 1); s(0x79, 0x79, 3, 2); s(0x7a, 0x7a, 2, 1); s(0x7b, 0x7b, 3, 2);
        s(0x7c, 0x7c, 2, 1); s(0x7d, 0x7d, 3, 2);
        s(0x7e, 0x7e, 2, 1); s(0x7f, 0x7f, 4, 2); s(0x80, 0x80, 2, 1); s(0x81, 0x81, 4, 2);
        s(0x82, 0x82, 2, 1); s(0x83, 0x83, 4, 2);
        s(0x84, 0x84, 0, 0);
        s(0x85, 0x85, 1, 2); s(0x86, 0x86, 1, 1); s(0x87, 0x87, 1, 2); s(0x88, 0x88, 2, 1);
        s(0x89, 0x89, 2, 1); s(0x8a, 0x8a, 2, 2); s(0x8b, 0x8b, 1, 1); s(0x8c, 0x8c, 1, 2);
        s(0x8d, 0x8d, 1, 2); s(0x8e, 0x8e, 2, 1); s(0x8f, 0x8f, 2, 2); s(0x90, 0x90, 2, 1);
        s(0x91, 0x93, 1, 1);
        s(0x94, 0x94, 4, 1); s(0x95, 0x96, 2, 1); s(0x97, 0x98, 4, 1);
        s(0x99, 0x9e, 1, 0); s(0x9f, 0xa6, 2, 0); s(0xa7, 0xa7, 0, 0);
        s(0xaa, 0xab, 1, 0);
        s(0xac, 0xac, 1, 0); s(0xad, 0xad, 2, 0); s(0xae, 0xae, 1, 0); s(0xaf, 0xaf, 2, 0);
        s(0xb0, 0xb0, 1, 0); s(0xb1, 0xb1, 0, 0);
        s(0xbb, 0xbb, 0, 1); s(0xbc, 0xbc, 1, 1); s(0xbd, 0xbd, 1, 1); s(0xbe, 0xbe, 1, 1);
        s(0xbf, 0xbf, 1, 0); s(0xc0, 0xc1, 1, 1); s(0xc2, 0xc3, 1, 0); s(0xc6, 0xc7, 1, 0);
        s(0xc8, 0xc8, 0, 0);
    }

    private static int fixedLen(int op) {
        if (op <= 0x0f) return 1;
        if (op == 0x10 || op == 0x12) return 2;
        if (op == 0x11 || op == 0x13 || op == 0x14) return 3;
        if (op >= 0x15 && op <= 0x19) return 2;
        if (op <= 0x35) return 1;
        if (op >= 0x36 && op <= 0x3a) return 2;
        if (op <= 0x83) return 1;
        if (op == 0x84) return 3;
        if (op <= 0x98) return 1;
        if (op <= 0xa8) return 3;
        if (op == 0xa9) return 2;
        if (op >= 0xac && op <= 0xb1) return 1;
        if (op >= 0xb2 && op <= 0xb8) return 3;
        if (op == 0xb9 || op == 0xba) return 5;
        if (op == 0xbb) return 3;
        if (op == 0xbc) return 2;
        if (op == 0xbd) return 3;
        if (op == 0xbe || op == 0xbf) return 1;
        if (op == 0xc0 || op == 0xc1) return 3;
        if (op == 0xc2 || op == 0xc3) return 1;
        if (op == 0xc5) return 4;
        if (op == 0xc6 || op == 0xc7) return 3;
        if (op == 0xc8 || op == 0xc9) return 5;
        return -1;
    }

    private static boolean isUncond(int op) {
        return op == 0xa7 || op == 0xc8 || op == 0xaa || op == 0xab || op == 0xbf || (op >= 0xac && op <= 0xb1);
    }

    // ------------------------------------------------------------------
    // one method's Code attribute

    private class CodeCheck {
        final String where;
        final String desc;
        final boolean isStatic;
        final DataInputStream in;
        byte[] code;
        int n, maxStack, maxLocals;
        boolean[] isStart, isTarget;

        CodeCheck(String where, String desc, boolean isStatic, DataInputStream in) {
            this.where = where;
            this.desc = desc;
            this.isStatic = isStatic;
            this.in = in;
        }

        void e(String m) { err(where + ": " + m); }

        int u1(int p) { return code[p] & 0xFF; }
        int u2(int p) { return ((code[p] & 0xFF) << 8) | (code[p + 1] & 0xFF); }
        int s2(int p) { return (short) u2(p); }
        int s4(int p) {
            if (p < 0 || p + 4 > n) throw new Stop(where + ": instruction operands run past end of code");
            return ((code[p] & 0xFF) << 24) | ((code[p + 1] & 0xFF) << 16) | ((code[p + 2] & 0xFF) << 8) | (code[p + 3] & 0xFF);
        }

        int insnLen(int pc) {
            int op = u1(pc);
            if (op == 0xaa) {
                int p = (pc + 4) & ~3;
                int low = s4(p + 4), high = s4(p + 8);
                if (high < low || (long) high - low > 65535) throw new Stop(where + ": bad tableswitch bounds at pc " + pc);
                return p + 12 + (high - low + 1) * 4 - pc;
            }
            if (op == 0xab) {
                int p = (pc + 4) & ~3;
                int np = s4(p + 4);
                if (np < 0 || np > 65535) throw new Stop(where + ": bad lookupswitch size at pc " + pc);
                return p + 8 + np * 8 - pc;
            }
            if (op == 0xc4) {
                if (pc + 1 >= n) return -1;
                int op2 = u1(pc + 1);
                if (op2 == 0x84) return 6;
                if ((op2 >= 0x15 && op2 <= 0x19) || (op2 >= 0x36 && op2 <= 0x3a) || op2 == 0xa9) return 4;
                return -1;
            }
            return fixedLen(op);
        }

        /** {index, width} of a local-variable access, or null. */
        int[] local(int pc) {
            int op = u1(pc);
            if ((op >= 0x15 && op <= 0x19) || (op >= 0x36 && op <= 0x3a)) {
                return new int[]{u1(pc + 1), (op == 0x16 || op == 0x18 || op == 0x37 || op == 0x39) ? 2 : 1};
            }
            if (op >= 0x1a && op <= 0x2d) {
                int k = (op - 0x1a) / 4;
                return new int[]{(op - 0x1a) % 4, (k == 1 || k == 3) ? 2 : 1};
            }
            if (op >= 0x3b && op <= 0x4e) {
                int k = (op - 0x3b) / 4;
                return new int[]{(op - 0x3b) % 4, (k == 1 || k == 3) ? 2 : 1};
            }
            if (op == 0x84) return new int[]{u1(pc + 1), 1};
            if (op == 0xc4) {
                int op2 = u1(pc + 1);
                if (op2 == 0x84) return new int[]{u2(pc + 2), 1};
                return new int[]{u2(pc + 2), (op2 == 0x16 || op2 == 0x18 || op2 == 0x37 || op2 == 0x39) ? 2 : 1};
            }
            return null;
        }

        /** Absolute branch targets of the instruction at pc (empty if none). */
        int[] targets(int pc) {
            int op = u1(pc);
            if ((op >= 0x99 && op <= 0xa7) || op == 0xc6 || op == 0xc7) return new int[]{pc + s2(pc + 1)};
            if (op == 0xc8) return new int[]{pc + s4(pc + 1)};
            if (op == 0xaa) {
                int p = (pc + 4) & ~3;
                int low = s4(p + 4), high = s4(p + 8);
                int cnt = high - low + 1;
                int[] t = new int[cnt + 1];
                t[0] = pc + s4(p);
                for (int i = 0; i < cnt; i++) t[i + 1] = pc + s4(p + 12 + 4 * i);
                return t;
            }
            if (op == 0xab) {
                int p = (pc + 4) & ~3;
                int np = s4(p + 4);
                int[] t = new int[np + 1];
                t[0] = pc + s4(p);
                for (int i = 0; i < np; i++) t[i + 1] = pc + s4(p + 12 + 8 * i);
                return t;
            }
            return new int[0];
        }

        void run() throws IOException {
            maxStack = in.readUnsignedShort();
            maxLocals = in.readUnsignedShort();
            n = in.readInt();
            if (n <= 0 || n > 65535) {
                e("code length " + n + " is outside 1..65535");
                return;
            }
            code = new byte[n];
            in.readFully(code);
            int exc = in.readUnsignedShort();
            int[][] ex = new int[exc][4];
            for (int i = 0; i < exc; i++) for (int j = 0; j < 4; j++) ex[i][j] = in.readUnsignedShort();
            int an = in.readUnsignedShort();
            String smName = null;
            byte[] smBody = null;
            for (int i = 0; i < an; i++) {
                String name = utf8(in.readUnsignedShort());
                int len = in.readInt();
                byte[] body = new byte[len];
                in.readFully(body);
                if ("StackMap".equals(name) || "StackMapTable".equals(name)) {
                    smName = name;
                    smBody = body;
                }
            }

            int argSlots = argSlots(desc) + (isStatic ? 0 : 1);
            if (maxLocals < argSlots) e("max_locals " + maxLocals + " is smaller than the " + argSlots + " argument slot(s)");

            // 1. decode: find every instruction start
            isStart = new boolean[n + 1];
            isTarget = new boolean[n + 1];
            for (int pc = 0; pc < n; ) {
                int len = insnLen(pc);
                if (len < 0) { e("invalid opcode 0x" + Integer.toHexString(u1(pc)) + " at pc " + pc); return; }
                if (pc + len > n) { e("instruction at pc " + pc + " runs past the end of the code"); return; }
                isStart[pc] = true;
                pc += len;
            }

            // 2. operands
            for (int pc = 0; pc < n; pc++) {
                if (!isStart[pc]) continue;
                checkOperands(pc);
            }

            // 3. exception table
            boolean[] isHandler = new boolean[n + 1];
            for (int i = 0; i < exc; i++) {
                int st = ex[i][0], en = ex[i][1], h = ex[i][2], ct = ex[i][3];
                if (st >= en || en > n || !isStart[st] || (en < n && !isStart[en])) e("bad exception range [" + st + "," + en + ")");
                if (h >= n || !isStart[h]) e("exception handler " + h + " is not an instruction start");
                else isHandler[h] = true;
                if (ct != 0) expect(ct, 7, "catch type");
            }

            // 4. stack depth data-flow
            int[] depth = new int[n];
            Arrays.fill(depth, -1);
            ArrayDeque<Integer> work = new ArrayDeque<Integer>();
            depth[0] = 0;
            work.add(0);
            for (int i = 0; i < exc; i++) {
                int h = ex[i][2];
                if (h < n && isStart[h]) {
                    if (depth[h] == -1) { depth[h] = 1; work.add(h); }
                    else if (depth[h] != 1) e("exception handler at pc " + h + " reached with stack depth " + depth[h] + " (must be 1)");
                }
            }
            char rc = retChar(desc);
            while (!work.isEmpty()) {
                int pc = work.poll();
                int d = depth[pc];
                int op = u1(pc);
                int len = insnLen(pc);
                int[] pp = effect(pc, op);
                if (pp == null) continue;
                if (d < pp[0]) { e("stack underflow at pc " + pc + " (needs " + pp[0] + " slot(s), has " + d + ")"); continue; }
                int nd = d - pp[0] + pp[1];
                if (nd > maxStack) { e("stack overflow at pc " + pc + " (depth " + nd + " > max_stack " + maxStack + ")"); continue; }
                if (op >= 0xac && op <= 0xb1) {
                    char want = op == 0xb1 ? 'V' : op == 0xac ? 'I' : op == 0xad ? 'J' : op == 0xae ? 'F' : op == 0xaf ? 'D' : 'L';
                    char have = retChar(desc);
                    boolean intLike = have == 'I' || have == 'B' || have == 'C' || have == 'S' || have == 'Z';
                    if (want != (intLike ? 'I' : have)) e("return instruction at pc " + pc + " does not match return type of " + desc);
                }
                int[] tg = targets(pc);
                for (int t : tg) {
                    if (t >= 0 && t < n && isStart[t]) merge(depth, work, t, nd, pc);
                }
                if (!isUncond(op)) {
                    int nx = pc + len;
                    if (nx >= n) e("execution can fall off the end of the code after pc " + pc);
                    else merge(depth, work, nx, nd, pc);
                }
            }
            for (int pc = 0; pc < n; pc++) {
                if (isStart[pc] && depth[pc] == -1) {
                    int q = pc;
                    while (q < n && (!isStart[q] || depth[q] == -1)) q++;
                    r.warnings.add(where + ": unreachable code at pc " + pc + ".." + (q - 1));
                    pc = q - 1;
                }
            }

            // 5. StackMap
            boolean needFrames = false;
            for (int pc = 0; pc < n; pc++) if (isTarget[pc] || isHandler[pc]) { needFrames = true; break; }
            if (smBody == null) {
                if (needFrames) e("no StackMap attribute, but the method has branch targets/handlers (CLDC preverification needs one)");
            } else if ("StackMap".equals(smName)) {
                checkStackMap(smBody, depth, isHandler);
            }
        }

        void merge(int[] depth, ArrayDeque<Integer> work, int t, int d, int from) {
            if (depth[t] == -1) { depth[t] = d; work.add(t); }
            else if (depth[t] != d) e("inconsistent stack depth at pc " + t + ": " + depth[t] + " vs " + d + " (from pc " + from + ")");
        }

        /** {pops, pushes} in slots, or null if the instruction can't be analysed. */
        int[] effect(int pc, int op) {
            if (op == 0xc4) {
                int op2 = u1(pc + 1);
                return new int[]{POP[op2], PUSH[op2]};
            }
            if (SIMPLE[op]) return new int[]{POP[op], PUSH[op]};
            switch (op) {
                case 0xb2: case 0xb3: case 0xb4: case 0xb5: {
                    String d = memberDesc(u2(pc + 1));
                    int sz = d == null ? 1 : slotsOf(d.charAt(0));
                    if (op == 0xb2) return new int[]{0, sz};
                    if (op == 0xb3) return new int[]{sz, 0};
                    if (op == 0xb4) return new int[]{1, sz};
                    return new int[]{1 + sz, 0};
                }
                case 0xb6: case 0xb7: case 0xb8: case 0xb9: {
                    String d = memberDesc(u2(pc + 1));
                    if (d == null || d.indexOf('(') != 0) return null;
                    int args = argSlots(d) + (op == 0xb8 ? 0 : 1);
                    return new int[]{args, slotsOf(retChar(d))};
                }
                case 0xc5: return new int[]{u1(pc + 3), 1};
                default: return null;
            }
        }

        void checkTarget(int pc, int t) {
            if (t < 0 || t >= n || !isStart[t]) e("branch at pc " + pc + " targets " + t + ", which is not an instruction start");
            else isTarget[t] = true;
        }

        void checkOperands(int pc) {
            int op = u1(pc);
            if (op == 0xa8 || op == 0xa9 || op == 0xc9) { e("jsr/ret at pc " + pc + " is not supported"); return; }
            if (op == 0xba) { e("invokedynamic at pc " + pc + " is not valid in a CLDC class"); return; }
            int[] loc = local(pc);
            if (loc != null && loc[0] + loc[1] > maxLocals) {
                e("local variable " + loc[0] + " used at pc " + pc + " but max_locals is " + maxLocals);
            }
            int[] tg = targets(pc);
            for (int t : tg) checkTarget(pc, t);
            if (op == 0xab) {
                int p = (pc + 4) & ~3;
                int np = s4(p + 4);
                for (int i = 1; i < np; i++) {
                    if (s4(p + 8 + 8 * i) <= s4(p + 8 + 8 * (i - 1))) { e("lookupswitch keys not sorted at pc " + pc); break; }
                }
            }
            switch (op) {
                case 0x12: constOperand(pc, u1(pc + 1), false); break;
                case 0x13: constOperand(pc, u2(pc + 1), false); break;
                case 0x14: constOperand(pc, u2(pc + 1), true); break;
                case 0xb2: case 0xb3: case 0xb4: case 0xb5:
                    if (!isTag(u2(pc + 1), 9)) e("pc " + pc + ": field instruction needs a Fieldref constant (#" + u2(pc + 1) + ")");
                    break;
                case 0xb6: case 0xb7: case 0xb8:
                    if (!isTag(u2(pc + 1), 10) && !isTag(u2(pc + 1), 11)) e("pc " + pc + ": invoke needs a Methodref constant (#" + u2(pc + 1) + ")");
                    break;
                case 0xb9:
                    if (!isTag(u2(pc + 1), 11)) e("pc " + pc + ": invokeinterface needs an InterfaceMethodref constant");
                    else {
                        String d = memberDesc(u2(pc + 1));
                        if (d != null && d.indexOf('(') == 0 && u1(pc + 3) != argSlots(d) + 1) {
                            e("pc " + pc + ": invokeinterface count " + u1(pc + 3) + " should be " + (argSlots(d) + 1));
                        }
                    }
                    break;
                case 0xbb: case 0xbd: case 0xc0: case 0xc1: case 0xc5:
                    if (!isTag(u2(pc + 1), 7)) e("pc " + pc + ": instruction needs a Class constant (#" + u2(pc + 1) + ")");
                    if (op == 0xc5 && u1(pc + 3) < 1) e("pc " + pc + ": multianewarray with zero dimensions");
                    break;
                case 0xbc: {
                    int at = u1(pc + 1);
                    if (at < 4 || at > 11) e("pc " + pc + ": bad newarray type " + at);
                    break;
                }
                default: break;
            }
        }

        void constOperand(int pc, int idx, boolean wide) {
            boolean ok = wide ? (isTag(idx, 5) || isTag(idx, 6))
                    : (isTag(idx, 3) || isTag(idx, 4) || isTag(idx, 8));
            if (!ok) e("pc " + pc + ": ldc operand #" + idx + " is not a loadable constant of the right size");
        }

        // ---- CLDC StackMap ----

        int vtype(DataInputStream s, int[] slots) throws IOException {
            int t = s.readUnsignedByte();
            if (t == 7) expect(s.readUnsignedShort(), 7, "StackMap object type");
            else if (t == 8) {
                int off = s.readUnsignedShort();
                if (off >= n || !isStart[off] || u1(off) != 0xbb) e("StackMap 'uninitialized' offset " + off + " is not a 'new' instruction");
            } else if (t > 8) throw new IOException("bad verification type " + t);
            return t;
        }

        /** Reads a list of verification types; returns slot count (long/double = 2, a Top right after one is its 2nd half). */
        int vlist(DataInputStream s, int count) throws IOException {
            int slots = 0;
            int prev = -1;
            for (int i = 0; i < count; i++) {
                int t = vtype(s, null);
                if (t == 0 && (prev == 3 || prev == 4)) { prev = 0; continue; }
                slots += (t == 3 || t == 4) ? 2 : 1;
                prev = t;
            }
            return slots;
        }

        void checkStackMap(byte[] body, int[] depth, boolean[] isHandler) {
            Map<Integer, Integer> frames = new HashMap<Integer, Integer>();
            try {
                DataInputStream s = new DataInputStream(new ByteArrayInputStream(body));
                int cnt = s.readUnsignedShort();
                int prev = -1;
                for (int i = 0; i < cnt; i++) {
                    int off = s.readUnsignedShort();
                    int nl = s.readUnsignedShort();
                    int lslots = vlist(s, nl);
                    int ns = s.readUnsignedShort();
                    int sslots = vlist(s, ns);
                    if (off >= n || !isStart[off]) e("StackMap entry at offset " + off + " is not an instruction start");
                    if (off <= prev) e("StackMap entries are not in increasing offset order (offset " + off + ")");
                    prev = off;
                    if (lslots > maxLocals) e("StackMap entry at " + off + " has " + lslots + " local slot(s) but max_locals is " + maxLocals);
                    if (sslots > maxStack) e("StackMap entry at " + off + " has " + sslots + " stack slot(s) but max_stack is " + maxStack);
                    if (off >= 0 && off < n && depth[off] >= 0 && depth[off] != sslots) {
                        e("StackMap entry at " + off + " says stack depth " + sslots + " but the code reaches it with " + depth[off]);
                    }
                    frames.put(off, sslots);
                }
                if (s.available() > 0) e("StackMap attribute has " + s.available() + " trailing byte(s)");
            } catch (IOException ex) {
                e("malformed StackMap attribute (" + ex.getMessage() + ")");
                return;
            }
            for (int pc = 0; pc < n; pc++) {
                if ((isTarget[pc] || isHandler[pc]) && !frames.containsKey(pc)) {
                    e("no StackMap entry at " + (isHandler[pc] ? "exception handler" : "branch target") + " pc " + pc);
                }
            }
        }
    }
}
