package com.dashers.j2mebuilderide.compiler;

import java.util.Vector;
import java.util.Hashtable;

/**
 * Hand-written tokenizer. CLDC 1.1 compatible (StringBuffer, Vector,
 * Hashtable, no String.split/regex, no generics).
 *
 * Numeric literals (Java 1.4 level): 123 (int), 123L (long), 0xFF / 0xFFL,
 * 1.5 / 1.5d (double), 1.5f (float), exponent forms (1e10, 2.5E-3f), and
 * leading/trailing-dot forms (.5, 1.). Int and long literals are INT_LIT
 * tokens (Token.numKind tells them apart); float and double literals are
 * FLOAT_LIT tokens. Octal integer literals and the minimum signed int/long
 * values are accepted, as are 1.f / 1.d / 1.e3 forms. Hex floating point remains
 * outside the current lexer grammar.
 *
 * Source level (mirrors javac -source): 'assert' is a keyword only at
 * source level 1.4 and up; below that it lexes as an ordinary identifier so
 * pre-1.4 sources that used it as a name keep compiling. 'enum' is not a
 * keyword at any level this compiler supports (<1.5) -- the hook below
 * exists so adding enums later cannot break older sources.
 */
public class Lexer {

    private static final Hashtable KEYWORDS = new Hashtable();
    static {
        String[] kw = {
            "class", "public", "private", "protected", "static", "void",
            "int", "boolean", "byte", "short", "char", "String", "true", "false", "if", "else",
            "while", "for", "do", "return", "new", "this", "extends", "null",
            "break", "continue", "import", "implements", "super", "package",
            "try", "catch", "finally", "throw", "switch", "case", "default",
            "instanceof", "final", "abstract", "interface",
            "long", "float", "double", "strictfp"
        };
        for (int i = 0; i < kw.length; i++) {
            KEYWORDS.put(kw[i], Boolean.TRUE);
        }
    }

    private String src;
    private int pos;
    private int len;
    private int line;
    private int sourceLevel;

    public Lexer(String source) {
        this(source, Compiler.SOURCE_1_4);
    }

    /** @param sourceLevel Compiler.SOURCE_1_3 or Compiler.SOURCE_1_4 */
    public Lexer(String source, int sourceLevel) {
        this.src = source;
        this.pos = 0;
        this.len = source.length();
        this.line = 1;
        this.sourceLevel = sourceLevel;
    }

    /** true if `text` is reserved at the configured source level. */
    private boolean isKeywordAtLevel(String text) {
        if (!KEYWORDS.containsKey(text)) {
            // 'assert' is added to KEYWORDS-by-level here rather than in the static table,
            // because whether it is reserved depends on the instance's source level.
            return sourceLevel >= Compiler.SOURCE_1_4 && text.equals("assert");
        }
        return true;
        // (enum would go here: reserved only if sourceLevel >= 1.5 -- never true today.)
    }
    public Vector tokenize() throws CompileError {
        Vector out = new Vector();
        for (;;) {
            skipWhitespaceAndComments();
            if (pos >= len) {
                out.addElement(new Token(Token.EOF, "<eof>", line));
                break;
            }
            char c = src.charAt(pos);
            int startLine = line;

            if (isIdentStart(c)) {
                int s = pos;
                while (pos < len && isIdentPart(src.charAt(pos))) pos++;
                String text = src.substring(s, pos);
                if (isKeywordAtLevel(text)) {
                    out.addElement(new Token(Token.KEYWORD, text, startLine));
                } else {
                    out.addElement(new Token(Token.IDENT, text, startLine));
                }
                continue;
            }

            if (c == '0' && pos + 1 < len && (src.charAt(pos + 1) == 'x' || src.charAt(pos + 1) == 'X')) {
                int s = pos + 2;
                pos = s;
                while (pos < len && Character.digit(src.charAt(pos), 16) >= 0) pos++;
                String digits = src.substring(s, pos);
                boolean isLong = pos < len && (src.charAt(pos) == 'L' || src.charAt(pos) == 'l');
                if (isLong) pos++;
                if (digits.length() == 0 || digits.length() > (isLong ? 16 : 8)) {
                    throw new CompileError("invalid hex literal '0x" + digits + "'", startLine);
                }
                if (isLong) {
                    long lv = 0;
                    for (int i = 0; i < digits.length(); i++) lv = (lv << 4) | Character.digit(digits.charAt(i), 16);
                    Token lt = new Token(Token.INT_LIT, "0x" + digits + "L", startLine);
                    lt.numKind = Token.NUM_LONG;
                    lt.longValue = lv;
                    out.addElement(lt);
                    continue;
                }
                int hv = (int) Long.parseLong(digits, 16);
                Token ht = new Token(Token.INT_LIT, Integer.toString(hv), startLine);
                ht.intValue = hv;
                out.addElement(ht);
                continue;
            }

            if ((c >= '0' && c <= '9')
                    || (c == '.' && pos + 1 < len && src.charAt(pos + 1) >= '0' && src.charAt(pos + 1) <= '9')) {
                out.addElement(lexNumber(startLine));
                continue;
            }

            if (c == '\'') {
                pos++;
                if (pos >= len) throw new CompileError("unterminated char literal", startLine);
                char ch = src.charAt(pos);
                int value;
                if (ch == '\\') {
                    value = readEscape(startLine, "char");
                } else {
                    if (ch == '\n') throw new CompileError("unterminated char literal", startLine);
                    value = ch;
                    pos++;
                }
                if (pos >= len || src.charAt(pos) != '\'') throw new CompileError("char literal must contain exactly one character", startLine);
                pos++; // closing quote
                Token t = new Token(Token.INT_LIT, "'" + ((char) value) + "'", startLine);
                t.intValue = value;
                t.isChar = true;
                out.addElement(t);
                continue;
            }

            if (c == '"') {
                pos++;
                StringBuffer sb = new StringBuffer();
                while (pos < len && src.charAt(pos) != '"') {
                    char ch = src.charAt(pos);
                    if (ch == '\\' && pos + 1 < len) {
                        sb.append((char) readEscape(startLine, "string"));
                        continue;
                    }
                    if (ch == '\n') throw new CompileError("unterminated string literal", startLine);
                    sb.append(ch);
                    pos++;
                }
                if (pos >= len) throw new CompileError("unterminated string literal", startLine);
                pos++; // closing quote
                Token t = new Token(Token.STRING_LIT, sb.toString(), startLine);
                t.strValue = sb.toString();
                out.addElement(t);
                continue;
            }

            // operators / punctuation, longest match first
            String[] multi = {
                "==", "!=", "<=", ">=", "&&", "||", "++", "--",
                "+=", "-=", "*=", "/=", "%=",
                ">>>=", ">>>", ">>=", ">>", "<<=", "<<",
                "&=", "|=", "^="
            };
            String matched = null;
            for (int i = 0; i < multi.length; i++) {
                String m = multi[i];
                if (src.regionMatches(false, pos, m, 0, m.length())) {
                    matched = m;
                    break;
                }
            }
            if (matched != null) {
                out.addElement(new Token(Token.OP, matched, startLine));
                pos += matched.length();
                continue;
            }

            if ("{}()[];,.=+-*/%<>!&|^~:?@".indexOf(c) >= 0) {
                out.addElement(new Token(Token.OP, String.valueOf(c), startLine));
                pos++;
                continue;
            }

            throw new CompileError("unexpected character '" + c + "'", startLine);
        }
        return out;
    }

    /** Reads one escape sequence; pos is at the backslash. Leaves pos after the sequence. */
    private int readEscape(int startLine, String what) throws CompileError {
        pos++; // backslash
        if (pos >= len) throw new CompileError("unterminated " + what + " literal", startLine);
        char esc = src.charAt(pos);
        int v;
        switch (esc) {
            case 'n': v = '\n'; break;
            case 't': v = '\t'; break;
            case 'r': v = '\r'; break;
            case 'b': v = '\b'; break;
            case 'f': v = '\f'; break;
            case '\'': v = '\''; break;
            case '"': v = '"'; break;
            case '\\': v = '\\'; break;
            case 'u': {
                while (pos < len && src.charAt(pos) == 'u') pos++;
                if (pos + 4 > len) throw new CompileError("illegal unicode escape in " + what + " literal", startLine);
                int u = 0;
                for (int i = 0; i < 4; i++) {
                    int d = Character.digit(src.charAt(pos + i), 16);
                    if (d < 0) throw new CompileError("illegal unicode escape in " + what + " literal", startLine);
                    u = (u << 4) | d;
                }
                pos += 4;
                return u;
            }
            default:
                if (esc >= '0' && esc <= '7') {
                    // octal escape: \0..\377 (up to 3 digits, 3 only if the first is 0-3)
                    int maxDigits = (esc <= '3') ? 3 : 2;
                    int o = 0, n = 0;
                    while (n < maxDigits && pos < len && src.charAt(pos) >= '0' && src.charAt(pos) <= '7') {
                        o = o * 8 + (src.charAt(pos) - '0');
                        pos++;
                        n++;
                    }
                    return o;
                }
                throw new CompileError("illegal escape character '\\" + esc + "' in " + what + " literal", startLine);
        }
        pos++;
        return v;
    }

    /** Parses an octal literal body ("017"), range-checked to `bits` bits (as unsigned). */
    private long parseOctal(String body, int bits, int startLine, String kind) throws CompileError {
        long v = 0;
        for (int i = 1; i < body.length(); i++) {
            int d = body.charAt(i) - '0';
            if (d < 0 || d > 7) throw new CompileError("integer number too large or digit not octal: '" + body + "'", startLine);
            if (bits == 64 && (v >>> 61) != 0) throw new CompileError("invalid " + kind + " literal '" + body + "' (out of range)", startLine);
            v = (v << 3) | d;
            if (bits == 32 && v > 0xFFFFFFFFL) throw new CompileError("invalid " + kind + " literal '" + body + "' (out of range)", startLine);
        }
        return v;
    }

    private boolean isDigit(int p) {
        return p < len && src.charAt(p) >= '0' && src.charAt(p) <= '9';
    }

    /** Lexes a decimal int/long/float/double literal starting at pos. */
    private Token lexNumber(int startLine) throws CompileError {
        int s = pos;
        boolean isFp = false;
        while (isDigit(pos)) pos++;
        if (pos < len && src.charAt(pos) == '.') {
            // "1.5", "1.", ".5" -- but not "1.foo" (the dot then belongs to a member access)
            boolean fracDigit = isDigit(pos + 1);
            char nx = (pos + 1 < len) ? src.charAt(pos + 1) : '\0';
            // "1.f" "1.d" "1.e3": the dot belongs to the number when what follows is a
            // float suffix / exponent, not the start of a longer identifier ("1.foo").
            boolean suffixAfterDot = (nx == 'f' || nx == 'F' || nx == 'd' || nx == 'D')
                    && !(pos + 2 < len && isIdentPart(src.charAt(pos + 2)));
            boolean expAfterDot = (nx == 'e' || nx == 'E')
                    && (isDigit(pos + 2) || ((pos + 2 < len && (src.charAt(pos + 2) == '+' || src.charAt(pos + 2) == '-')) && isDigit(pos + 3)));
            boolean trailingDot = !fracDigit
                    && (suffixAfterDot || expAfterDot
                        || pos + 1 >= len || !(isIdentStart(nx) || nx == '.'));
            if (fracDigit || trailingDot) {
                isFp = true;
                pos++;
                while (isDigit(pos)) pos++;
            }
        }
        if (pos < len && (src.charAt(pos) == 'e' || src.charAt(pos) == 'E')) {
            int q = pos + 1;
            if (q < len && (src.charAt(q) == '+' || src.charAt(q) == '-')) q++;
            if (isDigit(q)) {
                isFp = true;
                pos = q;
                while (isDigit(pos)) pos++;
            } else {
                throw new CompileError("malformed floating-point literal '" + src.substring(s, pos) + "'", startLine);
            }
        }
        String body = src.substring(s, pos);
        char suffix = (pos < len) ? src.charAt(pos) : '\0';
        if (suffix == 'L' || suffix == 'l') {
            if (isFp) throw new CompileError("malformed floating-point literal '" + body + suffix + "'", startLine);
            pos++;
            Token t = new Token(Token.INT_LIT, body + "L", startLine);
            t.numKind = Token.NUM_LONG;
            if (body.length() > 1 && body.charAt(0) == '0') {
                t.longValue = parseOctal(body, 64, startLine, "long");
                return t;
            }
            if (body.equals("9223372036854775808")) {
                t.longValue = Long.MIN_VALUE;
                t.minLit = true;
                return t;
            }
            try {
                t.longValue = Long.parseLong(body);
            } catch (NumberFormatException e) {
                throw new CompileError("invalid long literal '" + body + "L' (out of range)", startLine);
            }
            return t;
        }
        if (suffix == 'f' || suffix == 'F') {
            pos++;
            Token t = new Token(Token.FLOAT_LIT, body + "f", startLine);
            t.numKind = Token.NUM_FLOAT;
            try {
                t.floatValue = Float.parseFloat(body);
            } catch (NumberFormatException e) {
                throw new CompileError("invalid float literal '" + body + "f'", startLine);
            }
            if (Float.isInfinite(t.floatValue)) throw new CompileError("floating-point number too large: '" + body + "f'", startLine);
            return t;
        }
        if (isFp || suffix == 'd' || suffix == 'D') {
            if (suffix == 'd' || suffix == 'D') pos++;
            Token t = new Token(Token.FLOAT_LIT, body, startLine);
            t.numKind = Token.NUM_DOUBLE;
            try {
                t.doubleValue = Double.parseDouble(body);
            } catch (NumberFormatException e) {
                throw new CompileError("invalid double literal '" + body + "'", startLine);
            }
            if (Double.isInfinite(t.doubleValue)) throw new CompileError("floating-point number too large: '" + body + "'", startLine);
            return t;
        }
        Token t = new Token(Token.INT_LIT, body, startLine);
        if (body.length() > 1 && body.charAt(0) == '0') {
            t.intValue = (int) parseOctal(body, 32, startLine, "integer");
            return t;
        }
        if (body.equals("2147483648")) {
            t.intValue = Integer.MIN_VALUE;
            t.minLit = true;
            return t;
        }
        try {
            t.intValue = Integer.parseInt(body);
        } catch (NumberFormatException e) {
            throw new CompileError("invalid integer literal '" + body + "'", startLine);
        }
        return t;
    }

    private void skipWhitespaceAndComments() {
        for (;;) {
            if (pos >= len) return;
            char c = src.charAt(pos);
            if (c == '\n') { line++; pos++; continue; }
            if (c == ' ' || c == '\t' || c == '\r') { pos++; continue; }
            if (c == '/' && pos + 1 < len && src.charAt(pos + 1) == '/') {
                while (pos < len && src.charAt(pos) != '\n') pos++;
                continue;
            }
            if (c == '/' && pos + 1 < len && src.charAt(pos + 1) == '*') {
                pos += 2;
                while (pos + 1 < len && !(src.charAt(pos) == '*' && src.charAt(pos + 1) == '/')) {
                    if (src.charAt(pos) == '\n') line++;
                    pos++;
                }
                pos += 2;
                continue;
            }
            return;
        }
    }

    private boolean isIdentStart(char c) {
        return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == '_' || c == '$';
    }

    private boolean isIdentPart(char c) {
        return isIdentStart(c) || (c >= '0' && c <= '9');
    }
}
