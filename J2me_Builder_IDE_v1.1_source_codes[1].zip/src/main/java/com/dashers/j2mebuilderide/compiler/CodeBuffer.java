package com.dashers.j2mebuilderide.compiler;

/**
 * Growable byte buffer used to emit JVM bytecode. Supports patching
 * 2-byte branch offsets after forward-jump targets become known.
 */
public class CodeBuffer {
    private byte[] buf;
    private int len;

    public CodeBuffer() {
        buf = new byte[64];
        len = 0;
    }

    public int pc() {
        return len;
    }

    private void ensure(int extra) {
        if (len + extra <= buf.length) return;
        int newLen = buf.length * 2;
        while (newLen < len + extra) newLen *= 2;
        byte[] nb = new byte[newLen];
        System.arraycopy(buf, 0, nb, 0, len);
        buf = nb;
    }

    public void u1(int v) {
        ensure(1);
        buf[len++] = (byte) (v & 0xFF);
    }

    public void u2(int v) {
        ensure(2);
        buf[len++] = (byte) ((v >> 8) & 0xFF);
        buf[len++] = (byte) (v & 0xFF);
    }

    public void s2(int v) {
        u2(v & 0xFFFF);
    }

    public void u4(int v) {
        ensure(4);
        buf[len++] = (byte) ((v >> 24) & 0xFF);
        buf[len++] = (byte) ((v >> 16) & 0xFF);
        buf[len++] = (byte) ((v >> 8) & 0xFF);
        buf[len++] = (byte) (v & 0xFF);
    }

    /** Reserve 2 bytes now, returns position to patch later with patchU2. */
    public int reserveU2() {
        int p = len;
        u2(0);
        return p;
    }

    public void patchU2(int pos, int v) {
        buf[pos] = (byte) ((v >> 8) & 0xFF);
        buf[pos + 1] = (byte) (v & 0xFF);
    }

    /** Patch a branch offset stored at `pos` (2 bytes) computed as target - opcodePos. */
    public void patchBranch(int pos, int opcodePos, int targetPc) {
        int offset = targetPc - opcodePos;
        if (offset < -32768 || offset > 32767) {
            throw new MethodTooLargeException("method too large: branch offset " + offset
                + " exceeds 16-bit range (split the method into smaller ones)");
        }
        patchU2(pos, offset & 0xFFFF);
    }

    public byte[] toByteArray() {
        if (len > 65535) {
            throw new MethodTooLargeException("method too large: code is " + len + " bytes (limit 65535)");
        }
        byte[] out = new byte[len];
        System.arraycopy(buf, 0, out, 0, len);
        return out;
    }

    public int length() {
        return len;
    }
}