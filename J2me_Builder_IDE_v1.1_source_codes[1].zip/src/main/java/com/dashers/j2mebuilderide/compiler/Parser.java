package com.dashers.j2mebuilderide.compiler;

import java.util.Vector;
import java.util.Hashtable;

/**
 * Recursive-descent parser for the supported Java subset (Java 1.4 source
 * level, minus the features listed in T.java). CLDC 1.1 compatible.
 *
 * 1.4 additions over the old 1.1/1.3-level grammar: long/float/double types,
 * literals and primitive casts ((int) x, (float) i, ...); the assert statement;
 * the strictfp modifier (accepted and recorded on methods, no effect on the
 * bytecode semantics this compiler emits beyond setting ACC_STRICT).
 */
public class Parser {

    private Vector toks;
    private int idx;
    private ApiIndex api;
    private Vector imports = new Vector(); // ImportDecl, populated before class body
    private Vector siblingNames = new Vector(); // Strings; simple names of every top-level class in this file,
                                                 // pre-scanned before parsing so forward references
                                                 // ("class A { B b; } class B {}") resolve correctly.
    private Hashtable nestedNames = new Hashtable(); // simple name -> FQCN of every nested class/enum in the file
    private Vector extraClasses = new Vector();      // nested + anonymous classes, lifted to top level
    private Hashtable anonCounters = new Hashtable();
    private Vector scopeNames = new Vector();        // enclosing local variables (for anonymous-class capture)
    private Vector scopeTypes = new Vector();
    private boolean inStaticCtx;
    private ClassNode curClass;
    private boolean nextIsLocal;
    private String packageName = ""; // dotted, "" if the file has no package declaration

    private int sourceLevel = Compiler.SOURCE_1_4;

    public Parser(Vector tokens, ApiIndex api) {
        this.toks = prefilter(tokens);
        this.idx = 0;
        this.api = api;
    }

    /** Token pre-pass for syntax that has no effect on the generated code:
     *  annotations (@Override, @Deprecated(..)), the 'volatile' / 'transient' modifiers, and
     *  the 'synchronized' method modifier (recorded on the following token; the statement form
     *  'synchronized (x) {...}' is left alone). */
    private static Vector prefilter(Vector in) {
        Vector out = new Vector();
        boolean pendingSync = false;
        for (int i = 0; i < in.size(); i++) {
            Token t = (Token) in.elementAt(i);
            if (t.isOp("@") && i + 1 < in.size() && ((Token) in.elementAt(i + 1)).type == Token.IDENT) {
                int j = i + 1;
                while (j + 2 < in.size() && ((Token) in.elementAt(j + 1)).isOp(".") && ((Token) in.elementAt(j + 2)).type == Token.IDENT) j += 2;
                if (j + 1 < in.size() && ((Token) in.elementAt(j + 1)).isOp("(")) {
                    int depth = 0;
                    j++;
                    for (; j < in.size(); j++) {
                        Token u = (Token) in.elementAt(j);
                        if (u.isOp("(")) depth++;
                        else if (u.isOp(")")) { depth--; if (depth == 0) break; }
                    }
                }
                i = j;
                continue;
            }
            if (t.type == Token.IDENT && (t.text.equals("volatile") || t.text.equals("transient"))) continue;
            if (t.type == Token.IDENT && t.text.equals("synchronized")
                    && !(i + 1 < in.size() && ((Token) in.elementAt(i + 1)).isOp("("))) {
                pendingSync = true;
                continue;
            }
            if (pendingSync && !(t.isKeyword("public") || t.isKeyword("private") || t.isKeyword("protected")
                    || t.isKeyword("static") || t.isKeyword("final") || t.isKeyword("abstract") || t.isKeyword("strictfp"))) {
                t.syncMod = true;
                pendingSync = false;
            }
            out.addElement(t);
        }
        return out;
    }

    /** @param sourceLevel Compiler.SOURCE_1_3 or SOURCE_1_4. The lexer already decides
     *  whether 'assert' is a keyword; the parser keeps the level so source-level-specific
     *  diagnostics (and future 1.5+ gating) have one place to look. */
    public Parser(Vector tokens, ApiIndex api, int sourceLevel) {
        this(tokens, api);
        this.sourceLevel = sourceLevel;
    }

    private Token peek() {
        return (Token) toks.elementAt(idx);
    }

    private Token peek2() {
        int j = idx + 1;
        if (j >= toks.size()) return (Token) toks.elementAt(toks.size() - 1);
        return (Token) toks.elementAt(j);
    }

    private Token peek3() {
        int j = idx + 2;
        if (j >= toks.size()) return (Token) toks.elementAt(toks.size() - 1);
        return (Token) toks.elementAt(j);
    }

    private Token advance() {
        Token t = (Token) toks.elementAt(idx);
        if (idx < toks.size() - 1) idx++;
        return t;
    }

    private Token expectOp(String op) throws CompileError {
        Token t = peek();
        if (!t.isOp(op)) throw err("expected '" + op + "' but found '" + t.text + "'");
        return advance();
    }

    private Token expectKeyword(String kw) throws CompileError {
        Token t = peek();
        if (!t.isKeyword(kw)) throw err("expected '" + kw + "' but found '" + t.text + "'");
        return advance();
    }

    private Token expectIdent() throws CompileError {
        Token t = peek();
        if (t.isKeyword("assert")) throw assertAsIdentifier();
        if (t.type != Token.IDENT) throw err("expected identifier but found '" + t.text + "'");
        return advance();
    }

    /** Message text mirrors ECJ problem id 440 (see EcjMessages.translate). */
    private CompileError assertAsIdentifier() {
        return err("'assert' should not be used as an identifier, since it is a reserved keyword from source level 1.4 on",
                "this project is being compiled at source level 1.4; to keep using 'assert' as a name, compile at source level 1.3");
    }

    private CompileError err(String msg) {
        return new CompileError(msg, peek().line);
    }

    private CompileError err(String msg, String hint) {
        return new CompileError(msg, peek().line, hint);
    }

    /** True if, skipping any modifiers, the next real token is "class" or "interface".
     *  Used to detect another top-level type starting in the same file (both are
     *  supported as top-level declarations), to detect nested types (still not
     *  supported), and while pre-scanning sibling names. */
    private boolean isClassDeclAhead() {
        int save = idx;
        for (;;) {
            Token t = (Token) toks.elementAt(idx);
            if (t.isKeyword("public") || t.isKeyword("private") || t.isKeyword("protected") || t.isKeyword("strictfp") || t.isKeyword("static") || t.isKeyword("final") || t.isKeyword("abstract")) {
                idx++;
                continue;
            }
            break;
        }
        boolean r = peek().isKeyword("class") || peek().isKeyword("interface")
                || (peek().type == Token.IDENT && peek().text.equals("enum") && peek2().type == Token.IDENT);
        idx = save;
        return r;
    }

    /** Name of the class/interface at a position where isClassDeclAhead() returned
     *  true, without consuming any tokens. Used only to make an error message concrete. */
    private String peekClassDeclName() {
        int save = idx;
        while (peek().isKeyword("public") || peek().isKeyword("private") || peek().isKeyword("protected") || peek().isKeyword("strictfp") || peek().isKeyword("static") || peek().isKeyword("final") || peek().isKeyword("abstract")) {
            idx++;
        }
        idx++; // 'class' or 'interface'
        String name = (peek().type == Token.IDENT) ? peek().text : "?";
        idx = save;
        return name;
    }

    // ---------------- name resolution (imports-aware) ----------------

    /** Resolves a simple or dotted type name to a dotted FQCN using imports, sibling
     *  top-level classes in this same file, java.lang fallback, and the API index.
     *  Sibling classes are checked before the API so a local class can shadow an
     *  unimported API class of the same simple name (matches normal Java scoping:
     *  same-compilation-unit types win over anything requiring an import). */
    private String resolveTypeName(String simple) {
        if (simple.indexOf('.') >= 0) {
            // Outer.Inner (first segment is a class) -> Outer$Inner ; java.util.Vector stays as is
            int dot = simple.indexOf('.');
            String first = simple.substring(0, dot);
            if (Character.isUpperCase(first.charAt(0))) {
                return resolveTypeName(first) + "$" + simple.substring(dot + 1).replace('.', '$');
            }
            return simple;
        }
        if (nestedNames.containsKey(simple)) return (String) nestedNames.get(simple);
        for (int i = 0; i < imports.size(); i++) {
            ImportDecl id = (ImportDecl) imports.elementAt(i);
            if (!id.wildcard) {
                if (id.path.endsWith("." + simple) || id.path.equals(simple)) {
                    String imported = id.path;
                    if (api != null && api.has(imported)) return imported;
                    // Explicit imports may name a member class using Java source
                    // notation (p.Outer.Inner), while the class file uses
                    // p.Outer$Inner. Resolve that spelling transparently.
                    int last = imported.lastIndexOf('.');
                    if (last > 0) {
                        String nested = imported.substring(0, last) + "$" + imported.substring(last + 1);
                        if (api != null && api.has(nested)) return nested;
                    }
                    return imported;
                }
            }
        }
        if (siblingNames.contains(simple)) {
            return packageName.length() > 0 ? packageName + "." + simple : simple;
        }
        for (int i = 0; i < imports.size(); i++) {
            ImportDecl id = (ImportDecl) imports.elementAt(i);
            if (id.wildcard) {
                String cand = id.path + "." + simple;
                if (api != null && api.has(cand)) return cand;
            }
        }
        if (api != null && api.has("java.lang." + simple)) return "java.lang." + simple;
        return simple; // unresolved; CodeGen will report a clear error when it's actually used
    }

    // ---------------- top level ----------------

    /** Backward-compatible single-class entry point: parses a compilation unit and
     *  requires it contain exactly one top-level class. */
    public ClassNode parseClass() throws CompileError {
        Vector units = parseCompilationUnit();
        if (units.size() > 1) {
            ClassNode second = (ClassNode) units.elementAt(1);
            throw new CompileError("found a second top-level class '" + second.name
                    + "' but this entry point only supports one class per file", 0);
        }
        return (ClassNode) units.elementAt(0);
    }

    /** Parses every top-level class declared in the file (package/imports are
     *  shared; each class gets its own ClassNode). Classes may reference each
     *  other regardless of declaration order -- see siblingNames. */
    public Vector parseCompilationUnit() throws CompileError {
        if (peek().isKeyword("package")) {
            advance();
            StringBuffer pkg = new StringBuffer(expectIdent().text);
            while (peek().isOp(".")) { advance(); pkg.append('.').append(expectIdent().text); }
            expectOp(";");
            packageName = pkg.toString();
        }

        while (peek().isKeyword("import")) {
            advance();
            ImportDecl id = new ImportDecl();
            id.isStatic = false;
            if (peek().isKeyword("static")) { id.isStatic = true; advance(); }
            StringBuffer path = new StringBuffer();
            path.append(expectIdent().text);
            boolean wildcard = false;
            while (peek().isOp(".")) {
                advance();
                if (peek().isOp("*")) { advance(); wildcard = true; break; }
                path.append('.').append(expectIdent().text);
            }
            if (id.isStatic && !wildcard) {
                int dot = path.lastIndexOf(".");
                if (dot <= 0) throw err("static import requires an owning type and member");
                id.memberName = path.substring(dot + 1);
                path.setLength(dot);
            }
            expectOp(";");
            id.path = path.toString();
            id.wildcard = wildcard;
            imports.addElement(id);
        }

        scanSiblingClassNames();

        Vector units = new Vector();
        for (;;) {
            units.addElement(parseOneClassBody());
            if (peek().type == Token.EOF) break;
            if (!isClassDeclAhead()) {
                throw err("unexpected content after the end of class '"
                        + ((ClassNode) units.elementAt(units.size() - 1)).name + "'");
            }
            // another top-level class follows -- loop and parse it too
        }
        // nested and anonymous classes (lifted to top level), parents before children
        for (int depth = 1; ; depth++) {
            boolean any = false;
            for (int i = 0; i < extraClasses.size(); i++) {
                ClassNode e = (ClassNode) extraClasses.elementAt(i);
                int d = 0;
                String nm = e.name.substring(e.name.lastIndexOf('.') + 1);
                for (int k = 0; k < nm.length(); k++) if (nm.charAt(k) == '$') d++;
                if (d == depth) { units.addElement(e); any = true; }
            }
            if (!any && depth > 20) break;
            if (depth > 40) break;
        }
        return units;
    }

    /** Scans ahead (without consuming tokens) from the current position -- which is
     *  right after imports, at the first top-level class -- to collect every
     *  top-level class's simple name. Needed before parsing any class body so that
     *  a class declared earlier in the file can still reference one declared later. */
    private void scanSiblingClassNames() throws CompileError {
        int save = idx;
        int depth = 0;
        String pending = null;
        String prefix = packageName.length() > 0 ? packageName + "." : "";
        Vector stackFull = new Vector();
        Vector stackDepth = new Vector();
        Token prev = null;
        while (peek().type != Token.EOF) {
            Token t = peek();
            boolean declKw = (t.isKeyword("class") || t.isKeyword("interface")
                    || (t.type == Token.IDENT && t.text.equals("enum") && peek2().type == Token.IDENT
                        && (peek3().isOp("{") || peek3().isKeyword("implements"))))
                    && peek2().type == Token.IDENT && !(prev != null && prev.isOp("."));
            if (declKw) {
                String simple = peek2().text;
                if (stackFull.size() == 0) {
                    siblingNames.addElement(simple);
                    pending = prefix + simple;
                } else {
                    String full = ((String) stackFull.elementAt(stackFull.size() - 1)) + "$" + simple;
                    if (!nestedNames.containsKey(simple)) nestedNames.put(simple, full);
                    pending = full;
                }
            }
            if (t.isOp("{")) {
                depth++;
                if (pending != null) { stackFull.addElement(pending); stackDepth.addElement(new Integer(depth)); pending = null; }
            } else if (t.isOp("}")) {
                if (stackDepth.size() > 0 && ((Integer) stackDepth.elementAt(stackDepth.size() - 1)).intValue() == depth) {
                    stackDepth.removeElementAt(stackDepth.size() - 1);
                    stackFull.removeElementAt(stackFull.size() - 1);
                }
                depth--;
            }
            prev = t;
            idx++;
        }
        idx = save;
    }

    private ClassNode parseOneClassBody() throws CompileError {
        return parseClassDecl(null);
    }

    // ---- scope tracking (names of enclosing local variables, for anonymous-class capture) ----
    private int scopeMark() { return scopeNames.size(); }
    private void scopeReset(int m) { scopeNames.setSize(m); scopeTypes.setSize(m); }
    private void declareLocal(String name, int type) {
        scopeNames.addElement(name);
        scopeTypes.addElement(new Integer(type));
    }

    private ParamNode synthParam(String name, int type) {
        ParamNode p = new ParamNode();
        p.name = name; p.type = type; p.isSynthField = true;
        return p;
    }

    private FieldNode synthField(String name, int type) {
        FieldNode f = new FieldNode();
        f.name = name; f.type = type;
        return f;
    }

    /** Parses a class, interface or enum declaration (top-level, or nested when outer != null).
     *  Nested classes are lifted to top-level ClassNodes named Outer$Inner and queued in extraClasses. */
    private ClassNode parseClassDecl(ClassNode outer) throws CompileError {
        boolean isAbstract = false, isStaticDecl = false;
        for (;;) {
            Token t = peek();
            if (t.isKeyword("abstract")) { isAbstract = true; advance(); }
            else if (t.isKeyword("static")) { isStaticDecl = true; advance(); }
            else if (t.isKeyword("public") || t.isKeyword("private") || t.isKeyword("protected")
                    || t.isKeyword("strictfp") || t.isKeyword("final")) advance();
            else break;
        }

        boolean isLocal = nextIsLocal;
        nextIsLocal = false;
        boolean isEnum = peek().type == Token.IDENT && peek().text.equals("enum");
        boolean isInterface = peek().isKeyword("interface");
        if (isInterface || isEnum) advance();
        else expectKeyword("class");
        Token nameTok = expectIdent();
        if (isLocal && (isInterface || isEnum)) throw err("local interfaces and enums are not supported; declare it as a member of the enclosing class");
        ClassNode cls = new ClassNode();
        cls.simpleName = nameTok.text;
        String prefix = packageName.length() > 0 ? packageName + "." : "";
        cls.name = outer == null ? prefix + nameTok.text : outer.name + "$" + nameTok.text;
        if (isLocal) {
            String key = outer.name + "$#" + nameTok.text;
            Integer lc = (Integer) anonCounters.get(key);
            int ln = lc == null ? 1 : lc.intValue() + 1;
            anonCounters.put(key, new Integer(ln));
            cls.name = outer.name + "$" + ln + nameTok.text;
            nestedNames.put(nameTok.text, cls.name); // visible by its simple name from here on
        }
        cls.outerName = outer != null ? outer.name : null;
        cls.imports = imports;
        cls.superName = "java.lang.Object";
        cls.isInterface = isInterface;
        cls.isEnum = isEnum;
        cls.isAbstract = isAbstract;
        cls.packageName = packageName;
        cls.hasOuterThis = outer != null && !isStaticDecl && !isInterface && !isEnum && !outer.isInterface
                && !(isLocal && inStaticCtx);
        if (cls.hasOuterThis) cls.fields.addElement(synthField("this$0", T.refType(outer.name)));

        skipTypeParams();
        if (isInterface) {
            if (peek().isKeyword("extends")) {
                advance();
                for (;;) {
                    cls.interfaces.addElement(resolveTypeName(parseDottedIdent()));
                    skipTypeArgs();
                    if (peek().isOp(",")) { advance(); continue; }
                    break;
                }
            }
        } else {
            if (peek().isKeyword("extends")) {
                if (isEnum) throw err("an enum cannot extend a class");
                advance();
                cls.superName = resolveTypeName(parseDottedIdent());
                skipTypeArgs();
            }
            if (peek().isKeyword("implements")) {
                advance();
                for (;;) {
                    cls.interfaces.addElement(resolveTypeName(parseDottedIdent()));
                    skipTypeArgs();
                    if (peek().isOp(",")) { advance(); continue; }
                    break;
                }
            }
        }

        ClassNode savedCur = curClass;
        Vector savedNames = scopeNames, savedTypes = scopeTypes;
        boolean savedStatic = inStaticCtx;
        curClass = cls;
        scopeNames = new Vector(); scopeTypes = new Vector();

        int bodyStart = idx;
        expectOp("{");
        if (isEnum) parseEnumConstants(cls);
        while (!peek().isOp("}")) {
            if (peek().type == Token.EOF) throw err("unexpected end of file, missing '}'");
            if (isInterface) parseInterfaceMember(cls);
            else parseMember(cls);
        }
        expectOp("}");

        curClass = savedCur;
        scopeNames = savedNames; scopeTypes = savedTypes;
        inStaticCtx = savedStatic;

        if (isEnum) finishEnum(cls);
        finishConstructors(cls);
        if (isLocal) {
            boolean anyCtor = false;
            for (int i = 0; i < cls.methods.size(); i++) if (((MethodNode) cls.methods.elementAt(i)).isConstructor) anyCtor = true;
            if (!anyCtor) {
                MethodNode m = new MethodNode();
                m.name = "<init>"; m.returnType = T.VOID; m.isConstructor = true;
                m.body = new BlockStmt();
                cls.methods.addElement(m);
            }
            applyCaptures(cls, bodyStart, idx, savedNames, savedTypes);
        }
        if (outer != null) extraClasses.addElement(cls);
        return cls;
    }

    /** Adds the synthetic leading constructor parameters (this$0 of inner classes) and, for a class with
     *  no explicit constructor that needs them, synthesizes one. */
    private void finishConstructors(ClassNode cls) {
        if (cls.isInterface) return;
        boolean hasCtor = false;
        for (int i = 0; i < cls.methods.size(); i++) {
            MethodNode m = (MethodNode) cls.methods.elementAt(i);
            if (!m.isConstructor) continue;
            hasCtor = true;
            if (cls.hasOuterThis && !(m.params.size() > 0 && ((ParamNode) m.params.elementAt(0)).name.equals("this$0"))) {
                m.params.insertElementAt(synthParam("this$0", T.refType(cls.outerName)), 0);
            }
        }
        if (!hasCtor && cls.hasOuterThis) {
            MethodNode m = new MethodNode();
            m.name = "<init>"; m.returnType = T.VOID; m.isConstructor = true;
            m.params.addElement(synthParam("this$0", T.refType(cls.outerName)));
            m.body = new BlockStmt();
            cls.methods.addElement(m);
        }
    }

    /** "a.b.C" (type name possibly package-qualified) -- caller resolves it. */
    /** Skips an optional "throws A, B.C" clause (checked exceptions are not enforced). */
    private void skipThrows() throws CompileError {
        if (peek().text != null && peek().text.equals("throws")) {
            advance();
            for (;;) {
                parseDottedIdent();
                if (peek().isOp(",")) { advance(); continue; }
                break;
            }
        }
    }

    private String parseDottedIdent() throws CompileError {
        StringBuffer sb = new StringBuffer(expectIdent().text);
        while (peek().isOp(".") && peek2().type == Token.IDENT) { advance(); sb.append('.').append(advance().text); }
        return sb.toString();
    }

    // ---- generics: parsed and erased ----
    private Vector typeVars = new Vector(); // names of type parameters seen in the file (resolve to their bound / Object)
    private Hashtable typeVarBounds = new Hashtable();

    /** skips "<...>" (type arguments); no-op if the next token is not '<'. */
    private void skipTypeArgs() throws CompileError {
        if (!peek().isOp("<")) return;
        int depth = 0;
        for (;;) {
            Token t = advance();
            if (t.type == Token.EOF) throw err("unterminated '<...>'");
            if (t.isOp("<")) depth++;
            else if (t.isOp(">")) { depth--; if (depth <= 0) return; }
            else if (t.isOp(">>")) { depth -= 2; if (depth <= 0) return; }
            else if (t.isOp(">>>")) { depth -= 3; if (depth <= 0) return; }
        }
    }

    /** "<T, U extends Foo>" after a class name or before a method's return type. */
    private void skipTypeParams() throws CompileError {
        if (!peek().isOp("<")) return;
        advance();
        for (;;) {
            Token n = expectIdent();
            String bound = "java.lang.Object";
            if (peek().isKeyword("extends")) {
                advance();
                bound = resolveTypeName(parseDottedIdent());
                skipTypeArgs();
                while (peek().isOp("&")) { advance(); parseDottedIdent(); skipTypeArgs(); }
            }
            if (!typeVars.contains(n.text)) typeVars.addElement(n.text);
            typeVarBounds.put(n.text, bound);
            if (peek().isOp(",")) { advance(); continue; }
            break;
        }
        expectOp(">");
    }

    // ---- enums ----
    private void parseEnumConstants(ClassNode cls) throws CompileError {
        Vector constNames = new Vector();
        int ord = 0;
        while (peek().type == Token.IDENT) {
            Token c = advance();
            NewExpr ne = new NewExpr();
            ne.line = c.line; ne.className = cls.name;
            StrLit nm = new StrLit(); nm.line = c.line; nm.value = c.text;
            IntLit od = new IntLit(); od.line = c.line; od.value = ord++;
            ne.args.addElement(nm); ne.args.addElement(od);
            if (peek().isOp("(")) {
                advance();
                if (!peek().isOp(")")) {
                    for (;;) {
                        ne.args.addElement(parseExpr());
                        if (peek().isOp(",")) { advance(); continue; }
                        break;
                    }
                }
                expectOp(")");
            }
            Expr init = ne;
            if (peek().isOp("{")) {
                // constant-specific class body: an anonymous subclass of the enum, created in <clinit>
                boolean savedSt = inStaticCtx;
                inStaticCtx = true;
                try {
                    init = parseAnonBody(ne, c.line);
                } finally {
                    inStaticCtx = savedSt;
                }
            }
            FieldNode f = new FieldNode();
            f.name = c.text; f.type = T.refType(cls.name); f.isStatic = true; f.isFinal = true; f.line = c.line; f.init = init;
            cls.fields.addElement(f);
            constNames.addElement(c.text);
            if (peek().isOp(",")) { advance(); continue; }
            break;
        }
        if (peek().isOp(";")) advance();
        else if (!peek().isOp("}")) throw err("expected ',' ';' or '}' in enum '" + cls.simpleName + "'");

        cls.fields.addElement(synthField("$name", T.STRING));
        cls.fields.addElement(synthField("$ordinal", T.INT));
        ArrayInitExpr ai = new ArrayInitExpr();
        ai.line = peek().line; ai.elemDesc = T.desc(T.refType(cls.name));
        for (int i = 0; i < constNames.size(); i++) {
            NameExpr n = new NameExpr(); n.line = ai.line; n.name = (String) constNames.elementAt(i);
            ai.elems.addElement(n);
        }
        FieldNode vf = new FieldNode();
        vf.name = "$VALUES"; vf.type = T.refType("[" + ai.elemDesc); vf.isStatic = true; vf.isFinal = true; vf.line = ai.line; vf.init = ai;
        cls.fields.addElement(vf);
    }

    private void finishEnum(ClassNode cls) throws CompileError {
        // constructors get ($name, $ordinal) in front of the user's parameters
        boolean hasCtor = false;
        for (int i = 0; i < cls.methods.size(); i++) {
            MethodNode m = (MethodNode) cls.methods.elementAt(i);
            if (!m.isConstructor) continue;
            hasCtor = true;
            m.params.insertElementAt(synthParam("$ordinal", T.INT), 0);
            m.params.insertElementAt(synthParam("$name", T.STRING), 0);
        }
        if (!hasCtor) {
            MethodNode m = new MethodNode();
            m.name = "<init>"; m.returnType = T.VOID; m.isConstructor = true;
            m.params.addElement(synthParam("$name", T.STRING));
            m.params.addElement(synthParam("$ordinal", T.INT));
            m.body = new BlockStmt();
            cls.methods.addElement(m);
        }
        for (int i = 0; i < cls.methods.size(); i++) {
            if (((MethodNode) cls.methods.elementAt(i)).isAbstract) cls.isAbstract = true; // every constant then has its own body
        }
        boolean userToString = false;
        for (int i = 0; i < cls.methods.size(); i++) {
            MethodNode m = (MethodNode) cls.methods.elementAt(i);
            if (m.name.equals("toString") && m.params.size() == 0) userToString = true;
        }
        String n = cls.simpleName;
        String src = "public final String name() { return $name; }\n"
                + "public final int ordinal() { return $ordinal; }\n"
                + (userToString ? "" : "public String toString() { return $name; }\n")
                + "public static " + n + "[] values() { " + n + "[] r = new " + n + "[$VALUES.length]; "
                + "for (int i = 0; i < r.length; i++) r[i] = $VALUES[i]; return r; }\n"
                + "public static " + n + " valueOf(String s) { for (int i = 0; i < $VALUES.length; i++) "
                + "{ if ($VALUES[i].$name.equals(s)) return $VALUES[i]; } throw new IllegalArgumentException(s); }\n";
        Parser sp = new Parser(new Lexer(src, sourceLevel).tokenize(), api, sourceLevel);
        sp.imports = imports; sp.siblingNames = siblingNames; sp.nestedNames = nestedNames; sp.packageName = packageName;
        sp.curClass = cls;
        while (sp.peek().type != Token.EOF) sp.parseMember(cls);
    }

    /** Capture analysis for anonymous and local classes: enclosing locals/params that the body
     *  mentions as plain variables become fields val$x, passed as trailing constructor parameters. */
    private void applyCaptures(ClassNode a, int bodyStart, int bodyEnd, Vector encNames, Vector encTypes) {
        Vector capNames = new Vector(), capTypes = new Vector();
        for (int i = encNames.size() - 1; i >= 0; i--) {
            String nm = (String) encNames.elementAt(i);
            if (capNames.contains(nm)) continue;
            boolean own = false;
            for (int k = 0; k < a.fields.size(); k++) if (((FieldNode) a.fields.elementAt(k)).name.equals(nm)) own = true;
            if (own) continue;
            boolean used = false;
            for (int k = bodyStart; k < bodyEnd && !used; k++) {
                Token t = (Token) toks.elementAt(k);
                if (t.type != Token.IDENT || !t.text.equals(nm)) continue;
                if (k > 0 && ((Token) toks.elementAt(k - 1)).isOp(".")) continue;
                if (k + 1 < toks.size() && ((Token) toks.elementAt(k + 1)).isOp("(")) continue;
                used = true;
            }
            if (!used) continue;
            capNames.addElement(nm);
            capTypes.addElement(encTypes.elementAt(i));
        }
        // a subclass of a capturing local class must capture the same variables itself, so it can
        // hand them to the superclass constructor
        for (int e = 0; e < extraClasses.size(); e++) {
            ClassNode sup = (ClassNode) extraClasses.elementAt(e);
            if (sup == a || a.superName == null) continue;
            if (!(sup.name.equals(a.superName) || (sup.simpleName != null && sup.simpleName.equals(a.superName)))) continue;
            for (int c = 0; c < sup.capturedNames.size(); c++) {
                String nm = (String) sup.capturedNames.elementAt(c);
                if (capNames.contains(nm)) continue;
                for (int i = encNames.size() - 1; i >= 0; i--) {
                    if (encNames.elementAt(i).equals(nm)) {
                        capNames.addElement(nm);
                        capTypes.addElement(encTypes.elementAt(i));
                        break;
                    }
                }
            }
        }
        for (int i = 0; i < capNames.size(); i++) {
            String nm = "val$" + capNames.elementAt(i);
            int ty = ((Integer) capTypes.elementAt(i)).intValue();
            a.fields.addElement(synthField(nm, ty));
            a.capturedNames.addElement(capNames.elementAt(i));
            for (int k = 0; k < a.methods.size(); k++) {
                MethodNode m = (MethodNode) a.methods.elementAt(k);
                if (m.isConstructor) m.params.addElement(synthParam(nm, ty));
            }
        }
    }

    // ---- anonymous classes: new Base(args) { ... } ----
    private Expr parseAnonBody(NewExpr n, int line) throws CompileError {
        ClassNode encl = curClass;
        Integer cnt = (Integer) anonCounters.get(encl.name);
        int num = cnt == null ? 1 : cnt.intValue() + 1;
        anonCounters.put(encl.name, new Integer(num));

        ClassNode a = new ClassNode();
        a.name = encl.name + "$" + num;
        a.simpleName = "";
        a.isAnon = true;
        a.anonBase = n.className;
        a.superName = "java.lang.Object";
        a.outerName = encl.name;
        a.packageName = packageName;
        a.imports = imports;
        a.hasOuterThis = !inStaticCtx;
        if (a.hasOuterThis) a.fields.addElement(synthField("this$0", T.refType(encl.name)));

        Vector encNames = scopeNames, encTypes = scopeTypes;
        boolean savedStatic = inStaticCtx;
        ClassNode savedCur = curClass;
        curClass = a;
        scopeNames = new Vector(); scopeTypes = new Vector();
        int bodyStart = idx;
        expectOp("{");
        while (!peek().isOp("}")) {
            if (peek().type == Token.EOF) throw err("unexpected end of file, missing '}' of an anonymous class");
            parseMember(a);
        }
        expectOp("}");
        int bodyEnd = idx;
        curClass = savedCur;
        scopeNames = encNames; scopeTypes = encTypes;
        inStaticCtx = savedStatic;

        MethodNode ctor = new MethodNode();
        ctor.name = "<init>"; ctor.returnType = T.VOID; ctor.isConstructor = true; ctor.line = line;
        if (a.hasOuterThis) ctor.params.addElement(synthParam("this$0", T.refType(encl.name)));
        ctor.body = new BlockStmt();
        a.methods.addElement(ctor);
        applyCaptures(a, bodyStart, bodyEnd, encNames, encTypes);
        extraClasses.addElement(a);
        n.className = a.name;
        return n;
    }

    private void skipTypeArgsAfterNew() { }

    private void skipModifiers() {
        for (;;) {
            Token t = peek();
            if (t.isKeyword("public") || t.isKeyword("private") || t.isKeyword("protected") || t.isKeyword("strictfp") || t.isKeyword("final")) {
                advance();
            } else {
                return;
            }
        }
    }

    /** True if, skipping public/private/protected, the next real token is "abstract".
     *  Used at the top-level type declaration site (`abstract class Foo`) -- separate
     *  from skipModifiers/isFinalModifierAhead's own modifier sets since "abstract"
     *  is only meaningful there and on individual methods, never on fields or locals. */
    private boolean isAbstractModifierAhead() {
        int save = idx;
        boolean found = false;
        for (;;) {
            Token t = (Token) toks.elementAt(idx);
            if (t.isKeyword("public") || t.isKeyword("private") || t.isKeyword("protected") || t.isKeyword("strictfp") || t.isKeyword("static") || t.isKeyword("final")) {
                idx++;
                continue;
            }
            if (t.isKeyword("abstract")) { found = true; idx++; continue; }
            break;
        }
        idx = save;
        return found;
    }

    private boolean isStrictfpModifierAhead() {
        int save = idx;
        boolean found = false;
        for (;;) {
            Token t = (Token) toks.elementAt(idx);
            if (t.isKeyword("strictfp")) { found = true; idx++; continue; }
            if (t.isKeyword("public") || t.isKeyword("private") || t.isKeyword("protected")
                    || t.isKeyword("final") || t.isKeyword("static") || t.isKeyword("abstract")) {
                idx++;
                continue;
            }
            break;
        }
        idx = save;
        return found;
    }

    private boolean isStaticModifierAhead() {
        int save = idx;
        boolean found = false;
        for (;;) {
            Token t = (Token) toks.elementAt(idx);
            if (t.isKeyword("public") || t.isKeyword("private") || t.isKeyword("protected") || t.isKeyword("strictfp") || t.isKeyword("final")) {
                idx++;
                continue;
            }
            if (t.isKeyword("static")) { found = true; idx++; continue; }
            break;
        }
        idx = save;
        return found;
    }

    private boolean isPrivateModifierAhead() {
        int save = idx;
        boolean found = false;
        for (;;) {
            Token t = (Token) toks.elementAt(idx);
            if (t.isKeyword("private")) { found = true; idx++; continue; }
            if (t.isKeyword("public") || t.isKeyword("protected") || t.isKeyword("strictfp") || t.isKeyword("final")
                    || t.isKeyword("static") || t.isKeyword("abstract")) {
                idx++;
                continue;
            }
            break;
        }
        idx = save;
        return found;
    }

    private boolean isFinalModifierAhead() {
        int save = idx;
        boolean found = false;
        for (;;) {
            Token t = (Token) toks.elementAt(idx);
            if (t.isKeyword("public") || t.isKeyword("private") || t.isKeyword("protected") || t.isKeyword("strictfp") || t.isKeyword("static")) {
                idx++;
                continue;
            }
            if (t.isKeyword("final")) { found = true; idx++; continue; }
            break;
        }
        idx = save;
        return found;
    }

    private boolean isConstructorAhead(String clsName) {
        int save = idx;
        for (;;) {
            Token t = (Token) toks.elementAt(idx);
            if (t.isKeyword("public") || t.isKeyword("private") || t.isKeyword("protected") || t.isKeyword("strictfp") || t.isKeyword("final")) {
                idx++;
                continue;
            }
            break;
        }
        boolean r = peek().type == Token.IDENT && peek().text.equals(clsName) && peek2().isOp("(");
        idx = save;
        return r;
    }

    private void consumeModifiersAndStatic() {
        for (;;) {
            Token t = peek();
            if (t.isKeyword("public") || t.isKeyword("private") || t.isKeyword("protected") || t.isKeyword("strictfp") || t.isKeyword("static") || t.isKeyword("final") || t.isKeyword("abstract")) {
                advance();
            } else {
                return;
            }
        }
    }

    /** Consumes a leading 'final' if present -- used at parameter and local-variable
     *  declaration sites, which aren't covered by skipModifiers/consumeModifiersAndStatic
     *  (those are for member declarations). 'final' is accepted for source compatibility
     *  but not enforced (nothing in this compiler currently checks for reassignment). */
    private boolean skipFinal() {
        if (peek().isKeyword("final")) { advance(); return true; }
        return false;
    }

    private boolean isTypeKeyword(Token t) {
        if (t.type == Token.IDENT && t.text.equals("var") && peek2().type == Token.IDENT) return true;
        if (t.isKeyword("int") || t.isKeyword("boolean") || t.isKeyword("byte") || t.isKeyword("short") ||
            t.isKeyword("char") || t.isKeyword("String") || t.isKeyword("void") ||
            t.isKeyword("long") || t.isKeyword("float") || t.isKeyword("double")) return true;
        // heuristic for statement-position ambiguity ("Foo x = ..." vs "foo.bar()"):
        // an identifier immediately followed by another identifier, or by "[]", looks like "Type name".
        if (t.type == Token.IDENT && peek2().type == Token.IDENT) return true;
        if (t.type == Token.IDENT && peek2().isOp(".") && qualifiedTypeThenIdentAhead()) return true; // "java.util.Vector v"
        if (t.isKeyword("String") && peek2().isOp("[") && peek3().isOp("]")) return true;
        if (t.type == Token.IDENT && peek2().isOp("<") && genericDeclAhead()) return true; // "Vector<String> v"
        if (t.type == Token.IDENT && peek2().isOp("[") && peek3().isOp("]")) return true; // "Type[] name" -- NOT "arr[expr]"
        return false;
    }

    /** at IDENT: true for "a.b.C name" or "a.b.C[] name" (a package-qualified type then a variable name). */
    /** at IDENT '<' : true when a balanced <...> is followed by a variable name ("Vector<String> v"). */
    private boolean genericDeclAhead() {
        int j = idx + 1, depth = 0;
        for (; j < toks.size(); j++) {
            Token u = (Token) toks.elementAt(j);
            if (u.isOp("<")) depth++;
            else if (u.isOp(">")) depth--;
            else if (u.isOp(">>")) depth -= 2;
            else if (u.isOp(">>>")) depth -= 3;
            else if (!(u.type == Token.IDENT || u.isOp(",") || u.isOp(".") || u.isOp("?") || u.isOp("[") || u.isOp("]")
                    || u.isKeyword("extends") || u.isKeyword("String") || u.isKeyword("int") || u.isKeyword("char")
                    || u.isKeyword("boolean") || u.isKeyword("long") || u.isKeyword("double") || u.isKeyword("float")
                    || u.isKeyword("byte") || u.isKeyword("short") || u.isOp("&"))) return false;
            if (depth <= 0) { j++; break; }
        }
        while (j + 1 < toks.size() && ((Token) toks.elementAt(j)).isOp("[") && ((Token) toks.elementAt(j + 1)).isOp("]")) j += 2;
        return depth <= 0 && j < toks.size() && ((Token) toks.elementAt(j)).type == Token.IDENT;
    }

    private boolean qualifiedTypeThenIdentAhead() {
        int j = idx + 1;
        while (j + 1 < toks.size() && ((Token) toks.elementAt(j)).isOp(".") && ((Token) toks.elementAt(j + 1)).type == Token.IDENT) j += 2;
        while (j + 1 < toks.size() && ((Token) toks.elementAt(j)).isOp("[") && ((Token) toks.elementAt(j + 1)).isOp("]")) j += 2;
        return j < toks.size() && ((Token) toks.elementAt(j)).type == Token.IDENT && j > idx + 1;
    }

    private boolean lastPlainChar;   // the type just parsed was exactly 'char'
    private boolean lastTypeVar;     // the type just parsed was a type variable

    private int parseType() throws CompileError {
        lastPlainChar = false; lastTypeVar = false;
        Token t = peek();
        int base;
        String baseDesc;
        if (t.isKeyword("int")) { advance(); base = T.INT; baseDesc = "I"; }
        else if (t.isKeyword("boolean")) { advance(); base = T.BOOLEAN; baseDesc = "Z"; }
        else if (t.isKeyword("byte")) { advance(); base = T.INT; baseDesc = "B"; } // byte/short/char live in int-width slots; only distinguished for array element storage
        else if (t.isKeyword("short")) { advance(); base = T.INT; baseDesc = "S"; }
        else if (t.isKeyword("char")) { advance(); base = T.INT; baseDesc = "C"; }
        else if (t.isKeyword("long")) { advance(); base = T.LONG; baseDesc = "J"; }
        else if (t.isKeyword("float")) { advance(); base = T.FLOAT; baseDesc = "F"; }
        else if (t.isKeyword("double")) { advance(); base = T.DOUBLE; baseDesc = "D"; }
        else if (t.isKeyword("String")) { advance(); base = T.STRING; baseDesc = "Ljava/lang/String;"; }
        else if (t.isKeyword("void")) { advance(); return T.VOID; }
        else if (t.type == Token.IDENT) {
            advance();
            String tn = t.text;
            while (peek().isOp(".") && peek2().type == Token.IDENT) { // package-qualified: java.util.Vector
                advance();
                tn = tn + "." + advance().text;
            }
            skipTypeArgs(); // Vector<String> -- generics are erased
            boolean isVar = typeVars.contains(tn);
            String fqcn = isVar ? (String) typeVarBounds.get(tn) : resolveTypeName(tn);
            base = T.refType(fqcn);
            baseDesc = T.desc(base);
            lastTypeVar = isVar;
        } else {
            throw err("expected a type but found '" + t.text + "'");
        }
        if (peek().isOp("[") && peek2().isOp("]")) {
            String d = baseDesc;
            while (peek().isOp("[") && peek2().isOp("]")) { advance(); advance(); d = "[" + d; }
            lastPlainChar = false; lastTypeVar = false;
            return T.refType(d);
        }
        lastPlainChar = baseDesc.equals("C");
        return base;
    }

    private void parseMember(ClassNode cls) throws CompileError {
        if (peek().isOp("{") || (peek().isKeyword("static") && peek2().isOp("{"))) {
            InitBlock ib = new InitBlock();
            ib.isStatic = peek().isKeyword("static");
            if (ib.isStatic) advance();
            ib.pos = cls.fields.size();
            boolean savedSt = inStaticCtx;
            inStaticCtx = ib.isStatic;
            ib.body = parseBlock();
            inStaticCtx = savedSt;
            cls.initBlocks.addElement(ib);
            return;
        }
        if (isConstructorAhead(cls.simpleName)) {
            skipModifiers();
            Token nameTok = expectIdent();
            MethodNode m = new MethodNode();
            m.name = "<init>";
            m.returnType = T.VOID;
            m.isStatic = false;
            m.isConstructor = true;
            m.line = nameTok.line;
            advance(); // '('
            if (!peek().isOp(")")) {
                for (;;) {
                    boolean pf = skipFinal();
                    ParamNode p = new ParamNode();
                    p.type = parseType();
                    p.charTyped = lastPlainChar;
                    if (peek().isOp(".") && peek2().isOp(".") && peek3().isOp(".")) { // T... name
                        advance(); advance(); advance();
                        p.type = T.refType("[" + T.desc(p.type));
                        p.isVarargs = true;
                        m.isVarargs = true;
                    }
                    p.name = expectIdent().text;
                    if (peek().isOp("[") && peek2().isOp("]")) { advance(); advance(); p.type = T.refType("[" + T.desc(p.type)); }
                    p.isFinal = pf;
                    m.params.addElement(p);
                    if (peek().isOp(",")) { advance(); continue; }
                    break;
                }
            }
            expectOp(")");
            skipThrows();
            {
                int sm = scopeMark();
                for (int pi = 0; pi < m.params.size(); pi++) { ParamNode pp = (ParamNode) m.params.elementAt(pi); declareLocal(pp.name, pp.type); }
                boolean savedSt = inStaticCtx;
                inStaticCtx = false;
                m.body = parseBlock();
                inStaticCtx = savedSt;
                scopeReset(sm);
            }
            cls.methods.addElement(m);
            return;
        }

        if (isClassDeclAhead()) {
            parseClassDecl(cls); // nested class / interface / enum: lifted to top level, queued in extraClasses
            return;
        }

        boolean isStatic = isStaticModifierAhead();
        boolean isFinal = isFinalModifierAhead();
        boolean isAbstractMethod = isAbstractModifierAhead();
        boolean isPrivate = isPrivateModifierAhead();
        boolean isStrict = isStrictfpModifierAhead();
        consumeModifiersAndStatic();
        skipTypeParams(); // generic method: <T> void f(T x)
        Token syncTok = peek();
        int line = peek().line;
        int type = parseType();
        boolean typeIsChar = lastPlainChar, typeIsVar = lastTypeVar;
        Token nameTok = expectIdent();
        if (peek().isOp("(")) {
            // method
            MethodNode m = new MethodNode();
            m.name = nameTok.text;
            m.returnType = type;
            m.isStatic = isStatic;
            m.isPrivate = isPrivate;
            m.isAbstract = isAbstractMethod;
            m.isStrict = isStrict;
            m.isSynchronized = syncTok.syncMod;
            m.returnsChar = typeIsChar;
            m.returnIsTypeVar = typeIsVar;
            m.line = line;
            advance(); // '('
            if (!peek().isOp(")")) {
                for (;;) {
                    boolean pf = skipFinal();
                    ParamNode p = new ParamNode();
                    p.type = parseType();
                    p.charTyped = lastPlainChar;
                    if (peek().isOp(".") && peek2().isOp(".") && peek3().isOp(".")) { // T... name
                        advance(); advance(); advance();
                        p.type = T.refType("[" + T.desc(p.type));
                        p.isVarargs = true;
                        m.isVarargs = true;
                    }
                    p.name = expectIdent().text;
                    if (peek().isOp("[") && peek2().isOp("]")) { advance(); advance(); p.type = T.refType("[" + T.desc(p.type)); }
                    p.isFinal = pf;
                    m.params.addElement(p);
                    if (peek().isOp(",")) { advance(); continue; }
                    break;
                }
            }
            expectOp(")");
            skipThrows();
            if (isAbstractMethod) {
                if (isStatic) throw err("'" + m.name + "' cannot be both 'abstract' and 'static'");
                expectOp(";");
                m.body = null;
            } else {
                int sm = scopeMark();
                for (int pi = 0; pi < m.params.size(); pi++) { ParamNode pp = (ParamNode) m.params.elementAt(pi); declareLocal(pp.name, pp.type); }
                boolean savedSt = inStaticCtx;
                inStaticCtx = isStatic;
                m.body = parseBlock();
                inStaticCtx = savedSt;
                scopeReset(sm);
            }
            cls.methods.addElement(m);
        } else {
            if (isAbstractMethod) throw err("'abstract' is not allowed on a field ('" + nameTok.text + "')");
            // field
            Token curName = nameTok;
            for (;;) {
                FieldNode f = new FieldNode();
                f.type = type;
                f.name = curName.text;
                if (peek().isOp("[") && peek2().isOp("]")) { // C-style "int a[]"
                    advance(); advance();
                    f.type = T.refType("[" + T.desc(type));
                }
                f.isStatic = isStatic;
                f.isFinal = isFinal;
                f.isPrivate = isPrivate;
                f.charTyped = typeIsChar && f.type == type;
                f.line = line;
                if (peek().isOp("=")) {
                    advance();
                    boolean savedSt = inStaticCtx;
                    inStaticCtx = isStatic;
                    f.init = parseInitializer(f.type);
                    inStaticCtx = savedSt;
                }
                cls.fields.addElement(f);
                if (peek().isOp(",")) { advance(); curName = expectIdent(); continue; }
                break;
            }
            expectOp(";");
        }
    }

    /** Parses one member of an "interface { ... }" body. Every interface method is
     *  implicitly public+abstract (no body, no 'public'/'abstract' keywords required
     *  or even accepted here -- real Java allows redundant 'public abstract' on
     *  interface methods, but this compiler keeps the grammar minimal and just
     *  disallows the modifiers that would be meaningless: 'static', 'final',
     *  'private', 'protected'). Interface constant fields (implicitly
     *  public/static/final) are NOT supported -- a field here is a clear error
     *  rather than silently compiling as a plain instance field, which an
     *  interface can never have. */
    private void parseInterfaceMember(ClassNode cls) throws CompileError {
        if (isClassDeclAhead()) {
            parseClassDecl(cls);
            return;
        }
        if (false) {
            String nestedName = peekClassDeclName();
            throw err("nested type '" + nestedName + "' is not supported inside interface '" + cls.name + "'",
                    "close interface '" + cls.name + "' with a '}' first, then declare '" + nestedName
                            + "' as its own top-level class -- either later in this same file, "
                            + "or in its own " + nestedName + ".java in src/");
        }
        if (peek().isKeyword("public")) advance(); // accepted (redundant on an interface method) but not required
        if (peek().isKeyword("abstract")) advance(); // same -- interface methods are implicitly abstract already
        boolean skippedFieldModifier = false;
        while (peek().isKeyword("static") || peek().isKeyword("final")) { advance(); skippedFieldModifier = true; } // redundant on constants
        int line = peek().line;
        int type = parseType();
        Token nameTok = expectIdent();
        if (!peek().isOp("(")) {
            // interface constant: implicitly public static final, must have an initializer
            Token cur = nameTok;
            for (;;) {
                FieldNode f = new FieldNode();
                f.type = type; f.name = cur.text; f.isStatic = true; f.isFinal = true; f.line = line;
                if (!peek().isOp("=")) throw err("interface constant '" + cur.text + "' needs an initial value");
                advance();
                f.init = parseInitializer(type);
                cls.fields.addElement(f);
                if (peek().isOp(",")) { advance(); cur = expectIdent(); continue; }
                break;
            }
            expectOp(";");
            return;
        }
        if (skippedFieldModifier) throw err("'static' / 'final' are not allowed on interface method '" + nameTok.text + "'");
        MethodNode m = new MethodNode();
        m.name = nameTok.text;
        m.returnType = type;
        m.isStatic = false;
        m.isAbstract = true;
        m.line = line;
        advance(); // '('
        if (!peek().isOp(")")) {
            for (;;) {
                boolean pf = skipFinal();
                ParamNode p = new ParamNode();
                p.type = parseType();
                p.name = expectIdent().text;
                p.isFinal = pf;
                m.params.addElement(p);
                if (peek().isOp(",")) { advance(); continue; }
                break;
            }
        }
        expectOp(")");
        skipThrows();
        expectOp(";");
        m.body = null;
        cls.methods.addElement(m);
    }

    // ---------------- statements ----------------

    private BlockStmt parseBlock() throws CompileError {
        BlockStmt b = new BlockStmt();
        b.line = peek().line;
        expectOp("{");
        int sm = scopeMark();
        while (!peek().isOp("}")) {
            if (peek().type == Token.EOF) throw err("unexpected end of file, missing '}'");
            b.stmts.addElement(parseStmt());
        }
        expectOp("}");
        scopeReset(sm);
        return b;
    }

    private Stmt parseStmt() throws CompileError {
        Token t = peek();
        int line = t.line;

        if (t.isOp("{")) return parseBlock();

        if (t.isKeyword("if")) {
            advance();
            expectOp("(");
            Expr cond = parseExpr();
            expectOp(")");
            Stmt thenS = parseStmt();
            Stmt elseS = null;
            if (peek().isKeyword("else")) {
                advance();
                elseS = parseStmt();
            }
            IfStmt s = new IfStmt();
            s.line = line; s.cond = cond; s.thenS = thenS; s.elseS = elseS;
            return s;
        }

        if (t.isKeyword("while")) {
            advance();
            expectOp("(");
            Expr cond = parseExpr();
            expectOp(")");
            Stmt body = parseStmt();
            WhileStmt s = new WhileStmt();
            s.line = line; s.cond = cond; s.body = body;
            return s;
        }

        if (t.isKeyword("do")) {
            advance();
            Stmt body = parseStmt();
            expectKeyword("while");
            expectOp("(");
            Expr cond = parseExpr();
            expectOp(")");
            expectOp(";");
            DoWhileStmt s = new DoWhileStmt();
            s.line = line; s.body = body; s.cond = cond;
            return s;
        }

        if (t.isKeyword("switch")) {
            advance();
            expectOp("(");
            Expr sel = parseExpr();
            expectOp(")");
            expectOp("{");
            SwitchStmt sw = new SwitchStmt();
            sw.line = line; sw.selector = sel;
            SwitchCase cur = null;
            boolean sawDefault = false;
            while (!peek().isOp("}")) {
                if (peek().type == Token.EOF) throw err("unexpected end of file, missing '}'");
                if (peek().isKeyword("case")) {
                    advance();
                    Expr val = parseSwitchCaseLabel();
                    expectOp(":");
                    SwitchCase sc = new SwitchCase();
                    sc.values.addElement(val);
                    sw.cases.addElement(sc);
                    cur = sc;
                    continue;
                }
                if (peek().isKeyword("default")) {
                    if (sawDefault) throw err("duplicate 'default' label in switch");
                    sawDefault = true;
                    advance();
                    expectOp(":");
                    SwitchCase sc = new SwitchCase();
                    sc.isDefault = true;
                    sw.cases.addElement(sc);
                    cur = sc;
                    continue;
                }
                if (cur == null) throw err("statement in 'switch' body must be preceded by a 'case' or 'default' label");
                cur.stmts.addElement(parseStmt());
            }
            expectOp("}");
            return sw;
        }

        if (t.isKeyword("synchronized") || (t.type == Token.IDENT && t.text.equals("synchronized") && peek2().isOp("("))) {
            advance();
            expectOp("(");
            SyncStmt ss = new SyncStmt();
            ss.line = line;
            ss.lock = parseExpr();
            expectOp(")");
            ss.body = parseBlock();
            return ss;
        }

        // local class declaration inside a method body
        if (t.isKeyword("class") || ((t.isKeyword("final") || t.isKeyword("abstract")) && peek2().isKeyword("class"))) {
            nextIsLocal = true;
            parseClassDecl(curClass);
            BlockStmt empty = new BlockStmt();
            empty.line = line; empty.noScope = true;
            return empty;
        }

        // this(args); -- constructor delegation (first statement of a constructor)
        if (t.isKeyword("this") && peek2().isOp("(")) {
            advance(); advance();
            ThisCallStmt tc = new ThisCallStmt();
            tc.line = line;
            if (!peek().isOp(")")) {
                for (;;) {
                    tc.args.addElement(parseExpr());
                    if (peek().isOp(",")) { advance(); continue; }
                    break;
                }
            }
            expectOp(")");
            expectOp(";");
            return tc;
        }

        if (t.isKeyword("for")) {
            advance();
            expectOp("(");
            // enhanced for:  for ([final] Type name : expr)
            {
                int save = idx;
                boolean fin = skipFinal();
                if (isTypeKeyword(peek())) {
                    int vt = parseType();
                    if (peek().type == Token.IDENT && peek2().isOp(":")) {
                        String vn = advance().text;
                        declareLocal(vn, vt);
                        advance(); // ':'
                        ForEachStmt fe = new ForEachStmt();
                        fe.line = line; fe.varType = vt; fe.varName = vn; fe.isFinal = fin;
                        fe.iterable = parseExpr();
                        expectOp(")");
                        fe.body = parseStmt();
                        return fe;
                    }
                }
                idx = save;
            }
            Stmt init = null;
            if (!peek().isOp(";")) {
                init = parseForInitOrExprStmtNoSemi();
            }
            expectOp(";");
            Expr cond = null;
            if (!peek().isOp(";")) cond = parseExpr();
            expectOp(";");
            Stmt update = null;
            if (!peek().isOp(")")) {
                Vector ups = new Vector();
                for (;;) {
                    ExprStmt es = new ExprStmt();
                    es.line = peek().line;
                    es.expr = parseExpr();
                    ups.addElement(es);
                    if (peek().isOp(",")) { advance(); continue; }
                    break;
                }
                if (ups.size() == 1) update = (Stmt) ups.elementAt(0);
                else {
                    BlockStmt ub = new BlockStmt();
                    ub.line = line; ub.noScope = true; ub.stmts = ups;
                    update = ub;
                }
            }
            expectOp(")");
            Stmt body = parseStmt();
            ForStmt s = new ForStmt();
            s.line = line; s.init = init; s.cond = cond; s.update = update; s.body = body;
            return s;
        }

        if (t.isKeyword("return")) {
            advance();
            ReturnStmt s = new ReturnStmt();
            s.line = line;
            if (!peek().isOp(";")) s.value = parseExpr();
            expectOp(";");
            return s;
        }

        if (t.isKeyword("break")) {
            advance();
            BreakStmt s = new BreakStmt();
            s.line = line;
            if (peek().type == Token.IDENT) s.label = advance().text;
            expectOp(";");
            return s;
        }

        if (t.isKeyword("continue")) {
            advance();
            ContinueStmt s = new ContinueStmt();
            s.line = line;
            if (peek().type == Token.IDENT) s.label = advance().text;
            expectOp(";");
            return s;
        }

        if (t.type == Token.IDENT && peek2().isOp(":")) {
            // label:  statement   (also  a: b: for (...) ...)
            LabeledStmt ls = new LabeledStmt();
            ls.line = line;
            while (peek().type == Token.IDENT && peek2().isOp(":")) {
                String name = advance().text;
                advance(); // ':'
                if (ls.labels.contains(name)) throw new CompileError("label '" + name + "' is already defined", line);
                ls.labels.addElement(name);
            }
            ls.body = parseStmt();
            return ls;
        }

        if (t.isKeyword("try")) {
            advance();
            BlockStmt tryBlock = parseBlock();
            TryStmt ts = new TryStmt();
            ts.line = line; ts.tryBlock = tryBlock;
            while (peek().isKeyword("catch")) {
                advance();
                expectOp("(");
                StringBuffer tb = new StringBuffer(expectIdent().text);
                while (peek().isOp(".")) { advance(); tb.append('.').append(expectIdent().text); }
                String exFqcn = resolveTypeName(tb.toString());
                String varName = expectIdent().text;
                expectOp(")");
                int csm = scopeMark();
                declareLocal(varName, T.refType(exFqcn));
                BlockStmt cbody = parseBlock();
                scopeReset(csm);
                CatchClause cc = new CatchClause();
                cc.exFqcn = exFqcn; cc.varName = varName; cc.body = cbody;
                ts.catches.addElement(cc);
            }
            if (peek().isKeyword("finally")) {
                advance();
                ts.finallyBlock = parseBlock();
            }
            if (ts.catches.size() == 0 && ts.finallyBlock == null) {
                throw err("'try' must be followed by at least one 'catch' or a 'finally'");
            }
            return ts;
        }

        if (t.isKeyword("assert")) {
            advance();
            AssertStmt as = new AssertStmt();
            as.line = line;
            as.cond = parseExpr();
            if (peek().isOp(":")) {
                advance();
                as.message = parseExpr();
            }
            expectOp(";");
            return as;
        }

        if (t.isKeyword("throw")) {
            advance();
            ThrowStmt s = new ThrowStmt();
            s.line = line;
            s.value = parseExpr();
            expectOp(";");
            return s;
        }

        // "super(args);" -- only meaningful as the first statement of a
        // constructor (enforced in CodeGen, not here); parsed as its own
        // statement form since "super(...)" isn't a general expression.
        if (t.isKeyword("super") && peek2().isOp("(")) {
            advance(); // 'super'
            advance(); // '('
            SuperCallStmt s = new SuperCallStmt();
            s.line = line;
            if (!peek().isOp(")")) {
                for (;;) {
                    s.args.addElement(parseExpr());
                    if (peek().isOp(",")) { advance(); continue; }
                    break;
                }
            }
            expectOp(")");
            expectOp(";");
            return s;
        }

        if (t.isKeyword("final")) {
            advance();
            Stmt s = parseVarDeclNoSemi(true);
            expectOp(";");
            return s;
        }

        if (isTypeKeyword(t)) {
            Stmt s = parseVarDeclNoSemi(false);
            expectOp(";");
            return s;
        }

        // expression statement
        ExprStmt s = new ExprStmt();
        s.line = line;
        s.expr = parseExpr();
        expectOp(";");
        return s;
    }

    private Stmt parseForInitOrExprStmtNoSemi() throws CompileError {
        if (peek().isKeyword("final")) {
            advance();
            return parseVarDeclNoSemi(true);
        }
        if (isTypeKeyword(peek())) {
            return parseVarDeclNoSemi(false);
        }
        ExprStmt s = new ExprStmt();
        s.line = peek().line;
        s.expr = parseExpr();
        return s;
    }

    /** case labels must be constant int (or char, already lexed as int) literals,
     *  optionally negated -- no arbitrary constant expressions. */
    private Expr parseSwitchCaseLabel() throws CompileError {
        // fast path: [-]intLiteral ':' (keeps duplicate-label detection and old bytecode)
        int save = idx;
        boolean neg = false;
        if (peek().isOp("-")) { advance(); neg = true; }
        Token t = peek();
        if (t.type == Token.INT_LIT && t.numKind == Token.NUM_INT && peek2().isOp(":") && (neg || !t.minLit)) {
            advance();
            IntLit il = new IntLit();
            il.line = t.line; il.value = neg ? -t.intValue : t.intValue;
            return il;
        }
        idx = save;
        // anything else (CONSTANT, Canvas.FIRE, KEY_A + 1, ...): an int expression, compared at run time
        return parseOr();
    }

    /** "Type a = 1, b, c[] = {..}" -- one VarDeclStmt, or a scope-less BlockStmt of several. */
    private Stmt parseVarDeclNoSemi(boolean isFinal) throws CompileError {
        int line = peek().line;
        // Java 10-style local type inference, lowered to the concrete initializer
        // type before bytecode generation. Keep it local-only: fields/parameters
        // still require an explicit type, matching Java's rules.
        if (peek().type == Token.IDENT && peek().text.equals("var") && peek2().type == Token.IDENT) {
            advance();
            String name = expectIdent().text;
            if (!peek().isOp("=")) throw err("'var' requires an initializer");
            advance();
            Expr init = parseExpr();
            if (peek().isOp(",")) throw err("a 'var' declaration must declare exactly one variable");
            VarDeclStmt v = new VarDeclStmt();
            v.line = line; v.type = T.VAR; v.name = name; v.isFinal = isFinal; v.init = init;
            declareLocal(name, T.VAR);
            return v;
        }
        int type = parseType();
        boolean plainChar = lastPlainChar;
        Vector decls = new Vector();
        for (;;) {
            String name = expectIdent().text;
            int vt = type;
            if (peek().isOp("[") && peek2().isOp("]")) { // C-style "int a[]"
                advance(); advance();
                vt = T.refType("[" + T.desc(type));
            }
            VarDeclStmt s = new VarDeclStmt();
            s.line = line; s.type = vt; s.name = name; s.isFinal = isFinal;
            s.charTyped = plainChar && vt == type;
            if (peek().isOp("=")) {
                advance();
                s.init = parseInitializer(vt);
            }
            declareLocal(name, vt);
            decls.addElement(s);
            if (peek().isOp(",")) { advance(); continue; }
            break;
        }
        if (decls.size() == 1) return (Stmt) decls.elementAt(0);
        BlockStmt b = new BlockStmt();
        b.line = line; b.noScope = true;
        for (int i = 0; i < decls.size(); i++) b.stmts.addElement(decls.elementAt(i));
        return b;
    }

    /** initializer for a variable of type `type`: "{a, b, c}" for arrays, else an expression. */
    private Expr parseInitializer(int type) throws CompileError {
        if (peek().isOp("{")) {
            if (!T.isArray(type)) throw err("array initializer '{...}' used for a variable that is not an array");
            return parseArrayInit(T.arrayElemDesc(type));
        }
        return parseExpr();
    }

    private Expr parseArrayInit(String elemDesc) throws CompileError {
        int line = peek().line;
        expectOp("{");
        ArrayInitExpr ai = new ArrayInitExpr();
        ai.line = line; ai.elemDesc = elemDesc;
        while (!peek().isOp("}")) {
            if (peek().type == Token.EOF) throw err("unexpected end of file, missing '}'");
            if (peek().isOp("{") && elemDesc.startsWith("[")) ai.elems.addElement(parseArrayInit(elemDesc.substring(1)));
            else ai.elems.addElement(parseExpr());
            if (peek().isOp(",")) { advance(); continue; }
            break;
        }
        expectOp("}");
        return ai;
    }

    // ---------------- expressions ----------------

    private Expr parseExpr() throws CompileError {
        return parseAssignment();
    }

    private static boolean isAssignOp(Token t) {
        return t.isOp("=") || t.isOp("+=") || t.isOp("-=") || t.isOp("*=") || t.isOp("/=") || t.isOp("%=")
            || t.isOp("&=") || t.isOp("|=") || t.isOp("^=") || t.isOp("<<=") || t.isOp(">>=") || t.isOp(">>>=");
    }

    private Expr parseAssignment() throws CompileError {
        int line = peek().line;
        Expr left = parseTernary();
        if (isAssignOp(peek())) {
            if (left instanceof ArrayAccessExpr) {
                String aop = advance().text;
                ArrayAccessExpr ae = (ArrayAccessExpr) left;
                Expr value = parseAssignment();
                ArrayAssignExpr a = new ArrayAssignExpr();
                a.line = line; a.array = ae.array; a.index = ae.index; a.value = value; a.op = aop;
                return a;
            }
            if (left instanceof FieldAccessExpr || left instanceof ChainFieldExpr) {
                String fop = advance().text;
                Expr value = parseAssignment();
                FieldAssignExpr fa = new FieldAssignExpr();
                fa.line = line; fa.lhs = left; fa.op = fop; fa.value = value;
                return fa;
            }
            if (!(left instanceof NameExpr)) {
                throw err("left side of assignment must be a variable, a field (a.b, this.b, f().b) or an array element");
            }
            String targetName = ((NameExpr) left).name;
            String op = advance().text;
            Expr value = parseAssignment();
            AssignExpr a = new AssignExpr();
            a.line = line; a.target = targetName; a.op = op; a.value = value;
            return a;
        }
        return left;
    }

    /** cond ? a : b  (right-associative; the 'then' branch may be any expression). */
    private Expr parseTernary() throws CompileError {
        Expr c = parseOr();
        if (peek().isOp("?")) {
            int line = advance().line;
            Expr a = parseExpr();
            expectOp(":");
            Expr b = parseTernary();
            CondExpr ce = new CondExpr();
            ce.line = line; ce.cond = c; ce.a = a; ce.b = b;
            return ce;
        }
        return c;
    }

    private Expr parseOr() throws CompileError {
        Expr left = parseAnd();
        while (peek().isOp("||")) {
            int line = advance().line;
            Expr right = parseAnd();
            left = bin("||", left, right, line);
        }
        return left;
    }

    private Expr parseAnd() throws CompileError {
        Expr left = parseBitOr();
        while (peek().isOp("&&")) {
            int line = advance().line;
            Expr right = parseBitOr();
            left = bin("&&", left, right, line);
        }
        return left;
    }

    private Expr parseBitOr() throws CompileError {
        Expr left = parseBitXor();
        while (peek().isOp("|")) {
            int line = advance().line;
            Expr right = parseBitXor();
            left = bin("|", left, right, line);
        }
        return left;
    }

    private Expr parseBitXor() throws CompileError {
        Expr left = parseBitAnd();
        while (peek().isOp("^")) {
            int line = advance().line;
            Expr right = parseBitAnd();
            left = bin("^", left, right, line);
        }
        return left;
    }

    private Expr parseBitAnd() throws CompileError {
        Expr left = parseEquality();
        while (peek().isOp("&")) {
            int line = advance().line;
            Expr right = parseEquality();
            left = bin("&", left, right, line);
        }
        return left;
    }

    private Expr parseEquality() throws CompileError {
        Expr left = parseRelational();
        while (peek().isOp("==") || peek().isOp("!=")) {
            String op = advance().text;
            Expr right = parseRelational();
            left = bin(op, left, right, left.line);
        }
        return left;
    }

    private Expr parseRelational() throws CompileError {
        Expr left = parseShift();
        for (;;) {
            if (peek().isOp("<") || peek().isOp("<=") || peek().isOp(">") || peek().isOp(">=")) {
                String op = advance().text;
                Expr right = parseShift();
                left = bin(op, left, right, left.line);
                continue;
            }
            if (peek().isKeyword("instanceof")) {
                int line = advance().line;
                String firstTok = peek().isKeyword("String") ? advance().text : expectIdent().text;
                StringBuffer tb = new StringBuffer(firstTok);
                while (peek().isOp(".")) { advance(); tb.append('.').append(expectIdent().text); }
                String fqcn = resolveTypeName(tb.toString());
                InstanceOfExpr ie = new InstanceOfExpr();
                ie.line = line; ie.operand = left; ie.targetFqcn = fqcn;
                left = ie;
                continue;
            }
            break;
        }
        return left;
    }

    private Expr parseShift() throws CompileError {
        Expr left = parseAdditive();
        while (peek().isOp("<<") || peek().isOp(">>") || peek().isOp(">>>")) {
            String op = advance().text;
            Expr right = parseAdditive();
            left = bin(op, left, right, left.line);
        }
        return left;
    }

    private Expr parseAdditive() throws CompileError {
        Expr left = parseMultiplicative();
        while (peek().isOp("+") || peek().isOp("-")) {
            String op = advance().text;
            Expr right = parseMultiplicative();
            left = bin(op, left, right, left.line);
        }
        return left;
    }

    private Expr parseMultiplicative() throws CompileError {
        Expr left = parseUnary();
        while (peek().isOp("*") || peek().isOp("/") || peek().isOp("%")) {
            String op = advance().text;
            Expr right = parseUnary();
            left = bin(op, left, right, left.line);
        }
        return left;
    }

    private Expr parseUnary() throws CompileError {
        Token t = peek();
        if (t.isOp("-") && peek2().type == Token.INT_LIT && peek2().minLit) {
            // -2147483648 / -9223372036854775808L: the only place these literals are legal
            advance();
            Token lit = advance();
            if (lit.numKind == Token.NUM_LONG) {
                LongLit ll = new LongLit();
                ll.line = t.line; ll.value = Long.MIN_VALUE;
                return ll;
            }
            IntLit il = new IntLit();
            il.line = t.line; il.value = Integer.MIN_VALUE;
            return il;
        }
        if (t.isOp("!") || t.isOp("-") || t.isOp("~") || t.isOp("+")) {
            advance();
            Expr operand = parseUnary();
            UnaryExpr u = new UnaryExpr();
            u.line = t.line; u.op = t.text; u.operand = operand;
            return u;
        }
        if (t.isOp("++") || t.isOp("--")) {
            advance();
            Expr operand = parsePostfix();
            return makeIncDec(operand, t, true);
        }
        return parsePostfix();
    }

    private IncDecExpr makeIncDec(Expr operand, Token op, boolean prefix) throws CompileError {
        IncDecExpr id = new IncDecExpr();
        id.line = op.line; id.op = op.text; id.prefix = prefix;
        if (operand instanceof NameExpr) {
            id.name = ((NameExpr) operand).name;
        } else if (operand instanceof FieldAccessExpr || operand instanceof ChainFieldExpr
                || operand instanceof ArrayAccessExpr) {
            id.target = operand;
        } else {
            throw err("'" + op.text + "' needs a variable, field or array element as its operand");
        }
        return id;
    }

    private Expr parsePostfix() throws CompileError {
        Expr e = parsePrimary();
        for (;;) {
            if (peek().isOp("[")) {
                int line = advance().line;
                Expr idx = parseExpr();
                expectOp("]");
                ArrayAccessExpr ae = new ArrayAccessExpr();
                ae.line = line; ae.array = e; ae.index = idx;
                e = ae;
                continue;
            }
            if (peek().isOp(".")) {
                // receiver.member / receiver.method(args) on any expression
                // (call result, cast, parenthesized expr, array element, literal, 'new X()')
                int line = advance().line;
                if (peek().isKeyword("new")) { // outer.new Inner(args)
                    Expr created = parsePrimary();
                    if (!(created instanceof NewExpr)) throw err("'outer.new' must create a class instance");
                    ((NewExpr) created).outerInstance = e;
                    e = created;
                    continue;
                }
                Token nameTok = expectIdent();
                if (peek().isOp("(")) {
                    advance();
                    ChainCallExpr cc = new ChainCallExpr();
                    cc.line = line; cc.target = e; cc.name = nameTok.text;
                    if (!peek().isOp(")")) {
                        for (;;) {
                            cc.args.addElement(parseExpr());
                            if (peek().isOp(",")) { advance(); continue; }
                            break;
                        }
                    }
                    expectOp(")");
                    e = cc;
                } else {
                    ChainFieldExpr cf = new ChainFieldExpr();
                    cf.line = line; cf.target = e; cf.name = nameTok.text;
                    e = cf;
                }
                continue;
            }
            break;
        }
        if (peek().isOp("++") || peek().isOp("--")) {
            if (e instanceof NameExpr || e instanceof FieldAccessExpr || e instanceof ChainFieldExpr
                    || e instanceof ArrayAccessExpr) {
                Token op = advance();
                return makeIncDec(e, op, false);
            }
        }
        return e;
    }

    private Expr parsePrimary() throws CompileError {
        Token t = peek();

        if (t.isOp("(")) {
            if (looksLikePrimitiveCastAhead()) {
                advance(); // '('
                Token kw = advance();
                expectOp(")");
                Expr operand = parseUnary();
                CastExpr ce = new CastExpr();
                ce.line = t.line; ce.primitiveCast = true; ce.operand = operand;
                String k = kw.text;
                if (k.equals("int")) { ce.targetType = T.INT; ce.targetDesc = "I"; }
                else if (k.equals("long")) { ce.targetType = T.LONG; ce.targetDesc = "J"; }
                else if (k.equals("float")) { ce.targetType = T.FLOAT; ce.targetDesc = "F"; }
                else if (k.equals("double")) { ce.targetType = T.DOUBLE; ce.targetDesc = "D"; }
                else if (k.equals("byte")) { ce.targetType = T.INT; ce.targetDesc = "B"; }
                else if (k.equals("short")) { ce.targetType = T.INT; ce.targetDesc = "S"; }
                else { ce.targetType = T.INT; ce.targetDesc = "C"; }
                return ce;
            }
            if (looksLikeCastAhead()) {
                advance(); // '('
                String first = peek().isKeyword("String") ? advance().text : expectIdent().text;
                StringBuffer tb = new StringBuffer(first);
                while (peek().isOp(".")) { advance(); tb.append('.').append(expectIdent().text); }
                String fqcn = resolveTypeName(tb.toString());
                expectOp(")");
                Expr operand = parseUnary();
                CastExpr ce = new CastExpr();
                ce.line = t.line; ce.targetFqcn = fqcn; ce.operand = operand;
                return ce;
            }
            advance();
            Expr e = parseExpr();
            expectOp(")");
            return e;
        }

        if (t.type == Token.INT_LIT) {
            advance();
            if (t.minLit) {
                throw new CompileError("integer number too large: " + t.text.replace("L", "")
                        + " (only legal as the operand of unary minus)", t.line);
            }
            if (t.numKind == Token.NUM_LONG) {
                LongLit ll = new LongLit();
                ll.line = t.line; ll.value = t.longValue;
                return ll;
            }
            IntLit e = new IntLit();
            e.line = t.line; e.value = t.intValue; e.isChar = t.isChar;
            return e;
        }

        if (t.type == Token.FLOAT_LIT) {
            advance();
            if (t.numKind == Token.NUM_FLOAT) {
                FloatLit fl = new FloatLit();
                fl.line = t.line; fl.value = t.floatValue;
                return fl;
            }
            DoubleLit dl = new DoubleLit();
            dl.line = t.line; dl.value = t.doubleValue;
            return dl;
        }

        if (t.type == Token.STRING_LIT) {
            advance();
            StrLit e = new StrLit();
            e.line = t.line; e.value = t.strValue;
            return e;
        }

        if (t.isKeyword("true") || t.isKeyword("false")) {
            advance();
            BoolLit e = new BoolLit();
            e.line = t.line; e.value = t.text.equals("true");
            return e;
        }

        if (t.isKeyword("null")) {
            advance();
            NullLit e = new NullLit();
            e.line = t.line;
            return e;
        }

        if (t.isKeyword("new")) {
            advance();
            // array creation: new <type>[sizeExpr]
            if ((peek().isKeyword("int") || peek().isKeyword("boolean") || peek().isKeyword("byte") ||
                 peek().isKeyword("short") || peek().isKeyword("char") ||
                 peek().isKeyword("long") || peek().isKeyword("float") || peek().isKeyword("double") ||
                 peek().isKeyword("String") || peek().type == Token.IDENT) && peek2().isOp("[")) {
                String elemDesc;
                if (peek().isKeyword("int")) { advance(); elemDesc = "I"; }
                else if (peek().isKeyword("boolean")) { advance(); elemDesc = "Z"; }
                else if (peek().isKeyword("byte")) { advance(); elemDesc = "B"; }
                else if (peek().isKeyword("short")) { advance(); elemDesc = "S"; }
                else if (peek().isKeyword("char")) { advance(); elemDesc = "C"; }
                else if (peek().isKeyword("long")) { advance(); elemDesc = "J"; }
                else if (peek().isKeyword("float")) { advance(); elemDesc = "F"; }
                else if (peek().isKeyword("double")) { advance(); elemDesc = "D"; }
                else if (peek().isKeyword("String")) { advance(); elemDesc = "Ljava/lang/String;"; }
                else { elemDesc = T.desc(T.refType(resolveTypeName(advance().text))); }
                expectOp("[");
                if (peek().isOp("]")) { // new T[] { a, b, c }
                    advance();
                    String ied = elemDesc;
                    while (peek().isOp("[") && peek2().isOp("]")) { advance(); advance(); ied = "[" + ied; } // new int[][]{...}
                    if (!peek().isOp("{")) throw err("array dimension missing: expected '{' after 'new " + (elemDesc.length() == 1 ? "T" : "Type") + "[]'");
                    return parseArrayInit(ied);
                }
                Expr sizeExpr = parseExpr();
                expectOp("]");
                NewArrayExpr na = new NewArrayExpr();
                na.line = t.line; na.size = sizeExpr;
                // further dimensions: new T[a][b] (sized) and new T[a][][] (trailing, unsized)
                int unsized = 0;
                while (peek().isOp("[")) {
                    advance();
                    if (peek().isOp("]")) { advance(); unsized++; continue; }
                    if (unsized > 0) throw err("array dimension missing");
                    Expr dim = parseExpr();
                    expectOp("]");
                    if (na.extraDims == null) na.extraDims = new Vector();
                    na.extraDims.addElement(dim);
                }
                StringBuffer ed = new StringBuffer();
                for (int u = 0; u < unsized; u++) ed.append('[');
                ed.append(elemDesc);
                na.elemDesc = ed.toString();
                return na;
            }
            Token cname = expectIdent();
            String cn = cname.text;
            while (peek().isOp(".") && peek2().type == Token.IDENT) { advance(); cn = cn + "." + advance().text; } // new java.util.Vector()
            skipTypeArgs(); // new Box<String>(...) -- erased
            NewExpr n = new NewExpr();
            n.line = t.line;
            n.className = resolveTypeName(cn);
            expectOp("(");
            if (!peek().isOp(")")) {
                for (;;) {
                    n.args.addElement(parseExpr());
                    if (peek().isOp(",")) { advance(); continue; }
                    break;
                }
            }
            expectOp(")");
            if (peek().isOp("{")) return parseAnonBody(n, t.line);
            skipTypeArgsAfterNew();
            return n;
        }

        if (t.isKeyword("this")) {
            advance();
            if (!peek().isOp(".")) {
                ThisExpr te = new ThisExpr();
                te.line = t.line;
                return te;
            }
            // "this.member" / "this.method(...)": treat "this" as the first dotted part
            return parseDottedTail(t.line, "this");
        }

        if (t.isKeyword("super")) {
            advance();
            if (peek().isOp(".")) {
                // "super.method(...)" / "super.field": CodeGen resolves the
                // "super" qualifier against the real superclass chain.
                return parseDottedTail(t.line, "super");
            }
            throw err("'super' must be followed by '.' (e.g. super.method()), " +
                    "or used as 'super(...)' as the first statement of a constructor");
        }

        if (t.type == Token.IDENT) {
            String first = advance().text;
            return parseDottedTail(t.line, first);
        }

        // String.valueOf(x) / String.copyValueOf(..): 'String' is a keyword token here, but
        // followed by '.' it names the class java.lang.String
        if (t.isKeyword("String") && peek2().isOp(".")) {
            advance();
            return parseDottedTail(t.line, "String");
        }

        if (t.isKeyword("assert")) throw assertAsIdentifier();
        throw err("unexpected token '" + t.text + "'");
    }

    /** shared tail for "ident(.ident)* [ ( args ) ]" and "this(.ident)* [ ( args ) ]" */
    /** One-token-of-lookahead heuristic to distinguish "(Type) expr" (cast) from
     *  "(expr)" (grouping): requires a dotted identifier chain inside the
     *  parens, and a token after the closing ')' that can only start a new
     *  primary expression (never a binary operator continuation). Doesn't
     *  attempt to resolve whether the identifier is actually a known type --
     *  same pragmatic approach as isTypeKeyword() elsewhere in this parser. */
    private boolean looksLikeCastAhead() {
        int j = idx; // at '('
        if (!((Token) toks.elementAt(j)).isOp("(")) return false;
        j++;
        if (j >= toks.size()) return false;
        Token first = (Token) toks.elementAt(j);
        // "String" is lexed as a keyword (parseType() special-cases it), not an IDENT --
        // without this, "(String) x" never even looked like a cast, see resolveTypeName.
        if (first.type != Token.IDENT && !first.isKeyword("String")) return false;
        j++;
        while (j + 1 < toks.size() && ((Token) toks.elementAt(j)).isOp(".") && ((Token) toks.elementAt(j + 1)).type == Token.IDENT) {
            j += 2;
        }
        if (j >= toks.size() || !((Token) toks.elementAt(j)).isOp(")")) return false;
        j++;
        if (j >= toks.size()) return false;
        Token after = (Token) toks.elementAt(j);
        if (after.type == Token.IDENT || after.type == Token.INT_LIT || after.type == Token.FLOAT_LIT || after.type == Token.STRING_LIT) return true;
        if (after.isKeyword("true") || after.isKeyword("false") || after.isKeyword("null") ||
            after.isKeyword("new") || after.isKeyword("this") || after.isKeyword("super")) return true;
        if (after.isOp("(") || after.isOp("!") || after.isOp("~")) return true;
        return false;
    }

    /** "(int) x", "(long) -x", "(float) i" ... -- a primitive type keyword in parens is
     *  always a cast (a parenthesized expression can't start with one), so unlike the
     *  reference-cast heuristic above this needs no guess about what the type name is.
     *  A following '-', '+', '++' or '--' IS accepted here ("(int) -x" is a cast of -x;
     *  with a reference type it would be a subtraction, which is why looksLikeCastAhead
     *  must not accept them). */
    private boolean looksLikePrimitiveCastAhead() {
        int j = idx;
        if (!((Token) toks.elementAt(j)).isOp("(")) return false;
        j++;
        if (j + 1 >= toks.size()) return false;
        Token kw = (Token) toks.elementAt(j);
        if (!(kw.isKeyword("int") || kw.isKeyword("long") || kw.isKeyword("float") || kw.isKeyword("double")
                || kw.isKeyword("byte") || kw.isKeyword("short") || kw.isKeyword("char"))) return false;
        if (!((Token) toks.elementAt(j + 1)).isOp(")")) return false;
        if (j + 2 >= toks.size()) return false;
        Token after = (Token) toks.elementAt(j + 2);
        if (after.type == Token.IDENT || after.type == Token.INT_LIT || after.type == Token.FLOAT_LIT
                || after.type == Token.STRING_LIT) return true;
        if (after.isKeyword("true") || after.isKeyword("false") || after.isKeyword("null")
                || after.isKeyword("new") || after.isKeyword("this") || after.isKeyword("super")) return true;
        return after.isOp("(") || after.isOp("!") || after.isOp("~") || after.isOp("-") || after.isOp("+")
                || after.isOp("++") || after.isOp("--");
    }

    private Expr parseDottedTail(int line, String first) throws CompileError {
        Vector parts = new Vector();
        parts.addElement(first);
        while (peek().isOp(".")) {
            if (peek2().isKeyword("new")) break; // outer.new Inner(): handled by parsePostfix
            if (peek2().isKeyword("this")) { // Outer.this
                advance(); advance();
                OuterThisExpr ot = new OuterThisExpr();
                ot.line = line; ot.className = resolveTypeName(join(parts));
                return ot;
            }
            advance();
            parts.addElement(expectIdent().text);
        }
        if (peek().isOp("(")) {
            String name = (String) parts.elementAt(parts.size() - 1);
            String qualifier = null;
            if (parts.size() > 1) {
                StringBuffer qb = new StringBuffer();
                for (int i = 0; i < parts.size() - 1; i++) {
                    if (i > 0) qb.append('.');
                    qb.append((String) parts.elementAt(i));
                }
                qualifier = qb.toString();
            }
            advance(); // '('
            CallExpr c = new CallExpr();
            c.line = line; c.qualifier = qualifier; c.name = name;
            if (!peek().isOp(")")) {
                for (;;) {
                    c.args.addElement(parseExpr());
                    if (peek().isOp(",")) { advance(); continue; }
                    break;
                }
            }
            expectOp(")");
            return c;
        }
        if (parts.size() >= 2) {
            // a.b -> qualifier "a", name "b";  a.b.c -> qualifier "a.b", name "c"
            // (CodeGen decides whether the qualifier is a variable path or a class name)
            Vector qparts = new Vector();
            for (int i = 0; i < parts.size() - 1; i++) qparts.addElement(parts.elementAt(i));
            FieldAccessExpr fa = new FieldAccessExpr();
            fa.line = line;
            fa.qualifier = join(qparts);
            fa.name = (String) parts.elementAt(parts.size() - 1);
            return fa;
        }
        if (first.equals("this")) {
            // shouldn't reach here (bare "this" handled by caller), but keep safe fallback
            ThisExpr te = new ThisExpr();
            te.line = line;
            return te;
        }
        NameExpr n = new NameExpr();
        n.line = line; n.name = first;
        return n;
    }

    private static String join(Vector parts) {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < parts.size(); i++) {
            if (i > 0) sb.append('.');
            sb.append((String) parts.elementAt(i));
        }
        return sb.toString();
    }

    private BinaryExpr bin(String op, Expr left, Expr right, int line) {
        BinaryExpr b = new BinaryExpr();
        b.op = op; b.left = left; b.right = right; b.line = line;
        return b;
    }
}
