package com.dashers.j2mebuilderide.compiler;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipInputStream;

/**
 * Offline ECJ classpath for J2ME. The bundled SDK API is stored as a normal
 * jar in assets; its original .clazz entries are renamed to .class. Project
 * libraries are overlaid afterwards, so the same resolver handles MIDP/CLDC
 * classes and user supplied jars.
 *
 * ECJ is accessed through reflection (and a java.lang.reflect.Proxy for the
 * INameEnvironment interface) so this file compiles even when the build tool
 * does not put ecj-mini.jar on the compile classpath. If ECJ is missing at
 * runtime, EcjCompiler.isAvailable() is false and the built-in compiler is used.
 */
public final class J2meNameEnvironment {
    private final Hashtable classes = new Hashtable(); // internal name -> byte[]

    // Reflection handles (resolved lazily, once per instance)
    private Method readMethod;          // ClassFileReader.read(byte[], String)
    private Constructor readerCtor;     // ClassFileReader(byte[], char[]) on official ECJ
    private Constructor answerCtor;     // NameEnvironmentAnswer(IBinaryType, AccessRestriction)

    public J2meNameEnvironment(InputStream apiJar) throws IOException {
        loadZip(apiJar, true);
    }

    public void addJar(File jar) throws IOException {
        ZipFile z = new ZipFile(jar);
        try {
            Enumeration en = z.entries();
            while (en.hasMoreElements()) {
                ZipEntry e = (ZipEntry) en.nextElement();
                String n = e.getName();
                if (e.isDirectory() || !n.endsWith(".class")) continue;
                InputStream in = z.getInputStream(e);
                try { classes.put(internalName(n), readAll(in)); }
                finally { in.close(); }
            }
        } finally { z.close(); }
    }

    public void addClasses(Hashtable overlay) {
        if (overlay == null) return;
        Enumeration en = overlay.keys();
        while (en.hasMoreElements()) {
            String name = String.valueOf(en.nextElement());
            Object value = overlay.get(name);
            if (value instanceof byte[]) classes.put(name.replace('.', '/'), value);
        }
    }

    private void loadZip(InputStream input, boolean api) throws IOException {
        ZipInputStream zin = new ZipInputStream(input);
        ZipEntry e;
        while ((e = zin.getNextEntry()) != null) {
            String n = e.getName();
            if (e.isDirectory() || !n.endsWith(".class")) continue;
            classes.put(internalName(n), readAll(zin));
        }
        zin.close();
    }

    private static String internalName(String entry) {
        if (entry.startsWith("/")) entry = entry.substring(1);
        return entry.substring(0, entry.length() - 6);
    }

    private static byte[] readAll(InputStream in) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] b = new byte[8192];
        int n;
        while ((n = in.read(b)) != -1) out.write(b, 0, n);
        return out.toByteArray();
    }

    /** Builds an org.eclipse.jdt.internal.compiler.env.INameEnvironment proxy backed by this object. */
    public Object asNameEnvironment() throws Exception {
        final Class iface = EcjCompiler.cls("org.eclipse.jdt.internal.compiler.env.INameEnvironment");
        Class reader = EcjCompiler.cls("org.eclipse.jdt.internal.compiler.classfmt.ClassFileReader");
        Class binaryType = EcjCompiler.cls("org.eclipse.jdt.internal.compiler.env.IBinaryType");
        try {   // patched ecj-mini: ClassFileReader.read(byte[], String)
            readMethod = reader.getMethod("read", new Class[] { byte[].class, String.class });
        } catch (NoSuchMethodException e) {   // official ECJ: new ClassFileReader(byte[], char[])
            readerCtor = reader.getConstructor(new Class[] { byte[].class, char[].class });
        }
        Class answer = EcjCompiler.cls("org.eclipse.jdt.internal.compiler.env.NameEnvironmentAnswer");
        Constructor[] cs = answer.getConstructors();
        for (int i = 0; i < cs.length; i++) {
            Class[] p = cs[i].getParameterTypes();
            if (p.length == 2 && p[0] == binaryType) { answerCtor = cs[i]; break; }
        }
        if (answerCtor == null) throw new NoSuchMethodException("NameEnvironmentAnswer(IBinaryType, AccessRestriction)");

        return Proxy.newProxyInstance(iface.getClassLoader(), new Class[] { iface }, new InvocationHandler() {
            public Object invoke(Object proxy, Method m, Object[] a) throws Throwable {
                String name = m.getName();
                if (name.equals("findType")) {
                    if (a != null && a.length >= 1 && a[0] instanceof char[][] && (a.length == 1 || !(a[1] instanceof char[]))) {
                        return findType((char[][]) a[0]);
                    }
                    if (a != null && a.length >= 2 && a[0] instanceof char[] && a[1] instanceof char[][]) {
                        return findType((char[]) a[0], (char[][]) a[1]);
                    }
                    return null;
                }
                if (name.equals("isPackage")) {
                    return isPackage((char[][]) a[0], (char[]) a[1]) ? Boolean.TRUE : Boolean.FALSE;
                }
                if (name.equals("cleanup")) { cleanup(); return null; }
                if (name.equals("hashCode")) return Integer.valueOf(System.identityHashCode(proxy));
                if (name.equals("equals")) return Boolean.valueOf(proxy == a[0]);
                if (name.equals("toString")) return "J2meNameEnvironment";
                Class rt = m.getReturnType();
                if (rt == boolean.class) return Boolean.FALSE;
                return null; // module-related queries etc.
            }
        });
    }

    private Object find(String internal) {
        byte[] bytes = (byte[]) classes.get(internal);
        if (bytes == null) return null;
        try {
            Object binary = readMethod != null
                    ? readMethod.invoke(null, new Object[] { bytes, internal + ".class" })
                    : readerCtor.newInstance(new Object[] { bytes, (internal + ".class").toCharArray() });
            return answerCtor.newInstance(new Object[] { binary, null });
        } catch (Exception e) {
            return null;
        }
    }

    public Object findType(char[][] compoundTypeName) {
        if (compoundTypeName == null || compoundTypeName.length == 0) return null;
        StringBuffer s = new StringBuffer();
        for (int i = 0; i < compoundTypeName.length; i++) {
            if (i > 0) s.append('/');
            s.append(compoundTypeName[i]);
        }
        return find(s.toString());
    }

    public Object findType(char[] typeName, char[][] packageName) {
        StringBuffer s = new StringBuffer();
        if (packageName != null) {
            for (int i = 0; i < packageName.length; i++) {
                if (i > 0) s.append('/');
                s.append(packageName[i]);
            }
            if (packageName.length > 0) s.append('/');
        }
        s.append(typeName);
        return find(s.toString());
    }

    public boolean isPackage(char[][] parentPackageName, char[] packageName) {
        StringBuffer s = new StringBuffer();
        if (parentPackageName != null) {
            for (int i = 0; i < parentPackageName.length; i++) {
                if (i > 0) s.append('/');
                s.append(parentPackageName[i]);
            }
            if (parentPackageName.length > 0) s.append('/');
        }
        s.append(packageName);
        String prefix = s.toString() + "/";
        Enumeration en = classes.keys();
        while (en.hasMoreElements()) {
            if (String.valueOf(en.nextElement()).startsWith(prefix)) return true;
        }
        return false;
    }

    public void cleanup() { classes.clear(); }
}
