package com.dashers.j2mebuilderide.ui;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Theme palette (light + dark) and small view factories shared by every
 * screen. All icons are Material Design vector drawables (res/drawable/ic_*.xml)
 * tinted at runtime, so a single icon works in both themes.
 */
public final class Ui {
    private Ui() {}

    // ---- palette (mutable: applyTheme() swaps the whole set) ----
    public static boolean dark = true;
    public static int BG, EDITOR, SURFACE, SURFACE2, STROKE, TEXT, MUTED, ACCENT, GREEN, RED, AMBER;
    /** Soft accent tint used behind icon badges and selected chips. */
    public static int ACCENT_SOFT, ACCENT_SELECT, RED_SOFT, EDITOR_TEXT;
    public static final int WHITE = 0xFFFFFFFF;
    public static Themes.Theme theme = Themes.ALL[0];

    static { applyTheme(Themes.ALL[0], null); }

    /** Backwards-compatible switch used by older call sites. */
    public static void applyTheme(boolean useDark) {
        applyTheme(Themes.theme(useDark ? "midnight" : "light"), null);
    }

    /** @param syntaxId editor colour scheme id, or null/"auto" to follow the app theme. */
    public static void applyTheme(Themes.Theme t, String syntaxId) {
        theme = t;
        dark = t.dark;
        BG = t.bg; EDITOR = t.editor; SURFACE = t.surface; SURFACE2 = t.surface2; STROKE = t.stroke;
        TEXT = t.text; MUTED = t.muted; ACCENT = t.accent; GREEN = t.green; RED = t.red; AMBER = t.amber;
        EDITOR_TEXT = t.text;
        ACCENT_SOFT = (t.accent & 0x00FFFFFF) | (dark ? 0x22000000 : 0x1A000000);
        ACCENT_SELECT = (t.accent & 0x00FFFFFF) | 0x55000000;
        RED_SOFT = (t.red & 0x00FFFFFF) | (dark ? 0x22000000 : 0x14000000);

        Themes.Syntax sx = Themes.syntax(syntaxId == null ? "" : syntaxId);
        if (sx != null) {
            EDITOR = sx.bg;
            EDITOR_TEXT = sx.text;
            Highlighter.applyScheme(sx);
        } else {
            Highlighter.applyTheme(dark);
        }
    }

    private static float density = 1f;

    public static void init(Context c) {
        density = c.getResources().getDisplayMetrics().density;
    }

    public static int dp(float v) {
        return Math.round(v * density);
    }

    /** Status/navigation bar colours + light-icon flags for the active theme. */
    public static void applySystemBars(Activity a) {
        a.getWindow().setStatusBarColor(BG);
        a.getWindow().setNavigationBarColor(BG);
        a.getWindow().getDecorView().setBackgroundColor(BG);
        int flags = a.getWindow().getDecorView().getSystemUiVisibility();
        if (!dark) {
            if (Build.VERSION.SDK_INT >= 23) flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            if (Build.VERSION.SDK_INT >= 26) flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        } else {
            if (Build.VERSION.SDK_INT >= 23) flags &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            if (Build.VERSION.SDK_INT >= 26) flags &= ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        }
        a.getWindow().getDecorView().setSystemUiVisibility(flags);
    }

    public static int dialogTheme() {
        return dark ? AlertDialog.THEME_DEVICE_DEFAULT_DARK : AlertDialog.THEME_DEVICE_DEFAULT_LIGHT;
    }

    // ---- drawables ----

    public static GradientDrawable rect(int fill, float radiusDp, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radiusDp));
        if (stroke != 0) g.setStroke(dp(1), stroke);
        return g;
    }

    public static GradientDrawable circle(int fill) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(fill);
        return g;
    }

    public static Drawable ripple(Drawable content) {
        int rc = dark ? 0x33FFFFFF : 0x22000000;
        return new RippleDrawable(ColorStateList.valueOf(rc), content, null);
    }

    // ---- layout params ----

    public static LinearLayout.LayoutParams lp(int w, int h) {
        return new LinearLayout.LayoutParams(w, h);
    }

    public static LinearLayout.LayoutParams lpWeight(int w, int h, float weight) {
        return new LinearLayout.LayoutParams(w, h, weight);
    }

    /** Margins are in dp. */
    public static LinearLayout.LayoutParams lpMargin(int w, int h, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(dp(l), dp(t), dp(r), dp(b));
        return p;
    }

    public static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    public static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    // ---- text ----

    public static TextView label(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    /** Rounded tappable pill: filled when fill != 0, otherwise outlined. */
    public static TextView pill(Context c, String s, int fill, int textColor, View.OnClickListener l) {
        TextView t = label(c, s, 14, textColor, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(16), dp(9), dp(16), dp(9));
        t.setBackground(ripple(fill != 0 ? rect(fill, 20, 0) : rect(0x00000000, 20, STROKE)));
        t.setClickable(true);
        t.setOnClickListener(l);
        return t;
    }

    /** Small uppercase section heading. */
    public static TextView section(Context c, String s) {
        TextView t = label(c, s.toUpperCase(), 11.5f, MUTED, true);
        t.setLetterSpacing(0.08f);
        t.setPadding(dp(4), dp(18), 0, dp(8));
        return t;
    }

    // ---- icons (Material vector drawables, tinted) ----

    /** Plain tinted icon, no click ripple. */
    public static ImageView icon(Context c, int res, int tint, int sizeDp) {
        ImageView v = new ImageView(c);
        v.setImageResource(res);
        v.setColorFilter(tint, PorterDuff.Mode.SRC_IN);
        v.setScaleType(ImageView.ScaleType.FIT_CENTER);
        int pad = dp(Math.max(0, (sizeDp - 24) / 2f));
        v.setPadding(pad, pad, pad, pad);
        return v;
    }

    /** 44dp round tappable icon button. */
    public static ImageView iconButton(Context c, int res, int tint, View.OnClickListener l) {
        ImageView v = new ImageView(c);
        v.setImageResource(res);
        v.setColorFilter(tint, PorterDuff.Mode.SRC_IN);
        v.setScaleType(ImageView.ScaleType.CENTER);
        v.setBackground(ripple(circle(0x00000000)));
        v.setClickable(true);
        v.setOnClickListener(l);
        return v;
    }

    public static void setTint(ImageView v, int tint) {
        v.setColorFilter(tint, PorterDuff.Mode.SRC_IN);
    }

    // ---- inputs / cards ----

    public static EditText field(Context c, String hint, String value) {
        EditText e = new EditText(c);
        e.setHint(hint);
        e.setText(value);
        e.setSingleLine(true);
        e.setTextSize(15);
        e.setTextColor(TEXT);
        e.setHintTextColor(MUTED);
        e.setHighlightColor(ACCENT_SELECT);
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        e.setPadding(dp(14), dp(12), dp(14), dp(12));
        e.setBackground(rect(SURFACE2, 12, STROKE));
        return e;
    }

    /** Small caption above an input. */
    public static LinearLayout labeled(Context c, String caption, View input) {
        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        TextView t = label(c, caption, 12, MUTED, true);
        t.setPadding(dp(4), 0, 0, dp(6));
        col.addView(t);
        col.addView(input, lp(MATCH, WRAP));
        col.setLayoutParams(lpMargin(MATCH, WRAP, 0, 0, 0, 16));
        return col;
    }

    public static LinearLayout card(Context c) {
        LinearLayout card = new LinearLayout(c);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(rect(SURFACE, 16, STROKE));
        return card;
    }

    /** Settings-style row: round icon badge, title + subtitle, optional trailing view. */
    public static LinearLayout tile(Context c, int iconRes, String title, String sub, View trailing) {
        LinearLayout row = new LinearLayout(c);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(14), dp(12), dp(14), dp(12));
        row.setBackground(ripple(rect(0x00000000, 16, 0)));
        row.setClickable(true);

        FrameLayoutBadge badge = new FrameLayoutBadge(c, iconRes);
        row.addView(badge, lpMargin(dp(40), dp(40), 0, 0, 14, 0));

        LinearLayout mid = new LinearLayout(c);
        mid.setOrientation(LinearLayout.VERTICAL);
        mid.addView(label(c, title, 15, TEXT, true));
        if (sub != null && sub.length() > 0) {
            TextView s = label(c, sub, 12, MUTED, false);
            s.setPadding(0, dp(2), 0, 0);
            mid.addView(s);
        }
        row.addView(mid, lpWeight(0, WRAP, 1));
        if (trailing != null) row.addView(trailing);
        return row;
    }

    /** Tinted rounded-square holding a Material icon. */
    public static final class FrameLayoutBadge extends android.widget.FrameLayout {
        public FrameLayoutBadge(Context c, int iconRes) {
            super(c);
            setBackground(rect(ACCENT_SOFT, 12, 0));
            ImageView iv = new ImageView(c);
            iv.setImageResource(iconRes);
            iv.setColorFilter(ACCENT, PorterDuff.Mode.SRC_IN);
            iv.setScaleType(ImageView.ScaleType.CENTER);
            addView(iv, new LayoutParams(MATCH, MATCH));
        }
    }

    /** 1dp divider line. */
    public static View divider(Context c) {
        View v = new View(c);
        v.setBackgroundColor(STROKE);
        v.setLayoutParams(lpMargin(MATCH, 1, 14, 0, 14, 0));
        return v;
    }

    /** Parse "#RRGGBB" safely; returns fallback on error. */
    public static int parseColor(String s, int fallback) {
        try { return Color.parseColor(s); } catch (Exception e) { return fallback; }
    }
}
