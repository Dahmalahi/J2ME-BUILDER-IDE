package com.dashers.j2mebuilderide.ui;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

import com.dashers.j2mebuilderide.ide.SpriteDoc;

/**
 * Zoomable, pannable pixel canvas for the Sprite Editor. One finger draws with the current tool, two fingers
 * zoom (pinch) and pan. Transparent areas show a checkerboard; an optional pixel grid and sprite-sheet
 * frame grid are drawn on top.
 */
public final class PixelCanvasView extends View {
    public static final int T_PENCIL = 0, T_ERASER = 1, T_FILL = 2, T_PICK = 3, T_LINE = 4, T_RECT = 5, T_OVAL = 6, T_MOVE = 7, T_SELECT = 8,
            T_DITHER = 9, T_LIGHTEN = 10, T_DARKEN = 11, T_SPRAY = 12, T_RECOLOR = 13;

    public interface Listener {
        /** A pixel was picked with the eyedropper (ARGB, alpha may be 0). */
        void onPicked(int argb);
        /** The picture changed (stroke finished, fill ...). */
        void onChanged();
        /** Zoom / pan changed. */
        void onViewChanged();
        /** A floating layer (imported image, pasted or lifted selection) started or ended. */
        void onFloatChanged(boolean active);
    }

    public int tool = T_PENCIL;
    public int color = 0xFF000000;
    public int brush = 1;
    public boolean grid = true;
    public boolean mirror = false;
    public boolean filled = false;
    public boolean mirrorY = false;
    /** Custom guide grid (any cell size / offset), independent of the pixel grid and the sheet frame grid. */
    public boolean userGrid = false;
    public int gridW = 16, gridH = 16, gridOx = 0, gridOy = 0;
    public int gridColor = 0xCCFF4081;
    public boolean frameGrid = true;
    private boolean[] touched;
    private final java.util.Random rnd = new java.util.Random();

    private SpriteDoc doc;
    private Bitmap bmp;
    private boolean bmpDirty = true;
    private Listener listener;

    private float scale = 8f, offX, offY;
    private boolean fitted;

    private final Paint pBmp = new Paint();
    private final Paint pFill = new Paint();
    private final Paint pLine = new Paint();
    private final RectF rf = new RectF();
    private float[] pts = new float[0];
    private final ScaleGestureDetector sgd;

    // gesture state
    private boolean drawing, multi;
    private int[] base;
    private int sx, sy, lx, ly;
    private float lastFx, lastFy;
    private int lastPtrCount;

    // ---- floating layer (import / paste / lifted selection): move, resize, flip, rotate, then apply ----
    public boolean lockAspect = true;
    private boolean floating;
    private int[] fsrc;                 // source pixels of the layer (flips / rotation are baked in)
    private int fsw, fsh;               // source size
    private int fx, fy, fdw, fdh;       // where it sits on the picture and its current size
    private Bitmap fbmp;
    private boolean fdirty;
    private int fMode;                  // 0 none, 1 move, 2 resize
    private int fhx, fhy;               // resize handle direction (-1, 0, 1)
    private float fDownX, fDownY;
    private int fox, foy, fow, foh;     // rect when the gesture started
    private static final int[][] HANDLES = {{-1, -1}, {1, -1}, {-1, 1}, {1, 1}, {0, -1}, {0, 1}, {-1, 0}, {1, 0}};

    // ---- rectangular selection + internal clipboard ----
    private boolean hasSel;
    private int selX, selY, selW, selH;
    private boolean selDragging;
    private int[] clip;
    private int clipW, clipH;
    private final Paint pDash = new Paint();

    public PixelCanvasView(Context c) {
        super(c);
        pBmp.setFilterBitmap(false);
        pBmp.setAntiAlias(false);
        pFill.setStyle(Paint.Style.FILL);
        pLine.setStyle(Paint.Style.STROKE);
        pLine.setStrokeWidth(1f);
        pDash.setStyle(Paint.Style.STROKE);
        pDash.setStrokeWidth(Ui.dp(1.5f));
        pDash.setPathEffect(new DashPathEffect(new float[]{Ui.dp(5), Ui.dp(4)}, 0));
        sgd = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScale(ScaleGestureDetector d) {
                float f = d.getScaleFactor();
                zoomAround(d.getFocusX(), d.getFocusY(), scale * f);
                return true;
            }
        });
    }

    public void setListener(Listener l) { listener = l; }

    public void setDoc(SpriteDoc d) {
        boolean wasFloating = floating;
        doc = d;
        bmp = null;
        floating = false;
        fbmp = null;
        hasSel = false;
        selDragging = false;
        bmpDirty = true;
        fitted = false;
        invalidate();
        if (wasFloating && listener != null) listener.onFloatChanged(false);
    }

    public SpriteDoc getDoc() { return doc; }

    /** Pixels changed from outside (undo, redo, dialogs). */
    public void refresh() {
        bmpDirty = true;
        invalidate();
    }

    public float getScale() { return scale; }

    public void fit() {
        if (doc == null || getWidth() == 0 || getHeight() == 0) return;
        float s = Math.min(getWidth() / (float) doc.w, getHeight() / (float) doc.h) * 0.92f;
        scale = Math.max(1f, s);
        offX = (getWidth() - doc.w * scale) / 2f;
        offY = (getHeight() - doc.h * scale) / 2f;
        fitted = true;
        invalidate();
        if (listener != null) listener.onViewChanged();
    }

    private void zoomAround(float fx, float fy, float ns) {
        ns = Math.max(1f, Math.min(80f, ns));
        float k = ns / scale;
        offX = fx - (fx - offX) * k;
        offY = fy - (fy - offY) * k;
        scale = ns;
        clampPan();
        invalidate();
        if (listener != null) listener.onViewChanged();
    }

    /** Keep at least a few pixels of the picture on screen. */
    private void clampPan() {
        if (doc == null) return;
        float keep = Ui.dp(48);
        float iw = doc.w * scale, ih = doc.h * scale;
        offX = Math.max(keep - iw, Math.min(getWidth() - keep, offX));
        offY = Math.max(keep - ih, Math.min(getHeight() - keep, offY));
    }

    // ------------------------------------------------------------------
    // drawing
    // ------------------------------------------------------------------

    private void ensureBitmap() {
        if (doc == null) return;
        if (bmp == null || bmp.getWidth() != doc.w || bmp.getHeight() != doc.h) {
            bmp = Bitmap.createBitmap(doc.w, doc.h, Bitmap.Config.ARGB_8888);
            bmpDirty = true;
        }
        if (bmpDirty) {
            bmp.setPixels(doc.px, 0, doc.w, 0, 0, doc.w, doc.h);
            bmpDirty = false;
        }
    }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        if (!fitted) fit();
    }

    @Override protected void onDraw(Canvas c) {
        if (doc == null) return;
        if (!fitted) fit();
        ensureBitmap();
        float x0 = offX, y0 = offY, x1 = offX + doc.w * scale, y1 = offY + doc.h * scale;

        c.save();
        c.clipRect(x0, y0, x1, y1);
        drawChecker(c, x0, y0, x1, y1);
        rf.set(x0, y0, x1, y1);
        c.drawBitmap(bmp, null, rf, pBmp);
        if (floating) drawFloatBitmap(c);

        if (grid && scale >= 6f) {
            pLine.setColor(0x33000000);
            drawGrid(c, 1, 1, 0, 0, x0, y0, x1, y1);
        }
        if (userGrid) {
            pLine.setColor(gridColor);
            pLine.setStrokeWidth(Math.max(1f, Ui.dp(1)));
            drawGrid(c, Math.max(1, gridW), Math.max(1, gridH), gridOx, gridOy, x0, y0, x1, y1);
            pLine.setStrokeWidth(1f);
        }
        if (frameGrid && doc.frameW > 0 && doc.frameH > 0 && (doc.frameW < doc.w || doc.frameH < doc.h)) {
            pLine.setColor(0xCC00B0FF);
            drawGrid(c, doc.frameW, doc.frameH, 0, 0, x0, y0, x1, y1);
        }
        c.restore();

        pLine.setColor(0xFF888888);
        rf.set(x0 - 0.5f, y0 - 0.5f, x1 + 0.5f, y1 + 0.5f);
        c.drawRect(rf, pLine);
        drawOverlays(c);
    }

    private void drawChecker(Canvas c, float x0, float y0, float x1, float y1) {
        float cell = Ui.dp(8);
        float sx0 = Math.max(x0, 0), sy0 = Math.max(y0, 0), sx1 = Math.min(x1, getWidth()), sy1 = Math.min(y1, getHeight());
        int c0 = (int) Math.floor((sx0 - x0) / cell), r0 = (int) Math.floor((sy0 - y0) / cell);
        for (int r = r0; y0 + r * cell < sy1; r++) {
            for (int q = c0; x0 + q * cell < sx1; q++) {
                pFill.setColor(((r + q) & 1) == 0 ? 0xFFC4C4C4 : 0xFF9A9A9A);
                c.drawRect(x0 + q * cell, y0 + r * cell, x0 + (q + 1) * cell, y0 + (r + 1) * cell, pFill);
            }
        }
    }

    /** Lines every stepX / stepY picture pixels, only over the visible part. */
    private void drawGrid(Canvas c, int stepX, int stepY, int ox, int oy, float x0, float y0, float x1, float y1) {
        int firstCol = (int) Math.max(0, Math.floor(-x0 / scale));
        int lastCol = (int) Math.min(doc.w, Math.ceil((getWidth() - x0) / scale));
        int firstRow = (int) Math.max(0, Math.floor(-y0 / scale));
        int lastRow = (int) Math.min(doc.h, Math.ceil((getHeight() - y0) / scale));
        int need = ((lastCol - firstCol) / Math.max(1, stepX) + (lastRow - firstRow) / Math.max(1, stepY) + 4) * 4;
        if (pts.length < need) pts = new float[need];
        int n = 0;
        for (int i = firstCol; i <= lastCol; i++) {
            if (((i - ox) % stepX + stepX) % stepX != 0) continue;
            float x = x0 + i * scale;
            if (n + 4 > pts.length) break;
            pts[n++] = x; pts[n++] = y0; pts[n++] = x; pts[n++] = y1;
        }
        for (int j = firstRow; j <= lastRow; j++) {
            if (((j - oy) % stepY + stepY) % stepY != 0) continue;
            float y = y0 + j * scale;
            if (n + 4 > pts.length) break;
            pts[n++] = x0; pts[n++] = y; pts[n++] = x1; pts[n++] = y;
        }
        c.drawLines(pts, 0, n, pLine);
    }

    // ------------------------------------------------------------------
    // touch
    // ------------------------------------------------------------------

    @Override public boolean onTouchEvent(MotionEvent e) {
        if (doc == null) return false;
        sgd.onTouchEvent(e);
        int n = e.getPointerCount();
        int act = e.getActionMasked();

        if (n >= 2 || sgd.isInProgress()) {
            if (drawing) cancelStroke();
            multi = true;
            float fx = 0, fy = 0;
            for (int i = 0; i < n; i++) { fx += e.getX(i); fy += e.getY(i); }
            fx /= n;
            fy /= n;
            if (act == MotionEvent.ACTION_MOVE && lastPtrCount == n) {
                offX += fx - lastFx;
                offY += fy - lastFy;
                clampPan();
                invalidate();
                if (listener != null) listener.onViewChanged();
            }
            lastFx = fx;
            lastFy = fy;
            lastPtrCount = n;
            if (act == MotionEvent.ACTION_UP || act == MotionEvent.ACTION_CANCEL) { multi = false; lastPtrCount = 0; }
            return true;
        }
        lastPtrCount = n;
        if (multi) {
            if (act == MotionEvent.ACTION_UP || act == MotionEvent.ACTION_CANCEL) multi = false;
            return true;
        }

        int ix = (int) Math.floor((e.getX() - offX) / scale);
        int iy = (int) Math.floor((e.getY() - offY) / scale);
        if (floating) return floatTouch(e, act);
        if (tool == T_SELECT) return selectTouch(e, act, ix, iy);
        switch (act) {
            case MotionEvent.ACTION_DOWN: begin(ix, iy); break;
            case MotionEvent.ACTION_MOVE: move(ix, iy); break;
            case MotionEvent.ACTION_UP: end(ix, iy); break;
            case MotionEvent.ACTION_CANCEL: cancelStroke(); break;
            default: break;
        }
        return true;
    }

    private int paintColor() { return tool == T_ERASER ? 0 : color; }

    private int mx(int x) { return doc.w - 1 - x; }

    private void begin(int ix, int iy) {
        sx = lx = ix;
        sy = ly = iy;
        if (tool == T_PICK) {
            drawing = true;
            pick(ix, iy);
            return;
        }
        if (tool == T_FILL) {
            if (doc.in(ix, iy)) {
                doc.push();
                doc.fill(ix, iy, color);
                if (mirror) doc.fill(mx(ix), iy, color);
                if (mirrorY) doc.fill(ix, my(iy), color);
                changed();
            }
            drawing = false;
            return;
        }
        if (tool == T_RECOLOR) {
            if (doc.in(ix, iy)) {
                doc.replace(doc.get(ix, iy), color);     // records its own undo step
                changed();
            }
            drawing = false;
            return;
        }
        drawing = true;
        doc.push();
        if (tool == T_LINE || tool == T_RECT || tool == T_OVAL || tool == T_MOVE) base = doc.px.clone();
        if (isFreehand(tool)) {
            touched = (tool == T_LIGHTEN || tool == T_DARKEN) ? new boolean[doc.w * doc.h] : null;
            applyTool(ix, iy);
            bmpDirty = true;
            invalidate();
        }
    }

    private static boolean isFreehand(int t) {
        return t == T_PENCIL || t == T_ERASER || t == T_DITHER || t == T_LIGHTEN || t == T_DARKEN || t == T_SPRAY;
    }

    private int my(int y) { return doc.h - 1 - y; }

    /** Apply the freehand tool at x,y and at the mirrored positions. */
    private void applyTool(int x, int y) {
        applyOne(x, y);
        if (mirror) applyOne(mx(x), y);
        if (mirrorY) applyOne(x, my(y));
        if (mirror && mirrorY) applyOne(mx(x), my(y));
    }

    private void applyOne(int x, int y) {
        int o = brush / 2;
        switch (tool) {
            case T_PENCIL:
            case T_ERASER:
                doc.plot(x, y, paintColor(), brush);
                break;
            case T_DITHER:
                for (int j = 0; j < brush; j++) {
                    for (int i = 0; i < brush; i++) {
                        int tx = x - o + i, ty = y - o + j;
                        if (((tx + ty) & 1) == 0) doc.set(tx, ty, color);
                    }
                }
                break;
            case T_LIGHTEN:
            case T_DARKEN:
                for (int j = 0; j < brush; j++) {
                    for (int i = 0; i < brush; i++) shade(x - o + i, y - o + j, tool == T_LIGHTEN);
                }
                break;
            case T_SPRAY: {
                int r = Math.max(2, brush * 2);
                for (int k = 0; k < 5; k++) {
                    int dx = rnd.nextInt(2 * r + 1) - r, dy = rnd.nextInt(2 * r + 1) - r;
                    if (dx * dx + dy * dy <= r * r) doc.set(x + dx, y + dy, color);
                }
                break;
            }
            default: break;
        }
    }

    private void shade(int x, int y, boolean lighter) {
        if (!doc.in(x, y)) return;
        int idx = y * doc.w + x;
        if (touched != null) {
            if (touched[idx]) return;
            touched[idx] = true;
        }
        int p = doc.px[idx], a = p >>> 24;
        if (a == 0) return;
        int r = (p >> 16) & 255, g = (p >> 8) & 255, b = p & 255;
        if (lighter) {
            r += Math.round((255 - r) * 0.18f); g += Math.round((255 - g) * 0.18f); b += Math.round((255 - b) * 0.18f);
        } else {
            r = Math.round(r * 0.82f); g = Math.round(g * 0.82f); b = Math.round(b * 0.82f);
        }
        doc.px[idx] = (a << 24) | (r << 16) | (g << 8) | b;
    }

    /** Pixels along a line, so fast strokes leave no gaps. */
    private void walk(int x0, int y0, int x1, int y1) {
        int dx = Math.abs(x1 - x0), dy = -Math.abs(y1 - y0);
        int stx = x0 < x1 ? 1 : -1, sty = y0 < y1 ? 1 : -1;
        int err = dx + dy;
        int guard = (doc.w + doc.h) * 4 + 16;
        while (guard-- > 0) {
            applyTool(x0, y0);
            if (x0 == x1 && y0 == y1) break;
            int e2 = 2 * err;
            if (e2 >= dy) { err += dy; x0 += stx; }
            if (e2 <= dx) { err += dx; y0 += sty; }
        }
    }

    private void move(int ix, int iy) {
        if (!drawing) return;
        if (tool == T_PICK) { pick(ix, iy); return; }
        if (isFreehand(tool)) {
            walk(lx, ly, ix, iy);
            lx = ix;
            ly = iy;
        } else if (tool == T_MOVE) {
            System.arraycopy(base, 0, doc.px, 0, base.length);
            doc.shiftFrom(base, ix - sx, iy - sy);
        } else if (base != null) {
            System.arraycopy(base, 0, doc.px, 0, base.length);
            shape(sx, sy, ix, iy);
            if (mirror) shape(mx(sx), sy, mx(ix), iy);
            if (mirrorY) shape(sx, my(sy), ix, my(iy));
            if (mirror && mirrorY) shape(mx(sx), my(sy), mx(ix), my(iy));
        }
        bmpDirty = true;
        invalidate();
    }

    private void shape(int x0, int y0, int x1, int y1) {
        if (tool == T_LINE) doc.line(x0, y0, x1, y1, color, brush);
        else if (tool == T_RECT) doc.rect(x0, y0, x1, y1, color, filled, brush);
        else if (tool == T_OVAL) doc.ellipse(x0, y0, x1, y1, color, filled, brush);
    }

    private void end(int ix, int iy) {
        if (!drawing) return;
        if (tool != T_PICK) move(ix, iy);
        drawing = false;
        base = null;
        touched = null;
        if (tool != T_PICK) changed();
    }

    private void cancelStroke() {
        if (drawing && tool != T_PICK) {
            doc.cancelLast();
            bmpDirty = true;
            invalidate();
        }
        drawing = false;
        base = null;
    }

    private void pick(int ix, int iy) {
        if (doc.in(ix, iy) && listener != null) listener.onPicked(doc.get(ix, iy));
    }

    // ------------------------------------------------------------------
    // floating layer
    // ------------------------------------------------------------------

    public boolean isFloating() { return floating; }

    public int floatWidth() { return fdw; }

    public int floatHeight() { return fdh; }

    /**
     * Start a floating layer from ARGB pixels. It is placed around the middle of what is on screen (a layer
     * larger than the picture is shrunk to fit) and can then be dragged, resized, flipped, rotated and applied.
     */
    public void startFloat(int[] px, int w, int h) {
        if (doc == null || px == null || w < 1 || h < 1) return;
        if (floating) commitFloat();
        doc.push();
        beginFloat(px, w, h, true, 0, 0);
    }

    private void beginFloat(int[] px, int w, int h, boolean autoPlace, int x, int y) {
        fsrc = px;
        fsw = w;
        fsh = h;
        fdw = w;
        fdh = h;
        if (autoPlace) {
            if (fdw > doc.w || fdh > doc.h) {
                float k = Math.min(doc.w / (float) fdw, doc.h / (float) fdh);
                fdw = Math.max(1, Math.round(fdw * k));
                fdh = Math.max(1, Math.round(fdh * k));
            }
            int cx = (int) Math.floor((getWidth() / 2f - offX) / scale);
            int cy = (int) Math.floor((getHeight() / 2f - offY) / scale);
            x = Math.max(0, Math.min(doc.w - fdw, cx - fdw / 2));
            y = Math.max(0, Math.min(doc.h - fdh, cy - fdh / 2));
        }
        fx = x;
        fy = y;
        floating = true;
        fdirty = true;
        fMode = 0;
        hasSel = false;
        invalidate();
        if (listener != null) listener.onFloatChanged(true);
    }

    private void rebuildFloat() {
        int[] sc = fdw == fsw && fdh == fsh ? fsrc : SpriteDoc.scaleBlock(fsrc, fsw, fsh, fdw, fdh);
        if (fbmp == null || fbmp.getWidth() != fdw || fbmp.getHeight() != fdh) {
            fbmp = Bitmap.createBitmap(fdw, fdh, Bitmap.Config.ARGB_8888);
        }
        fbmp.setPixels(sc, 0, fdw, 0, 0, fdw, fdh);
        fdirty = false;
    }

    private void drawFloatBitmap(Canvas c) {
        if (fdirty || fbmp == null) rebuildFloat();
        rf.set(offX + fx * scale, offY + fy * scale, offX + (fx + fdw) * scale, offY + (fy + fdh) * scale);
        c.drawBitmap(fbmp, null, rf, pBmp);
    }

    /** Apply the floating layer to the picture. */
    public void commitFloat() {
        if (!floating || doc == null) return;
        int[] sc = fdw == fsw && fdh == fsh ? fsrc : SpriteDoc.scaleBlock(fsrc, fsw, fsh, fdw, fdh);
        doc.stamp(sc, fdw, fdh, fx, fy);
        // keep the applied area selected so it can be lifted and moved again
        int l = Math.max(0, fx), t = Math.max(0, fy), r = Math.min(doc.w, fx + fdw), b = Math.min(doc.h, fy + fdh);
        hasSel = r > l && b > t;
        selX = l; selY = t; selW = r - l; selH = b - t;
        endFloat();
        changed();
    }

    /** Throw the floating layer away (a lifted selection goes back where it was). */
    public void cancelFloat() {
        if (!floating || doc == null) return;
        doc.cancelLast();
        endFloat();
        bmpDirty = true;
        invalidate();
        if (listener != null) listener.onChanged();
    }

    private void endFloat() {
        floating = false;
        fsrc = null;
        fbmp = null;
        fMode = 0;
        invalidate();
        if (listener != null) listener.onFloatChanged(false);
    }

    public void floatFlipH() {
        if (!floating) return;
        for (int y = 0; y < fsh; y++) {
            for (int x = 0; x < fsw / 2; x++) {
                int a = y * fsw + x, b = y * fsw + fsw - 1 - x, t = fsrc[a];
                fsrc[a] = fsrc[b];
                fsrc[b] = t;
            }
        }
        fdirty = true;
        invalidate();
    }

    public void floatFlipV() {
        if (!floating) return;
        for (int y = 0; y < fsh / 2; y++) {
            for (int x = 0; x < fsw; x++) {
                int a = y * fsw + x, b = (fsh - 1 - y) * fsw + x, t = fsrc[a];
                fsrc[a] = fsrc[b];
                fsrc[b] = t;
            }
        }
        fdirty = true;
        invalidate();
    }

    public void floatRotate(boolean cw) {
        if (!floating) return;
        int[] n = new int[fsw * fsh];
        for (int y = 0; y < fsh; y++) {
            for (int x = 0; x < fsw; x++) {
                int nx = cw ? fsh - 1 - y : y;
                int ny = cw ? x : fsw - 1 - x;
                n[ny * fsh + nx] = fsrc[y * fsw + x];
            }
        }
        float cx = fx + fdw / 2f, cy = fy + fdh / 2f;
        fsrc = n;
        int t = fsw; fsw = fsh; fsh = t;
        t = fdw; fdw = fdh; fdh = t;
        fx = Math.round(cx - fdw / 2f);
        fy = Math.round(cy - fdh / 2f);
        fdirty = true;
        invalidate();
    }

    /** Set the size of the floating layer exactly (the middle stays where it is). Returns false if too big. */
    public boolean floatSetSize(int nw, int nh) {
        if (!floating || nw < 1 || nh < 1 || nw > 2048 || nh > 2048) return false;
        float cx = fx + fdw / 2f, cy = fy + fdh / 2f;
        fdw = nw;
        fdh = nh;
        fx = Math.round(cx - nw / 2f);
        fy = Math.round(cy - nh / 2f);
        fdirty = true;
        invalidate();
        return true;
    }

    /** Back to the original pixel size of the layer. */
    public void floatOriginalSize() { floatSetSize(fsw, fsh); }

    /** Fit inside the sprite-sheet frame the layer is over (or the whole picture when there is no frame grid). */
    public void floatFit() {
        if (!floating) return;
        int cl = 0, ct = 0, cw = doc.w, ch = doc.h;
        if (doc.frameW > 0 && doc.frameH > 0 && doc.frameW <= doc.w && doc.frameH <= doc.h) {
            int col = Math.max(0, Math.min(doc.w / doc.frameW - 1, (fx + fdw / 2) / doc.frameW));
            int row = Math.max(0, Math.min(doc.h / doc.frameH - 1, (fy + fdh / 2) / doc.frameH));
            cl = col * doc.frameW;
            ct = row * doc.frameH;
            cw = doc.frameW;
            ch = doc.frameH;
        }
        float k = Math.min(cw / (float) fsw, ch / (float) fsh);
        fdw = Math.max(1, Math.round(fsw * k));
        fdh = Math.max(1, Math.round(fsh * k));
        fx = cl + (cw - fdw) / 2;
        fy = ct + (ch - fdh) / 2;
        fdirty = true;
        invalidate();
    }

    private boolean floatTouch(MotionEvent e, int act) {
        float x = e.getX(), y = e.getY();
        if (act == MotionEvent.ACTION_DOWN) {
            fDownX = x;
            fDownY = y;
            fox = fx; foy = fy; fow = fdw; foh = fdh;
            fMode = 0;
            float hit = Ui.dp(24);
            float l = offX + fx * scale, r = offX + (fx + fdw) * scale, t = offY + fy * scale, b = offY + (fy + fdh) * scale;
            float mx = (l + r) / 2f, my = (t + b) / 2f;
            for (int i = 0; i < HANDLES.length; i++) {
                float hx = HANDLES[i][0] < 0 ? l : HANDLES[i][0] > 0 ? r : mx;
                float hy = HANDLES[i][1] < 0 ? t : HANDLES[i][1] > 0 ? b : my;
                if (Math.abs(x - hx) <= hit && Math.abs(y - hy) <= hit) {
                    fMode = 2;
                    fhx = HANDLES[i][0];
                    fhy = HANDLES[i][1];
                    return true;
                }
            }
            float slop = Ui.dp(8);
            if (x >= l - slop && x <= r + slop && y >= t - slop && y <= b + slop) fMode = 1;
            return true;
        }
        if (act == MotionEvent.ACTION_MOVE && fMode != 0) {
            int ddx = Math.round((x - fDownX) / scale), ddy = Math.round((y - fDownY) / scale);
            if (fMode == 1) {
                fx = fox + ddx;
                fy = foy + ddy;
            } else {
                resizeFloat(ddx, ddy);
            }
            invalidate();
            return true;
        }
        if (act == MotionEvent.ACTION_UP || act == MotionEvent.ACTION_CANCEL) fMode = 0;
        return true;
    }

    private void resizeFloat(int ddx, int ddy) {
        int nl = fox, nr = fox + fow, nt = foy, nb = foy + foh;
        if (fhx < 0) nl += ddx; else if (fhx > 0) nr += ddx;
        if (fhy < 0) nt += ddy; else if (fhy > 0) nb += ddy;
        if (nr - nl < 1) { if (fhx < 0) nl = nr - 1; else nr = nl + 1; }
        if (nb - nt < 1) { if (fhy < 0) nt = nb - 1; else nb = nt + 1; }
        int nw = nr - nl, nh = nb - nt;
        if (lockAspect && fhx != 0 && fhy != 0) {
            float k = Math.max(nw / (float) fow, nh / (float) foh);
            nw = Math.max(1, Math.round(fow * k));
            nh = Math.max(1, Math.round(foh * k));
            if (fhx < 0) nl = nr - nw; else nr = nl + nw;
            if (fhy < 0) nt = nb - nh; else nb = nt + nh;
        }
        if (nw > 2048 || nh > 2048) return;
        if (nw != fdw || nh != fdh) fdirty = true;
        fx = nl;
        fy = nt;
        fdw = nw;
        fdh = nh;
    }

    // ------------------------------------------------------------------
    // selection + clipboard
    // ------------------------------------------------------------------

    public boolean hasSelection() { return hasSel; }

    public boolean hasClipboard() { return clip != null; }

    public void selectAll() {
        if (doc == null) return;
        if (floating) commitFloat();
        hasSel = true;
        selX = 0; selY = 0; selW = doc.w; selH = doc.h;
        invalidate();
    }

    public void deselect() {
        hasSel = false;
        invalidate();
    }

    /** Copy (or cut) the selected pixels to the clipboard. */
    public boolean copySelection(boolean cut) {
        if (!hasSel || doc == null) return false;
        clip = doc.copyRect(selX, selY, selW, selH);
        clipW = selW;
        clipH = selH;
        if (cut) {
            doc.push();
            doc.clearRect(selX, selY, selW, selH);
            changed();
        }
        return true;
    }

    public boolean deleteSelection() {
        if (!hasSel || doc == null) return false;
        doc.push();
        doc.clearRect(selX, selY, selW, selH);
        changed();
        return true;
    }

    /** Paste the clipboard as a floating layer. */
    public boolean paste() {
        if (clip == null) return false;
        startFloat(clip.clone(), clipW, clipH);
        return true;
    }

    /** Lift the selected pixels into a floating layer (the hole is left transparent until it is applied). */
    private void liftSelection() {
        int[] px = doc.copyRect(selX, selY, selW, selH);
        doc.push();
        doc.clearRect(selX, selY, selW, selH);
        bmpDirty = true;
        beginFloat(px, selW, selH, false, selX, selY);
    }

    private boolean selectTouch(MotionEvent e, int act, int ix, int iy) {
        int cx = Math.max(0, Math.min(doc.w - 1, ix)), cy = Math.max(0, Math.min(doc.h - 1, iy));
        switch (act) {
            case MotionEvent.ACTION_DOWN:
                if (hasSel && ix >= selX && iy >= selY && ix < selX + selW && iy < selY + selH) {
                    liftSelection();
                    return floatTouch(e, MotionEvent.ACTION_DOWN);
                }
                sx = cx;
                sy = cy;
                selDragging = true;
                hasSel = true;
                selX = cx; selY = cy; selW = 1; selH = 1;
                invalidate();
                break;
            case MotionEvent.ACTION_MOVE:
                if (selDragging) setSelFrom(sx, sy, cx, cy);
                break;
            case MotionEvent.ACTION_UP:
                if (selDragging) {
                    if (cx == sx && cy == sy) hasSel = false;     // a tap clears the selection
                    else setSelFrom(sx, sy, cx, cy);
                    selDragging = false;
                    invalidate();
                }
                break;
            case MotionEvent.ACTION_CANCEL:
                selDragging = false;
                break;
            default: break;
        }
        return true;
    }

    private void setSelFrom(int x0, int y0, int x1, int y1) {
        selX = Math.min(x0, x1);
        selY = Math.min(y0, y1);
        selW = Math.abs(x1 - x0) + 1;
        selH = Math.abs(y1 - y0) + 1;
        invalidate();
    }

    // ------------------------------------------------------------------
    // overlays (outline, handles)
    // ------------------------------------------------------------------

    private void dashedRect(Canvas c, float l, float t, float r, float b) {
        pDash.setColor(0xFF000000);
        c.drawRect(l, t, r, b, pDash);
        pDash.setColor(0xFFFFFFFF);
        pDash.setPathEffect(new DashPathEffect(new float[]{Ui.dp(5), Ui.dp(4)}, Ui.dp(4.5f)));
        c.drawRect(l, t, r, b, pDash);
        pDash.setPathEffect(new DashPathEffect(new float[]{Ui.dp(5), Ui.dp(4)}, 0));
    }

    private void drawOverlays(Canvas c) {
        if (floating) {
            float l = offX + fx * scale, r = offX + (fx + fdw) * scale, t = offY + fy * scale, b = offY + (fy + fdh) * scale;
            dashedRect(c, l, t, r, b);
            float mx = (l + r) / 2f, my = (t + b) / 2f, hs = Ui.dp(7);
            for (int i = 0; i < HANDLES.length; i++) {
                float hx = HANDLES[i][0] < 0 ? l : HANDLES[i][0] > 0 ? r : mx;
                float hy = HANDLES[i][1] < 0 ? t : HANDLES[i][1] > 0 ? b : my;
                pFill.setColor(0xFFFFFFFF);
                c.drawRect(hx - hs, hy - hs, hx + hs, hy + hs, pFill);
                pLine.setColor(0xFF1E88E5);
                pLine.setStrokeWidth(Ui.dp(1.5f));
                c.drawRect(hx - hs, hy - hs, hx + hs, hy + hs, pLine);
                pLine.setStrokeWidth(1f);
            }
        } else if (hasSel) {
            dashedRect(c, offX + selX * scale, offY + selY * scale, offX + (selX + selW) * scale, offY + (selY + selH) * scale);
        }
    }

    private void changed() {
        bmpDirty = true;
        invalidate();
        if (listener != null) listener.onChanged();
    }
}
