package com.dashers.j2mebuilderide.ui;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.SubMenu;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ScrollView;
import android.widget.TextView;

import com.dashers.j2mebuilderide.R;
import com.dashers.j2mebuilderide.ide.SpriteDoc;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import java.util.Vector;

/**
 * Pixel / sprite editor: draw on a zoomable canvas (pencil, eraser, fill, eyedropper, line, rectangle, oval,
 * move), mirror drawing, brush sizes, transparency, undo / redo, flip / rotate / resize / scale, replace colour,
 * outline, and sprite-sheet frames with an animation preview. Opens and saves PNG files in the project's res/.
 */
public final class SpriteEditorScreen {
    private static final String[] TOOL_NAMES = {"Pencil", "Eraser", "Fill", "Pick", "Line", "Rect", "Oval", "Move", "Select",
            "Dither", "Lighten", "Darken", "Spray", "Recolor"};
    private static final int PANEL_DP = 270;
    private static final int MAX_SIDE = 1024;

    private interface ColorCallback { void got(int argb); }

    private final ToolHost host;
    private final Activity a;
    private SpriteDoc doc;
    private String resRel;                 // null = not saved yet

    private PixelCanvasView canvas;
    private TextView subtitle, zoomLabel, swatch, gridPill, mirrorPill, filledPill, brushPill;
    private ImageView undoBtn, redoBtn;
    private LinearLayout quickRow, floatBar;
    private TextView lockPill;
    private View floatBarHolder;
    private SpritePalettes pal;
    private View leftPanel, rightPanel, scrim;
    private boolean leftOpen, rightOpen;
    private LinearLayout palGrid;
    private TextView palName, userGridPill, frameGridPill, mirrorYPill;
    private ImageView toolsBtn, palBtn;
    private interface NameCallback { void got(String s); }
    private final ArrayList<TextView> toolPills = new ArrayList<TextView>();
    private final ArrayList<Integer> recent = new ArrayList<Integer>();
    private int color = 0xFF000000;
    private int lastPicked = 0;

    public SpriteEditorScreen(ToolHost host, String resRel) {
        this.host = host;
        this.a = host.activity();
        Bitmap bmp = resRel != null ? host.loadResBitmap(resRel) : null;
        if (bmp != null && bmp.getWidth() * (long) bmp.getHeight() <= (long) MAX_SIDE * MAX_SIDE) {
            this.doc = fromBitmap(bmp);
            this.resRel = resRel;
        } else {
            if (resRel != null) host.toast(bmp == null ? "Could not open " + resRel : "Image too large (max " + MAX_SIDE + "x" + MAX_SIDE + ")");
            this.doc = new SpriteDoc(32, 32);
            this.resRel = null;
        }
    }

    // ------------------------------------------------------------------
    // layout
    // ------------------------------------------------------------------

    public View build() {
        LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);

        // ---- top bar ----
        LinearLayout bar = new LinearLayout(a);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(Ui.SURFACE);
        bar.setPadding(Ui.dp(4), Ui.dp(6), Ui.dp(4), Ui.dp(6));
        bar.setElevation(Ui.dp(2));
        bar.addView(Ui.iconButton(a, R.drawable.ic_arrow_back, Ui.TEXT, new View.OnClickListener() {
            public void onClick(View v) { requestExit(); }
        }), Ui.lp(Ui.dp(44), Ui.dp(44)));
        toolsBtn = Ui.iconButton(a, R.drawable.ic_build, Ui.TEXT, new View.OnClickListener() {
            public void onClick(View v) { if (leftOpen) closeDrawers(); else openLeft(); }
        });
        bar.addView(toolsBtn, Ui.lp(Ui.dp(36), Ui.dp(44)));
        LinearLayout titles = new LinearLayout(a);
        titles.setOrientation(LinearLayout.VERTICAL);
        TextView t = Ui.label(a, "Sprite Editor", 17, Ui.TEXT, true);
        t.setSingleLine(true);
        titles.addView(t);
        subtitle = Ui.label(a, "", 12, Ui.MUTED, false);
        subtitle.setSingleLine(true);
        subtitle.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
        titles.addView(subtitle);
        bar.addView(titles, Ui.lpWeight(0, Ui.WRAP, 1));
        undoBtn = Ui.iconButton(a, R.drawable.ic_undo, Ui.TEXT, new View.OnClickListener() {
            public void onClick(View v) {
                if (canvas.isFloating()) { canvas.cancelFloat(); return; }
                if (doc.undo()) { canvas.refresh(); updateAll(); }
            }
        });
        redoBtn = Ui.iconButton(a, R.drawable.ic_redo, Ui.TEXT, new View.OnClickListener() {
            public void onClick(View v) {
                if (canvas.isFloating()) return;
                if (doc.redo()) { canvas.refresh(); updateAll(); }
            }
        });
        bar.addView(undoBtn, Ui.lp(Ui.dp(36), Ui.dp(44)));
        bar.addView(redoBtn, Ui.lp(Ui.dp(36), Ui.dp(44)));
        palBtn = Ui.iconButton(a, R.drawable.ic_palette, Ui.TEXT, new View.OnClickListener() {
            public void onClick(View v) { if (rightOpen) closeDrawers(); else openRight(); }
        });
        bar.addView(palBtn, Ui.lp(Ui.dp(36), Ui.dp(44)));
        bar.addView(Ui.iconButton(a, R.drawable.ic_save, Ui.ACCENT, new View.OnClickListener() {
            public void onClick(View v) { save(null); }
        }), Ui.lp(Ui.dp(36), Ui.dp(44)));
        bar.addView(Ui.iconButton(a, R.drawable.ic_more_vert, Ui.TEXT, new View.OnClickListener() {
            public void onClick(View v) { showMenu(v); }
        }), Ui.lp(Ui.dp(36), Ui.dp(44)));
        root.addView(bar, Ui.lp(Ui.MATCH, Ui.WRAP));

        // ---- canvas ----
        FrameLayout holder = new FrameLayout(a);
        holder.setBackgroundColor(Ui.EDITOR);
        canvas = new PixelCanvasView(a);
        canvas.setListener(new PixelCanvasView.Listener() {
            public void onPicked(int argb) { lastPicked = argb; setColor(argb); }
            public void onChanged() { updateAll(); }
            public void onViewChanged() { updateZoom(); }
            public void onFloatChanged(boolean active) {
                if (floatBarHolder != null) floatBarHolder.setVisibility(active ? View.VISIBLE : View.GONE);
                updateAll();
            }
        });
        canvas.setDoc(doc);
        canvas.color = color;
        holder.addView(canvas, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        zoomLabel = Ui.label(a, "", 11.5f, Ui.WHITE, true);
        zoomLabel.setBackground(Ui.rect(0x99000000, 12, 0));
        zoomLabel.setPadding(Ui.dp(10), Ui.dp(4), Ui.dp(10), Ui.dp(4));
        FrameLayout.LayoutParams zl = new FrameLayout.LayoutParams(Ui.WRAP, Ui.WRAP, Gravity.BOTTOM | Gravity.START);
        zl.setMargins(Ui.dp(10), 0, 0, Ui.dp(10));
        holder.addView(zoomLabel, zl);
        root.addView(holder, Ui.lpWeight(Ui.MATCH, 0, 1));

        // ---- floating layer bar (import / paste / lifted selection) ----
        floatBar = new LinearLayout(a);
        floatBar.setGravity(Gravity.CENTER_VERTICAL);
        TextView apply = optionPill("Apply", new View.OnClickListener() {
            public void onClick(View v) { canvas.commitFloat(); }
        });
        apply.setBackground(Ui.ripple(Ui.rect(Ui.ACCENT, 20, 0)));
        apply.setTextColor(Ui.WHITE);
        floatBar.addView(apply, Ui.lpMargin(Ui.WRAP, Ui.WRAP, 0, 0, 8, 0));
        floatBar.addView(optionPill("Cancel", new View.OnClickListener() {
            public void onClick(View v) { canvas.cancelFloat(); }
        }), Ui.lpMargin(Ui.WRAP, Ui.WRAP, 0, 0, 8, 0));
        floatBar.addView(optionPill("Flip H", new View.OnClickListener() {
            public void onClick(View v) { canvas.floatFlipH(); }
        }), Ui.lpMargin(Ui.WRAP, Ui.WRAP, 0, 0, 8, 0));
        floatBar.addView(optionPill("Flip V", new View.OnClickListener() {
            public void onClick(View v) { canvas.floatFlipV(); }
        }), Ui.lpMargin(Ui.WRAP, Ui.WRAP, 0, 0, 8, 0));
        floatBar.addView(optionPill("Rotate", new View.OnClickListener() {
            public void onClick(View v) { canvas.floatRotate(true); }
        }), Ui.lpMargin(Ui.WRAP, Ui.WRAP, 0, 0, 8, 0));
        lockPill = optionPill("Lock ratio", new View.OnClickListener() {
            public void onClick(View v) { canvas.lockAspect = !canvas.lockAspect; styleToggle(lockPill, canvas.lockAspect); }
        });
        floatBar.addView(lockPill, Ui.lpMargin(Ui.WRAP, Ui.WRAP, 0, 0, 8, 0));
        floatBar.addView(optionPill("Fit", new View.OnClickListener() {
            public void onClick(View v) { canvas.floatFit(); }
        }), Ui.lpMargin(Ui.WRAP, Ui.WRAP, 0, 0, 8, 0));
        floatBar.addView(optionPill("1:1", new View.OnClickListener() {
            public void onClick(View v) { canvas.floatOriginalSize(); }
        }), Ui.lpMargin(Ui.WRAP, Ui.WRAP, 0, 0, 8, 0));
        floatBar.addView(optionPill("Size...", new View.OnClickListener() {
            public void onClick(View v) { floatSizeDialog(); }
        }), Ui.lpMargin(Ui.WRAP, Ui.WRAP, 0, 0, 8, 0));
        View floatStrip = strip(floatBar);
        floatStrip.setVisibility(View.GONE);
        floatBarHolder = floatStrip;
        root.addView(floatStrip, Ui.lp(Ui.MATCH, Ui.WRAP));
        styleToggle(lockPill, canvas.lockAspect);

        // ---- tool + option pills (they live in the left drawer) ----
        for (int i = 0; i < TOOL_NAMES.length; i++) {
            final int tool = i;
            TextView p = Ui.pill(a, TOOL_NAMES[i], 0, Ui.TEXT, new View.OnClickListener() {
                public void onClick(View v) { selectTool(tool); closeDrawers(); }
            });
            toolPills.add(p);
        }
        swatch = Ui.label(a, "", 10, Ui.WHITE, true);
        swatch.setGravity(Gravity.CENTER);
        swatch.setClickable(true);
        swatch.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                chooseColor(color, new ColorCallback() { public void got(int c) { setColor(c); } });
            }
        });
        brushPill = optionPill("Brush 1", new View.OnClickListener() {
            public void onClick(View v) {
                canvas.brush = canvas.brush >= 8 ? 1 : canvas.brush + 1;
                brushPill.setText("Brush " + canvas.brush);
            }
        });
        gridPill = optionPill("Pixel grid", new View.OnClickListener() {
            public void onClick(View v) { toggleGrid(); }
        });
        userGridPill = optionPill("Custom grid", new View.OnClickListener() {
            public void onClick(View v) { toggleUserGrid(); }
        });
        frameGridPill = optionPill("Frame grid", new View.OnClickListener() {
            public void onClick(View v) { toggleFrameGrid(); }
        });
        mirrorPill = optionPill("Mirror X", new View.OnClickListener() {
            public void onClick(View v) { canvas.mirror = !canvas.mirror; styleToggle(mirrorPill, canvas.mirror); }
        });
        mirrorYPill = optionPill("Mirror Y", new View.OnClickListener() {
            public void onClick(View v) { canvas.mirrorY = !canvas.mirrorY; styleToggle(mirrorYPill, canvas.mirrorY); }
        });
        filledPill = optionPill("Filled", new View.OnClickListener() {
            public void onClick(View v) { canvas.filled = !canvas.filled; styleToggle(filledPill, canvas.filled); }
        });

        // ---- bottom bar: current colour + quick colours ----
        LinearLayout bottom = new LinearLayout(a);
        bottom.setGravity(Gravity.CENTER_VERTICAL);
        bottom.setPadding(Ui.dp(12), Ui.dp(8), Ui.dp(12), Ui.dp(10));
        bottom.addView(swatch, Ui.lpMargin(Ui.dp(40), Ui.dp(40), 0, 0, 10, 0));
        quickRow = new LinearLayout(a);
        quickRow.setGravity(Gravity.CENTER_VERTICAL);
        HorizontalScrollView qs = new HorizontalScrollView(a);
        qs.setHorizontalScrollBarEnabled(false);
        qs.addView(quickRow);
        bottom.addView(qs, Ui.lpWeight(0, Ui.WRAP, 1));
        root.addView(bottom, Ui.lp(Ui.MATCH, Ui.WRAP));

        pal = new SpritePalettes(a);
        loadGridPrefs();
        buildDrawers(holder);

        selectTool(PixelCanvasView.T_PENCIL);
        styleToggle(gridPill, canvas.grid);
        styleToggle(userGridPill, canvas.userGrid);
        styleToggle(frameGridPill, canvas.frameGrid);
        styleToggle(mirrorYPill, canvas.mirrorY);
        styleToggle(mirrorPill, canvas.mirror);
        styleToggle(filledPill, canvas.filled);
        setColor(color);
        updateAll();
        updateZoom();
        return root;
    }

    private View strip(LinearLayout row) {
        HorizontalScrollView hs = new HorizontalScrollView(a);
        hs.setHorizontalScrollBarEnabled(false);
        hs.addView(row);
        hs.setPadding(Ui.dp(12), Ui.dp(8), Ui.dp(12), Ui.dp(4));
        return hs;
    }

    private TextView optionPill(String text, View.OnClickListener l) {
        TextView p = Ui.pill(a, text, 0, Ui.TEXT, l);
        p.setTextSize(13);
        p.setPadding(Ui.dp(14), Ui.dp(8), Ui.dp(14), Ui.dp(8));
        return p;
    }

    private void styleToggle(TextView t, boolean on) {
        t.setBackground(Ui.ripple(on ? Ui.rect(Ui.ACCENT_SOFT, 20, Ui.ACCENT) : Ui.rect(0, 20, Ui.STROKE)));
        t.setTextColor(on ? Ui.ACCENT : Ui.TEXT);
    }

    private void selectTool(int tool) {
        canvas.tool = tool;
        for (int i = 0; i < toolPills.size(); i++) {
            TextView p = toolPills.get(i);
            boolean on = i == tool;
            p.setBackground(Ui.ripple(on ? Ui.rect(Ui.ACCENT, 20, 0) : Ui.rect(0, 20, Ui.STROKE)));
            p.setTextColor(on ? Ui.WHITE : Ui.TEXT);
        }
        updateZoom();
    }

    private void setColor(int c) {
        color = c;
        if (rightOpen && palGrid != null) rebuildPalette();
        canvas.color = c;
        swatch.setBackground(Ui.rect((c >>> 24) == 0 ? Ui.SURFACE2 : c, 12, Ui.STROKE));
        swatch.setText((c >>> 24) == 0 ? "A0" : "");
        swatch.setTextColor(Ui.TEXT);
        if ((c >>> 24) != 0) {
            Integer boxed = Integer.valueOf(c);
            recent.remove(boxed);
            recent.add(0, boxed);
            while (recent.size() > 10) recent.remove(recent.size() - 1);
        }
        rebuildQuick();
    }

    private void rebuildQuick() {
        quickRow.removeAllViews();
        ArrayList<Integer> all = new ArrayList<Integer>(recent);
        for (int i = 0; i < 24; i++) {
            Integer p = Integer.valueOf(ColorTool.PALETTE[i]);
            if (!all.contains(p)) all.add(p);
        }
        for (int i = 0; i < all.size(); i++) {
            final int c = all.get(i).intValue();
            View v = new View(a);
            boolean sel = c == color;
            android.graphics.drawable.GradientDrawable g = Ui.rect(c, 8, sel ? Ui.ACCENT : Ui.STROKE);
            if (sel) g.setStroke(Ui.dp(2.5f), Ui.ACCENT);
            v.setBackground(Ui.ripple(g));
            v.setClickable(true);
            v.setOnClickListener(new View.OnClickListener() {
                public void onClick(View x) { setColor(c); }
            });
            quickRow.addView(v, Ui.lpMargin(Ui.dp(32), Ui.dp(32), 0, 0, 6, 0));
        }
    }

    private void updateAll() {
        updateSubtitle();
        undoBtn.setAlpha(doc.canUndo() ? 1f : 0.35f);
        redoBtn.setAlpha(doc.canRedo() ? 1f : 0.35f);
    }

    private void updateSubtitle() {
        String name = resRel != null ? resRel : "unsaved";
        int fc = doc.frameCount();
        subtitle.setText(name + "  \u00B7  " + doc.w + "\u00D7" + doc.h + (fc > 0 ? "  \u00B7  " + fc + " frames" : "") + (doc.dirty ? "  \u2022 edited" : ""));
    }

    private void updateZoom() {
        if (zoomLabel != null) zoomLabel.setText(doc.w + "\u00D7" + doc.h + "   " + Math.round(canvas.getScale() * 100f) + "%"
                + (canvas.tool >= 0 && canvas.tool < TOOL_NAMES.length ? "   \u00B7 " + TOOL_NAMES[canvas.tool] : ""));
    }

    // ------------------------------------------------------------------
    // menu
    // ------------------------------------------------------------------

    private void showMenu(View anchor) {
        Context themed = new ContextThemeWrapper(a, Ui.dark ? android.R.style.Theme_Material : android.R.style.Theme_Material_Light);
        PopupMenu pm = new PopupMenu(themed, anchor);
        pm.getMenu().add(0, 1, 0, "New...");
        pm.getMenu().add(0, 2, 1, "Open from project res...");
        pm.getMenu().add(0, 3, 2, "Open from device...");
        pm.getMenu().add(0, 4, 3, "Save as...");
        SubMenu gm = pm.getMenu().addSubMenu(0, 102, 3, "Grid");
        MenuItem g1 = gm.add(0, 40, 0, "Pixel grid");
        g1.setCheckable(true);
        g1.setChecked(canvas.grid);
        MenuItem g2 = gm.add(0, 41, 1, "Custom grid");
        g2.setCheckable(true);
        g2.setChecked(canvas.userGrid);
        MenuItem g3 = gm.add(0, 42, 2, "Frame grid (sprite sheet)");
        g3.setCheckable(true);
        g3.setChecked(canvas.frameGrid);
        gm.add(0, 43, 3, "Custom grid size...");
        pm.getMenu().add(0, 44, 3, "Tools panel");
        pm.getMenu().add(0, 45, 3, "Color palettes");
        pm.getMenu().add(0, 46, 3, "Crop to content");
        pm.getMenu().add(0, 24, 3, "Import image as layer (move / resize)...");
        SubMenu selm = pm.getMenu().addSubMenu(0, 101, 3, "Selection");
        selm.add(0, 25, 0, "Select all");
        selm.add(0, 26, 1, "Deselect");
        selm.add(0, 27, 2, "Copy");
        selm.add(0, 28, 3, "Cut");
        selm.add(0, 29, 4, "Delete");
        selm.add(0, 30, 5, canvas.hasClipboard() ? "Paste (as movable layer)" : "Paste (clipboard empty)");
        SubMenu sheet = pm.getMenu().addSubMenu(0, 100, 4, "Sprite sheet");
        sheet.add(0, 19, 0, "New sprite sheet...");
        sheet.add(0, 20, 1, "Import frames into a sheet...");
        sheet.add(0, 21, 2, "Export sheet to device (PNG)");
        sheet.add(0, 22, 3, doc.frameCount() > 0 ? "Export frames to " + (host.hasProject() ? "res/" : "sprites folder") : "Export frames (set frames first)");
        sheet.add(0, 23, 4, "Export frames as ZIP to device");
        pm.getMenu().add(0, 5, 4, "Flip horizontal");
        pm.getMenu().add(0, 6, 5, "Flip vertical");
        pm.getMenu().add(0, 7, 6, "Rotate right");
        pm.getMenu().add(0, 8, 7, "Rotate left");
        pm.getMenu().add(0, 9, 8, "Resize / scale...");
        pm.getMenu().add(0, 10, 9, "Frames (sprite sheet)...");
        pm.getMenu().add(0, 11, 10, "Preview animation");
        pm.getMenu().add(0, 12, 11, "Replace color...");
        pm.getMenu().add(0, 13, 12, "Outline");
        pm.getMenu().add(0, 14, 13, "Invert colors");
        pm.getMenu().add(0, 15, 14, "Grayscale");
        pm.getMenu().add(0, 16, 15, "Clear");
        pm.getMenu().add(0, 17, 16, "Copy Sprite code");
        if (host.canInsert()) pm.getMenu().add(0, 18, 17, "Insert Sprite code in editor");
        pm.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            public boolean onMenuItemClick(MenuItem item) {
                menuAction(item.getItemId());
                return true;
            }
        });
        pm.show();
    }

    private void menuAction(int id) {
        if (canvas.isFloating()) canvas.commitFloat();
        switch (id) {
            case 1: newDialog(); break;
            case 2: openFromRes(); break;
            case 3: openFromDevice(); break;
            case 4: saveAs(null); break;
            case 5: doc.flipH(); changed(); break;
            case 6: doc.flipV(); changed(); break;
            case 7: doc.rotate(true); canvas.fit(); changed(); break;
            case 8: doc.rotate(false); canvas.fit(); changed(); break;
            case 9: resizeDialog(); break;
            case 10: framesDialog(); break;
            case 11: previewAnimation(); break;
            case 12: replaceDialog(); break;
            case 13:
                if ((color >>> 24) == 0) { host.toast("Pick an opaque color first"); break; }
                doc.outline(color);
                changed();
                break;
            case 14: doc.invert(); changed(); break;
            case 15: doc.grayscale(); changed(); break;
            case 16: confirmClear(); break;
            case 17: host.copy(spriteCode()); host.toast("Sprite code copied"); break;
            case 18: host.insertIntoEditor(spriteCode()); break;
            case 19: newSheetDialog(); break;
            case 20: importFramesDialog(); break;
            case 21: exportSheetToDevice(); break;
            case 22: exportFramesToRes(); break;
            case 23: exportFramesZip(); break;
            case 24: importLayerDialog(); break;
            case 40: toggleGrid(); break;
            case 41: toggleUserGrid(); break;
            case 42: toggleFrameGrid(); break;
            case 43: gridDialog(); break;
            case 44: openLeft(); break;
            case 45: openRight(); break;
            case 46:
                if (doc.trim()) { canvas.fit(); changed(); host.toast("Cropped to " + doc.w + "x" + doc.h); }
                else host.toast("Nothing to crop");
                break;
            case 25: selectTool(PixelCanvasView.T_SELECT); canvas.selectAll(); break;
            case 26: canvas.deselect(); break;
            case 27: if (canvas.copySelection(false)) host.toast("Copied"); else host.toast("Select an area first (Select tool)"); break;
            case 28: if (!canvas.copySelection(true)) host.toast("Select an area first (Select tool)"); break;
            case 29: if (!canvas.deleteSelection()) host.toast("Select an area first (Select tool)"); break;
            case 30: if (!canvas.paste()) host.toast("Clipboard is empty - copy a selection first"); break;
            default: break;
        }
    }

    private void changed() {
        canvas.refresh();
        updateAll();
        updateZoom();
    }

    private void confirmClear() {
        new AlertDialog.Builder(a, Ui.dialogTheme()).setTitle("Clear the picture?")
            .setMessage("Every pixel becomes transparent. You can undo this.")
            .setPositiveButton("Clear", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int w) { doc.clear(0); changed(); }
            }).setNegativeButton("Cancel", null).show();
    }

    private String spriteCode() {
        String name = resRel != null ? resRel : "sprite.png";
        StringBuffer sb = new StringBuffer();
        sb.append("Image img = Image.createImage(\"/").append(name).append("\");\n");
        if (doc.frameCount() > 0) sb.append("Sprite sprite = new Sprite(img, ").append(doc.frameW).append(", ").append(doc.frameH).append(");\n");
        return sb.toString();
    }

    // ------------------------------------------------------------------
    // open / new / save
    // ------------------------------------------------------------------

    private static SpriteDoc fromBitmap(Bitmap bmp) {
        int w = bmp.getWidth(), h = bmp.getHeight();
        int[] px = new int[w * h];
        bmp.getPixels(px, 0, w, 0, 0, w, h);
        return SpriteDoc.of(w, h, px);
    }

    private void adopt(SpriteDoc d, String rel) {
        doc = d;
        resRel = rel;
        canvas.setDoc(d);
        updateAll();
        updateZoom();
    }

    private void confirmDiscard(final Runnable next) {
        if (!doc.dirty) { next.run(); return; }
        new AlertDialog.Builder(a, Ui.dialogTheme()).setTitle("Unsaved changes")
            .setMessage("This sprite has changes that are not saved.")
            .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int w) { save(next); }
            })
            .setNeutralButton("Discard", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int w) { next.run(); }
            })
            .setNegativeButton("Cancel", null).show();
    }

    public void requestExit() {
        confirmDiscard(new Runnable() { public void run() { host.exit(); } });
    }

    private EditText numberField(String hint, int value) {
        EditText e = Ui.field(a, hint, String.valueOf(value));
        e.setInputType(InputType.TYPE_CLASS_NUMBER);
        return e;
    }

    private static int intOf(EditText e, int def) {
        try { return Integer.parseInt(e.getText().toString().trim()); } catch (NumberFormatException x) { return def; }
    }

    private void newDialog() {
        final EditText fw = numberField("Width", 32), fh = numberField("Height", 32);
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(Ui.dp(20), Ui.dp(8), Ui.dp(20), 0);
        LinearLayout presets = new LinearLayout(a);
        int[] sizes = {8, 16, 24, 32, 48, 64, 96, 128};
        for (int i = 0; i < sizes.length; i++) {
            final int s = sizes[i];
            TextView p = Ui.pill(a, String.valueOf(s), 0, Ui.TEXT, new View.OnClickListener() {
                public void onClick(View v) { fw.setText(String.valueOf(s)); fh.setText(String.valueOf(s)); }
            });
            p.setTextSize(12.5f);
            p.setPadding(Ui.dp(12), Ui.dp(7), Ui.dp(12), Ui.dp(7));
            presets.addView(p, Ui.lpMargin(Ui.WRAP, Ui.WRAP, 0, 0, 6, 0));
        }
        HorizontalScrollView hs = new HorizontalScrollView(a);
        hs.setHorizontalScrollBarEnabled(false);
        hs.addView(presets);
        box.addView(hs, Ui.lpMargin(Ui.MATCH, Ui.WRAP, 0, 0, 0, 8));
        // phone screen sizes (a full-screen background / sheet)
        LinearLayout screens = new LinearLayout(a);
        int[][] scr = {{128, 128}, {128, 160}, {176, 208}, {240, 320}, {320, 240}, {240, 400}, {360, 640}};
        for (int i = 0; i < scr.length; i++) {
            final int sw = scr[i][0], sh = scr[i][1];
            TextView p = Ui.pill(a, sw + "\u00D7" + sh, 0, Ui.ACCENT, new View.OnClickListener() {
                public void onClick(View v) { fw.setText(String.valueOf(sw)); fh.setText(String.valueOf(sh)); }
            });
            p.setTextSize(12.5f);
            p.setPadding(Ui.dp(12), Ui.dp(7), Ui.dp(12), Ui.dp(7));
            screens.addView(p, Ui.lpMargin(Ui.WRAP, Ui.WRAP, 0, 0, 6, 0));
        }
        HorizontalScrollView hs2 = new HorizontalScrollView(a);
        hs2.setHorizontalScrollBarEnabled(false);
        hs2.addView(screens);
        box.addView(hs2, Ui.lpMargin(Ui.MATCH, Ui.WRAP, 0, 0, 0, 12));
        LinearLayout row = new LinearLayout(a);
        row.addView(Ui.labeled(a, "Width", fw), Ui.lpWeight(0, Ui.WRAP, 1));
        row.addView(new View(a), Ui.lp(Ui.dp(10), 1));
        row.addView(Ui.labeled(a, "Height", fh), Ui.lpWeight(0, Ui.WRAP, 1));
        box.addView(row);
        box.addView(Ui.label(a, "Any size from 1 to " + MAX_SIDE + " pixels, for example 240 \u00D7 320.", 12, Ui.MUTED, false),
                Ui.lpMargin(Ui.MATCH, Ui.WRAP, 4, 0, 4, 0));
        new AlertDialog.Builder(a, Ui.dialogTheme()).setTitle("New sprite").setView(box)
            .setPositiveButton("Create", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int w) {
                    final int nw = Math.max(1, Math.min(MAX_SIDE, intOf(fw, 32)));
                    final int nh = Math.max(1, Math.min(MAX_SIDE, intOf(fh, 32)));
                    confirmDiscard(new Runnable() { public void run() { adopt(new SpriteDoc(nw, nh), null); } });
                }
            }).setNegativeButton("Cancel", null).show();
    }

    // ------------------------------------------------------------------
    // grids
    // ------------------------------------------------------------------

    private void toggleGrid() {
        canvas.grid = !canvas.grid;
        styleToggle(gridPill, canvas.grid);
        canvas.invalidate();
        saveGridPrefs();
    }

    private void toggleUserGrid() {
        canvas.userGrid = !canvas.userGrid;
        styleToggle(userGridPill, canvas.userGrid);
        canvas.invalidate();
        saveGridPrefs();
    }

    private void toggleFrameGrid() {
        canvas.frameGrid = !canvas.frameGrid;
        styleToggle(frameGridPill, canvas.frameGrid);
        canvas.invalidate();
        saveGridPrefs();
    }

    private android.content.SharedPreferences prefs() {
        return a.getSharedPreferences("sprite_editor", Context.MODE_PRIVATE);
    }

    private void loadGridPrefs() {
        android.content.SharedPreferences sp = prefs();
        canvas.grid = sp.getBoolean("g_pixel", true);
        canvas.userGrid = sp.getBoolean("g_user", false);
        canvas.frameGrid = sp.getBoolean("g_frame", true);
        canvas.gridW = Math.max(1, sp.getInt("g_w", 16));
        canvas.gridH = Math.max(1, sp.getInt("g_h", 16));
        canvas.gridOx = sp.getInt("g_ox", 0);
        canvas.gridOy = sp.getInt("g_oy", 0);
        canvas.gridColor = sp.getInt("g_color", 0xCCFF4081);
    }

    private void saveGridPrefs() {
        prefs().edit().putBoolean("g_pixel", canvas.grid).putBoolean("g_user", canvas.userGrid)
            .putBoolean("g_frame", canvas.frameGrid).putInt("g_w", canvas.gridW).putInt("g_h", canvas.gridH)
            .putInt("g_ox", canvas.gridOx).putInt("g_oy", canvas.gridOy).putInt("g_color", canvas.gridColor).commit();
    }

    private void gridDialog() {
        final EditText fw = numberField("Cell width", canvas.gridW), fh = numberField("Cell height", canvas.gridH);
        final EditText fx = numberField("Offset X", canvas.gridOx), fy = numberField("Offset Y", canvas.gridOy);
        final int[] gc = {canvas.gridColor};
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(Ui.dp(20), Ui.dp(8), Ui.dp(20), 0);
        LinearLayout presets = new LinearLayout(a);
        int[] sizes = {4, 8, 16, 24, 32, 48, 64};
        for (int i = 0; i < sizes.length; i++) {
            final int sz = sizes[i];
            TextView p = Ui.pill(a, sz + "", 0, Ui.TEXT, new View.OnClickListener() {
                public void onClick(View v) { fw.setText(String.valueOf(sz)); fh.setText(String.valueOf(sz)); }
            });
            p.setTextSize(12.5f);
            p.setPadding(Ui.dp(12), Ui.dp(7), Ui.dp(12), Ui.dp(7));
            presets.addView(p, Ui.lpMargin(Ui.WRAP, Ui.WRAP, 0, 0, 6, 0));
        }
        HorizontalScrollView hs = new HorizontalScrollView(a);
        hs.setHorizontalScrollBarEnabled(false);
        hs.addView(presets);
        box.addView(hs, Ui.lpMargin(Ui.MATCH, Ui.WRAP, 0, 0, 0, 8));
        LinearLayout r1 = new LinearLayout(a);
        r1.addView(Ui.labeled(a, "Cell width", fw), Ui.lpWeight(0, Ui.WRAP, 1));
        r1.addView(new View(a), Ui.lp(Ui.dp(10), 1));
        r1.addView(Ui.labeled(a, "Cell height", fh), Ui.lpWeight(0, Ui.WRAP, 1));
        box.addView(r1);
        LinearLayout r2 = new LinearLayout(a);
        r2.addView(Ui.labeled(a, "Offset X", fx), Ui.lpWeight(0, Ui.WRAP, 1));
        r2.addView(new View(a), Ui.lp(Ui.dp(10), 1));
        r2.addView(Ui.labeled(a, "Offset Y", fy), Ui.lpWeight(0, Ui.WRAP, 1));
        box.addView(r2);
        LinearLayout colors = new LinearLayout(a);
        final int[] opts = {0xCCFF4081, 0xCCFFFFFF, 0xCC000000, 0xCC00E5FF, 0xCCFFEB3B, 0xCC76FF03};
        for (int i = 0; i < opts.length; i++) {
            final int c = opts[i];
            View v = new View(a);
            v.setBackground(Ui.ripple(Ui.rect(c | 0xFF000000, 8, Ui.STROKE)));
            v.setClickable(true);
            v.setOnClickListener(new View.OnClickListener() { public void onClick(View x) { gc[0] = c; host.toast("Grid color set"); } });
            colors.addView(v, Ui.lpMargin(Ui.dp(34), Ui.dp(34), 0, 10, 8, 0));
        }
        box.addView(colors);
        box.addView(Ui.label(a, "Guide lines every N pixels, drawn above your picture. Handy for tiles, UI slots and aligning layers.", 12, Ui.MUTED, false),
                Ui.lpMargin(Ui.MATCH, Ui.WRAP, 4, 10, 4, 0));
        new AlertDialog.Builder(a, Ui.dialogTheme()).setTitle("Custom grid").setView(box)
            .setPositiveButton("Show grid", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int w) {
                    canvas.gridW = Math.max(1, Math.min(MAX_SIDE, intOf(fw, 16)));
                    canvas.gridH = Math.max(1, Math.min(MAX_SIDE, intOf(fh, 16)));
                    canvas.gridOx = Math.max(0, intOf(fx, 0));
                    canvas.gridOy = Math.max(0, intOf(fy, 0));
                    canvas.gridColor = gc[0];
                    canvas.userGrid = true;
                    styleToggle(userGridPill, true);
                    canvas.invalidate();
                    saveGridPrefs();
                }
            }).setNegativeButton("Cancel", null).show();
    }

    // ------------------------------------------------------------------
    // side drawers: tools (left) and colour palettes (right)
    // ------------------------------------------------------------------

    private void buildDrawers(FrameLayout holder) {
        final int pw = Ui.dp(PANEL_DP);
        scrim = new View(a);
        scrim.setBackgroundColor(0x66000000);
        scrim.setVisibility(View.GONE);
        scrim.setOnTouchListener(new View.OnTouchListener() {
            float dx;
            public boolean onTouch(View v, MotionEvent e) {
                if (e.getActionMasked() == MotionEvent.ACTION_DOWN) dx = e.getRawX();
                else if (e.getActionMasked() == MotionEvent.ACTION_UP || (e.getActionMasked() == MotionEvent.ACTION_MOVE && Math.abs(e.getRawX() - dx) > Ui.dp(16))) closeDrawers();
                return true;
            }
        });
        holder.addView(scrim, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        holder.addView(edgeZone(true), new FrameLayout.LayoutParams(Ui.dp(16), Ui.MATCH, Gravity.START));
        holder.addView(edgeZone(false), new FrameLayout.LayoutParams(Ui.dp(16), Ui.MATCH, Gravity.END));
        leftPanel = buildLeftPanel();
        rightPanel = buildRightPanel();
        holder.addView(leftPanel, new FrameLayout.LayoutParams(pw, Ui.MATCH, Gravity.START));
        holder.addView(rightPanel, new FrameLayout.LayoutParams(pw, Ui.MATCH, Gravity.END));
        leftPanel.setTranslationX(-pw);
        rightPanel.setTranslationX(pw);
        leftPanel.setVisibility(View.INVISIBLE);
        rightPanel.setVisibility(View.INVISIBLE);
    }

    /** A thin strip at the screen edge: swipe inwards to open that drawer. */
    private View edgeZone(final boolean left) {
        View v = new View(a);
        v.setOnTouchListener(new View.OnTouchListener() {
            float downX;
            boolean fired;
            public boolean onTouch(View view, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN: downX = e.getRawX(); fired = false; break;
                    case MotionEvent.ACTION_MOVE:
                        if (!fired && (left ? e.getRawX() - downX : downX - e.getRawX()) > Ui.dp(24)) {
                            fired = true;
                            if (left) openLeft(); else openRight();
                        }
                        break;
                    default: break;
                }
                return true;
            }
        });
        return v;
    }

    private void slide(final View panel, final boolean open, final boolean fromLeft) {
        int pw = Ui.dp(PANEL_DP);
        panel.animate().cancel();
        if (open) {
            panel.setVisibility(View.VISIBLE);
            panel.animate().translationX(0).setDuration(180).start();
        } else {
            panel.animate().translationX(fromLeft ? -pw : pw).setDuration(160).withEndAction(new Runnable() {
                public void run() {
                    if (!(fromLeft ? leftOpen : rightOpen)) panel.setVisibility(View.INVISIBLE);
                }
            }).start();
        }
    }

    private void openLeft() {
        if (rightOpen) { rightOpen = false; slide(rightPanel, false, false); }
        leftOpen = true;
        scrim.setVisibility(View.VISIBLE);
        slide(leftPanel, true, true);
    }

    private void openRight() {
        if (leftOpen) { leftOpen = false; slide(leftPanel, false, true); }
        rightOpen = true;
        rebuildPalette();
        scrim.setVisibility(View.VISIBLE);
        slide(rightPanel, true, false);
    }

    private void closeDrawers() {
        if (leftOpen) { leftOpen = false; slide(leftPanel, false, true); }
        if (rightOpen) { rightOpen = false; slide(rightPanel, false, false); }
        if (scrim != null) scrim.setVisibility(View.GONE);
    }

    private ScrollView panelShell(LinearLayout col) {
        ScrollView sv = new ScrollView(a);
        sv.setBackgroundColor(Ui.SURFACE);
        sv.setElevation(Ui.dp(8));
        sv.setClickable(true);                       // keep touches from reaching the canvas underneath
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(Ui.dp(12), Ui.dp(8), Ui.dp(12), Ui.dp(20));
        sv.addView(col);
        return sv;
    }

    private void addPillGrid(LinearLayout parent, ArrayList<TextView> pills, int cols) {
        LinearLayout row = null;
        for (int i = 0; i < pills.size(); i++) {
            if (i % cols == 0) {
                row = new LinearLayout(a);
                parent.addView(row, Ui.lpMargin(Ui.MATCH, Ui.WRAP, 0, 0, 0, 6));
            }
            TextView p = pills.get(i);
            p.setPadding(Ui.dp(6), Ui.dp(9), Ui.dp(6), Ui.dp(9));
            p.setSingleLine(true);
            row.addView(p, weighted(i % cols == cols - 1));
        }
        int rem = pills.size() % cols;
        if (rem != 0 && row != null) {
            for (int k = rem; k < cols; k++) row.addView(new View(a), weighted(k == cols - 1));
        }
    }

    private LinearLayout.LayoutParams weighted(boolean last) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, Ui.WRAP, 1f);
        lp.setMargins(0, 0, last ? 0 : Ui.dp(6), 0);
        return lp;
    }

    private View buildLeftPanel() {
        LinearLayout col = new LinearLayout(a);
        ScrollView sv = panelShell(col);
        col.addView(Ui.label(a, "Tools", 17, Ui.TEXT, true), Ui.lpMargin(Ui.MATCH, Ui.WRAP, 4, 8, 0, 0));
        col.addView(Ui.label(a, "Swipe in from the left edge or tap the wrench icon.", 11.5f, Ui.MUTED, false), Ui.lpMargin(Ui.MATCH, Ui.WRAP, 4, 2, 0, 0));
        col.addView(Ui.section(a, "Draw"));
        addPillGrid(col, toolPills, 2);
        col.addView(Ui.section(a, "Brush & symmetry"));
        ArrayList<TextView> o1 = new ArrayList<TextView>();
        o1.add(brushPill); o1.add(filledPill); o1.add(mirrorPill); o1.add(mirrorYPill);
        addPillGrid(col, o1, 2);
        col.addView(Ui.section(a, "Grids"));
        ArrayList<TextView> o2 = new ArrayList<TextView>();
        o2.add(gridPill); o2.add(userGridPill); o2.add(frameGridPill);
        o2.add(optionPill("Grid size...", new View.OnClickListener() { public void onClick(View v) { gridDialog(); } }));
        addPillGrid(col, o2, 2);
        col.addView(Ui.section(a, "View & sheet"));
        ArrayList<TextView> o3 = new ArrayList<TextView>();
        o3.add(optionPill("Fit view", new View.OnClickListener() { public void onClick(View v) { canvas.fit(); closeDrawers(); } }));
        o3.add(optionPill("Frames...", new View.OnClickListener() { public void onClick(View v) { closeDrawers(); framesDialog(); } }));
        o3.add(optionPill("Crop to content", new View.OnClickListener() { public void onClick(View v) { menuAction(46); } }));
        o3.add(optionPill("Import layer", new View.OnClickListener() { public void onClick(View v) { closeDrawers(); menuAction(24); } }));
        addPillGrid(col, o3, 2);
        return sv;
    }

    private View buildRightPanel() {
        LinearLayout col = new LinearLayout(a);
        ScrollView sv = panelShell(col);
        col.addView(Ui.label(a, "Color palettes", 17, Ui.TEXT, true), Ui.lpMargin(Ui.MATCH, Ui.WRAP, 4, 8, 0, 0));
        col.addView(Ui.label(a, "Swipe in from the right edge or tap the palette icon.", 11.5f, Ui.MUTED, false), Ui.lpMargin(Ui.MATCH, Ui.WRAP, 4, 2, 0, 8));
        palName = Ui.pill(a, "", 0, Ui.ACCENT, new View.OnClickListener() {
            public void onClick(View v) { paletteListDialog(); }
        });
        palName.setSingleLine(true);
        palName.setEllipsize(android.text.TextUtils.TruncateAt.END);
        col.addView(palName, Ui.lpMargin(Ui.MATCH, Ui.WRAP, 0, 0, 0, 8));
        ArrayList<TextView> acts = new ArrayList<TextView>();
        acts.add(optionPill("+ Add color", new View.OnClickListener() { public void onClick(View v) { palAddColor(); } }));
        acts.add(optionPill("New palette", new View.OnClickListener() { public void onClick(View v) { palNew(); } }));
        acts.add(optionPill("From sprite", new View.OnClickListener() { public void onClick(View v) { palFromSprite(); } }));
        acts.add(optionPill("Duplicate", new View.OnClickListener() { public void onClick(View v) { palDuplicate(); } }));
        acts.add(optionPill("Rename", new View.OnClickListener() { public void onClick(View v) { palRename(); } }));
        acts.add(optionPill("Delete", new View.OnClickListener() { public void onClick(View v) { palDelete(); } }));
        acts.add(optionPill("Copy code", new View.OnClickListener() { public void onClick(View v) { palCopyCode(); } }));
        addPillGrid(col, acts, 2);
        palGrid = new LinearLayout(a);
        palGrid.setOrientation(LinearLayout.VERTICAL);
        col.addView(palGrid, Ui.lpMargin(Ui.MATCH, Ui.WRAP, 0, 12, 0, 0));
        col.addView(Ui.label(a, "Tap a swatch to use it. Long-press a swatch in your own palette to remove it. Built-in palettes are read-only: Duplicate one to edit it.",
                11.5f, Ui.MUTED, false), Ui.lpMargin(Ui.MATCH, Ui.WRAP, 4, 12, 4, 0));
        rebuildPalette();
        return sv;
    }

    private void rebuildPalette() {
        if (palGrid == null || pal == null) return;
        final SpritePalettes.Palette p = pal.current();
        palName.setText(p.name + (p.builtin ? "  (built-in)" : "") + "  ·  " + p.colors.length + "  ▾");
        palGrid.removeAllViews();
        if (p.colors.length == 0) {
            palGrid.addView(Ui.label(a, "Empty. Pick a color, then tap \"+ Add color\".", 12.5f, Ui.MUTED, false));
            return;
        }
        int cols = 6;
        LinearLayout row = null;
        for (int i = 0; i < p.colors.length; i++) {
            if (i % cols == 0) {
                row = new LinearLayout(a);
                palGrid.addView(row, Ui.lpMargin(Ui.MATCH, Ui.WRAP, 0, 0, 0, 6));
            }
            final int idx = i, c = p.colors[i];
            View v = new View(a);
            android.graphics.drawable.GradientDrawable g = Ui.rect(c, 6, c == color ? Ui.ACCENT : Ui.STROKE);
            if (c == color) g.setStroke(Ui.dp(2.5f), Ui.ACCENT);
            v.setBackground(Ui.ripple(g));
            v.setClickable(true);
            v.setOnClickListener(new View.OnClickListener() { public void onClick(View x) { setColor(c); } });
            v.setOnLongClickListener(new View.OnLongClickListener() {
                public boolean onLongClick(View x) {
                    if (p.builtin) { host.toast("Built-in palette - Duplicate it to edit"); return true; }
                    pal.removeColorAt(p, idx);
                    rebuildPalette();
                    return true;
                }
            });
            row.addView(v, Ui.lpMargin(Ui.dp(34), Ui.dp(34), 0, 0, 6, 0));
        }
    }

    private void paletteListDialog() {
        final String[] names = new String[pal.all.size()];
        for (int i = 0; i < names.length; i++) {
            SpritePalettes.Palette p = pal.all.get(i);
            names[i] = (i == pal.selected ? "✓  " : "     ") + p.name + (p.builtin ? "" : "  (mine)") + "  ·  " + p.colors.length;
        }
        new AlertDialog.Builder(a, Ui.dialogTheme()).setTitle("Choose palette").setItems(names, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface d, int which) { pal.select(which); rebuildPalette(); }
        }).setNegativeButton("Cancel", null).show();
    }

    private void askName(String title, String initial, final NameCallback cb) {
        final EditText f = Ui.field(a, "Palette name", initial);
        FrameLayout box = new FrameLayout(a);
        box.setPadding(Ui.dp(22), Ui.dp(8), Ui.dp(22), 0);
        box.addView(f);
        new AlertDialog.Builder(a, Ui.dialogTheme()).setTitle(title).setView(box)
            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int w) { cb.got(f.getText().toString()); }
            }).setNegativeButton("Cancel", null).show();
    }

    private void palNew() {
        askName("New palette", pal.uniqueName("My palette"), new NameCallback() {
            public void got(String s) {
                pal.addCustom(pal.uniqueName(s), new int[0]);
                rebuildPalette();
            }
        });
    }

    private void palAddColor() {
        SpritePalettes.Palette p = pal.current();
        if (p.builtin) { host.toast("Built-in palette. Tap \"New palette\" or \"Duplicate\" first."); return; }
        if (pal.addColor(p, color)) rebuildPalette(); else host.toast("That color is already there (or the palette is full)");
    }

    private void palDuplicate() {
        SpritePalettes.Palette p = pal.current();
        pal.addCustom(pal.uniqueName(p.name + " copy"), p.colors.clone());
        rebuildPalette();
    }

    private void palFromSprite() {
        if (canvas.isFloating()) canvas.commitFloat();
        int[] cols = doc.usedColors(64);
        if (cols.length == 0) { host.toast("The picture has no colors yet"); return; }
        pal.addCustom(pal.uniqueName("From sprite"), cols);
        rebuildPalette();
        host.toast(cols.length + " colors collected");
    }

    private void palRename() {
        final SpritePalettes.Palette p = pal.current();
        if (p.builtin) { host.toast("Built-in palettes cannot be renamed"); return; }
        askName("Rename palette", p.name, new NameCallback() {
            public void got(String s) {
                if (s.trim().length() == 0) return;
                pal.rename(p, s);
                rebuildPalette();
            }
        });
    }

    private void palDelete() {
        final SpritePalettes.Palette p = pal.current();
        if (p.builtin) { host.toast("Built-in palettes cannot be deleted"); return; }
        new AlertDialog.Builder(a, Ui.dialogTheme()).setTitle("Delete \"" + p.name + "\"?")
            .setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int w) { pal.remove(p); rebuildPalette(); }
            }).setNegativeButton("Cancel", null).show();
    }

    private void palCopyCode() {
        SpritePalettes.Palette p = pal.current();
        if (p.colors.length == 0) { host.toast("Palette is empty"); return; }
        host.copy(SpritePalettes.code(p));
        host.toast("Palette code copied");
    }

    // ------------------------------------------------------------------
    // import an image as a floating layer
    // ------------------------------------------------------------------

    private void importLayerDialog() {
        final String[] items = {"From project res...", "From device..."};
        new AlertDialog.Builder(a, Ui.dialogTheme()).setTitle("Import image as layer").setItems(items, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface d, int which) {
                if (which == 0) {
                    final Vector imgs = host.listImageResources();
                    if (imgs.size() == 0) { host.toast("No images in res/ yet"); return; }
                    final String[] names = new String[imgs.size()];
                    for (int i = 0; i < names.length; i++) names[i] = "res/" + imgs.elementAt(i);
                    new AlertDialog.Builder(a, Ui.dialogTheme()).setTitle("Pick an image").setItems(names, new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface d2, int w2) {
                            startLayer(host.loadResBitmap((String) imgs.elementAt(w2)));
                        }
                    }).setNegativeButton("Cancel", null).show();
                } else {
                    host.pickDeviceImage(new ToolHost.ImageSink() {
                        public void onImage(Bitmap bmp, String name) { startLayer(bmp); }
                    });
                }
            }
        }).setNegativeButton("Cancel", null).show();
    }

    private void startLayer(Bitmap bmp) {
        if (bmp == null) { host.toast("Could not read that image"); return; }
        if (bmp.getWidth() * (long) bmp.getHeight() > (long) MAX_SIDE * MAX_SIDE) {
            host.toast("Image too large (max " + MAX_SIDE + "x" + MAX_SIDE + ")");
            return;
        }
        SpriteDoc src = fromBitmap(bmp);
        canvas.startFloat(src.px, src.w, src.h);
        host.toast("Drag to move, drag the handles to resize, then Apply");
    }

    private void floatSizeDialog() {
        if (!canvas.isFloating()) return;
        final int ow = canvas.floatWidth(), oh = canvas.floatHeight();
        final EditText fw = numberField("Width", ow), fh = numberField("Height", oh);
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(Ui.dp(20), Ui.dp(8), Ui.dp(20), 0);
        LinearLayout row = new LinearLayout(a);
        row.addView(Ui.labeled(a, "Width", fw), Ui.lpWeight(0, Ui.WRAP, 1));
        row.addView(new View(a), Ui.lp(Ui.dp(10), 1));
        row.addView(Ui.labeled(a, "Height", fh), Ui.lpWeight(0, Ui.WRAP, 1));
        box.addView(row);
        box.addView(Ui.label(a, "Leave one value as it is and the other follows when 'Lock ratio' is on.", 12, Ui.MUTED, false),
                Ui.lpMargin(Ui.MATCH, Ui.WRAP, 4, 0, 4, 0));
        new AlertDialog.Builder(a, Ui.dialogTheme()).setTitle("Layer size").setView(box)
            .setPositiveButton("Set", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int w) {
                    int nw = intOf(fw, ow), nh = intOf(fh, oh);
                    if (canvas.lockAspect) {
                        if (nw != ow && nh == oh) nh = Math.max(1, Math.round(oh * (nw / (float) ow)));
                        else if (nh != oh && nw == ow) nw = Math.max(1, Math.round(ow * (nh / (float) oh)));
                    }
                    if (!canvas.floatSetSize(nw, nh)) host.toast("Size must be 1 to 2048");
                }
            }).setNegativeButton("Cancel", null).show();
    }

    private void openFromRes() {
        final Vector imgs = host.listImageResources();
        if (imgs.size() == 0) { host.toast("No images in res/ yet"); return; }
        final String[] items = new String[imgs.size()];
        for (int i = 0; i < items.length; i++) items[i] = "res/" + imgs.elementAt(i);
        new AlertDialog.Builder(a, Ui.dialogTheme()).setTitle("Open from res").setItems(items, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface d, final int which) {
                confirmDiscard(new Runnable() {
                    public void run() {
                        String rel = (String) imgs.elementAt(which);
                        loadBitmap(host.loadResBitmap(rel), rel);
                    }
                });
            }
        }).setNegativeButton("Cancel", null).show();
    }

    private void openFromDevice() {
        confirmDiscard(new Runnable() {
            public void run() {
                host.pickDeviceImage(new ToolHost.ImageSink() {
                    public void onImage(Bitmap bmp, String name) { loadBitmap(bmp, null); }
                });
            }
        });
    }

    private void loadBitmap(Bitmap bmp, String rel) {
        if (bmp == null) { host.toast("Could not read that image"); return; }
        if (bmp.getWidth() * (long) bmp.getHeight() > (long) MAX_SIDE * MAX_SIDE) {
            host.toast("Image too large (max " + MAX_SIDE + "x" + MAX_SIDE + ")");
            return;
        }
        adopt(fromBitmap(bmp), rel);
    }

    private byte[] encode() {
        try {
            Bitmap b = Bitmap.createBitmap(doc.w, doc.h, Bitmap.Config.ARGB_8888);
            try { b.setPremultiplied(false); } catch (Throwable ignore) { }
            b.setPixels(doc.px, 0, doc.w, 0, 0, doc.w, doc.h);
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            return b.compress(Bitmap.CompressFormat.PNG, 100, bos) ? bos.toByteArray() : null;
        } catch (Throwable t) {
            return null;
        }
    }

    private boolean write(String rel) {
        byte[] png = encode();
        if (png == null) { host.toast("Could not create the PNG"); return false; }
        String err = host.savePng(rel, png);
        if (err.length() > 0) { host.toast(err); return false; }
        doc.dirty = false;
        resRel = rel;
        updateAll();
        host.toast("Saved " + host.describeSave(rel));
        return true;
    }

    /** Save to the current name, or ask for one the first time. */
    private void save(Runnable after) {
        if (canvas.isFloating()) canvas.commitFloat();
        if (resRel == null) { saveAs(after); return; }
        if (write(resRel) && after != null) after.run();
    }

    private void saveAs(final Runnable after) {
        final EditText f = Ui.field(a, "name.png", resRel != null ? resRel : "sprite.png");
        FrameLayout box = new FrameLayout(a);
        box.setPadding(Ui.dp(22), Ui.dp(8), Ui.dp(22), 0);
        box.addView(f);
        new AlertDialog.Builder(a, Ui.dialogTheme()).setTitle("Save as")
            .setMessage(host.hasProject() ? "A PNG inside the project's res/ folder (sub-folders are fine, e.g. img/hero.png)."
                    : "No project is open, so the PNG goes to the sprites folder.")
            .setView(box)
            .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int w) {
                    String n = f.getText().toString().trim().replace('\\', '/');
                    while (n.startsWith("/")) n = n.substring(1);
                    if (n.length() == 0 || n.indexOf("..") >= 0) { host.toast("Enter a valid file name"); return; }
                    if (!n.toLowerCase().endsWith(".png")) n = n + ".png";
                    final String rel = n;
                    boolean exists = host.listImageResources().contains(rel) && !rel.equals(resRel);
                    if (exists) {
                        new AlertDialog.Builder(a, Ui.dialogTheme()).setTitle("Replace " + rel + "?")
                            .setMessage("A file with this name already exists.")
                            .setPositiveButton("Replace", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface d2, int w2) { if (write(rel) && after != null) after.run(); }
                            }).setNegativeButton("Cancel", null).show();
                    } else if (write(rel) && after != null) {
                        after.run();
                    }
                }
            }).setNegativeButton("Cancel", null).show();
    }

    // ------------------------------------------------------------------
    // sprite sheets: new / import frames / export
    // ------------------------------------------------------------------

    /** New empty sheet from a frame size and a grid, e.g. 16x16 frames in 8 columns x 4 rows. */
    private void newSheetDialog() {
        final EditText ffw = numberField("Frame width", doc.frameW > 0 ? doc.frameW : 32);
        final EditText ffh = numberField("Frame height", doc.frameH > 0 ? doc.frameH : 32);
        final EditText cols = numberField("Columns", 4), rows = numberField("Rows", 4);
        final TextView info = Ui.label(a, "", 13, Ui.TEXT, true);
        info.setPadding(Ui.dp(4), Ui.dp(2), 0, Ui.dp(4));
        final Runnable update = new Runnable() {
            public void run() {
                int fw = intOf(ffw, 0), fh = intOf(ffh, 0), c = intOf(cols, 0), r = intOf(rows, 0);
                if (fw < 1 || fh < 1 || c < 1 || r < 1) { info.setText("Enter sizes of 1 or more"); info.setTextColor(Ui.MUTED); return; }
                long sw = (long) fw * c, sh = (long) fh * r;
                boolean ok = sw <= MAX_SIDE && sh <= MAX_SIDE;
                info.setText("Sheet: " + sw + "\u00D7" + sh + "   (" + (c * r) + " frames)" + (ok ? "" : "   - too big, max " + MAX_SIDE));
                info.setTextColor(ok ? Ui.TEXT : Ui.RED);
            }
        };
        TextWatcher tw = new TextWatcher() {
            public void beforeTextChanged(CharSequence x, int s, int c, int d) { }
            public void onTextChanged(CharSequence x, int s, int b, int c) { }
            public void afterTextChanged(Editable e) { update.run(); }
        };
        ffw.addTextChangedListener(tw);
        ffh.addTextChangedListener(tw);
        cols.addTextChangedListener(tw);
        rows.addTextChangedListener(tw);

        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(Ui.dp(20), Ui.dp(8), Ui.dp(20), 0);
        LinearLayout r1 = new LinearLayout(a);
        r1.addView(Ui.labeled(a, "Frame width", ffw), Ui.lpWeight(0, Ui.WRAP, 1));
        r1.addView(new View(a), Ui.lp(Ui.dp(10), 1));
        r1.addView(Ui.labeled(a, "Frame height", ffh), Ui.lpWeight(0, Ui.WRAP, 1));
        box.addView(r1);
        LinearLayout r2 = new LinearLayout(a);
        r2.addView(Ui.labeled(a, "Columns", cols), Ui.lpWeight(0, Ui.WRAP, 1));
        r2.addView(new View(a), Ui.lp(Ui.dp(10), 1));
        r2.addView(Ui.labeled(a, "Rows", rows), Ui.lpWeight(0, Ui.WRAP, 1));
        box.addView(r2);
        box.addView(info);
        update.run();
        new AlertDialog.Builder(a, Ui.dialogTheme()).setTitle("New sprite sheet").setView(box)
            .setPositiveButton("Create", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int w) {
                    final int fw = intOf(ffw, 0), fh = intOf(ffh, 0), c = intOf(cols, 0), r = intOf(rows, 0);
                    if (fw < 1 || fh < 1 || c < 1 || r < 1 || (long) fw * c > MAX_SIDE || (long) fh * r > MAX_SIDE) {
                        host.toast("Sheet size must be 1 to " + MAX_SIDE + " pixels");
                        return;
                    }
                    confirmDiscard(new Runnable() {
                        public void run() {
                            SpriteDoc nd = new SpriteDoc(fw * c, fh * r);
                            nd.frameW = fw;
                            nd.frameH = fh;
                            adopt(nd, null);
                        }
                    });
                }
            }).setNegativeButton("Cancel", null).show();
    }

    /** Pick several images (res/ or device) and pack them side by side into one sheet. */
    private void importFramesDialog() {
        String[] items = {"From project res (choose several)...", "From this device (choose several)..."};
        new AlertDialog.Builder(a, Ui.dialogTheme()).setTitle("Import frames into a sheet")
            .setItems(items, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int which) {
                    if (which == 0) importFramesFromRes();
                    else host.pickDeviceImages(new ToolHost.ImagesSink() {
                        public void onImages(List<Bitmap> bitmaps, List<String> names) { packFramesDialog(bitmaps, names); }
                    });
                }
            }).setNegativeButton("Cancel", null).show();
    }

    private void importFramesFromRes() {
        final Vector imgs = host.listImageResources();
        if (imgs.size() == 0) { host.toast("No images in res/ yet"); return; }
        final String[] items = new String[imgs.size()];
        final boolean[] checked = new boolean[imgs.size()];
        for (int i = 0; i < items.length; i++) items[i] = "res/" + imgs.elementAt(i);
        new AlertDialog.Builder(a, Ui.dialogTheme()).setTitle("Choose the frames")
            .setMultiChoiceItems(items, checked, new DialogInterface.OnMultiChoiceClickListener() {
                public void onClick(DialogInterface d, int which, boolean isChecked) { checked[which] = isChecked; }
            })
            .setPositiveButton("Next", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int w) {
                    ArrayList<Bitmap> bmps = new ArrayList<Bitmap>();
                    ArrayList<String> names = new ArrayList<String>();
                    for (int i = 0; i < checked.length; i++) {
                        if (!checked[i]) continue;
                        Bitmap b = host.loadResBitmap((String) imgs.elementAt(i));
                        if (b != null) { bmps.add(b); names.add((String) imgs.elementAt(i)); }
                    }
                    packFramesDialog(bmps, names);
                }
            }).setNegativeButton("Cancel", null).show();
    }

    private static String baseName(String path) {
        String n = path.replace('\\', '/');
        int slash = n.lastIndexOf('/');
        if (slash >= 0) n = n.substring(slash + 1);
        int dot = n.lastIndexOf('.');
        return dot > 0 ? n.substring(0, dot) : n;
    }

    /** "frame2" before "frame10". */
    private static int naturalCompare(String x, String y) {
        int i = 0, j = 0;
        while (i < x.length() && j < y.length()) {
            char c = x.charAt(i), d = y.charAt(j);
            if (Character.isDigit(c) && Character.isDigit(d)) {
                int si = i, sj = j;
                while (i < x.length() && Character.isDigit(x.charAt(i))) i++;
                while (j < y.length() && Character.isDigit(y.charAt(j))) j++;
                String nx = x.substring(si, i).replaceFirst("^0+(?=.)", ""), ny = y.substring(sj, j).replaceFirst("^0+(?=.)", "");
                if (nx.length() != ny.length()) return nx.length() - ny.length();
                int cmp = nx.compareTo(ny);
                if (cmp != 0) return cmp;
            } else {
                if (c != d) return Character.toLowerCase(c) - Character.toLowerCase(d);
                i++;
                j++;
            }
        }
        return (x.length() - i) - (y.length() - j);
    }

    private void packFramesDialog(final List<Bitmap> bitmaps, final List<String> names) {
        if (bitmaps == null || bitmaps.size() == 0) { host.toast("No images chosen"); return; }
        // order by name (natural), keeping bitmaps and names together
        final Integer[] order = new Integer[bitmaps.size()];
        for (int i = 0; i < order.length; i++) order[i] = Integer.valueOf(i);
        Collections.sort(java.util.Arrays.asList(order), new Comparator<Integer>() {
            public int compare(Integer p, Integer q) { return naturalCompare(names.get(p.intValue()), names.get(q.intValue())); }
        });
        int maxW = 1, maxH = 1;
        for (int i = 0; i < bitmaps.size(); i++) {
            maxW = Math.max(maxW, bitmaps.get(i).getWidth());
            maxH = Math.max(maxH, bitmaps.get(i).getHeight());
        }
        final int n = bitmaps.size();
        final EditText ffw = numberField("Frame width", maxW), ffh = numberField("Frame height", maxH);
        final EditText cols = numberField("Columns", (int) Math.ceil(Math.sqrt(n)));
        final int[] align = {0};   // 0 centre, 1 bottom centre, 2 top left
        final String[] alignNames = {"Align in frame: center", "Align in frame: bottom (feet)", "Align in frame: top-left"};
        final TextView alignPill = Ui.pill(a, alignNames[0], 0, Ui.TEXT, null);
        alignPill.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { align[0] = (align[0] + 1) % 3; alignPill.setText(alignNames[align[0]]); }
        });
        final TextView info = Ui.label(a, "", 13, Ui.TEXT, true);
        info.setPadding(Ui.dp(4), Ui.dp(6), 0, Ui.dp(2));
        final Runnable update = new Runnable() {
            public void run() {
                int fw = intOf(ffw, 0), fh = intOf(ffh, 0), c = intOf(cols, 0);
                if (fw < 1 || fh < 1 || c < 1) { info.setText("Enter sizes of 1 or more"); info.setTextColor(Ui.MUTED); return; }
                int r = (n + c - 1) / c;
                long sw = (long) fw * c, sh = (long) fh * r;
                boolean ok = sw <= MAX_SIDE && sh <= MAX_SIDE;
                info.setText(n + " frames \u2192 sheet " + sw + "\u00D7" + sh + " (" + c + " \u00D7 " + r + ")" + (ok ? "" : "   - too big, max " + MAX_SIDE));
                info.setTextColor(ok ? Ui.TEXT : Ui.RED);
            }
        };
        TextWatcher tw = new TextWatcher() {
            public void beforeTextChanged(CharSequence x, int s, int c, int d) { }
            public void onTextChanged(CharSequence x, int s, int b, int c) { }
            public void afterTextChanged(Editable e) { update.run(); }
        };
        ffw.addTextChangedListener(tw);
        ffh.addTextChangedListener(tw);
        cols.addTextChangedListener(tw);

        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(Ui.dp(20), Ui.dp(8), Ui.dp(20), 0);
        LinearLayout r1 = new LinearLayout(a);
        r1.addView(Ui.labeled(a, "Frame width", ffw), Ui.lpWeight(0, Ui.WRAP, 1));
        r1.addView(new View(a), Ui.lp(Ui.dp(10), 1));
        r1.addView(Ui.labeled(a, "Frame height", ffh), Ui.lpWeight(0, Ui.WRAP, 1));
        box.addView(r1);
        box.addView(Ui.labeled(a, "Columns", cols));
        box.addView(alignPill, Ui.lp(Ui.MATCH, Ui.WRAP));
        box.addView(info);
        box.addView(Ui.label(a, "Frames are ordered by file name (frame2 before frame10). Larger images are cropped to the frame size.",
                12, Ui.MUTED, false), Ui.lpMargin(Ui.MATCH, Ui.WRAP, 4, 6, 4, 0));
        update.run();
        new AlertDialog.Builder(a, Ui.dialogTheme()).setTitle("Pack " + n + " frames").setView(box)
            .setPositiveButton("Create sheet", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int w) {
                    final int fw = intOf(ffw, 0), fh = intOf(ffh, 0), c = intOf(cols, 0);
                    if (fw < 1 || fh < 1 || c < 1) { host.toast("Enter valid sizes"); return; }
                    final int r = (n + c - 1) / c;
                    if ((long) fw * c > MAX_SIDE || (long) fh * r > MAX_SIDE) { host.toast("Sheet would be too big (max " + MAX_SIDE + ")"); return; }
                    confirmDiscard(new Runnable() {
                        public void run() {
                            SpriteDoc nd = new SpriteDoc(fw * c, fh * r);
                            for (int k = 0; k < n; k++) {
                                Bitmap b = bitmaps.get(order[k].intValue());
                                int bw = b.getWidth(), bh = b.getHeight();
                                int[] src = new int[bw * bh];
                                b.getPixels(src, 0, bw, 0, 0, bw, bh);
                                int cellX = (k % c) * fw, cellY = (k / c) * fh;
                                int offX = align[0] == 2 ? 0 : (fw - bw) / 2;
                                int offY = align[0] == 0 ? (fh - bh) / 2 : align[0] == 1 ? fh - bh : 0;
                                for (int y = 0; y < bh; y++) {
                                    int ty = y + offY;
                                    if (ty < 0 || ty >= fh) continue;
                                    for (int x = 0; x < bw; x++) {
                                        int tx = x + offX;
                                        if (tx < 0 || tx >= fw) continue;
                                        nd.px[(cellY + ty) * nd.w + cellX + tx] = src[y * bw + x];
                                    }
                                }
                            }
                            nd.frameW = fw;
                            nd.frameH = fh;
                            adopt(nd, null);
                            nd.dirty = true;
                            updateAll();
                        }
                    });
                }
            }).setNegativeButton("Cancel", null).show();
    }

    private String sheetBaseName() { return resRel != null ? baseName(resRel) : "sprite_sheet"; }

    private void exportSheetToDevice() {
        byte[] png = encode();
        if (png == null) { host.toast("Could not create the PNG"); return; }
        host.exportToDevice(sheetBaseName() + ".png", "image/png", png);
    }

    /** PNG bytes of one frame of the sheet. */
    private byte[] framePng(int index) {
        int fw = doc.frameW, fh = doc.frameH, cols = doc.w / fw;
        int fx = (index % cols) * fw, fy = (index / cols) * fh;
        int[] px = new int[fw * fh];
        for (int y = 0; y < fh; y++) System.arraycopy(doc.px, (fy + y) * doc.w + fx, px, y * fw, fw);
        try {
            Bitmap b = Bitmap.createBitmap(fw, fh, Bitmap.Config.ARGB_8888);
            try { b.setPremultiplied(false); } catch (Throwable ignore) { }
            b.setPixels(px, 0, fw, 0, 0, fw, fh);
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            return b.compress(Bitmap.CompressFormat.PNG, 100, bos) ? bos.toByteArray() : null;
        } catch (Throwable t) {
            return null;
        }
    }

    private String frameName(String base, int index, int total) {
        int digits = String.valueOf(Math.max(1, total - 1)).length();
        return base + "_" + String.format(java.util.Locale.US, "%0" + Math.max(2, digits) + "d", index) + ".png";
    }

    /** One PNG per frame, written into res/<name>_frames/ (or the sprites folder without a project). */
    private void exportFramesToRes() {
        final int total = doc.frameCount();
        if (total < 1) { host.toast("Set a frame size first (Frames...)"); return; }
        final String base = sheetBaseName();
        int saved = 0;
        String err = "";
        for (int i = 0; i < total; i++) {
            byte[] png = framePng(i);
            if (png == null) { err = "Could not create frame " + i; break; }
            String e = host.savePng(base + "_frames/" + frameName(base, i, total), png);
            if (e.length() > 0) { err = e; break; }
            saved++;
        }
        if (err.length() > 0) host.toast("Saved " + saved + " of " + total + " frames. " + err);
        else host.toast("Saved " + saved + " frames to " + host.describeSave(base + "_frames/"));
    }

    private void exportFramesZip() {
        int total = doc.frameCount();
        if (total < 1) { host.toast("Set a frame size first (Frames...)"); return; }
        String base = sheetBaseName();
        try {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            ZipOutputStream zos = new ZipOutputStream(bos);
            for (int i = 0; i < total; i++) {
                byte[] png = framePng(i);
                if (png == null) { host.toast("Could not create frame " + i); return; }
                zos.putNextEntry(new ZipEntry(frameName(base, i, total)));
                zos.write(png);
                zos.closeEntry();
            }
            zos.close();
            host.exportToDevice(base + "_frames.zip", "application/zip", bos.toByteArray());
        } catch (java.io.IOException e) {
            host.toast("Could not create the ZIP: " + e.getMessage());
        }
    }

    // ------------------------------------------------------------------
    // dialogs: colour, resize, frames, replace, animation
    // ------------------------------------------------------------------

    private void chooseColor(int initial, final ColorCallback cb) {
        final ColorTool[] ct = new ColorTool[1];
        ColorTool.Actions act = new ColorTool.Actions() {
            public void copy(String text) { host.copy(text); }
            public boolean canInsert() { return false; }
            public void insert(String text) { }
            public void pickFromImage() {
                ImageColorPicker.show(host, new ImageColorPicker.Result() {
                    public void onColor(int argb) { ct[0].setArgb(argb); }
                });
            }
        };
        ct[0] = new ColorTool(a, initial, true, false, act, null);
        ScrollView sv = new ScrollView(a);
        LinearLayout pad = new LinearLayout(a);
        pad.setOrientation(LinearLayout.VERTICAL);
        pad.setPadding(Ui.dp(18), 0, Ui.dp(18), Ui.dp(8));
        pad.addView(ct[0].getView(), Ui.lp(Ui.MATCH, Ui.WRAP));
        sv.addView(pad);
        new AlertDialog.Builder(a, Ui.dialogTheme()).setTitle("Color").setView(sv)
            .setPositiveButton("Use", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int w) { cb.got(ct[0].getArgb()); }
            })
            .setNeutralButton("Transparent", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int w) { cb.got(0); }
            })
            .setNegativeButton("Cancel", null).show();
    }

    private void resizeDialog() {
        final EditText fw = numberField("Width", doc.w), fh = numberField("Height", doc.h);
        final int[] anchor = {1};
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(Ui.dp(20), Ui.dp(8), Ui.dp(20), 0);
        LinearLayout row = new LinearLayout(a);
        row.addView(Ui.labeled(a, "Width", fw), Ui.lpWeight(0, Ui.WRAP, 1));
        row.addView(new View(a), Ui.lp(Ui.dp(10), 1));
        row.addView(Ui.labeled(a, "Height", fh), Ui.lpWeight(0, Ui.WRAP, 1));
        box.addView(row);
        final TextView anchorPill = Ui.pill(a, "Crop / extend from: center", 0, Ui.TEXT, null);
        anchorPill.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                anchor[0] = anchor[0] == 1 ? 0 : 1;
                anchorPill.setText(anchor[0] == 1 ? "Crop / extend from: center" : "Crop / extend from: top-left");
            }
        });
        box.addView(anchorPill, Ui.lp(Ui.MATCH, Ui.WRAP));
        box.addView(Ui.label(a, "Crop / extend keeps the pixels as they are. Scale stretches the picture (nearest neighbour, sharp pixels).",
                12, Ui.MUTED, false), Ui.lpMargin(Ui.MATCH, Ui.WRAP, 4, 10, 4, 0));
        new AlertDialog.Builder(a, Ui.dialogTheme()).setTitle("Resize canvas").setView(box)
            .setPositiveButton("Crop / extend", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int w) {
                    doc.resizeCrop(clampSide(intOf(fw, doc.w)), clampSide(intOf(fh, doc.h)), anchor[0]);
                    canvas.fit();
                    changed();
                }
            })
            .setNeutralButton("Scale", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int w) {
                    doc.scaleTo(clampSide(intOf(fw, doc.w)), clampSide(intOf(fh, doc.h)));
                    canvas.fit();
                    changed();
                }
            })
            .setNegativeButton("Cancel", null).show();
    }

    private static int clampSide(int v) { return Math.max(1, Math.min(MAX_SIDE, v)); }

    private void framesDialog() {
        final EditText fw = numberField("Frame width", doc.frameW > 0 ? doc.frameW : doc.w);
        final EditText fh = numberField("Frame height", doc.frameH > 0 ? doc.frameH : doc.h);
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(Ui.dp(20), Ui.dp(8), Ui.dp(20), 0);
        LinearLayout row = new LinearLayout(a);
        row.addView(Ui.labeled(a, "Frame width", fw), Ui.lpWeight(0, Ui.WRAP, 1));
        row.addView(new View(a), Ui.lp(Ui.dp(10), 1));
        row.addView(Ui.labeled(a, "Frame height", fh), Ui.lpWeight(0, Ui.WRAP, 1));
        box.addView(row);
        box.addView(Ui.label(a, "For a sprite sheet: the size of one frame. A blue grid is drawn over the picture, and the size is used in the Sprite code (new Sprite(img, w, h)).",
                12, Ui.MUTED, false), Ui.lpMargin(Ui.MATCH, Ui.WRAP, 4, 0, 4, 0));
        new AlertDialog.Builder(a, Ui.dialogTheme()).setTitle("Sprite-sheet frames").setView(box)
            .setPositiveButton("Apply", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int w) {
                    int nw = intOf(fw, 0), nh = intOf(fh, 0);
                    if (nw < 1 || nh < 1 || nw > doc.w || nh > doc.h) { host.toast("Frame size must fit inside " + doc.w + "x" + doc.h); return; }
                    doc.frameW = nw;
                    doc.frameH = nh;
                    updateAll();
                    canvas.invalidate();
                    host.toast((doc.w / nw) * (doc.h / nh) + " frames");
                }
            })
            .setNeutralButton("Remove grid", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int w) { doc.frameW = 0; doc.frameH = 0; updateAll(); canvas.invalidate(); }
            })
            .setNegativeButton("Cancel", null).show();
    }

    private void replaceDialog() {
        final int[] from = {lastPicked != 0 ? lastPicked : doc.get(0, 0)};
        final int[] to = {color};
        final TextView sFrom = colorChip(from[0]), sTo = colorChip(to[0]);
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(Ui.dp(20), Ui.dp(8), Ui.dp(20), 0);
        box.addView(chipRow("Replace", sFrom));
        box.addView(chipRow("With", sTo));
        box.addView(Ui.label(a, "Tap a color to change it. Tip: use the Pick tool first - the picked color is used here.", 12, Ui.MUTED, false),
                Ui.lpMargin(Ui.MATCH, Ui.WRAP, 4, 6, 4, 0));
        sFrom.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                chooseColor(from[0], new ColorCallback() { public void got(int c) { from[0] = c; styleChip(sFrom, c); } });
            }
        });
        sTo.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                chooseColor(to[0], new ColorCallback() { public void got(int c) { to[0] = c; styleChip(sTo, c); } });
            }
        });
        new AlertDialog.Builder(a, Ui.dialogTheme()).setTitle("Replace color").setView(box)
            .setPositiveButton("Replace", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int w) {
                    int n = doc.replace(from[0], to[0]);
                    changed();
                    host.toast(n + (n == 1 ? " pixel replaced" : " pixels replaced"));
                }
            }).setNegativeButton("Cancel", null).show();
    }

    private TextView colorChip(int c) {
        TextView t = Ui.label(a, "", 12, Ui.TEXT, true);
        t.setGravity(Gravity.CENTER);
        t.setClickable(true);
        styleChip(t, c);
        return t;
    }

    private void styleChip(TextView t, int c) {
        t.setBackground(Ui.ripple(Ui.rect((c >>> 24) == 0 ? Ui.SURFACE2 : c, 12, Ui.STROKE)));
        t.setText((c >>> 24) == 0 ? "transparent" : String.format(java.util.Locale.US, "#%08X", c));
        int lum = (((c >> 16) & 255) * 30 + ((c >> 8) & 255) * 59 + (c & 255) * 11) / 100;
        t.setTextColor((c >>> 24) == 0 ? Ui.TEXT : (lum > 140 ? 0xFF000000 : 0xFFFFFFFF));
    }

    private View chipRow(String caption, TextView chip) {
        LinearLayout row = new LinearLayout(a);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.addView(Ui.label(a, caption, 14, Ui.TEXT, true), Ui.lp(Ui.dp(80), Ui.WRAP));
        row.addView(chip, Ui.lpWeight(0, Ui.dp(44), 1));
        row.setLayoutParams(Ui.lpMargin(Ui.MATCH, Ui.WRAP, 0, 4, 0, 8));
        return row;
    }

    private void previewAnimation() {
        if (doc.frameCount() < 2) {
            host.toast("Set a frame size first (Frames...) so the sheet has 2 or more frames");
            return;
        }
        final int fw = doc.frameW, fh = doc.frameH, cols = doc.w / fw, total = cols * (doc.h / fh);
        final int zoom = Math.max(1, Math.min(10, 260 / Math.max(fw, fh)));
        final int[] fps = {8};
        final int[] frame = {0};
        final ImageView iv = new ImageView(a);
        iv.setScaleType(ImageView.ScaleType.CENTER);
        iv.setBackground(Ui.rect(0xFF9A9A9A, 12, Ui.STROKE));
        final TextView info = Ui.label(a, "", 13, Ui.MUTED, false);
        info.setGravity(Gravity.CENTER);
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(Ui.dp(20), Ui.dp(8), Ui.dp(20), 0);
        box.addView(iv, Ui.lp(Ui.MATCH, Ui.dp(Math.min(300, fh * zoom + 24))));
        box.addView(info, Ui.lpMargin(Ui.MATCH, Ui.WRAP, 0, 10, 0, 6));
        LinearLayout speed = new LinearLayout(a);
        speed.setGravity(Gravity.CENTER);
        TextView slower = Ui.pill(a, "Slower", 0, Ui.TEXT, null);
        TextView faster = Ui.pill(a, "Faster", 0, Ui.TEXT, null);
        speed.addView(slower, Ui.lpMargin(Ui.WRAP, Ui.WRAP, 0, 0, 10, 0));
        speed.addView(faster);
        box.addView(speed);

        final Handler h = new Handler(Looper.getMainLooper());
        final boolean[] running = {true};
        final Runnable tick = new Runnable() {
            public void run() {
                if (!running[0]) return;
                int fx = (frame[0] % cols) * fw, fy = (frame[0] / cols) * fh;
                int[] px = new int[fw * fh];
                for (int y = 0; y < fh; y++) System.arraycopy(doc.px, (fy + y) * doc.w + fx, px, y * fw, fw);
                Bitmap small = Bitmap.createBitmap(fw, fh, Bitmap.Config.ARGB_8888);
                small.setPixels(px, 0, fw, 0, 0, fw, fh);
                iv.setImageBitmap(Bitmap.createScaledBitmap(small, fw * zoom, fh * zoom, false));
                info.setText("Frame " + (frame[0] + 1) + " / " + total + "   \u00B7   " + fps[0] + " fps");
                frame[0] = (frame[0] + 1) % total;
                h.postDelayed(this, 1000L / fps[0]);
            }
        };
        slower.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { fps[0] = Math.max(1, fps[0] - 2); }
        });
        faster.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { fps[0] = Math.min(30, fps[0] + 2); }
        });
        AlertDialog dlg = new AlertDialog.Builder(a, Ui.dialogTheme()).setTitle("Animation preview").setView(box)
            .setPositiveButton("Close", null).create();
        dlg.setOnDismissListener(new DialogInterface.OnDismissListener() {
            public void onDismiss(DialogInterface d) { running[0] = false; h.removeCallbacks(tick); }
        });
        dlg.show();
        h.post(tick);
    }
}
