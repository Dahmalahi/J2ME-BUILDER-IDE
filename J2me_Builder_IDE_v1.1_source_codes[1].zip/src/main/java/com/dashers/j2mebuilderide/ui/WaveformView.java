package com.dashers.j2mebuilderide.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

/**
 * Sound wave with a draggable selection. One finger drags the selection (or its edges), two fingers pinch to zoom and pan,
 * a tap moves the play position.
 */
public final class WaveformView extends View {
    public interface Listener {
        void onSelectionChanged();
        void onSeek(int sample);
    }

    private short[] pcm = new short[0];
    private int rate = 22050;
    private float viewStart;              // first visible sample
    private float spp = 100f;             // samples per pixel
    private int selA = -1, selB = -1;
    private int playhead = -1;
    private Listener listener;
    private boolean fitted;

    private final Paint pWave = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pFill = new Paint();
    private final Paint pText = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final ScaleGestureDetector sgd;

    private int dragMode;                 // 0 none, 1 new selection, 2 move start, 3 move end
    private int anchor;
    private float downX, lastFx;
    private boolean moved, multi;

    public WaveformView(Context c) {
        super(c);
        pWave.setStrokeWidth(1f);
        pText.setTextSize(Ui.dp(10));
        sgd = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScale(ScaleGestureDetector d) {
                float focusSample = viewStart + d.getFocusX() * spp;
                spp = clampSpp(spp / d.getScaleFactor());
                viewStart = focusSample - d.getFocusX() * spp;
                clampView();
                invalidate();
                return true;
            }
        });
    }

    public void setListener(Listener l) { listener = l; }

    public void setData(short[] data, int sampleRate) {
        pcm = data == null ? new short[0] : data;
        rate = Math.max(1, sampleRate);
        selA = selB = -1;
        playhead = -1;
        fitted = false;
        fit();
    }

    /** Same sound edited in place (keeps zoom). */
    public void refreshData(short[] data) {
        pcm = data;
        selA = selB = -1;
        clampView();
        invalidate();
    }

    public int length() { return pcm.length; }

    public int sampleRate() { return rate; }

    public boolean hasSelection() { return selA >= 0 && selB > selA; }

    /** Selection start, or 0 when nothing is selected. */
    public int selStart() { return hasSelection() ? selA : 0; }

    /** Selection end, or the whole length when nothing is selected. */
    public int selEnd() { return hasSelection() ? selB : pcm.length; }

    public void selectAll() { selA = 0; selB = pcm.length; invalidate(); notifySel(); }

    public void clearSelection() { selA = selB = -1; invalidate(); notifySel(); }

    public void setSelection(int a, int b) {
        selA = Math.max(0, Math.min(pcm.length, Math.min(a, b)));
        selB = Math.max(0, Math.min(pcm.length, Math.max(a, b)));
        invalidate();
        notifySel();
    }

    public void setPlayhead(int sample) { playhead = sample; invalidate(); }

    public void fit() {
        if (getWidth() == 0) return;
        spp = clampSpp(Math.max(1f, pcm.length / (float) getWidth()));
        viewStart = 0;
        fitted = true;
        invalidate();
    }

    public void zoom(float factor) {
        float focus = viewStart + getWidth() / 2f * spp;
        spp = clampSpp(spp / factor);
        viewStart = focus - getWidth() / 2f * spp;
        clampView();
        invalidate();
    }

    private float clampSpp(float v) {
        float max = Math.max(1f, pcm.length / (float) Math.max(1, getWidth()));
        return Math.max(0.05f, Math.min(max, v));
    }

    private void clampView() {
        float max = Math.max(0, pcm.length - getWidth() * spp);
        viewStart = Math.max(0, Math.min(max, viewStart));
    }

    private void notifySel() { if (listener != null) listener.onSelectionChanged(); }

    private int sampleAt(float x) { return (int) Math.max(0, Math.min(pcm.length, viewStart + x * spp)); }

    private float xOf(int sample) { return (sample - viewStart) / spp; }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        if (!fitted) fit();
    }

    @Override protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        pFill.setColor(Ui.EDITOR);
        c.drawRect(0, 0, w, h, pFill);
        float mid = h / 2f;
        pFill.setColor(0x33FFFFFF);
        c.drawRect(0, mid, w, mid + 1, pFill);
        if (pcm.length == 0) {
            pText.setColor(Ui.MUTED);
            c.drawText("No sound yet - record or import one", Ui.dp(12), mid, pText);
            return;
        }
        // time marks
        float[] steps = {0.05f, 0.1f, 0.2f, 0.5f, 1, 2, 5, 10, 30, 60, 120, 300};
        float stepSec = steps[steps.length - 1];
        for (int i = 0; i < steps.length; i++) if (steps[i] * rate / spp >= Ui.dp(64)) { stepSec = steps[i]; break; }
        pText.setColor(Ui.MUTED);
        pFill.setColor(0x22FFFFFF);
        double t0 = Math.floor(viewStart / rate / stepSec) * stepSec;
        for (double t = t0; t * rate < viewStart + w * spp; t += stepSec) {
            float x = xOf((int) (t * rate));
            if (x < 0) continue;
            c.drawRect(x, 0, x + 1, h, pFill);
            int mins = (int) (t / 60);
            float sec = (float) (t - mins * 60);
            c.drawText(mins + ":" + (sec < 10 ? "0" : "") + (Math.round(sec * 10f) / 10f), x + Ui.dp(3), Ui.dp(11), pText);
        }
        // wave
        pWave.setColor(Ui.ACCENT);
        float amp = (h / 2f - Ui.dp(14));
        for (int x = 0; x < w; x++) {
            int a = (int) (viewStart + x * spp), b = (int) (viewStart + (x + 1) * spp);
            if (a >= pcm.length) break;
            b = Math.min(pcm.length, Math.max(a + 1, b));
            int stride = Math.max(1, (b - a) / 48);
            int mn = 32767, mx = -32768;
            for (int i = a; i < b; i += stride) {
                int s = pcm[i];
                if (s < mn) mn = s;
                if (s > mx) mx = s;
            }
            float y1 = mid - mx / 32768f * amp, y2 = mid - mn / 32768f * amp;
            if (y2 - y1 < 1f) y2 = y1 + 1f;
            c.drawLine(x, y1, x, y2, pWave);
        }
        // selection
        if (hasSelection()) {
            float xa = xOf(selA), xb = xOf(selB);
            pFill.setColor(0x44FFFFFF);
            c.drawRect(Math.max(0, xa), 0, Math.min(w, xb), h, pFill);
            pFill.setColor(0xFFFFFFFF);
            float hw = Ui.dp(3);
            c.drawRect(xa - hw / 2, 0, xa + hw / 2, h, pFill);
            c.drawRect(xb - hw / 2, 0, xb + hw / 2, h, pFill);
        }
        if (playhead >= 0) {
            float x = xOf(playhead);
            pFill.setColor(0xFFFF5252);
            c.drawRect(x, 0, x + Ui.dp(2), h, pFill);
        }
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        if (pcm.length == 0) return false;
        getParent().requestDisallowInterceptTouchEvent(true);
        sgd.onTouchEvent(e);
        int n = e.getPointerCount();
        int act = e.getActionMasked();
        if (n >= 2 || sgd.isInProgress()) {
            multi = true;
            float fx = 0;
            for (int i = 0; i < n; i++) fx += e.getX(i);
            fx /= n;
            if (act == MotionEvent.ACTION_MOVE && n >= 2) {
                viewStart -= (fx - lastFx) * spp;
                clampView();
                invalidate();
            }
            lastFx = fx;
            if (act == MotionEvent.ACTION_UP || act == MotionEvent.ACTION_CANCEL) multi = false;
            return true;
        }
        if (multi) {
            if (act == MotionEvent.ACTION_UP || act == MotionEvent.ACTION_CANCEL) multi = false;
            lastFx = e.getX();
            return true;
        }
        float x = e.getX();
        int s = sampleAt(x);
        switch (act) {
            case MotionEvent.ACTION_DOWN: {
                downX = x;
                moved = false;
                dragMode = 1;
                anchor = s;
                if (hasSelection()) {
                    float slop = Ui.dp(22);
                    if (Math.abs(x - xOf(selA)) <= slop) { dragMode = 2; }
                    else if (Math.abs(x - xOf(selB)) <= slop) { dragMode = 3; }
                }
                break;
            }
            case MotionEvent.ACTION_MOVE: {
                if (!moved && Math.abs(x - downX) > Ui.dp(6)) moved = true;
                if (!moved) break;
                if (dragMode == 1) { selA = Math.min(anchor, s); selB = Math.max(anchor, s); }
                else if (dragMode == 2) { selA = Math.min(s, selB - 1); }
                else if (dragMode == 3) { selB = Math.max(s, selA + 1); }
                invalidate();
                notifySel();
                break;
            }
            case MotionEvent.ACTION_UP: {
                if (!moved) {
                    if (dragMode == 1) {
                        selA = selB = -1;
                        playhead = s;
                        if (listener != null) listener.onSeek(s);
                        notifySel();
                    }
                }
                dragMode = 0;
                invalidate();
                break;
            }
            case MotionEvent.ACTION_CANCEL: dragMode = 0; break;
            default: break;
        }
        return true;
    }
}
