package com.dashers.j2mebuilderide.ui;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

/**
 * Colour panel: preview, hex field, ready-to-use J2ME code (copy / insert), R G B (A) sliders and a palette.
 * Used full screen by the Color Palette and as a dialog body by the Sprite Editor.
 */
public final class ColorTool {

    public interface Listener { void onColor(int argb); }

    /** Optional buttons; pass null for none. */
    public interface Actions {
        void copy(String text);
        boolean canInsert();
        void insert(String text);
        /** Opens an image so a colour can be picked from it; may be a no-op. */
        void pickFromImage();
    }

    public static final int[] PALETTE = {
        0xFF000000, 0xFF424242, 0xFF757575, 0xFFBDBDBD, 0xFFFFFFFF, 0xFFF44336, 0xFFE91E63, 0xFF9C27B0,
        0xFF673AB7, 0xFF3F51B5, 0xFF2196F3, 0xFF03A9F4, 0xFF00BCD4, 0xFF009688, 0xFF4CAF50, 0xFF8BC34A,
        0xFFCDDC39, 0xFFFFEB3B, 0xFFFFC107, 0xFFFF9800, 0xFFFF5722, 0xFF795548, 0xFF607D8B, 0xFF33B5E5,
        0xFFB71C1C, 0xFF880E4F, 0xFF4A148C, 0xFF0D47A1, 0xFF006064, 0xFF004D40, 0xFF1B5E20, 0xFFE65100,
        0xFFFFCDD2, 0xFFF8BBD0, 0xFFE1BEE7, 0xFFBBDEFB, 0xFFB2EBF2, 0xFFC8E6C9, 0xFFFFE0B2, 0xFFD7CCC8,
        0xFFFFDBAC, 0xFFF1C27D, 0xFFE0AC69, 0xFFC68642, 0xFF8D5524, 0xFF5D4037, 0xFF3E2723, 0xFF263238
    };

    private final Context ctx;
    private final boolean withAlpha;
    private final Actions actions;
    private final Listener listener;
    private int argb;
    private boolean updating;

    private final LinearLayout root;
    private PreviewView preview;
    private EditText hex;
    private final SeekBar[] bars = new SeekBar[4];       // A R G B
    private final TextView[] vals = new TextView[4];
    private final TextView[] codeText = new TextView[5];
    private final View[] cells = new View[PALETTE.length];

    public ColorTool(Context ctx, int initialArgb, boolean withAlpha, boolean showCode, Actions actions, Listener listener) {
        this.ctx = ctx;
        this.withAlpha = withAlpha;
        this.actions = actions;
        this.listener = listener;
        this.argb = withAlpha ? initialArgb : (0xFF000000 | initialArgb);

        root = new LinearLayout(ctx);
        root.setOrientation(LinearLayout.VERTICAL);

        root.addView(Ui.section(ctx, "Preview"));
        preview = new PreviewView(ctx);
        root.addView(preview, Ui.lp(Ui.MATCH, Ui.dp(88)));

        if (actions != null) {
            TextView pick = Ui.pill(ctx, "Pick color from an image", 0, Ui.ACCENT, new View.OnClickListener() {
                public void onClick(View v) { ColorTool.this.actions.pickFromImage(); }
            });
            pick.setTextSize(13);
            root.addView(pick, Ui.lpMargin(Ui.MATCH, Ui.WRAP, 0, 10, 0, 0));
        }

        root.addView(Ui.section(ctx, withAlpha ? "Hex code (AARRGGBB, type or paste)" : "Hex code (type or paste)"));
        hex = Ui.field(ctx, withAlpha ? "FF33B5E5" : "33B5E5", "");
        hex.setTypeface(Typeface.MONOSPACE);
        hex.setTextSize(18);
        hex.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
                | android.text.InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
        hex.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            public void onTextChanged(CharSequence s, int a, int b, int c) { }
            public void afterTextChanged(Editable e) { onHexTyped(e.toString()); }
        });
        root.addView(hex, Ui.lp(Ui.MATCH, Ui.WRAP));

        if (showCode) {
            root.addView(Ui.section(ctx, "Code"));
            LinearLayout card = Ui.card(ctx);
            String[] captions = withAlpha
                    ? new String[]{"J2ME color int", "ARGB int", "Hex", "Graphics call", "Graphics call (r, g, b)"}
                    : new String[]{"J2ME color int", "Hex", "Graphics call", "Graphics call (r, g, b)"};
            for (int i = 0; i < captions.length; i++) {
                if (i > 0) card.addView(Ui.divider(ctx));
                card.addView(codeRow(captions[i], i));
            }
            root.addView(card, Ui.lp(Ui.MATCH, Ui.WRAP));
        }

        root.addView(Ui.section(ctx, withAlpha ? "ARGB" : "RGB"));
        String[] names = {"A", "R", "G", "B"};
        int[] tints = {0xFF9E9E9E, 0xFFF44336, 0xFF4CAF50, 0xFF2196F3};
        for (int i = withAlpha ? 0 : 1; i < 4; i++) {
            root.addView(sliderRow(i, names[i], tints[i]), Ui.lp(Ui.MATCH, Ui.WRAP));
        }

        root.addView(Ui.section(ctx, "Palette (tap a color)"));
        for (int r = 0; r < PALETTE.length / 8; r++) {
            LinearLayout row = new LinearLayout(ctx);
            for (int q = 0; q < 8; q++) {
                final int idx = r * 8 + q;
                Square sq = new Square(ctx);
                sq.setBackground(Ui.ripple(Ui.rect(PALETTE[idx], 8, Ui.STROKE)));
                sq.setClickable(true);
                sq.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        int c = PALETTE[idx];
                        setArgb(ColorTool.this.withAlpha ? c : (0xFF000000 | c), true);
                    }
                });
                cells[idx] = sq;
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroupWrap(), 1f);
                lp.setMargins(Ui.dp(3), Ui.dp(3), Ui.dp(3), Ui.dp(3));
                row.addView(sq, lp);
            }
            root.addView(row, Ui.lp(Ui.MATCH, Ui.WRAP));
        }
        setArgb(argb, false);
    }

    private static int ViewGroupWrap() { return android.view.ViewGroup.LayoutParams.WRAP_CONTENT; }

    public View getView() { return root; }

    public int getArgb() { return argb; }

    public void setArgb(int c) { setArgb(c, true); }

    // ------------------------------------------------------------------

    private void setArgb(int c, boolean notify) {
        if (!withAlpha) c = 0xFF000000 | c;
        argb = c;
        refresh(null);
        if (notify && listener != null) listener.onColor(argb);
    }

    /** Update every widget except 'skip'. */
    private void refresh(View skip) {
        updating = true;
        try {
            preview.setColor(argb);
            if (skip != hex) {
                String h = withAlpha ? hex8(argb) : hex6(argb);
                if (!h.equals(hex.getText().toString())) hex.setText(h);
                hex.setTextColor(Ui.TEXT);
            }
            int[] comp = {argb >>> 24, (argb >> 16) & 255, (argb >> 8) & 255, argb & 255};
            for (int i = 0; i < 4; i++) {
                if (bars[i] == null) continue;
                if (skip != bars[i]) bars[i].setProgress(comp[i]);
                vals[i].setText(String.valueOf(comp[i]));
            }
            String[] code = codeStrings();
            for (int i = 0; i < codeText.length; i++) {
                if (codeText[i] != null && i < code.length) codeText[i].setText(code[i]);
            }
            for (int i = 0; i < PALETTE.length; i++) {
                int p = withAlpha ? PALETTE[i] : (0xFF000000 | PALETTE[i]);
                boolean sel = p == argb;
                if (cells[i] != null) {
                    cells[i].setBackground(Ui.ripple(sel
                            ? sel(PALETTE[i]) : Ui.rect(PALETTE[i], 8, Ui.STROKE)));
                }
            }
        } finally {
            updating = false;
        }
    }

    private android.graphics.drawable.GradientDrawable sel(int fill) {
        android.graphics.drawable.GradientDrawable g = Ui.rect(fill, 8, 0);
        g.setStroke(Ui.dp(3), Ui.ACCENT);
        return g;
    }

    private void onHexTyped(String raw) {
        if (updating) return;
        String s = raw.trim();
        if (s.startsWith("#")) s = s.substring(1);
        if (s.toLowerCase().startsWith("0x")) s = s.substring(2);
        Integer parsed = null;
        try {
            if (s.length() == 3) {
                String e = "" + s.charAt(0) + s.charAt(0) + s.charAt(1) + s.charAt(1) + s.charAt(2) + s.charAt(2);
                parsed = Integer.valueOf(0xFF000000 | (int) Long.parseLong(e, 16));
            } else if (s.length() == 6) {
                parsed = Integer.valueOf(0xFF000000 | (int) Long.parseLong(s, 16));
            } else if (s.length() == 8 && withAlpha) {
                parsed = Integer.valueOf((int) Long.parseLong(s, 16));
            }
        } catch (NumberFormatException ignore) { }
        if (parsed == null) {
            hex.setTextColor(Ui.RED);
            return;
        }
        argb = withAlpha ? parsed.intValue() : (0xFF000000 | parsed.intValue());
        refresh(hex);
        if (listener != null) listener.onColor(argb);
    }

    private static String hex6(int c) { return String.format(java.util.Locale.US, "%06X", c & 0xFFFFFF); }

    private static String hex8(int c) { return String.format(java.util.Locale.US, "%08X", c); }

    private String[] codeStrings() {
        int r = (argb >> 16) & 255, g = (argb >> 8) & 255, b = argb & 255;
        if (withAlpha) {
            return new String[]{"0x" + hex6(argb), "0x" + hex8(argb), "#" + hex8(argb),
                "g.setColor(0x" + hex6(argb) + ");", "g.setColor(" + r + ", " + g + ", " + b + ");"};
        }
        return new String[]{"0x" + hex6(argb), "#" + hex6(argb),
            "g.setColor(0x" + hex6(argb) + ");", "g.setColor(" + r + ", " + g + ", " + b + ");"};
    }

    private View codeRow(String caption, final int index) {
        LinearLayout row = new LinearLayout(ctx);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(Ui.dp(14), Ui.dp(10), Ui.dp(10), Ui.dp(10));
        LinearLayout left = new LinearLayout(ctx);
        left.setOrientation(LinearLayout.VERTICAL);
        left.addView(Ui.label(ctx, caption, 12, Ui.MUTED, false));
        TextView v = Ui.label(ctx, "", 15, Ui.TEXT, false);
        v.setTypeface(Typeface.MONOSPACE);
        v.setPadding(0, Ui.dp(3), 0, 0);
        left.addView(v);
        codeText[index] = v;
        row.addView(left, Ui.lpWeight(0, Ui.WRAP, 1));

        TextView copy = Ui.pill(ctx, "COPY", 0, Ui.ACCENT, new View.OnClickListener() {
            public void onClick(View x) {
                if (actions != null) actions.copy(codeText[index].getText().toString());
                else copyToClipboard(codeText[index].getText().toString());
            }
        });
        smallPill(copy);
        row.addView(copy, Ui.lpMargin(Ui.WRAP, Ui.WRAP, 8, 0, 0, 0));
        if (actions != null && actions.canInsert()) {
            TextView ins = Ui.pill(ctx, "INSERT", Ui.ACCENT, Ui.WHITE, new View.OnClickListener() {
                public void onClick(View x) { actions.insert(codeText[index].getText().toString()); }
            });
            smallPill(ins);
            row.addView(ins, Ui.lpMargin(Ui.WRAP, Ui.WRAP, 6, 0, 0, 0));
        }
        return row;
    }

    private void copyToClipboard(String s) {
        try {
            android.content.ClipboardManager cm = (android.content.ClipboardManager) ctx.getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(android.content.ClipData.newPlainText("color", s));
        } catch (Throwable ignore) { }
    }

    private static void smallPill(TextView t) {
        t.setTextSize(12);
        t.setPadding(Ui.dp(12), Ui.dp(7), Ui.dp(12), Ui.dp(7));
    }

    private View sliderRow(final int i, String name, int tint) {
        LinearLayout row = new LinearLayout(ctx);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView n = Ui.label(ctx, name, 15, Ui.TEXT, true);
        row.addView(n, Ui.lp(Ui.dp(24), Ui.WRAP));
        SeekBar sb = new SeekBar(ctx);
        sb.setMax(255);
        sb.setProgressTintList(ColorStateList.valueOf(tint));
        sb.setThumbTintList(ColorStateList.valueOf(tint));
        sb.setProgressBackgroundTintList(ColorStateList.valueOf(Ui.STROKE));
        sb.setPadding(Ui.dp(14), Ui.dp(10), Ui.dp(14), Ui.dp(10));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                if (!fromUser || updating) return;
                int a = argb >>> 24, r = (argb >> 16) & 255, g = (argb >> 8) & 255, b = argb & 255;
                if (i == 0) a = p; else if (i == 1) r = p; else if (i == 2) g = p; else b = p;
                argb = (a << 24) | (r << 16) | (g << 8) | b;
                refresh(s);
                if (listener != null) listener.onColor(argb);
            }
            public void onStartTrackingTouch(SeekBar s) { }
            public void onStopTrackingTouch(SeekBar s) { }
        });
        bars[i] = sb;
        row.addView(sb, Ui.lpWeight(0, Ui.WRAP, 1));
        TextView v = Ui.label(ctx, "0", 15, Ui.TEXT, false);
        v.setTypeface(Typeface.MONOSPACE);
        v.setGravity(Gravity.END);
        vals[i] = v;
        row.addView(v, Ui.lp(Ui.dp(40), Ui.WRAP));
        return row;
    }

    // ------------------------------------------------------------------

    /** Square cell for the palette grid: height follows the width. */
    private static final class Square extends View {
        Square(Context c) { super(c); }
        @Override protected void onMeasure(int w, int h) {
            int size = View.MeasureSpec.getSize(w);
            setMeasuredDimension(size, size);
        }
    }

    /** Rounded colour preview with a checkerboard behind transparent colours. */
    private static final class PreviewView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF r = new RectF();
        private final Path clip = new Path();
        private int color = 0xFF000000;

        PreviewView(Context c) { super(c); }

        void setColor(int c) { color = c; invalidate(); }

        @Override protected void onDraw(Canvas cv) {
            float w = getWidth(), h = getHeight(), rad = Ui.dp(14);
            r.set(1, 1, w - 1, h - 1);
            clip.reset();
            clip.addRoundRect(r, rad, rad, Path.Direction.CW);
            cv.save();
            cv.clipPath(clip);
            if ((color >>> 24) != 255) {
                float cell = Ui.dp(10);
                for (int row = 0; row * cell < h; row++) {
                    for (int q = 0; q * cell < w; q++) {
                        p.setStyle(Paint.Style.FILL);
                        p.setColor(((row + q) & 1) == 0 ? 0xFFC4C4C4 : 0xFF9A9A9A);
                        cv.drawRect(q * cell, row * cell, (q + 1) * cell, (row + 1) * cell, p);
                    }
                }
            }
            p.setStyle(Paint.Style.FILL);
            p.setColor(color);
            cv.drawRect(0, 0, w, h, p);
            cv.restore();
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(Ui.dp(1.5f));
            p.setColor(Ui.STROKE);
            cv.drawRoundRect(r, rad, rad, p);
        }
    }
}
