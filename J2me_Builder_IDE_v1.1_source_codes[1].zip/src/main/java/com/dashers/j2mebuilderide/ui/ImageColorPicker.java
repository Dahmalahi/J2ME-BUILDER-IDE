package com.dashers.j2mebuilderide.ui;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Vector;

/** Eyedropper: choose an image (project res/ or the device), touch it, get that pixel's colour. */
public final class ImageColorPicker {

    public interface Result { void onColor(int argb); }

    private ImageColorPicker() { }

    public static void show(final ToolHost host, final Result result) {
        final Activity a = host.activity();
        final Vector imgs = host.listImageResources();
        final ToolHost.ImageSink sink = new ToolHost.ImageSink() {
            public void onImage(Bitmap bmp, String name) {
                if (bmp == null) { host.toast("Could not read that image"); return; }
                pick(host, bmp, name, result);
            }
        };
        if (imgs.size() == 0) {
            host.pickDeviceImage(sink);
            return;
        }
        final String[] items = new String[imgs.size() + 1];
        items[0] = "From this device...";
        for (int i = 0; i < imgs.size(); i++) items[i + 1] = "res/" + imgs.elementAt(i);
        new AlertDialog.Builder(a, Ui.dialogTheme()).setTitle("Pick color from")
            .setItems(items, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int which) {
                    if (which == 0) { host.pickDeviceImage(sink); return; }
                    String rel = (String) imgs.elementAt(which - 1);
                    sink.onImage(host.loadResBitmap(rel), rel);
                }
            }).setNegativeButton("Cancel", null).show();
    }

    private static void pick(final ToolHost host, final Bitmap bmp, String name, final Result result) {
        final Activity a = host.activity();
        final int[] chosen = {0};
        final boolean[] has = {false};

        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(Ui.dp(16), Ui.dp(8), Ui.dp(16), 0);

        LinearLayout top = new LinearLayout(a);
        top.setGravity(Gravity.CENTER_VERTICAL);
        final View swatch = new View(a);
        swatch.setBackground(Ui.rect(0xFF000000, 10, Ui.STROKE));
        top.addView(swatch, Ui.lpMargin(Ui.dp(44), Ui.dp(44), 0, 0, 12, 0));
        final TextView info = Ui.label(a, "Touch the image to pick a color", 14, Ui.MUTED, false);
        info.setTypeface(Typeface.MONOSPACE);
        top.addView(info, Ui.lpWeight(0, Ui.WRAP, 1));
        box.addView(top, Ui.lpMargin(Ui.MATCH, Ui.WRAP, 0, 0, 0, 10));

        final ImageView iv = new ImageView(a);
        iv.setImageBitmap(bmp);
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        iv.setBackground(Ui.rect(Ui.SURFACE2, 10, Ui.STROKE));
        iv.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent e) {
                int act = e.getActionMasked();
                if (act != MotionEvent.ACTION_DOWN && act != MotionEvent.ACTION_MOVE && act != MotionEvent.ACTION_UP) return true;
                Matrix inv = new Matrix();
                if (!iv.getImageMatrix().invert(inv)) return true;
                float[] pt = {e.getX() - iv.getPaddingLeft(), e.getY() - iv.getPaddingTop()};
                inv.mapPoints(pt);
                int x = (int) Math.floor(pt[0]), y = (int) Math.floor(pt[1]);
                if (x >= 0 && y >= 0 && x < bmp.getWidth() && y < bmp.getHeight()) {
                    int c = bmp.getPixel(x, y);
                    chosen[0] = c;
                    has[0] = true;
                    swatch.setBackground(Ui.rect(c | 0xFF000000, 10, Ui.STROKE));
                    info.setTextColor(Ui.TEXT);
                    info.setText(String.format(java.util.Locale.US, "#%06X   x%d y%d", c & 0xFFFFFF, x, y)
                            + ((c >>> 24) != 255 ? String.format(java.util.Locale.US, "   a%d", c >>> 24) : ""));
                }
                return true;
            }
        });
        box.addView(iv, Ui.lp(Ui.MATCH, Ui.dp(300)));

        new AlertDialog.Builder(a, Ui.dialogTheme())
            .setTitle(name == null ? "Pick color" : name + "  (" + bmp.getWidth() + "x" + bmp.getHeight() + ")")
            .setView(box)
            .setPositiveButton("Use color", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int w) {
                    if (has[0]) result.onColor(chosen[0]); else host.toast("Touch the image first");
                }
            })
            .setNegativeButton("Cancel", null)
            .show();
    }
}
