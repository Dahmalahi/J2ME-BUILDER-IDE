package com.dashers.j2mebuilderide.ui;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

/** Thin rounded progress bar for the splash screen; setProgress() animates smoothly. */
public final class SplashBar extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();
    private float shown = 0f;
    private ValueAnimator anim;

    public SplashBar(Context c) { super(c); }

    public void setProgress(float target) {
        if (anim != null) anim.cancel();
        anim = ValueAnimator.ofFloat(shown, Math.max(0f, Math.min(1f, target)));
        anim.setDuration(420);
        anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            public void onAnimationUpdate(ValueAnimator a) {
                shown = ((Float) a.getAnimatedValue()).floatValue();
                invalidate();
            }
        });
        anim.start();
    }

    @Override
    protected void onDraw(Canvas cv) {
        float w = getWidth(), h = getHeight();
        p.setColor(Ui.STROKE);
        r.set(0, 0, w, h);
        cv.drawRoundRect(r, h / 2, h / 2, p);
        p.setColor(Ui.ACCENT);
        r.set(0, 0, Math.max(h, w * shown), h);
        cv.drawRoundRect(r, h / 2, h / 2, p);
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (anim != null) anim.cancel();
    }
}
