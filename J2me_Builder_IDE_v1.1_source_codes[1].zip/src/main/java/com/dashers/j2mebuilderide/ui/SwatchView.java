package com.dashers.j2mebuilderide.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

/** Small preview tile for the theme / editor-colour pickers. */
public final class SwatchView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();
    private final int[] c;          // [bg, card, accent, textA, textB, textC, border]
    private boolean selected;

    /** Theme preview. */
    public static SwatchView ofTheme(Context ctx, Themes.Theme t) {
        return new SwatchView(ctx, new int[]{t.bg, t.surface, t.accent, t.text, t.muted, t.green, t.stroke});
    }

    /** Editor scheme preview ("auto" when sx == null). */
    public static SwatchView ofSyntax(Context ctx, Themes.Syntax sx) {
        if (sx == null) {
            return new SwatchView(ctx, new int[]{Ui.SURFACE2, Ui.SURFACE, Ui.ACCENT, Ui.TEXT, Ui.MUTED, Ui.GREEN, Ui.STROKE});
        }
        return new SwatchView(ctx, new int[]{sx.bg, sx.bg, sx.keyword, sx.string, sx.type, sx.number, Ui.STROKE});
    }

    private SwatchView(Context ctx, int[] colors) {
        super(ctx);
        c = colors;
    }

    public void setSelected2(boolean on) { selected = on; invalidate(); }

    @Override
    protected void onDraw(Canvas cv) {
        float w = getWidth(), h = getHeight(), d = Ui.dp(1);
        p.setStyle(Paint.Style.FILL);
        p.setColor(c[0]);
        r.set(d, d, w - d, h - d);
        cv.drawRoundRect(r, Ui.dp(12), Ui.dp(12), p);
        // card
        p.setColor(c[1]);
        r.set(Ui.dp(8), Ui.dp(22), w - Ui.dp(8), h - Ui.dp(8));
        cv.drawRoundRect(r, Ui.dp(6), Ui.dp(6), p);
        // accent pill
        p.setColor(c[2]);
        r.set(Ui.dp(8), Ui.dp(8), Ui.dp(8) + w * 0.38f, Ui.dp(15));
        cv.drawRoundRect(r, Ui.dp(4), Ui.dp(4), p);
        // text lines
        float y = Ui.dp(28);
        int[] cols = {c[3], c[4], c[5]};
        float[] len = {0.62f, 0.45f, 0.54f};
        for (int i = 0; i < 3; i++) {
            p.setColor(cols[i]);
            r.set(Ui.dp(14), y, Ui.dp(14) + (w - Ui.dp(28)) * len[i], y + Ui.dp(4));
            cv.drawRoundRect(r, Ui.dp(2), Ui.dp(2), p);
            y += Ui.dp(9);
        }
        // border
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(selected ? Ui.dp(2.5f) : d);
        p.setColor(selected ? Ui.ACCENT : c[6]);
        r.set(d, d, w - d, h - d);
        cv.drawRoundRect(r, Ui.dp(12), Ui.dp(12), p);
    }
}
