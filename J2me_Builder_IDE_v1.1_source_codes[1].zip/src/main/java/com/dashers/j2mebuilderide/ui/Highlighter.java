package com.dashers.j2mebuilderide.ui;

import android.text.Editable;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/** Lightweight Java syntax colouring applied as spans on an Editable. */
public final class Highlighter {
    private Highlighter() {}

    public static int KEYWORD = 0xFFC792EA;
    public static int STRING  = 0xFFC3E88D;
    public static int COMMENT = 0xFF646E8C;
    public static int NUMBER  = 0xFFF78C6C;
    public static int TYPE    = 0xFF82AAFF;
    public static int METHOD  = 0xFFFFCB6B;

    /** Swaps the colour set for the light or dark editor background. */
    public static void applyTheme(boolean dark) {
        if (dark) {
            KEYWORD = 0xFFC792EA; STRING = 0xFFC3E88D; COMMENT = 0xFF646E8C;
            NUMBER = 0xFFF78C6C; TYPE = 0xFF82AAFF; METHOD = 0xFFFFCB6B;
        } else {
            KEYWORD = 0xFF8E24AA; STRING = 0xFF2E7D32; COMMENT = 0xFF8A93A6;
            NUMBER = 0xFFD2561F; TYPE = 0xFF1E5FD6; METHOD = 0xFF9A6A00;
        }
    }

    /** Applies a named editor scheme (Dracula, Monokai, ...). */
    public static void applyScheme(Themes.Syntax s) {
        KEYWORD = s.keyword; STRING = s.string; COMMENT = s.comment;
        NUMBER = s.number; TYPE = s.type; METHOD = s.method;
    }

    /** Marker subclass so we only ever remove our own spans. */
    private static final class Span extends ForegroundColorSpan {
        Span(int c) { super(c); }
    }

    private static final Set<String> KW = new HashSet<String>(Arrays.asList(
        "abstract", "boolean", "break", "byte", "case", "catch", "char", "class", "continue",
        "default", "do", "double", "else", "extends", "final", "finally", "float", "for", "if",
        "implements", "import", "instanceof", "int", "interface", "long", "native", "new",
        "package", "private", "protected", "public", "return", "short", "static", "super",
        "switch", "synchronized", "this", "throw", "throws", "try", "void", "volatile",
        "while", "true", "false", "null", "assert", "strictfp"));

    public static final int MAX_CHARS = 120000;
    /** Up to this many chars the whole file is coloured in one pass; bigger files are coloured window by window. */
    public static final int FULL_LIMIT = 40000;

    public static void apply(Editable e) {
        Span[] old = e.getSpans(0, e.length(), Span.class);
        for (int k = 0; k < old.length; k++) e.removeSpan(old[k]);
        String t = e.toString();
        scan(e, t, 0, t.length());
    }

    /**
     * Colours only the lines that touch [from, to) - used for big files (4000+ lines) so typing and scrolling
     * stay smooth. Spans of that window are replaced; spans elsewhere are kept (the text there did not change).
     * A block comment that started above the window is recognised.
     */
    public static void applyRange(Editable e, int from, int to) {
        int n = e.length();
        if (n == 0) return;
        from = Math.max(0, Math.min(from, n));
        to = Math.max(from, Math.min(to, n));
        String t = e.toString();
        int a = from;
        while (a > 0 && t.charAt(a - 1) != '\n') a--;
        int b = to;
        while (b < n && t.charAt(b) != '\n') b++;
        Span[] old = e.getSpans(a, b, Span.class);
        for (int k = 0; k < old.length; k++) e.removeSpan(old[k]);
        int start = a;
        int open = t.lastIndexOf("/*", a);
        if (open >= 0 && open < a && t.lastIndexOf("*/", a) < open) {   // window starts inside a block comment
            int close = t.indexOf("*/", a);
            int end = close < 0 ? n : close + 2;
            mark(e, a, Math.min(end, n), COMMENT);
            start = Math.min(end, n);
        }
        if (start < b) scan(e, t, start, b);
    }

    private static void scan(Editable e, String t, int i, int end) {
        int n = t.length();
        while (i < end) {
            char c = t.charAt(i);
            if (c == '/' && i + 1 < n && t.charAt(i + 1) == '/') {
                int j = t.indexOf('\n', i);
                if (j < 0) j = n;
                mark(e, i, j, COMMENT);
                i = j;
            } else if (c == '/' && i + 1 < n && t.charAt(i + 1) == '*') {
                int j = t.indexOf("*/", i + 2);
                j = (j < 0) ? n : j + 2;
                mark(e, i, j, COMMENT);
                i = j;
            } else if (c == '"' || c == '\'') {
                int j = i + 1;
                while (j < n) {
                    char d = t.charAt(j);
                    if (d == '\\') { j += 2; continue; }
                    if (d == c) { j++; break; }
                    if (d == '\n') break;
                    j++;
                }
                if (j > n) j = n;
                mark(e, i, j, STRING);
                i = j;
            } else if (c >= '0' && c <= '9') {
                int j = i + 1;
                while (j < n && (Character.isLetterOrDigit(t.charAt(j)) || t.charAt(j) == '.')) j++;
                mark(e, i, j, NUMBER);
                i = j;
            } else if (Character.isJavaIdentifierStart(c)) {
                int j = i + 1;
                while (j < n && Character.isJavaIdentifierPart(t.charAt(j))) j++;
                String w = t.substring(i, j);
                if (KW.contains(w)) {
                    mark(e, i, j, KEYWORD);
                } else if (Character.isUpperCase(w.charAt(0)) && w.length() > 1) {
                    mark(e, i, j, TYPE);
                } else {
                    int k = j;
                    while (k < n && t.charAt(k) == ' ') k++;
                    if (k < n && t.charAt(k) == '(') mark(e, i, j, METHOD);
                }
                i = j;
            } else {
                i++;
            }
        }
    }

    private static void mark(Editable e, int s, int en, int color) {
        if (en > e.length()) en = e.length();
        if (s >= en) return;
        e.setSpan(new Span(color), s, en, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
    }
}
