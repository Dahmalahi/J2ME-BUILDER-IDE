package com.dashers.j2mebuilderide.ui;

import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Build console that "types" its lines like a terminal. Lines (and small
 * Runnable actions that must run once everything before them has been
 * printed) are queued with add()/addAction() and drained on the UI thread.
 * With animation off, lines appear instantly.
 */
public class ConsoleLog {

    private static final class Entry {
        String text;
        int color;
        Runnable action;
    }

    private final TextView tv;
    private final ScrollView scroll;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final SpannableStringBuilder shown = new SpannableStringBuilder();
    private final ArrayList<Entry> queue = new ArrayList<Entry>();
    private Entry cur;
    private int pos;
    private boolean running;
    private boolean animate = true;
    private int generation;
    private long lastRender;
    /** The log keeps the last ~90k chars only: setText() re-lays out the whole text, so an endless log gets slower. */
    private static final int MAX_CHARS = 90000;

    public ConsoleLog(TextView tv, ScrollView scroll) {
        this.tv = tv;
        this.scroll = scroll;
    }

    public void setAnimate(boolean on) { animate = on; }

    public boolean isBusy() { return running; }

    /** Drops everything, shown or queued. */
    public void clear() {
        generation++;
        handler.removeCallbacksAndMessages(null);
        queue.clear();
        cur = null;
        pos = 0;
        running = false;
        shown.clear();
        render(false);
    }

    /** Shows a single block of text immediately (no typing). */
    public void setInstant(String text, int color) {
        clear();
        append(text + "\n", color);
        render(false);
    }

    public void add(String text, int color) {
        Entry e = new Entry();
        e.text = text;
        e.color = color;
        queue.add(e);
        kick();
    }

    /** Runs `r` on the UI thread after every earlier line has been printed. */
    public void addAction(Runnable r) {
        Entry e = new Entry();
        e.action = r;
        queue.add(e);
        kick();
    }

    private void kick() {
        if (running) return;
        running = true;
        final int gen = generation;
        handler.post(new Runnable() {
            public void run() {
                if (gen == generation) step(gen);
            }
        });
    }

    private void step(final int gen) {
        if (gen != generation) return;
        if (cur == null) {
            if (queue.isEmpty()) {
                running = false;
                render(false);
                return;
            }
            cur = queue.remove(0);
            pos = 0;
            if (cur.action != null) {
                Runnable a = cur.action;
                cur = null;
                a.run();
                handler.post(new Runnable() {
                    public void run() { step(gen); }
                });
                return;
            }
        }
        long delay;
        if (!animate || queue.size() > 150) {   // huge backlog: no typing effect, print whole lines
            append(cur.text + "\n", cur.color);
            cur = null;
            delay = 0;
        } else {
            // faster when many lines are waiting, so long logs never drag
            int backlog = queue.size();
            int chunk = backlog > 12 ? 8 : (backlog > 5 ? 4 : 2);
            int end = Math.min(cur.text.length(), pos + chunk);
            append(cur.text.substring(pos, end), cur.color);
            pos = end;
            if (pos >= cur.text.length()) {
                append("\n", cur.color);
                cur = null;
                delay = backlog > 12 ? 20 : 90;
            } else {
                delay = 14;
            }
        }
        render(true);
        handler.postDelayed(new Runnable() {
            public void run() { step(gen); }
        }, delay);
    }

    private void append(String s, int color) {
        int a = shown.length();
        shown.append(s);
        shown.setSpan(new ForegroundColorSpan(color), a, shown.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        if (shown.length() > MAX_CHARS) {
            int cut = shown.length() - (MAX_CHARS * 3 / 4);
            int nl = shown.toString().indexOf('\n', cut);
            shown.delete(0, nl < 0 ? cut : nl + 1);
        }
    }

    private void render(boolean cursor) {
        if (cursor) {
            long now = SystemClock.uptimeMillis();
            if (now - lastRender < 45) return;   // typing steps: at most ~20 redraws a second
            lastRender = now;
            int a = shown.length();
            shown.append("_");
            shown.setSpan(new ForegroundColorSpan(Ui.MUTED), a, shown.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            tv.setText(shown);          // TextView keeps its own copy, so the cursor can be removed again
            shown.delete(a, shown.length());
        } else {
            tv.setText(shown);
        }
        scroll.post(new Runnable() {
            public void run() { scroll.fullScroll(ScrollView.FOCUS_DOWN); }
        });
    }
}
