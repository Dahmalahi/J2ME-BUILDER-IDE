package com.dashers.j2mebuilderide.ui;

import android.app.Activity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.dashers.j2mebuilderide.R;

/**
 * Color Palette screen: pick a colour (hex, sliders, palette or from an image) and get ready-to-use J2ME code
 * to copy, or insert straight into the code editor.
 */
public final class ColorPaletteScreen {
    private final ToolHost host;
    private final Activity a;

    public ColorPaletteScreen(ToolHost host) {
        this.host = host;
        this.a = host.activity();
    }

    public View build() {
        LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);

        // top bar
        LinearLayout bar = new LinearLayout(a);
        bar.setGravity(android.view.Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(Ui.SURFACE);
        bar.setPadding(Ui.dp(4), Ui.dp(6), Ui.dp(8), Ui.dp(6));
        bar.setElevation(Ui.dp(2));
        ImageView back = Ui.iconButton(a, R.drawable.ic_arrow_back, Ui.TEXT, new View.OnClickListener() {
            public void onClick(View v) { host.exit(); }
        });
        bar.addView(back, Ui.lp(Ui.dp(44), Ui.dp(44)));
        LinearLayout titles = new LinearLayout(a);
        titles.setOrientation(LinearLayout.VERTICAL);
        TextView t = Ui.label(a, "Color Palette", 17, Ui.TEXT, true);
        t.setSingleLine(true);
        titles.addView(t);
        TextView s = Ui.label(a, host.canInsert() ? "Copy or insert color code" : "Copy color code", 12, Ui.MUTED, false);
        s.setSingleLine(true);
        titles.addView(s);
        bar.addView(titles, Ui.lpWeight(0, Ui.WRAP, 1));
        root.addView(bar, Ui.lp(Ui.MATCH, Ui.WRAP));

        // body
        ScrollView sv = new ScrollView(a);
        sv.setVerticalScrollBarEnabled(false);
        sv.setFillViewport(true);
        LinearLayout body = new LinearLayout(a);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(Ui.dp(16), Ui.dp(4), Ui.dp(16), Ui.dp(40));
        sv.addView(body, new ScrollView.LayoutParams(Ui.MATCH, Ui.WRAP));
        root.addView(sv, Ui.lpWeight(Ui.MATCH, 0, 1));

        final ColorTool[] tool = new ColorTool[1];
        ColorTool.Actions actions = new ColorTool.Actions() {
            public void copy(String text) { host.copy(text); host.toast("Copied: " + text); }
            public boolean canInsert() { return host.canInsert(); }
            public void insert(String text) { host.insertIntoEditor(text); }
            public void pickFromImage() {
                ImageColorPicker.show(host, new ImageColorPicker.Result() {
                    public void onColor(int argb) { tool[0].setArgb(argb | 0xFF000000); }
                });
            }
        };
        tool[0] = new ColorTool(a, 0xFF33B5E5, false, true, actions, null);
        body.addView(tool[0].getView(), Ui.lp(Ui.MATCH, Ui.WRAP));
        return root;
    }
}
