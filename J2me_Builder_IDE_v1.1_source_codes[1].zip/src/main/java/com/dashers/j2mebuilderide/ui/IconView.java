package com.dashers.j2mebuilderide.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;

/** Tiny vector icons drawn with Canvas, so there are no drawable files
 *  or font glyphs that can go missing on a device. */
public class IconView extends View {
    public static final int BACK = 0, MORE = 1, PLUS = 2, PLAY = 3, SAVE = 4, UP = 5, DOWN = 6, FOLDER = 7;

    private final int kind;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();

    public IconView(Context c, int kind, int color) {
        super(c);
        this.kind = kind;
        p.setColor(color);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeJoin(Paint.Join.ROUND);
        setBackground(Ui.ripple(Ui.circle(0x00000000)));
        setClickable(true);
    }

    public void setColor(int color) {
        p.setColor(color);
        invalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        float cx = w / 2f, cy = h / 2f, u = Math.min(w, h) / 24f;
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2.2f * u);
        path.reset();
        switch (kind) {
            case BACK:
                c.drawLine(cx + 5 * u, cy, cx - 6 * u, cy, p);
                c.drawLine(cx - 6 * u, cy, cx - 0.5f * u, cy - 5.5f * u, p);
                c.drawLine(cx - 6 * u, cy, cx - 0.5f * u, cy + 5.5f * u, p);
                break;
            case MORE:
                p.setStyle(Paint.Style.FILL);
                c.drawCircle(cx, cy - 6 * u, 2f * u, p);
                c.drawCircle(cx, cy, 2f * u, p);
                c.drawCircle(cx, cy + 6 * u, 2f * u, p);
                break;
            case PLUS:
                c.drawLine(cx - 6 * u, cy, cx + 6 * u, cy, p);
                c.drawLine(cx, cy - 6 * u, cx, cy + 6 * u, p);
                break;
            case PLAY:
                p.setStyle(Paint.Style.FILL);
                path.moveTo(cx - 4 * u, cy - 6 * u);
                path.lineTo(cx + 6 * u, cy);
                path.lineTo(cx - 4 * u, cy + 6 * u);
                path.close();
                c.drawPath(path, p);
                break;
            case SAVE:
                c.drawRoundRect(cx - 6.5f * u, cy - 6.5f * u, cx + 6.5f * u, cy + 6.5f * u, 2 * u, 2 * u, p);
                c.drawLine(cx - 3 * u, cy - 6.5f * u, cx - 3 * u, cy - 2.5f * u, p);
                c.drawLine(cx + 3 * u, cy - 2.5f * u, cx - 3 * u, cy - 2.5f * u, p);
                c.drawLine(cx - 3.5f * u, cy + 6.5f * u, cx - 3.5f * u, cy + 2.5f * u, p);
                c.drawLine(cx + 3.5f * u, cy + 2.5f * u, cx - 3.5f * u, cy + 2.5f * u, p);
                break;
            case UP:
                c.drawLine(cx - 5 * u, cy + 2.5f * u, cx, cy - 2.5f * u, p);
                c.drawLine(cx + 5 * u, cy + 2.5f * u, cx, cy - 2.5f * u, p);
                break;
            case DOWN:
                c.drawLine(cx - 5 * u, cy - 2.5f * u, cx, cy + 2.5f * u, p);
                c.drawLine(cx + 5 * u, cy - 2.5f * u, cx, cy + 2.5f * u, p);
                break;
            default:
                c.drawRoundRect(cx - 8 * u, cy - 5.5f * u, cx + 8 * u, cy + 6.5f * u, 2.5f * u, 2.5f * u, p);
                c.drawLine(cx - 8 * u, cy - 2 * u, cx + 8 * u, cy - 2 * u, p);
                break;
        }
    }
}
