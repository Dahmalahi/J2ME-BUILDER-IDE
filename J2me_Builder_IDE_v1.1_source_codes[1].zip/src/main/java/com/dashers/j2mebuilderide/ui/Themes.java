package com.dashers.j2mebuilderide.ui;

/**
 * App-wide colour themes. Each theme styles the whole app (backgrounds,
 * cards, text, accent) and also carries a matching code-editor palette.
 * The editor palette can be overridden separately in Settings.
 */
public final class Themes {
    private Themes() {}

    /** One complete theme. */
    public static final class Theme {
        public final String id, name;
        public final boolean dark;
        public final int bg, editor, surface, surface2, stroke, text, muted, accent, green, red, amber;

        Theme(String id, String name, boolean dark, int bg, int editor, int surface, int surface2,
              int stroke, int text, int muted, int accent, int green, int red, int amber) {
            this.id = id; this.name = name; this.dark = dark;
            this.bg = bg; this.editor = editor; this.surface = surface; this.surface2 = surface2;
            this.stroke = stroke; this.text = text; this.muted = muted; this.accent = accent;
            this.green = green; this.red = red; this.amber = amber;
        }
    }

    /** Code-editor colour scheme (background + syntax colours). */
    public static final class Syntax {
        public final String id, name;
        public final boolean dark;
        public final int bg, text, keyword, string, comment, number, type, method;

        Syntax(String id, String name, boolean dark, int bg, int text, int keyword, int string,
               int comment, int number, int type, int method) {
            this.id = id; this.name = name; this.dark = dark; this.bg = bg; this.text = text;
            this.keyword = keyword; this.string = string; this.comment = comment;
            this.number = number; this.type = type; this.method = method;
        }
    }

    public static final String SYNTAX_AUTO = "auto";

    public static final Theme[] ALL = {
        new Theme("midnight", "Midnight", true,
                0xFF0D1015, 0xFF11141A, 0xFF171B23, 0xFF202632, 0xFF2B3240, 0xFFE8EAEE, 0xFF8C94A5,
                0xFF4C8DFF, 0xFF3DDC84, 0xFFFF5D6E, 0xFFFFB84D),
        new Theme("light", "Daylight", false,
                0xFFF3F5F9, 0xFFFFFFFF, 0xFFFFFFFF, 0xFFEBEEF4, 0xFFD8DDE8, 0xFF1B1F27, 0xFF667085,
                0xFF2F6BFF, 0xFF168A4E, 0xFFD63446, 0xFFB86E00),
        new Theme("amoled", "AMOLED Black", true,
                0xFF000000, 0xFF000000, 0xFF0B0B0D, 0xFF16161A, 0xFF24242B, 0xFFEDEDF0, 0xFF8A8A94,
                0xFF3EA6FF, 0xFF3DDC84, 0xFFFF5D6E, 0xFFFFB84D),
        new Theme("dracula", "Dracula", true,
                0xFF1E1F29, 0xFF282A36, 0xFF2B2D3B, 0xFF343746, 0xFF44475A, 0xFFF8F8F2, 0xFF9AA0C0,
                0xFFBD93F9, 0xFF50FA7B, 0xFFFF5555, 0xFFFFB86C),
        new Theme("ocean", "Ocean", true,
                0xFF08141C, 0xFF0B1C27, 0xFF0F222F, 0xFF16303F, 0xFF1F3F50, 0xFFE3F1F7, 0xFF7FA3B5,
                0xFF2EC4E6, 0xFF3DDC9A, 0xFFFF6B7A, 0xFFFFC857),
        new Theme("forest", "Forest", true,
                0xFF0C1410, 0xFF101A15, 0xFF15211A, 0xFF1D2D24, 0xFF29402F, 0xFFE4F0E7, 0xFF86A290,
                0xFF4CD27A, 0xFF4CD27A, 0xFFFF6B6B, 0xFFE8B84A),
        new Theme("sunset", "Sunset", true,
                0xFF1A1014, 0xFF211318, 0xFF2A171D, 0xFF371F27, 0xFF4A2B35, 0xFFF6E9EC, 0xFFB394A0,
                0xFFFF7A59, 0xFF6BD68A, 0xFFFF5D6E, 0xFFFFB84D),
        new Theme("solar", "Solarized Light", false,
                0xFFFDF6E3, 0xFFFDF6E3, 0xFFFFFBEF, 0xFFEEE8D5, 0xFFDDD6C0, 0xFF3B4A50, 0xFF7B8A8C,
                0xFF268BD2, 0xFF5E9900, 0xFFDC322F, 0xFFB58900),
        new Theme("rose", "Rose Light", false,
                0xFFFBF3F5, 0xFFFFFFFF, 0xFFFFFFFF, 0xFFF6E7EB, 0xFFEBD3DA, 0xFF2B1E22, 0xFF8B6F78,
                0xFFE0457B, 0xFF1F9A5A, 0xFFD63446, 0xFFB86E00),
    };

    public static final Syntax[] SYNTAX = {
        new Syntax("material", "Material", true, 0xFF263238, 0xFFEEFFFF,
                0xFFC792EA, 0xFFC3E88D, 0xFF546E7A, 0xFFF78C6C, 0xFF82AAFF, 0xFFFFCB6B),
        new Syntax("dracula", "Dracula", true, 0xFF282A36, 0xFFF8F8F2,
                0xFFFF79C6, 0xFFF1FA8C, 0xFF6272A4, 0xFFBD93F9, 0xFF8BE9FD, 0xFF50FA7B),
        new Syntax("monokai", "Monokai", true, 0xFF272822, 0xFFF8F8F2,
                0xFFF92672, 0xFFE6DB74, 0xFF75715E, 0xFFAE81FF, 0xFF66D9EF, 0xFFA6E22E),
        new Syntax("solardark", "Solarized Dark", true, 0xFF002B36, 0xFF93A1A1,
                0xFF859900, 0xFF2AA198, 0xFF586E75, 0xFFD33682, 0xFF268BD2, 0xFFB58900),
        new Syntax("github", "GitHub Light", false, 0xFFFFFFFF, 0xFF24292F,
                0xFFCF222E, 0xFF0A3069, 0xFF6E7781, 0xFF0550AE, 0xFF8250DF, 0xFF953800),
        new Syntax("solarlight", "Solarized Light", false, 0xFFFDF6E3, 0xFF586E75,
                0xFF859900, 0xFF2AA198, 0xFF93A1A1, 0xFFD33682, 0xFF268BD2, 0xFFB58900),
    };

    public static Theme theme(String id) {
        for (int i = 0; i < ALL.length; i++) if (ALL[i].id.equals(id)) return ALL[i];
        return ALL[0];
    }

    /** Returns null for "auto" / unknown ids (editor then follows the app theme). */
    public static Syntax syntax(String id) {
        for (int i = 0; i < SYNTAX.length; i++) if (SYNTAX[i].id.equals(id)) return SYNTAX[i];
        return null;
    }
}
