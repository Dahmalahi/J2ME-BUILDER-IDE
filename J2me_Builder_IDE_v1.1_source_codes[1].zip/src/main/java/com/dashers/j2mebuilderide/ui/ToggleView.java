package com.dashers.j2mebuilderide.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

/** Material-style on/off switch drawn by hand (no tint APIs, works on API 21+). */
public class ToggleView extends View {

    public interface Listener { void onChanged(boolean on); }

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();
    private boolean on;
    private float pos;          // 0 = off, 1 = on (animated)
    private Listener listener;

    public ToggleView(Context c, boolean initial, Listener l) {
        super(c);
        on = initial;
        pos = initial ? 1f : 0f;
        listener = l;
        setClickable(true);
        setOnClickListener(new OnClickListener() {
            public void onClick(View v) { setChecked(!on, true); }
        });
    }

    public boolean isChecked() { return on; }

    public void setChecked(boolean v, boolean notify) {
        if (on == v) return;
        on = v;
        startAnim();
        if (notify && listener != null) listener.onChanged(on);
    }

    private void startAnim() {
        postOnAnimation(new Runnable() {
            public void run() {
                float target = on ? 1f : 0f;
                float d = target - pos;
                if (Math.abs(d) < 0.08f) { pos = target; invalidate(); return; }
                pos += d * 0.35f;
                invalidate();
                postOnAnimation(this);
            }
        });
    }

    @Override
    protected void onMeasure(int w, int h) {
        setMeasuredDimension(Ui.dp(52), Ui.dp(32));
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        float trackH = Ui.dp(26);
        float top = (h - trackH) / 2f;
        r.set(Ui.dp(2), top, w - Ui.dp(2), top + trackH);
        p.setStyle(Paint.Style.FILL);
        p.setColor(blend(Ui.dark ? 0xFF3A4254 : 0xFFC4CAD6, Ui.ACCENT, pos));
        c.drawRoundRect(r, trackH / 2f, trackH / 2f, p);

        float rad = Ui.dp(10) + Ui.dp(1.5f) * pos;
        float cxOff = r.left + trackH / 2f;
        float cxOn = r.right - trackH / 2f;
        float cx = cxOff + (cxOn - cxOff) * pos;
        p.setColor(0xFFFFFFFF);
        c.drawCircle(cx, h / 2f, rad, p);
    }

    private static int blend(int a, int b, float t) {
        int ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
        int br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
        int rr = (int) (ar + (br - ar) * t), rg = (int) (ag + (bg - ag) * t), rb = (int) (ab + (bb - ab) * t);
        return 0xFF000000 | (rr << 16) | (rg << 8) | rb;
    }
}
