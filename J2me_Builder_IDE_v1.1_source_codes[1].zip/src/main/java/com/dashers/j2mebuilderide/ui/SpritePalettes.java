package com.dashers.j2mebuilderide.ui;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;

/** Built-in and user-made colour palettes for the Sprite Editor (custom ones are kept in SharedPreferences). */
public final class SpritePalettes {
    public static final class Palette {
        public String name;
        public int[] colors;
        public final boolean builtin;
        Palette(String name, int[] colors, boolean builtin) { this.name = name; this.colors = colors; this.builtin = builtin; }
    }

    private static final String PREF = "sprite_editor", KEY = "palettes", SEL = "palette_sel";
    public static final int MAX_COLORS = 256;

    private final SharedPreferences sp;
    public final ArrayList<Palette> all = new ArrayList<Palette>();
    public int selected;

    public SpritePalettes(Context c) {
        sp = c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        load();
    }

    private static int[] rgb(int... v) {
        int[] o = new int[v.length];
        for (int i = 0; i < v.length; i++) o[i] = 0xFF000000 | v[i];
        return o;
    }

    private void load() {
        all.clear();
        all.add(new Palette("Default", ColorTool.PALETTE.clone(), true));
        all.add(new Palette("PICO-8", rgb(0x000000, 0x1D2B53, 0x7E2553, 0x008751, 0xAB5236, 0x5F574F, 0xC2C3C7, 0xFFF1E8,
                0xFF004D, 0xFFA300, 0xFFEC27, 0x00E436, 0x29ADFF, 0x83769C, 0xFF77A8, 0xFFCCAA), true));
        all.add(new Palette("Sweetie 16", rgb(0x1A1C2C, 0x5D275D, 0xB13E53, 0xEF7D57, 0xFFCD75, 0xA7F070, 0x38B764, 0x257179,
                0x29366F, 0x3B5DC9, 0x41A6F6, 0x73EFF7, 0xF4F4F4, 0x94B0C2, 0x566C86, 0x333C57), true));
        all.add(new Palette("Game Boy", rgb(0x0F380F, 0x306230, 0x8BAC0F, 0x9BBC0F), true));
        all.add(new Palette("Nokia LCD", rgb(0x43523D, 0xC7F0D8), true));
        int[] gray = new int[8];
        for (int i = 0; i < gray.length; i++) { int g = i * 255 / (gray.length - 1); gray[i] = 0xFF000000 | (g << 16) | (g << 8) | g; }
        all.add(new Palette("Grayscale 8", gray, true));
        String raw = sp.getString(KEY, "");
        String[] lines = raw.split("\n");
        for (int i = 0; i < lines.length; i++) {
            int tab = lines[i].indexOf('\t');
            if (tab <= 0) continue;
            String[] parts = lines[i].substring(tab + 1).split(",");
            int[] tmp = new int[parts.length];
            int n = 0;
            for (int j = 0; j < parts.length; j++) {
                try { tmp[n] = (int) Long.parseLong(parts[j].trim(), 16); n++; } catch (NumberFormatException x) { /* skip */ }
            }
            int[] cols = new int[n];
            System.arraycopy(tmp, 0, cols, 0, n);
            all.add(new Palette(lines[i].substring(0, tab), cols, false));
        }
        selected = Math.max(0, Math.min(all.size() - 1, sp.getInt(SEL, 0)));
    }

    public void save() {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < all.size(); i++) {
            Palette p = all.get(i);
            if (p.builtin) continue;
            sb.append(clean(p.name)).append('\t');
            for (int j = 0; j < p.colors.length; j++) {
                if (j > 0) sb.append(',');
                sb.append(Integer.toHexString(p.colors[j]));
            }
            sb.append('\n');
        }
        sp.edit().putString(KEY, sb.toString()).putInt(SEL, selected).commit();
    }

    public Palette current() { return all.get(Math.max(0, Math.min(all.size() - 1, selected))); }

    public void select(int i) {
        selected = Math.max(0, Math.min(all.size() - 1, i));
        save();
    }

    public Palette addCustom(String name, int[] colors) {
        Palette p = new Palette(clean(name), colors, false);
        all.add(p);
        selected = all.size() - 1;
        save();
        return p;
    }

    public void remove(Palette p) {
        int i = all.indexOf(p);
        if (i < 0 || p.builtin) return;
        all.remove(i);
        if (selected >= all.size()) selected = all.size() - 1;
        if (selected < 0) selected = 0;
        save();
    }

    public void rename(Palette p, String name) {
        if (p.builtin) return;
        p.name = clean(name);
        save();
    }

    public boolean addColor(Palette p, int argb) {
        if (p.builtin || p.colors.length >= MAX_COLORS) return false;
        for (int i = 0; i < p.colors.length; i++) if (p.colors[i] == argb) return false;
        int[] n = new int[p.colors.length + 1];
        System.arraycopy(p.colors, 0, n, 0, p.colors.length);
        n[p.colors.length] = argb;
        p.colors = n;
        save();
        return true;
    }

    public void removeColorAt(Palette p, int index) {
        if (p.builtin || index < 0 || index >= p.colors.length) return;
        int[] n = new int[p.colors.length - 1];
        System.arraycopy(p.colors, 0, n, 0, index);
        System.arraycopy(p.colors, index + 1, n, index, p.colors.length - index - 1);
        p.colors = n;
        save();
    }

    public String uniqueName(String base) {
        String b = clean(base);
        if (b.length() == 0) b = "My palette";
        String name = b;
        for (int k = 2; exists(name); k++) name = b + " " + k;
        return name;
    }

    private boolean exists(String name) {
        for (int i = 0; i < all.size(); i++) if (all.get(i).name.equalsIgnoreCase(name)) return true;
        return false;
    }

    static String clean(String n) {
        String s = n == null ? "" : n.replace('\t', ' ').replace('\n', ' ').replace('\r', ' ').trim();
        return s.length() > 24 ? s.substring(0, 24) : s;
    }

    /** J2ME int array for the palette, e.g. "int[] PALETTE = {0xFF0000, 0x00FF00};". */
    public static String code(Palette p) {
        boolean alpha = false;
        for (int i = 0; i < p.colors.length; i++) if ((p.colors[i] >>> 24) != 255) alpha = true;
        StringBuffer sb = new StringBuffer("int[] PALETTE = {");
        for (int i = 0; i < p.colors.length; i++) {
            if (i > 0) sb.append(", ");
            if (i % 8 == 0 && i > 0) sb.append("\n    ");
            String h = Integer.toHexString(alpha ? p.colors[i] : (p.colors[i] & 0xFFFFFF)).toUpperCase();
            int len = alpha ? 8 : 6;
            while (h.length() < len) h = "0" + h;
            sb.append("0x").append(h);
        }
        return sb.append("};").toString();
    }
}
