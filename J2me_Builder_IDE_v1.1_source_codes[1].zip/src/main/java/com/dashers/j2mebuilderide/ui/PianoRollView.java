package com.dashers.j2mebuilderide.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

import com.dashers.j2mebuilderide.ide.SeqModel;

import java.util.ArrayList;

/**
 * FL-Studio style piano roll: notes on a tick grid with a key column. Draw / Erase / Pan tools.
 * Draw: tap an empty cell to add a note (drag right to make it longer), drag a note to move it, drag its right end to resize.
 * Two fingers always pan and pinch-zoom.
 */
public final class PianoRollView extends View {
    public static final int T_DRAW = 0, T_ERASE = 1, T_PAN = 2;
    private static final int TOP_PITCH = 107, LOW_PITCH = 24;

    public interface Listener {
        void onChanged();
        void onSelect(SeqModel.Note n);
        /** Play a short tone so the note can be heard while editing. */
        void onAudition(int pitch, boolean drum);
    }

    public int tool = T_DRAW;
    public int gridTicks = SeqModel.PPQ / 4;
    public int defaultVel = 100;
    public int scaleRoot = 0, scaleType = 0;

    private SeqModel.Project proj;
    private int cur;
    private SeqModel.Note sel;
    private Listener listener;
    private int playTick = -1;

    private float pxPerTick;
    private float scrollX;               // ticks
    private float scrollRow;             // rows
    private final float rowH, keyW;

    private final Paint pFill = new Paint();
    private final Paint pLine = new Paint();
    private final Paint pText = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rf = new RectF();
    private final ScaleGestureDetector sgd;

    // gesture
    private int mode;                    // 0 none, 1 move, 2 resize, 3 erase, 4 pan
    private int grabOffset;
    private float lastX, lastY, lastFx, lastFy;
    private int lastAuditPitch = -1;
    private boolean multi, changedInGesture;
    private int lastPtr;

    public PianoRollView(Context c) {
        super(c);
        rowH = Ui.dp(22);
        keyW = Ui.dp(52);
        pxPerTick = Ui.dp(64) / (float) SeqModel.PPQ;
        pLine.setStyle(Paint.Style.STROKE);
        pText.setTextSize(Ui.dp(10));
        sgd = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScale(ScaleGestureDetector d) {
                float fx = d.getFocusX() - keyW;
                float focusTick = scrollX + fx / pxPerTick;
                pxPerTick = Math.max(Ui.dp(8) / (float) SeqModel.PPQ, Math.min(Ui.dp(400) / (float) SeqModel.PPQ, pxPerTick * d.getScaleFactor()));
                scrollX = focusTick - fx / pxPerTick;
                clampScroll();
                invalidate();
                return true;
            }
        });
    }

    public void setListener(Listener l) { listener = l; }

    public void setProject(SeqModel.Project p) {
        proj = p;
        cur = 0;
        sel = null;
        scrollX = 0;
        centerRows();
        invalidate();
    }

    public void setTrack(int i) {
        if (proj == null || proj.tracks.isEmpty()) return;
        cur = Math.max(0, Math.min(proj.tracks.size() - 1, i));
        sel = null;
        if (listener != null) listener.onSelect(null);
        centerRows();
        invalidate();
    }

    public int track() { return cur; }

    private SeqModel.Track track0() { return proj != null && cur < proj.tracks.size() ? proj.tracks.get(cur) : null; }

    public SeqModel.Note selected() { return sel; }

    public void select(SeqModel.Note n) {
        sel = n;
        if (listener != null) listener.onSelect(n);
        invalidate();
    }

    public void setPlayTick(int t) {
        playTick = t;
        invalidate();
    }

    public void refresh() { invalidate(); }

    // ---- rows ----

    private boolean drumTrack() { SeqModel.Track t = track0(); return t != null && t.drum; }

    private int rowCount() { return drumTrack() ? SeqModel.DRUM_ROWS.length : TOP_PITCH - LOW_PITCH + 1; }

    private int pitchOfRow(int r) { return drumTrack() ? SeqModel.DRUM_ROWS[Math.max(0, Math.min(SeqModel.DRUM_ROWS.length - 1, r))] : TOP_PITCH - r; }

    private int rowOfPitch(int pitch) { return drumTrack() ? SeqModel.drumRow(pitch) : TOP_PITCH - pitch; }

    private void centerRows() {
        if (getHeight() == 0) { scrollRow = -1; return; }
        if (drumTrack()) { scrollRow = 0; return; }
        SeqModel.Track t = track0();
        int pitch = 60;
        if (t != null && !t.notes.isEmpty()) {
            long sum = 0;
            for (int i = 0; i < t.notes.size(); i++) sum += t.notes.get(i).pitch;
            pitch = (int) (sum / t.notes.size());
        }
        scrollRow = rowOfPitch(pitch) - getHeight() / rowH / 2f;
        clampScroll();
    }

    private void clampScroll() {
        float visRows = getHeight() / rowH;
        scrollRow = Math.max(0, Math.min(Math.max(0, rowCount() - visRows), scrollRow));
        float maxX = proj == null ? 0 : proj.lengthTicks() + SeqModel.PPQ * 4 - (getWidth() - keyW) / pxPerTick;
        scrollX = Math.max(0, Math.min(Math.max(0, maxX), scrollX));
    }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        if (scrollRow < 0 || oh == 0) centerRows();
        else clampScroll();
    }

    public void zoom(float f) {
        float focus = scrollX + (getWidth() - keyW) / 2f / pxPerTick;
        pxPerTick = Math.max(Ui.dp(8) / (float) SeqModel.PPQ, Math.min(Ui.dp(400) / (float) SeqModel.PPQ, pxPerTick * f));
        scrollX = focus - (getWidth() - keyW) / 2f / pxPerTick;
        clampScroll();
        invalidate();
    }

    // ---- editing helpers ----

    public void deleteSelected() {
        SeqModel.Track t = track0();
        if (t == null || sel == null) return;
        t.notes.remove(sel);
        select(null);
        if (listener != null) listener.onChanged();
    }

    public void duplicateSelected() {
        SeqModel.Track t = track0();
        if (t == null || sel == null) return;
        SeqModel.Note n = sel.copy();
        n.start = sel.start + sel.len;
        t.notes.add(n);
        proj.fitBars();
        select(n);
        scrollToTick(n.start);
        if (listener != null) listener.onChanged();
    }

    /** Move the selected note, or every note of the track when none is selected. */
    public void transpose(int semis) {
        SeqModel.Track t = track0();
        if (t == null || t.drum) return;
        ArrayList<SeqModel.Note> list = new ArrayList<SeqModel.Note>();
        if (sel != null) list.add(sel); else list.addAll(t.notes);
        for (int i = 0; i < list.size(); i++) {
            SeqModel.Note n = list.get(i);
            n.pitch = Math.max(LOW_PITCH, Math.min(TOP_PITCH, n.pitch + semis));
        }
        if (listener != null) listener.onChanged();
        invalidate();
    }

    /** Snap every note start and length to the grid. */
    public void quantizeAll() {
        SeqModel.Track t = track0();
        if (t == null) return;
        int g = Math.max(1, gridTicks);
        for (int i = 0; i < t.notes.size(); i++) {
            SeqModel.Note n = t.notes.get(i);
            n.start = Math.round(n.start / (float) g) * g;
            n.len = Math.max(g, Math.round(n.len / (float) g) * g);
        }
        proj.fitBars();
        if (listener != null) listener.onChanged();
        invalidate();
    }

    public void clearTrack() {
        SeqModel.Track t = track0();
        if (t == null) return;
        t.notes.clear();
        select(null);
        if (listener != null) listener.onChanged();
    }

    public void scrollToTick(int tick) {
        float vis = (getWidth() - keyW) / pxPerTick;
        if (tick < scrollX || tick > scrollX + vis) scrollX = Math.max(0, tick - vis * 0.1f);
        clampScroll();
        invalidate();
    }

    // ---- drawing ----

    private float xOf(int tick) { return keyW + (tick - scrollX) * pxPerTick; }

    private float yOf(int row) { return (row - scrollRow) * rowH; }

    @Override protected void onDraw(Canvas c) {
        if (proj == null) return;
        int w = getWidth(), h = getHeight();
        boolean drum = drumTrack();
        pFill.setColor(Ui.EDITOR);
        c.drawRect(0, 0, w, h, pFill);
        int rows = rowCount();
        int r0 = Math.max(0, (int) Math.floor(scrollRow)), r1 = Math.min(rows - 1, (int) Math.ceil(scrollRow + h / rowH));

        c.save();
        c.clipRect(keyW, 0, w, h);
        // rows
        for (int r = r0; r <= r1; r++) {
            int p = pitchOfRow(r);
            int shade;
            if (drum) shade = (r & 1) == 0 ? 0x10FFFFFF : 0x00000000;
            else {
                boolean black = SeqModel.isBlack(p);
                shade = black ? 0x28000000 : 0x08FFFFFF;
                if (scaleType != 0 && SeqModel.inScale(p, scaleRoot, scaleType)) shade = black ? 0x22FF9100 : 0x1EFF9100;
            }
            pFill.setColor(shade);
            c.drawRect(keyW, yOf(r), w, yOf(r) + rowH, pFill);
            pFill.setColor(p % 12 == 0 && !drum ? 0x44FFFFFF : 0x14FFFFFF);
            c.drawRect(keyW, yOf(r + 1) - 1, w, yOf(r + 1), pFill);
        }
        // beyond the end of the song
        float endX = xOf(proj.lengthTicks());
        if (endX < w) {
            pFill.setColor(0x44000000);
            c.drawRect(Math.max(keyW, endX), 0, w, h, pFill);
        }
        // vertical grid
        int g = Math.max(1, gridTicks);
        int firstTick = Math.max(0, (int) (scrollX / g) * g);
        for (int t = firstTick; xOf(t) < w; t += g) {
            float x = xOf(t);
            if (x < keyW) continue;
            boolean bar = t % (4 * SeqModel.PPQ) == 0, beat = t % SeqModel.PPQ == 0;
            if (!bar && !beat && g * pxPerTick < Ui.dp(7)) continue;
            pFill.setColor(bar ? 0x66FFFFFF : beat ? 0x33FFFFFF : 0x14FFFFFF);
            c.drawRect(x, 0, x + (bar ? 2 : 1), h, pFill);
            if (bar) {
                pText.setColor(Ui.MUTED);
                c.drawText(String.valueOf(t / (4 * SeqModel.PPQ) + 1), x + Ui.dp(3), Ui.dp(10), pText);
            }
        }
        // other tracks, faded
        for (int ti = 0; ti < proj.tracks.size(); ti++) {
            SeqModel.Track t = proj.tracks.get(ti);
            if (ti == cur || t.drum != drum) continue;
            pFill.setColor((t.color & 0x00FFFFFF) | 0x44000000);
            for (int i = 0; i < t.notes.size(); i++) {
                SeqModel.Note n = t.notes.get(i);
                int r = rowOfPitch(n.pitch);
                if (r < r0 || r > r1) continue;
                float x0 = xOf(n.start), x1 = xOf(n.start + n.len);
                if (x1 < keyW || x0 > w) continue;
                rf.set(x0, yOf(r) + 2, Math.max(x1, x0 + 3), yOf(r) + rowH - 2);
                c.drawRect(rf, pFill);
            }
        }
        // this track's notes
        SeqModel.Track tr = track0();
        if (tr != null) {
            for (int i = 0; i < tr.notes.size(); i++) {
                SeqModel.Note n = tr.notes.get(i);
                int r = rowOfPitch(n.pitch);
                if (r < r0 || r > r1) continue;
                float x0 = xOf(n.start), x1 = xOf(n.start + n.len);
                if (x1 < keyW || x0 > w) continue;
                rf.set(x0 + 1, yOf(r) + 1, Math.max(x1 - 1, x0 + 4), yOf(r) + rowH - 1);
                int alpha = 150 + n.vel * 105 / 127;
                pFill.setColor((tr.color & 0x00FFFFFF) | (alpha << 24));
                c.drawRoundRect(rf, Ui.dp(3), Ui.dp(3), pFill);
                if (n == sel) {
                    pLine.setColor(0xFFFFFFFF);
                    pLine.setStrokeWidth(Ui.dp(1.5f));
                    c.drawRoundRect(rf, Ui.dp(3), Ui.dp(3), pLine);
                }
                if (!drum && rf.width() > Ui.dp(30)) {
                    pText.setColor(0xCC000000);
                    c.drawText(SeqModel.noteName(n.pitch), rf.left + Ui.dp(4), rf.bottom - Ui.dp(6), pText);
                }
            }
        }
        // play position
        if (playTick >= 0) {
            float x = xOf(playTick);
            pFill.setColor(0xFFFF5252);
            c.drawRect(x, 0, x + Ui.dp(2), h, pFill);
        }
        c.restore();

        // key column
        pFill.setColor(Ui.SURFACE);
        c.drawRect(0, 0, keyW, h, pFill);
        for (int r = r0; r <= r1; r++) {
            int p = pitchOfRow(r);
            float y = yOf(r);
            if (drum) {
                pFill.setColor((r & 1) == 0 ? Ui.SURFACE2 : Ui.SURFACE);
                c.drawRect(0, y, keyW, y + rowH, pFill);
                pText.setColor(Ui.TEXT);
                c.drawText(SeqModel.DRUM_NAMES[r], Ui.dp(4), y + rowH - Ui.dp(7), pText);
            } else {
                boolean black = SeqModel.isBlack(p);
                pFill.setColor(black ? 0xFF2B2B2B : 0xFFE8E8E8);
                c.drawRect(0, y, black ? keyW * 0.62f : keyW, y + rowH - 1, pFill);
                if (black) {
                    pFill.setColor(0xFFE8E8E8);
                    c.drawRect(keyW * 0.62f, y, keyW, y + rowH - 1, pFill);
                }
                if (p % 12 == 0) {
                    pText.setColor(0xFF222222);
                    c.drawText(SeqModel.noteName(p), keyW - Ui.dp(24), y + rowH - Ui.dp(7), pText);
                }
            }
        }
    }

    // ---- touch ----

    private SeqModel.Note hit(int tick, int row) {
        SeqModel.Track t = track0();
        if (t == null) return null;
        int pitch = pitchOfRow(row);
        for (int i = t.notes.size() - 1; i >= 0; i--) {
            SeqModel.Note n = t.notes.get(i);
            if (n.pitch == pitch && tick >= n.start && tick < n.start + n.len) return n;
        }
        return null;
    }

    private int snapFloor(int tick) { int g = Math.max(1, gridTicks); return Math.max(0, tick / g * g); }

    private int snapRound(int tick) { int g = Math.max(1, gridTicks); return Math.max(0, Math.round(tick / (float) g) * g); }

    @Override public boolean onTouchEvent(MotionEvent e) {
        if (proj == null) return false;
        getParent().requestDisallowInterceptTouchEvent(true);
        sgd.onTouchEvent(e);
        int n = e.getPointerCount();
        int act = e.getActionMasked();
        if (n >= 2 || sgd.isInProgress()) {
            multi = true;
            mode = 0;
            float fx = 0, fy = 0;
            for (int i = 0; i < n; i++) { fx += e.getX(i); fy += e.getY(i); }
            fx /= n;
            fy /= n;
            if (act == MotionEvent.ACTION_MOVE && lastPtr == n) {
                scrollX -= (fx - lastFx) / pxPerTick;
                scrollRow -= (fy - lastFy) / rowH;
                clampScroll();
                invalidate();
            }
            lastFx = fx;
            lastFy = fy;
            lastPtr = n;
            if (act == MotionEvent.ACTION_UP || act == MotionEvent.ACTION_CANCEL) { multi = false; lastPtr = 0; }
            return true;
        }
        lastPtr = n;
        if (multi) {
            if (act == MotionEvent.ACTION_UP || act == MotionEvent.ACTION_CANCEL) multi = false;
            return true;
        }
        float x = e.getX(), y = e.getY();
        SeqModel.Track t = track0();
        if (t == null) return true;
        int tick = (int) (scrollX + (x - keyW) / pxPerTick);
        int row = (int) Math.floor(y / rowH + scrollRow);
        row = Math.max(0, Math.min(rowCount() - 1, row));

        switch (act) {
            case MotionEvent.ACTION_DOWN: {
                changedInGesture = false;
                lastX = x;
                lastY = y;
                if (x < keyW) {
                    if (listener != null) listener.onAudition(pitchOfRow(row), t.drum);
                    mode = 0;
                    return true;
                }
                if (tool == T_PAN) { mode = 4; return true; }
                SeqModel.Note hn = hit(tick, row);
                if (tool == T_ERASE) {
                    mode = 3;
                    if (hn != null) { t.notes.remove(hn); changedInGesture = true; if (hn == sel) select(null); invalidate(); }
                    return true;
                }
                if (hn != null) {
                    select(hn);
                    float x1 = xOf(hn.start + hn.len);
                    boolean edge = x > x1 - Math.max(Ui.dp(14), (x1 - xOf(hn.start)) * 0.28f);
                    mode = edge ? 2 : 1;
                    grabOffset = tick - hn.start;
                    lastAuditPitch = hn.pitch;
                    if (listener != null) listener.onAudition(hn.pitch, t.drum);
                } else {
                    SeqModel.Note nn = new SeqModel.Note(pitchOfRow(row), snapFloor(tick), Math.max(1, gridTicks), defaultVel);
                    t.notes.add(nn);
                    changedInGesture = true;
                    select(nn);
                    mode = 2;
                    grabOffset = 0;
                    lastAuditPitch = nn.pitch;
                    if (listener != null) listener.onAudition(nn.pitch, t.drum);
                }
                invalidate();
                return true;
            }
            case MotionEvent.ACTION_MOVE: {
                if (mode == 4) {
                    scrollX -= (x - lastX) / pxPerTick;
                    scrollRow -= (y - lastY) / rowH;
                    clampScroll();
                    lastX = x;
                    lastY = y;
                    invalidate();
                } else if (mode == 3) {
                    SeqModel.Note hn = x >= keyW ? hit(tick, row) : null;
                    if (hn != null) { t.notes.remove(hn); changedInGesture = true; if (hn == sel) select(null); invalidate(); }
                } else if (mode == 1 && sel != null) {
                    sel.start = snapRound(tick - grabOffset);
                    int p = pitchOfRow(row);
                    if (p != sel.pitch) {
                        sel.pitch = p;
                        if (p != lastAuditPitch && listener != null) listener.onAudition(p, t.drum);
                        lastAuditPitch = p;
                    }
                    changedInGesture = true;
                    invalidate();
                } else if (mode == 2 && sel != null) {
                    int end = snapRound(tick);
                    sel.len = Math.max(Math.max(1, gridTicks), end - sel.start);
                    changedInGesture = true;
                    invalidate();
                }
                return true;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL: {
                if (changedInGesture) {
                    proj.fitBars();
                    if (listener != null) listener.onChanged();
                }
                mode = 0;
                invalidate();
                return true;
            }
            default: return true;
        }
    }
}
