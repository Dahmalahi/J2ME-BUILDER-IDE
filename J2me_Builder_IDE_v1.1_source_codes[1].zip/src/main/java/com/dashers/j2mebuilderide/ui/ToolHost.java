package com.dashers.j2mebuilderide.ui;

import android.app.Activity;
import android.graphics.Bitmap;

import java.util.Vector;

/** What the Color Palette, Sprite Editor and Audio Studio screens need from the app (implemented by MainActivity). */
public interface ToolHost {
    interface ImageSink { void onImage(Bitmap bmp, String name); }

    interface ImagesSink { void onImages(java.util.List<Bitmap> bitmaps, java.util.List<String> names); }

    /** A file picked on the device, copied into the app's cache so it can be read like a normal file. */
    interface FileSink { void onFile(java.io.File file, String name); }

    Activity activity();

    void toast(String s);

    /** Copy text to the clipboard. */
    void copy(String text);

    /** True when the screen was opened from the code editor, so code can be inserted at the caret. */
    boolean canInsert();

    /** Return to the code editor and insert the text at the caret (copies it when not opened from the editor). */
    void insertIntoEditor(String text);

    boolean hasProject();

    /** Relative paths (inside res/) of the project's images. */
    Vector listImageResources();

    /** Decode a res/ image without premultiplying; null when unreadable. */
    Bitmap loadResBitmap(String rel);

    /** Write a PNG to res/ (or a sprites folder when no project is open). Returns "" on success, else an error. */
    String savePng(String rel, byte[] png);

    /** Human readable location for a saved file, e.g. "res/hero.png". */
    String describeSave(String rel);

    /** Open the system image picker. */
    void pickDeviceImage(ImageSink sink);

    /** Open the system picker so several images can be chosen at once. */
    void pickDeviceImages(ImagesSink sink);

    /** Let the user save a file anywhere (system "save as" screen). */
    void exportToDevice(String fileName, String mime, byte[] data);

    /** Open the system file picker for any of these MIME types (e.g. "audio/*"). */
    void pickDeviceFile(String[] mimeTypes, FileSink sink);

    /** Relative paths (inside res/) of project files with one of these extensions (lower case, no dot). */
    Vector listResourcesByExt(String[] exts);

    /** Bytes of a res/ file; null when unreadable. */
    byte[] readResource(String rel);

    boolean hasMicPermission();

    /** Ask for the microphone permission; the Runnable runs only when it was granted. */
    void requestMicPermission(Runnable onGranted);

    /** Open the old text based MIDI composer. */
    void openTextComposer();

    /** Leave the screen (back to wherever it was opened from). */
    void exit();
}
