package com.dashers.j2mebuilderide.ui;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

import com.google.android.material.button.MaterialButton;

import com.dashers.j2mebuilderide.R;
import com.dashers.j2mebuilderide.ide.AacEncoder;
import com.dashers.j2mebuilderide.ide.AudioBuf;
import com.dashers.j2mebuilderide.ide.AudioDecoder;
import com.dashers.j2mebuilderide.ide.MidiFile;
import com.dashers.j2mebuilderide.ide.MidiIO;
import com.dashers.j2mebuilderide.ide.NoteSynth;
import com.dashers.j2mebuilderide.ide.PcmPlayer;
import com.dashers.j2mebuilderide.ide.PitchTracker;
import com.dashers.j2mebuilderide.ide.SeqModel;
import com.dashers.j2mebuilderide.ide.VoiceRecorder;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Vector;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * Audio Studio: an FL-Studio style piano roll and drum grid with MIDI import / export, a track rack,
 * and an audio workbench (voice recording, import, trim, split, compress, audio to MIDI).
 */
public final class AudioStudioScreen {
    private static final int TAB_ROLL = 0, TAB_RACK = 1, TAB_AUDIO = 2;
    private static final int[] SNAP_TICKS = {480, 240, 120, 60};
    private static final String[] SNAP_NAMES = {"1/4", "1/8", "1/16", "1/32"};
    private static final int[] OUT_RATES = {8000, 11025, 16000, 22050, 44100};
    private static final int[] AAC_KBPS = {24, 32, 64, 96, 128};

    private interface IntCb { void got(int v); }

    private interface StrCb { void got(String s); }

    private final ToolHost host;
    private final Activity a;
    private final Handler handler = new Handler(Looper.getMainLooper());

    // song
    private SeqModel.Project song = SeqModel.newSong();
    private boolean dirty;
    private int tab = TAB_ROLL;
    private final View[] tabViews = new View[3];
    private final ImageView[] navIcons = new ImageView[3];
    private final TextView[] navLabels = new TextView[3];
    private final View[] navBubbles = new View[3];

    // top bar + transport
    private TextView subtitle, bpmPill;
    private ImageView playBtn;
    private MediaPlayer mp;
    private boolean playing, loop, useSynth;
    private final PcmPlayer songPlayer = new PcmPlayer();
    private final PcmPlayer auditPlayer = new PcmPlayer();

    // piano roll tab
    private PianoRollView roll;
    private TextView trackChip, snapPill, barsPill, drawPill, erasePill, panPill, scalePill;
    private View notePanel;
    private TextView noteLabel;
    private SeekBar velBar;
    private boolean velSetting;

    // rack tab
    private LinearLayout rackList;

    // audio tab
    private final ArrayList<AudioBuf.Clip> clips = new ArrayList<AudioBuf.Clip>();
    private int curClip = -1;
    private WaveformView wave;
    private LinearLayout clipRow;
    private TextView audioInfo, estimateText, recBtn, recTime, progName;
    private ProgressBar level;
    private VoiceRecorder recorder;
    private boolean hiFiRec;
    private int recCount;
    private final PcmPlayer clipPlayer = new PcmPlayer();
    private TextView clipPlayBtn;
    private int seekPos = -1;
    private short[] undoPcm;
    private int undoRate, undoClip = -1;
    private int outRate = 11025, outBits = 16, aacKbps = 64;
    private boolean optNormalize = true, optTrimSilence;
    private int sens = 60, minNoteMs = 100, quantIdx = 2, convProgram = 0;
    private TextView convInstr;
    private boolean convCancel;

    public AudioStudioScreen(ToolHost host) {
        this.host = host;
        this.a = host.activity();
    }

    // ------------------------------------------------------------------
    // layout
    // ------------------------------------------------------------------

    public View build() {
        LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);

        LinearLayout bar = new LinearLayout(a);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(Ui.SURFACE);
        bar.setPadding(Ui.dp(4), Ui.dp(6), Ui.dp(4), Ui.dp(6));
        bar.setElevation(Ui.dp(2));
        bar.addView(Ui.iconButton(a, R.drawable.ic_arrow_back, Ui.TEXT, new View.OnClickListener() {
            public void onClick(View v) { requestExit(); }
        }), Ui.lp(Ui.dp(44), Ui.dp(44)));
        LinearLayout titles = new LinearLayout(a);
        titles.setOrientation(LinearLayout.VERTICAL);
        TextView t = Ui.label(a, "Audio Studio", 17, Ui.TEXT, true);
        t.setSingleLine(true);
        titles.addView(t);
        subtitle = Ui.label(a, "", 12, Ui.MUTED, false);
        subtitle.setSingleLine(true);
        titles.addView(subtitle);
        bar.addView(titles, Ui.lpWeight(0, Ui.WRAP, 1));
        bpmPill = Ui.pill(a, "", 0, Ui.ACCENT, new View.OnClickListener() {
            public void onClick(View v) {
                askNumber("Tempo (BPM)", song.bpm, 30, 300, new IntCb() {
                    public void got(int val) { song.bpm = val; dirty = true; updateHeader(); }
                });
            }
        });
        bpmPill.setPadding(Ui.dp(12), Ui.dp(6), Ui.dp(12), Ui.dp(6));
        bar.addView(bpmPill, Ui.lpMargin(Ui.WRAP, Ui.WRAP, 0, 0, 4, 0));
        playBtn = Ui.iconButton(a, R.drawable.ic_play_arrow, Ui.ACCENT, new View.OnClickListener() {
            public void onClick(View v) { if (playing) stopSong(); else startSong(); }
        });
        bar.addView(playBtn, Ui.lp(Ui.dp(44), Ui.dp(44)));
        bar.addView(Ui.iconButton(a, R.drawable.ic_more_vert, Ui.TEXT, new View.OnClickListener() {
            public void onClick(View v) { showMenu(v); }
        }), Ui.lp(Ui.dp(40), Ui.dp(44)));
        root.addView(bar, Ui.lp(Ui.MATCH, Ui.WRAP));

        FrameLayout content = new FrameLayout(a);
        tabViews[TAB_ROLL] = buildRollTab();
        tabViews[TAB_RACK] = buildRackTab();
        tabViews[TAB_AUDIO] = buildAudioTab();
        for (int i = 0; i < 3; i++) content.addView(tabViews[i], new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        root.addView(content, Ui.lpWeight(Ui.MATCH, 0, 1));

        LinearLayout nav = new LinearLayout(a);
        nav.setBackgroundColor(Ui.SURFACE);
        nav.setElevation(Ui.dp(8));
        nav.setPadding(0, Ui.dp(6), 0, Ui.dp(6));
        String[] names = {"Piano roll", "Rack", "Audio"};
        int[] icons = {R.drawable.ic_music_note, R.drawable.ic_list, R.drawable.ic_graphic_eq};
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            LinearLayout item = new LinearLayout(a);
            item.setOrientation(LinearLayout.VERTICAL);
            item.setGravity(Gravity.CENTER_HORIZONTAL);
            item.setClickable(true);
            FrameLayout bubble = new FrameLayout(a);
            navIcons[i] = Ui.icon(a, icons[i], Ui.MUTED, 24);
            bubble.addView(navIcons[i], new FrameLayout.LayoutParams(Ui.dp(24), Ui.dp(24), Gravity.CENTER));
            navBubbles[i] = bubble;
            item.addView(bubble, Ui.lp(Ui.dp(56), Ui.dp(30)));
            navLabels[i] = Ui.label(a, names[i], 11.5f, Ui.MUTED, true);
            item.addView(navLabels[i], Ui.lpMargin(Ui.WRAP, Ui.WRAP, 0, 2, 0, 0));
            item.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { showTab(idx); } });
            nav.addView(item, Ui.lpWeight(0, Ui.WRAP, 1));
        }
        root.addView(nav, Ui.lp(Ui.MATCH, Ui.WRAP));

        roll.setProject(song);
        rebuildRack();
        rebuildClips();
        updateAudioInfo();
        showTab(TAB_ROLL);
        updateHeader();
        updateTrackChip();
        return root;
    }

    private void showTab(int i) {
        tab = i;
        for (int k = 0; k < 3; k++) {
            tabViews[k].setVisibility(k == i ? View.VISIBLE : View.GONE);
            boolean on = k == i;
            Ui.setTint(navIcons[k], on ? Ui.ACCENT : Ui.MUTED);
            navLabels[k].setTextColor(on ? Ui.ACCENT : Ui.MUTED);
            navBubbles[k].setBackground(on ? Ui.rect(Ui.ACCENT_SOFT, 16, 0) : null);
        }
        if (i == TAB_RACK) rebuildRack();
    }

    private View strip(LinearLayout row) {
        HorizontalScrollView hs = new HorizontalScrollView(a);
        hs.setHorizontalScrollBarEnabled(false);
        hs.addView(row);
        hs.setPadding(Ui.dp(10), Ui.dp(6), Ui.dp(10), Ui.dp(2));
        return hs;
    }

    /** Real Material Components button (not a hand-drawn TextView): rounded, outlined,
     *  lower-case text, same footprint the old pill() produced. */
    private TextView pill(String text, View.OnClickListener l) {
        MaterialButton p = new MaterialButton(a, null, com.google.android.material.R.attr.materialButtonOutlinedStyle);
        p.setText(text);
        p.setAllCaps(false);
        p.setTextSize(13);
        p.setSingleLine(true);
        p.setInsetTop(0);
        p.setInsetBottom(0);
        p.setCornerRadius(Ui.dp(20));
        p.setStrokeColor(android.content.res.ColorStateList.valueOf(Ui.STROKE));
        p.setStrokeWidth(Ui.dp(1));
        p.setTextColor(Ui.TEXT);
        p.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0x00000000));
        p.setPadding(Ui.dp(14), Ui.dp(8), Ui.dp(14), Ui.dp(8));
        if (l != null) p.setOnClickListener(l);
        return p;
    }

    private void style(TextView t, boolean on) {
        if (t instanceof MaterialButton) {
            MaterialButton b = (MaterialButton) t;
            b.setStrokeColor(android.content.res.ColorStateList.valueOf(on ? Ui.ACCENT : Ui.STROKE));
            b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(on ? Ui.ACCENT_SOFT : 0x00000000));
            b.setTextColor(on ? Ui.ACCENT : Ui.TEXT);
        } else {
            t.setBackground(Ui.ripple(on ? Ui.rect(Ui.ACCENT_SOFT, 20, Ui.ACCENT) : Ui.rect(0, 20, Ui.STROKE)));
            t.setTextColor(on ? Ui.ACCENT : Ui.TEXT);
        }
    }

    private void add(LinearLayout row, View v) { row.addView(v, Ui.lpMargin(Ui.WRAP, Ui.WRAP, 0, 0, 8, 0)); }

    // ---------------------------------------------------------------- piano roll tab

    private View buildRollTab() {
        LinearLayout col = new LinearLayout(a);
        col.setOrientation(LinearLayout.VERTICAL);

        LinearLayout r1 = new LinearLayout(a);
        r1.setGravity(Gravity.CENTER_VERTICAL);
        trackChip = pill("", new View.OnClickListener() { public void onClick(View v) { chooseTrackDialog(); } });
        trackChip.setTextColor(Ui.ACCENT);
        add(r1, trackChip);
        drawPill = pill("Draw", new View.OnClickListener() { public void onClick(View v) { setTool(PianoRollView.T_DRAW); } });
        erasePill = pill("Erase", new View.OnClickListener() { public void onClick(View v) { setTool(PianoRollView.T_ERASE); } });
        panPill = pill("Pan", new View.OnClickListener() { public void onClick(View v) { setTool(PianoRollView.T_PAN); } });
        add(r1, drawPill);
        add(r1, erasePill);
        add(r1, panPill);
        snapPill = pill("Snap 1/16", new View.OnClickListener() {
            public void onClick(View v) {
                int i = 0;
                for (int k = 0; k < SNAP_TICKS.length; k++) if (SNAP_TICKS[k] == roll.gridTicks) i = k;
                i = (i + 1) % SNAP_TICKS.length;
                roll.gridTicks = SNAP_TICKS[i];
                snapPill.setText("Snap " + SNAP_NAMES[i]);
                roll.refresh();
            }
        });
        add(r1, snapPill);
        barsPill = pill("", new View.OnClickListener() {
            public void onClick(View v) {
                int[] opts = {1, 2, 4, 8, 16, 32, 64};
                int i = 0;
                for (int k = 0; k < opts.length; k++) if (opts[k] == song.bars) i = k;
                int minBars = Math.max(1, (song.endTick() + 4 * SeqModel.PPQ - 1) / (4 * SeqModel.PPQ));
                for (int tries = 0; tries < opts.length; tries++) {
                    i = (i + 1) % opts.length;
                    if (opts[i] >= minBars) break;
                }
                song.bars = Math.max(opts[i], minBars);
                updateHeader();
                roll.refresh();
            }
        });
        add(r1, barsPill);
        scalePill = pill("Scale", new View.OnClickListener() { public void onClick(View v) { scaleDialog(); } });
        add(r1, scalePill);
        add(r1, pill("Zoom -", new View.OnClickListener() { public void onClick(View v) { roll.zoom(0.7f); } }));
        add(r1, pill("Zoom +", new View.OnClickListener() { public void onClick(View v) { roll.zoom(1.4f); } }));
        col.addView(strip(r1), Ui.lp(Ui.MATCH, Ui.WRAP));

        LinearLayout r2 = new LinearLayout(a);
        r2.setGravity(Gravity.CENTER_VERTICAL);
        add(r2, pill("Quantize", new View.OnClickListener() { public void onClick(View v) { roll.quantizeAll(); } }));
        add(r2, pill("-12", new View.OnClickListener() { public void onClick(View v) { roll.transpose(-12); } }));
        add(r2, pill("-1", new View.OnClickListener() { public void onClick(View v) { roll.transpose(-1); } }));
        add(r2, pill("+1", new View.OnClickListener() { public void onClick(View v) { roll.transpose(1); } }));
        add(r2, pill("+12", new View.OnClickListener() { public void onClick(View v) { roll.transpose(12); } }));
        add(r2, pill("Clear track", new View.OnClickListener() {
            public void onClick(View v) {
                new AlertDialog.Builder(a, Ui.dialogTheme()).setTitle("Clear this track?")
                    .setMessage("Removes every note in this track.")
                    .setPositiveButton("Clear", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface d, int w) { roll.clearTrack(); }
                    }).setNegativeButton("Cancel", null).show();
            }
        }));
        col.addView(strip(r2), Ui.lp(Ui.MATCH, Ui.WRAP));

        roll = new PianoRollView(a);
        roll.setListener(new PianoRollView.Listener() {
            public void onChanged() { dirty = true; updateHeader(); }
            public void onSelect(SeqModel.Note n) { updateNotePanel(n); }
            public void onAudition(int pitch, boolean drum) { audition(pitch, drum); }
        });
        col.addView(roll, Ui.lpWeight(Ui.MATCH, 0, 1));

        LinearLayout np = new LinearLayout(a);
        np.setGravity(Gravity.CENTER_VERTICAL);
        np.setPadding(Ui.dp(12), Ui.dp(4), Ui.dp(8), Ui.dp(4));
        np.setBackgroundColor(Ui.SURFACE);
        noteLabel = Ui.label(a, "", 14, Ui.ACCENT, true);
        np.addView(noteLabel, Ui.lpMargin(Ui.dp(52), Ui.WRAP, 0, 0, 6, 0));
        np.addView(Ui.label(a, "Vel", 12, Ui.MUTED, false), Ui.lpMargin(Ui.WRAP, Ui.WRAP, 0, 0, 4, 0));
        velBar = new SeekBar(a);
        velBar.setMax(126);
        velBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                if (!fromUser || velSetting) return;
                SeqModel.Note n = roll.selected();
                if (n != null) { n.vel = p + 1; roll.defaultVel = n.vel; roll.refresh(); dirty = true; }
            }
            public void onStartTrackingTouch(SeekBar s) { }
            public void onStopTrackingTouch(SeekBar s) { }
        });
        np.addView(velBar, Ui.lpWeight(0, Ui.WRAP, 1));
        np.addView(pill("Copy", new View.OnClickListener() { public void onClick(View v) { roll.duplicateSelected(); } }), Ui.lpMargin(Ui.WRAP, Ui.WRAP, 6, 0, 0, 0));
        np.addView(pill("Delete", new View.OnClickListener() { public void onClick(View v) { roll.deleteSelected(); } }), Ui.lpMargin(Ui.WRAP, Ui.WRAP, 6, 0, 0, 0));
        notePanel = np;
        np.setVisibility(View.GONE);
        col.addView(np, Ui.lp(Ui.MATCH, Ui.WRAP));
        setTool(PianoRollView.T_DRAW);
        return col;
    }

    private void setTool(int tool) {
        roll.tool = tool;
        style(drawPill, tool == PianoRollView.T_DRAW);
        style(erasePill, tool == PianoRollView.T_ERASE);
        style(panPill, tool == PianoRollView.T_PAN);
    }

    private void updateNotePanel(SeqModel.Note n) {
        if (notePanel == null) return;
        notePanel.setVisibility(n == null ? View.GONE : View.VISIBLE);
        if (n != null) {
            SeqModel.Track t = song.tracks.get(roll.track());
            noteLabel.setText(t.drum ? SeqModel.DRUM_NAMES[Math.max(0, SeqModel.drumRow(n.pitch))] : SeqModel.noteName(n.pitch));
            velSetting = true;
            velBar.setProgress(Math.max(0, Math.min(126, n.vel - 1)));
            velSetting = false;
        }
    }

    private void updateTrackChip() {
        if (trackChip == null || song.tracks.isEmpty()) return;
        SeqModel.Track t = song.tracks.get(Math.min(roll.track(), song.tracks.size() - 1));
        trackChip.setText(t.name + (t.drum ? " (drums)" : "") + "  ▾");
    }

    private void chooseTrackDialog() {
        final String[] names = new String[song.tracks.size()];
        for (int i = 0; i < names.length; i++) {
            SeqModel.Track t = song.tracks.get(i);
            names[i] = (i == roll.track() ? "✓  " : "     ") + t.name + (t.drum ? "  (drums)" : "") + "  ·  " + t.notes.size() + " notes";
        }
        new AlertDialog.Builder(a, Ui.dialogTheme()).setTitle("Edit track").setItems(names, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface d, int which) { roll.setTrack(which); updateTrackChip(); }
        }).setNegativeButton("Cancel", null).show();
    }

    private void scaleDialog() {
        final String[] roots = SeqModel.NOTE_NAMES;
        final String[] scales = SeqModel.SCALE_NAMES;
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(Ui.dp(20), Ui.dp(8), Ui.dp(20), 0);
        box.addView(Ui.label(a, "Highlights notes in the selected scale.", 12, Ui.MUTED, false));
        box.addView(Ui.section(a, "Key"));
        box.addView(chips(roots, roll.scaleRoot, new IntCb() { public void got(int v) { roll.scaleRoot = v; updateScalePill(); roll.refresh(); } }));
        box.addView(Ui.section(a, "Scale"));
        box.addView(chips(new String[]{"None", "Major", "Minor", "Penta", "Blues"}, roll.scaleType, new IntCb() {
            public void got(int v) { roll.scaleType = v; updateScalePill(); roll.refresh(); }
        }));
        new AlertDialog.Builder(a, Ui.dialogTheme()).setTitle("Scale highlight").setView(box).setPositiveButton("Done", null).show();
    }

    private void updateScalePill() {
        scalePill.setText(roll.scaleType == 0 ? "Scale" : SeqModel.NOTE_NAMES[roll.scaleRoot] + " " + SeqModel.SCALE_NAMES[roll.scaleType]);
        style(scalePill, roll.scaleType != 0);
    }

    // ---------------------------------------------------------------- rack tab

    private View buildRackTab() {
        ScrollView sv = new ScrollView(a);
        rackList = new LinearLayout(a);
        rackList.setOrientation(LinearLayout.VERTICAL);
        rackList.setPadding(Ui.dp(12), Ui.dp(8), Ui.dp(12), Ui.dp(24));
        sv.addView(rackList);
        return sv;
    }

    private void rebuildRack() {
        if (rackList == null) return;
        rackList.removeAllViews();
        rackList.addView(Ui.label(a, "Tap Edit to open a track.", 12.5f, Ui.MUTED, false),
                Ui.lpMargin(Ui.MATCH, Ui.WRAP, 4, 4, 4, 8));
        for (int i = 0; i < song.tracks.size(); i++) {
            final int idx = i;
            final SeqModel.Track t = song.tracks.get(i);
            LinearLayout card = Ui.card(a);
            card.setPadding(Ui.dp(14), Ui.dp(12), Ui.dp(14), Ui.dp(12));
            LinearLayout head = new LinearLayout(a);
            head.setGravity(Gravity.CENTER_VERTICAL);
            View dot = new View(a);
            dot.setBackground(Ui.circle(t.color));
            head.addView(dot, Ui.lpMargin(Ui.dp(14), Ui.dp(14), 0, 0, 10, 0));
            LinearLayout names = new LinearLayout(a);
            names.setOrientation(LinearLayout.VERTICAL);
            TextView nm = Ui.label(a, t.name, 16, Ui.TEXT, true);
            nm.setSingleLine(true);
            names.addView(nm);
            names.addView(Ui.label(a, (t.drum ? "Drum kit" : MidiFile.INSTRUMENTS[t.program & 127]) + "  ·  " + t.notes.size() + " notes", 12, Ui.MUTED, false));
            head.addView(names, Ui.lpWeight(0, Ui.WRAP, 1));
            final TextView mute = pill(t.mute ? "Muted" : "On", null);
            style(mute, !t.mute);
            mute.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) { t.mute = !t.mute; dirty = true; mute.setText(t.mute ? "Muted" : "On"); style(mute, !t.mute); }
            });
            head.addView(mute);
            card.addView(head);
            LinearLayout vol = new LinearLayout(a);
            vol.setGravity(Gravity.CENTER_VERTICAL);
            vol.addView(Ui.label(a, "Volume", 12, Ui.MUTED, false), Ui.lpMargin(Ui.dp(52), Ui.WRAP, 0, 0, 0, 0));
            SeekBar vb = new SeekBar(a);
            vb.setMax(127);
            vb.setProgress(t.volume);
            vb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                public void onProgressChanged(SeekBar s, int p, boolean fromUser) { if (fromUser) { t.volume = p; dirty = true; } }
                public void onStartTrackingTouch(SeekBar s) { }
                public void onStopTrackingTouch(SeekBar s) { }
            });
            vol.addView(vb, Ui.lpWeight(0, Ui.WRAP, 1));
            card.addView(vol, Ui.lpMargin(Ui.MATCH, Ui.WRAP, 0, 6, 0, 6));
            LinearLayout acts = new LinearLayout(a);
            add(acts, pill("Edit", new View.OnClickListener() {
                public void onClick(View v) { roll.setTrack(idx); updateTrackChip(); showTab(TAB_ROLL); }
            }));
            if (!t.drum) {
                add(acts, pill("Instrument", new View.OnClickListener() {
                    public void onClick(View v) {
                        pickProgram(t.program, new IntCb() { public void got(int p) { t.program = p; dirty = true; rebuildRack(); } });
                    }
                }));
            } else {
                add(acts, pill("Pattern", new View.OnClickListener() { public void onClick(View v) { drumPresetDialog(t); } }));
            }
            add(acts, pill("Rename", new View.OnClickListener() {
                public void onClick(View v) {
                    askText("Rename track", t.name, new StrCb() {
                        public void got(String s) { if (s.trim().length() > 0) { t.name = s.trim(); dirty = true; rebuildRack(); updateTrackChip(); } }
                    });
                }
            }));
            add(acts, pill("Delete", new View.OnClickListener() {
                public void onClick(View v) {
                    if (song.tracks.size() <= 1) { host.toast("A song needs at least one track"); return; }
                    song.tracks.remove(idx);
                    roll.setTrack(0);
                    dirty = true;
                    updateTrackChip();
                    rebuildRack();
                    updateHeader();
                }
            }));
            HorizontalScrollView hs = new HorizontalScrollView(a);
            hs.setHorizontalScrollBarEnabled(false);
            hs.addView(acts);
            card.addView(hs);
            rackList.addView(card, Ui.lpMargin(Ui.MATCH, Ui.WRAP, 0, 0, 0, 10));
        }
        LinearLayout add = new LinearLayout(a);
        add(add, pill("+ Instrument track", new View.OnClickListener() {
            public void onClick(View v) {
                if (song.tracks.size() >= 12) { host.toast("12 tracks is the limit"); return; }
                pickProgram(0, new IntCb() {
                    public void got(int p) {
                        song.addTrack(MidiFile.INSTRUMENTS[p], p, false);
                        dirty = true;
                        rebuildRack();
                        updateHeader();
                    }
                });
            }
        }));
        add(add, pill("+ Drum track", new View.OnClickListener() {
            public void onClick(View v) {
                if (song.tracks.size() >= 12) { host.toast("12 tracks is the limit"); return; }
                SeqModel.Track d = song.addTrack("Drums", 0, true);
                dirty = true;
                drumPresetDialog(d);
                rebuildRack();
                updateHeader();
            }
        }));
        rackList.addView(add, Ui.lpMargin(Ui.MATCH, Ui.WRAP, 0, 4, 0, 0));
    }

    private void drumPresetDialog(final SeqModel.Track t) {
        new AlertDialog.Builder(a, Ui.dialogTheme()).setTitle("Drum pattern").setItems(SeqModel.DRUM_PRESET_NAMES, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface d, int which) {
                SeqModel.applyDrumPreset(song, t, which);
                dirty = true;
                roll.refresh();
                rebuildRack();
            }
        }).setNegativeButton("Cancel", null).show();
    }

    private void pickProgram(int current, final IntCb cb) {
        String[] names = new String[128];
        for (int i = 0; i < 128; i++) names[i] = (i == current ? "✓  " : "") + i + "  " + MidiFile.INSTRUMENTS[i];
        new AlertDialog.Builder(a, Ui.dialogTheme()).setTitle("Instrument").setItems(names, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface d, int which) { cb.got(which); }
        }).setNegativeButton("Cancel", null).show();
    }

    // ---------------------------------------------------------------- audio tab

    private LinearLayout card(LinearLayout parent, String title, String sub) {
        LinearLayout c = Ui.card(a);
        c.setPadding(Ui.dp(14), Ui.dp(12), Ui.dp(14), Ui.dp(12));
        c.addView(Ui.label(a, title, 15, Ui.TEXT, true));
        if (sub != null) c.addView(Ui.label(a, sub, 12, Ui.MUTED, false), Ui.lpMargin(Ui.MATCH, Ui.WRAP, 0, 2, 0, 6));
        parent.addView(c, Ui.lpMargin(Ui.MATCH, Ui.WRAP, 0, 0, 0, 10));
        return c;
    }

    private View chips(final String[] labels, int selected, final IntCb cb) {
        LinearLayout row = new LinearLayout(a);
        final TextView[] ps = new TextView[labels.length];
        for (int i = 0; i < labels.length; i++) {
            final int idx = i;
            ps[i] = pill(labels[i], new View.OnClickListener() {
                public void onClick(View v) {
                    for (int j = 0; j < ps.length; j++) style(ps[j], j == idx);
                    cb.got(idx);
                }
            });
            style(ps[i], i == selected);
            add(row, ps[i]);
        }
        HorizontalScrollView hs = new HorizontalScrollView(a);
        hs.setHorizontalScrollBarEnabled(false);
        hs.addView(row);
        return hs;
    }

    private View buildAudioTab() {
        ScrollView sv = new ScrollView(a);
        LinearLayout col = new LinearLayout(a);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(Ui.dp(12), Ui.dp(10), Ui.dp(12), Ui.dp(28));
        sv.addView(col);

        // ---- record / import ----
        LinearLayout rec = card(col, "Record & import", "Record or import audio.");
        LinearLayout recRow = new LinearLayout(a);
        recRow.setGravity(Gravity.CENTER_VERTICAL);
        recBtn = Ui.label(a, "Record", 14, Ui.WHITE, true);
        recBtn.setGravity(Gravity.CENTER);
        recBtn.setPadding(Ui.dp(20), Ui.dp(12), Ui.dp(20), Ui.dp(12));
        recBtn.setBackground(Ui.ripple(Ui.rect(0xFFE53935, 28, 0)));
        recBtn.setClickable(true);
        recBtn.setElevation(Ui.dp(4));
        recBtn.setCompoundDrawablePadding(Ui.dp(8));
        recBtn.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { toggleRecord(); } });
        recRow.addView(recBtn, Ui.lpMargin(Ui.WRAP, Ui.WRAP, 0, 4, 12, 4));
        LinearLayout lv = new LinearLayout(a);
        lv.setOrientation(LinearLayout.VERTICAL);
        recTime = Ui.label(a, "0:00.0", 18, Ui.TEXT, true);
        lv.addView(recTime);
        level = new ProgressBar(a, null, android.R.attr.progressBarStyleHorizontal);
        level.setMax(100);
        lv.addView(level, Ui.lp(Ui.MATCH, Ui.dp(10)));
        recRow.addView(lv, Ui.lpWeight(0, Ui.WRAP, 1));
        rec.addView(recRow);
        LinearLayout imp = new LinearLayout(a);
        add(imp, pill("Import audio", new View.OnClickListener() { public void onClick(View v) { importAudio(); } }));
        final TextView hifi = pill("Hi-Fi 44.1 kHz", null);
        style(hifi, hiFiRec);
        hifi.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { hiFiRec = !hiFiRec; style(hifi, hiFiRec); }
        });
        add(imp, hifi);
        add(imp, pill("Song as audio", new View.OnClickListener() { public void onClick(View v) { songToClip(); } }));
        HorizontalScrollView impS = new HorizontalScrollView(a);
        impS.setHorizontalScrollBarEnabled(false);
        impS.addView(imp);
        rec.addView(impS, Ui.lpMargin(Ui.MATCH, Ui.WRAP, 0, 6, 0, 0));

        // ---- clips + wave ----
        LinearLayout wc = card(col, "Sound", null);
        clipRow = new LinearLayout(a);
        HorizontalScrollView cs = new HorizontalScrollView(a);
        cs.setHorizontalScrollBarEnabled(false);
        cs.addView(clipRow);
        wc.addView(cs, Ui.lpMargin(Ui.MATCH, Ui.WRAP, 0, 0, 0, 8));
        wave = new WaveformView(a);
        wave.setListener(new WaveformView.Listener() {
            public void onSelectionChanged() { updateAudioInfo(); }
            public void onSeek(int sample) { seekPos = sample; }
        });
        wc.addView(wave, Ui.lp(Ui.MATCH, Ui.dp(170)));
        audioInfo = Ui.label(a, "", 12, Ui.MUTED, false);
        wc.addView(audioInfo, Ui.lpMargin(Ui.MATCH, Ui.WRAP, 2, 6, 0, 6));
        LinearLayout tr = new LinearLayout(a);
        clipPlayBtn = pill("Play", new View.OnClickListener() { public void onClick(View v) { toggleClipPlay(); } });
        clipPlayBtn.setBackground(Ui.ripple(Ui.rect(Ui.ACCENT, 20, 0)));
        clipPlayBtn.setTextColor(Ui.WHITE);
        add(tr, clipPlayBtn);
        add(tr, pill("Zoom +", new View.OnClickListener() { public void onClick(View v) { wave.zoom(1.6f); } }));
        add(tr, pill("Zoom -", new View.OnClickListener() { public void onClick(View v) { wave.zoom(0.6f); } }));
        add(tr, pill("Fit", new View.OnClickListener() { public void onClick(View v) { wave.fit(); } }));
        add(tr, pill("Select all", new View.OnClickListener() { public void onClick(View v) { wave.selectAll(); } }));
        add(tr, pill("Select none", new View.OnClickListener() { public void onClick(View v) { wave.clearSelection(); } }));
        wc.addView(strip(tr), Ui.lp(Ui.MATCH, Ui.WRAP));
        wc.addView(Ui.label(a, "Drag to select, pinch to zoom.", 11.5f, Ui.MUTED, false),
                Ui.lpMargin(Ui.MATCH, Ui.WRAP, 2, 6, 0, 0));

        // ---- edit ----
        LinearLayout ed = card(col, "Edit", "Applies to the selection, or the whole sound.");
        LinearLayout e1 = new LinearLayout(a);
        add(e1, pill("Keep selection", new View.OnClickListener() { public void onClick(View v) { editKeep(); } }));
        add(e1, pill("Delete selection", new View.OnClickListener() { public void onClick(View v) { editDelete(); } }));
        add(e1, pill("Normalize", new View.OnClickListener() { public void onClick(View v) { editNormalize(); } }));
        add(e1, pill("Fade in/out", new View.OnClickListener() { public void onClick(View v) { editFade(); } }));
        add(e1, pill("Trim silence", new View.OnClickListener() { public void onClick(View v) { editTrimSilence(); } }));
        add(e1, pill("Reverse", new View.OnClickListener() { public void onClick(View v) { editReverse(); } }));
        add(e1, pill("Undo", new View.OnClickListener() { public void onClick(View v) { editUndo(); } }));
        add(e1, pill("Delete sound", new View.OnClickListener() { public void onClick(View v) { deleteClip(); } }));
        HorizontalScrollView e1s = new HorizontalScrollView(a);
        e1s.setHorizontalScrollBarEnabled(false);
        e1s.addView(e1);
        ed.addView(e1s);

        // ---- split ----
        LinearLayout sp = card(col, "Split", "Cut one sound into several parts.");
        LinearLayout s1 = new LinearLayout(a);
        add(s1, pill("At selection (3 parts)", new View.OnClickListener() { public void onClick(View v) { splitAtSelection(); } }));
        add(s1, pill("Equal parts...", new View.OnClickListener() { public void onClick(View v) { splitEqualDialog(); } }));
        add(s1, pill("On silence...", new View.OnClickListener() { public void onClick(View v) { splitSilenceDialog(); } }));
        add(s1, pill("Save all as ZIP", new View.OnClickListener() { public void onClick(View v) { saveAllZip(); } }));
        HorizontalScrollView s1s = new HorizontalScrollView(a);
        s1s.setHorizontalScrollBarEnabled(false);
        s1s.addView(s1);
        sp.addView(s1s);

        // ---- compress ----
        LinearLayout cp = card(col, "Compress & reduce", "Shrink the file: lower rate, 8-bit, or AAC.");
        cp.addView(Ui.label(a, "Sample rate", 12, Ui.MUTED, true), Ui.lpMargin(Ui.MATCH, Ui.WRAP, 2, 4, 0, 4));
        cp.addView(chips(new String[]{"8 kHz", "11 kHz", "16 kHz", "22 kHz", "44 kHz"}, 1, new IntCb() {
            public void got(int v) { outRate = OUT_RATES[v]; updateAudioInfo(); }
        }));
        cp.addView(Ui.label(a, "WAV depth", 12, Ui.MUTED, true), Ui.lpMargin(Ui.MATCH, Ui.WRAP, 2, 8, 0, 4));
        cp.addView(chips(new String[]{"8-bit (smallest)", "16-bit"}, 1, new IntCb() {
            public void got(int v) { outBits = v == 0 ? 8 : 16; updateAudioInfo(); }
        }));
        cp.addView(Ui.label(a, "AAC quality (.m4a)", 12, Ui.MUTED, true), Ui.lpMargin(Ui.MATCH, Ui.WRAP, 2, 8, 0, 4));
        cp.addView(chips(new String[]{"24 kbps", "32 kbps", "64 kbps", "96 kbps", "128 kbps"}, 2, new IntCb() {
            public void got(int v) { aacKbps = AAC_KBPS[v]; updateAudioInfo(); }
        }));
        LinearLayout o = new LinearLayout(a);
        final TextView nz = pill("Normalize", null);
        style(nz, optNormalize);
        nz.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { optNormalize = !optNormalize; style(nz, optNormalize); } });
        final TextView ts = pill("Trim silence", null);
        style(ts, optTrimSilence);
        ts.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { optTrimSilence = !optTrimSilence; style(ts, optTrimSilence); updateAudioInfo(); } });
        add(o, nz);
        add(o, ts);
        cp.addView(o, Ui.lpMargin(Ui.MATCH, Ui.WRAP, 0, 10, 0, 0));
        estimateText = Ui.label(a, "", 12.5f, Ui.TEXT, false);
        cp.addView(estimateText, Ui.lpMargin(Ui.MATCH, Ui.WRAP, 2, 8, 0, 6));
        LinearLayout c2 = new LinearLayout(a);
        add(c2, pill("Apply to sound", new View.OnClickListener() { public void onClick(View v) { applyReduce(); } }));
        add(c2, pill("Save WAV", new View.OnClickListener() { public void onClick(View v) { saveWav(); } }));
        add(c2, pill("Save AAC (.m4a)", new View.OnClickListener() { public void onClick(View v) { saveAac(); } }));
        HorizontalScrollView c2s = new HorizontalScrollView(a);
        c2s.setHorizontalScrollBarEnabled(false);
        c2s.addView(c2);
        cp.addView(c2s);

        // ---- audio to midi ----
        LinearLayout cv = card(col, "Convert to MIDI", "Converts one melody into piano-roll notes.");
        cv.addView(Ui.label(a, "Sensitivity", 12, Ui.MUTED, true), Ui.lpMargin(Ui.MATCH, Ui.WRAP, 2, 4, 0, 2));
        SeekBar sb = new SeekBar(a);
        sb.setMax(100);
        sb.setProgress(sens);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean u) { sens = p; }
            public void onStartTrackingTouch(SeekBar s) { }
            public void onStopTrackingTouch(SeekBar s) { }
        });
        cv.addView(sb);
        cv.addView(Ui.label(a, "Shortest note", 12, Ui.MUTED, true), Ui.lpMargin(Ui.MATCH, Ui.WRAP, 2, 8, 0, 4));
        cv.addView(chips(new String[]{"60 ms", "100 ms", "150 ms", "250 ms"}, 1, new IntCb() {
            public void got(int v) { int[] ms = {60, 100, 150, 250}; minNoteMs = ms[v]; }
        }));
        cv.addView(Ui.label(a, "Snap notes to", 12, Ui.MUTED, true), Ui.lpMargin(Ui.MATCH, Ui.WRAP, 2, 8, 0, 4));
        cv.addView(chips(new String[]{"1/4", "1/8", "1/16", "1/32"}, 2, new IntCb() { public void got(int v) { quantIdx = v; } }));
        convInstr = pill("Instrument: " + MidiFile.INSTRUMENTS[convProgram], new View.OnClickListener() {
            public void onClick(View v) {
                pickProgram(convProgram, new IntCb() {
                    public void got(int p) { convProgram = p; convInstr.setText("Instrument: " + MidiFile.INSTRUMENTS[p]); }
                });
            }
        });
        cv.addView(convInstr, Ui.lpMargin(Ui.WRAP, Ui.WRAP, 0, 10, 0, 0));
        TextView go = pill("Convert to MIDI track", new View.OnClickListener() { public void onClick(View v) { convertToMidi(); } });
        go.setBackground(Ui.ripple(Ui.rect(Ui.ACCENT, 20, 0)));
        go.setTextColor(Ui.WHITE);
        cv.addView(go, Ui.lpMargin(Ui.WRAP, Ui.WRAP, 0, 12, 0, 0));
        return sv;
    }

    // ------------------------------------------------------------------
    // header, menu
    // ------------------------------------------------------------------

    private void updateHeader() {
        if (subtitle == null) return;
        subtitle.setText(song.bars + " bars  ·  " + song.tracks.size() + " tracks  ·  " + song.noteCount() + " notes" + (dirty ? "  • edited" : ""));
        bpmPill.setText(song.bpm + " BPM");
        if (barsPill != null) barsPill.setText(song.bars + (song.bars == 1 ? " bar" : " bars"));
        updateTrackChip();
    }

    private void showMenu(View anchor) {
        Context themed = new ContextThemeWrapper(a, Ui.dark ? android.R.style.Theme_Material : android.R.style.Theme_Material_Light);
        PopupMenu pm = new PopupMenu(themed, anchor);
        pm.getMenu().add(0, 1, 0, "New song");
        pm.getMenu().add(0, 2, 1, "Open MIDI from device...");
        pm.getMenu().add(0, 3, 2, "Open MIDI from project res...");
        pm.getMenu().add(0, 4, 3, "Save MIDI...");
        pm.getMenu().add(0, 5, 4, "Export song as WAV...");
        MenuItem lp = pm.getMenu().add(0, 6, 5, "Loop playback");
        lp.setCheckable(true);
        lp.setChecked(loop);
        MenuItem sy = pm.getMenu().add(0, 7, 6, "Use built-in synth for playback");
        sy.setCheckable(true);
        sy.setChecked(useSynth);
        pm.getMenu().add(0, 8, 7, "Text composer (note names)");
        pm.getMenu().add(0, 9, 8, "Help");
        pm.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            public boolean onMenuItemClick(MenuItem item) { menuAction(item.getItemId()); return true; }
        });
        pm.show();
    }

    private void menuAction(int id) {
        switch (id) {
            case 1:
                confirmDiscard(new Runnable() {
                    public void run() {
                        stopSong();
                        loadSong(SeqModel.newSong());
                        dirty = false;
                        updateHeader();
                    }
                });
                break;
            case 2: openMidiDevice(); break;
            case 3: openMidiRes(); break;
            case 4: saveMidi(); break;
            case 5: exportSongWav(); break;
            case 6: loop = !loop; if (mp != null) mp.setLooping(loop); break;
            case 7: useSynth = !useSynth; stopSong(); break;
            case 8: stopAll(); host.openTextComposer(); break;
            case 9: helpDialog(); break;
            default: break;
        }
    }

    private void helpDialog() {
        new AlertDialog.Builder(a, Ui.dialogTheme()).setTitle("Audio Studio")
            .setMessage("PIANO ROLL\nTap to add a note, drag to move or resize. Pinch to zoom.\n\n"
                + "RACK\nOne instrument per track. Drum tracks use a step grid.\n\n"
                + "AUDIO\nRecord or import, then trim, split or compress. \"Convert to MIDI\" turns one melody into notes.")
            .setPositiveButton("OK", null).show();
    }

    // ------------------------------------------------------------------
    // song playback
    // ------------------------------------------------------------------

    private void audition(int pitch, boolean drum) {
        SeqModel.Track t = song.tracks.get(Math.min(roll.track(), song.tracks.size() - 1));
        short[] tone = NoteSynth.tone(pitch, drum, t.program);
        auditPlayer.play(tone, 0, tone.length, NoteSynth.RATE, null);
    }

    private final Runnable playTick = new Runnable() {
        public void run() {
            if (!playing) return;
            int tick = -1;
            if (mp != null) {
                try { tick = (int) (mp.getCurrentPosition() * (long) song.bpm * SeqModel.PPQ / 60000L); } catch (Exception ignore) { }
            } else if (songPlayer.isPlaying()) {
                tick = (int) (songPlayer.position() * (long) song.bpm * SeqModel.PPQ / (60L * NoteSynth.RATE));
            }
            if (tick >= 0) {
                roll.setPlayTick(tick);
                if (tab == TAB_ROLL) roll.scrollToTick(tick);
            }
            handler.postDelayed(this, 40);
        }
    };

    private void startSong() {
        if (song.noteCount() == 0) { host.toast("Add some notes first"); return; }
        stopClip();
        stopSong();
        if (!useSynth) {
            try {
                byte[] mid = MidiIO.write(song);
                File f = new File(a.getCacheDir(), "studio_preview.mid");
                FileOutputStream fo = new FileOutputStream(f);
                try { fo.write(mid); } finally { fo.close(); }
                MediaPlayer m = new MediaPlayer();
                try {
                    m.setDataSource(f.getAbsolutePath());
                    m.setLooping(loop);
                    m.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                        public void onCompletion(MediaPlayer x) { stopSong(); }
                    });
                    m.prepare();
                    m.start();
                } catch (Exception e) {
                    try { m.release(); } catch (Exception ignore) { }
                    throw e;
                }
                mp = m;
                setPlaying(true);
                return;
            } catch (Exception e) {
                host.toast("Using built-in synth");
            }
        }
        setPlaying(true);
        host.toast("Rendering...");
        final SeqModel.Project snap = song;
        new Thread(new Runnable() {
            public void run() {
                final short[] pcm = NoteSynth.render(snap);
                handler.post(new Runnable() {
                    public void run() {
                        if (!playing) return;
                        songPlayer.play(pcm, 0, pcm.length, NoteSynth.RATE, new PcmPlayer.Done() {
                            public void onDone() {
                                handler.post(new Runnable() { public void run() { if (loop && playing) startSong(); else stopSong(); } });
                            }
                        });
                    }
                });
            }
        }).start();
    }

    private void setPlaying(boolean on) {
        playing = on;
        playBtn.setImageResource(on ? R.drawable.ic_stop : R.drawable.ic_play_arrow);
        handler.removeCallbacks(playTick);
        if (on) handler.post(playTick); else roll.setPlayTick(-1);
    }

    private void stopSong() {
        if (mp != null) {
            try { mp.stop(); } catch (Exception ignore) { }
            try { mp.release(); } catch (Exception ignore) { }
            mp = null;
        }
        songPlayer.stop();
        if (playing) setPlaying(false);
    }

    // ------------------------------------------------------------------
    // open / save MIDI
    // ------------------------------------------------------------------

    private void loadSong(SeqModel.Project p) {
        song = p;
        roll.setProject(song);
        rebuildRack();
        updateHeader();
        updateTrackChip();
    }

    private void confirmDiscard(final Runnable next) {
        if (!dirty) { next.run(); return; }
        new AlertDialog.Builder(a, Ui.dialogTheme()).setTitle("Discard the current song?")
            .setMessage("Unsaved changes.")
            .setPositiveButton("Discard", new DialogInterface.OnClickListener() { public void onClick(DialogInterface d, int w) { next.run(); } })
            .setNegativeButton("Cancel", null).show();
    }

    private void loadMidiBytes(final byte[] data) {
        confirmDiscard(new Runnable() {
            public void run() {
                try {
                    stopSong();
                    loadSong(MidiIO.read(data));
                    dirty = false;
                    updateHeader();
                    showTab(TAB_ROLL);
                    host.toast("MIDI loaded: " + song.tracks.size() + " tracks, " + song.noteCount() + " notes");
                } catch (Exception e) {
                    host.toast("Could not open: " + e.getMessage());
                }
            }
        });
    }

    private void openMidiDevice() {
        host.pickDeviceFile(new String[]{"audio/midi", "audio/mid", "audio/x-midi", "audio/sp-midi", "application/x-midi", "application/octet-stream"},
            new ToolHost.FileSink() {
                public void onFile(File f, String name) { loadMidiBytes(readFile(f)); }
            });
    }

    private void openMidiRes() {
        final Vector items = host.listResourcesByExt(new String[]{"mid", "midi"});
        if (items.size() == 0) { host.toast("No .mid files in res/ yet"); return; }
        final String[] names = new String[items.size()];
        for (int i = 0; i < names.length; i++) names[i] = "res/" + items.elementAt(i);
        new AlertDialog.Builder(a, Ui.dialogTheme()).setTitle("Open MIDI from res").setItems(names, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface d, int which) { loadMidiBytes(host.readResource((String) items.elementAt(which))); }
        }).setNegativeButton("Cancel", null).show();
    }

    private void saveMidi() {
        try {
            saveDialog("song.mid", "audio/midi", MidiIO.write(song));
        } catch (Exception e) {
            host.toast("Could not build MIDI: " + e.getMessage());
        }
    }

    private void exportSongWav() {
        if (song.noteCount() == 0) { host.toast("Add some notes first"); return; }
        host.toast("Rendering...");
        final SeqModel.Project snap = song;
        new Thread(new Runnable() {
            public void run() {
                short[] pcm = NoteSynth.render(snap);
                final byte[] wav = AudioBuf.wav(pcm, NoteSynth.RATE, 16);
                handler.post(new Runnable() { public void run() { saveDialog("song.wav", "audio/wav", wav); } });
            }
        }).start();
    }

    /** Ask for a file name, then save into the project (res/), the app folder or anywhere on the device. */
    private void saveDialog(String defName, final String mime, final byte[] data) {
        final EditText f = Ui.field(a, "file name", defName);
        FrameLayout box = new FrameLayout(a);
        box.setPadding(Ui.dp(22), Ui.dp(8), Ui.dp(22), 0);
        box.addView(f);
        new AlertDialog.Builder(a, Ui.dialogTheme()).setTitle("Save " + humanSize(data.length)).setView(box)
            .setPositiveButton(host.hasProject() ? "Save in project" : "Save in app folder", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int w) {
                    String n = f.getText().toString().trim();
                    if (n.length() == 0) return;
                    String err = host.savePng(n, data);
                    host.toast(err.length() == 0 ? "Saved " + host.describeSave(n) : err);
                }
            })
            .setNeutralButton("Export...", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int w) {
                    String n = f.getText().toString().trim();
                    host.exportToDevice(n.length() == 0 ? "audio" : n, mime, data);
                }
            })
            .setNegativeButton("Cancel", null).show();
    }

    private static String humanSize(long b) {
        if (b < 1024) return b + " B";
        if (b < 1024 * 1024) return (b / 102) / 10f + " KB";
        return (b / (1024 * 102)) / 10f + " MB";
    }

    private static byte[] readFile(File f) {
        try {
            FileInputStream in = new FileInputStream(f);
            try {
                ByteArrayOutputStream o = new ByteArrayOutputStream();
                byte[] buf = new byte[16384];
                int n;
                while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
                return o.toByteArray();
            } finally { in.close(); }
        } catch (Exception e) {
            return null;
        }
    }

    // ------------------------------------------------------------------
    // clips: record, import, play
    // ------------------------------------------------------------------

    private AudioBuf.Clip clip() { return curClip >= 0 && curClip < clips.size() ? clips.get(curClip) : null; }

    private void addClip(AudioBuf.Clip c) {
        clips.add(c);
        curClip = clips.size() - 1;
        undoPcm = null;
        showClip();
        rebuildClips();
    }

    private void showClip() {
        AudioBuf.Clip c = clip();
        wave.setData(c == null ? null : c.pcm, c == null ? 22050 : c.rate);
        seekPos = -1;
        updateAudioInfo();
    }

    private void rebuildClips() {
        if (clipRow == null) return;
        clipRow.removeAllViews();
        if (clips.isEmpty()) {
            clipRow.addView(Ui.label(a, "No sounds yet", 12.5f, Ui.MUTED, false));
            return;
        }
        for (int i = 0; i < clips.size(); i++) {
            final int idx = i;
            AudioBuf.Clip c = clips.get(i);
            TextView p = pill(c.name + "  " + (Math.round(c.seconds() * 10f) / 10f) + "s", new View.OnClickListener() {
                public void onClick(View v) { stopClip(); curClip = idx; undoPcm = null; showClip(); rebuildClips(); }
            });
            style(p, i == curClip);
            add(clipRow, p);
        }
    }

    private void updateAudioInfo() {
        if (audioInfo == null) return;
        AudioBuf.Clip c = clip();
        if (c == null) {
            audioInfo.setText("Record or import a sound to start.");
            estimateText.setText("");
            return;
        }
        int from = wave.selStart(), to = wave.selEnd();
        String sel = wave.hasSelection() ? "  ·  selected " + secs(to - from, c.rate) : "";
        audioInfo.setText(c.name + "  ·  " + secs(c.pcm.length, c.rate) + "  ·  " + c.rate + " Hz" + sel);
        int outSamples = (int) ((long) (to - from) * outRate / Math.max(1, c.rate));
        long wavBytes = AudioBuf.wavSize(outSamples, outBits);
        long aacBytes = (long) (outSamples / (float) outRate * aacKbps * 1000 / 8);
        estimateText.setText("Result: WAV " + humanSize(wavBytes) + "   ·   AAC about " + humanSize(aacBytes) + "   (now " + humanSize(AudioBuf.wavSize(to - from, 16)) + ")");
    }

    private static String secs(int samples, int rate) {
        float s = samples / (float) Math.max(1, rate);
        int m = (int) (s / 60);
        float r = s - m * 60;
        return m + ":" + (r < 10 ? "0" : "") + (Math.round(r * 10f) / 10f);
    }

    private void toggleRecord() {
        if (recorder != null && recorder.isRecording()) { finishRecording(); return; }
        if (!host.hasMicPermission()) {
            host.requestMicPermission(new Runnable() { public void run() { startRecording(); } });
            return;
        }
        startRecording();
    }

    private void startRecording() {
        stopClip();
        stopSong();
        recorder = new VoiceRecorder(hiFiRec ? 44100 : 22050);
        if (!recorder.start()) {
            recorder = null;
            host.toast("Could not open the microphone");
            return;
        }
        recBtn.setText("Stop");
        handler.post(recTick);
    }

    private final Runnable recTick = new Runnable() {
        public void run() {
            VoiceRecorder r = recorder;
            if (r == null) return;
            if (!r.isRecording()) { finishRecording(); return; }
            recTime.setText(secs((int) (r.seconds() * r.rate()), r.rate()));
            level.setProgress(Math.min(100, r.peak() * 100 / 20000));
            handler.postDelayed(this, 80);
        }
    };

    private void finishRecording() {
        VoiceRecorder r = recorder;
        recorder = null;
        handler.removeCallbacks(recTick);
        recBtn.setText("Record");
        level.setProgress(0);
        if (r == null) return;
        short[] pcm = r.stop();
        if (pcm.length < r.rate() / 10) { host.toast("Recording was too short"); return; }
        recCount++;
        addClip(new AudioBuf.Clip("Voice " + recCount, pcm, r.rate()));
        host.toast("Recorded " + secs(pcm.length, r.rate()));
    }

    private void importAudio() {
        host.pickDeviceFile(new String[]{"audio/*", "application/ogg", "application/octet-stream"}, new ToolHost.FileSink() {
            public void onFile(final File f, final String name) {
                String l = name == null ? "" : name.toLowerCase();
                if (l.endsWith(".mid") || l.endsWith(".midi")) { loadMidiBytes(readFile(f)); return; }
                host.toast("Reading " + name + "...");
                new Thread(new Runnable() {
                    public void run() {
                        try {
                            String base = name == null ? "Sound" : name;
                            int dot = base.lastIndexOf('.');
                            if (dot > 0) base = base.substring(0, dot);
                            final AudioBuf.Clip c = AudioDecoder.decode(f, base.length() > 18 ? base.substring(0, 18) : base, 600);
                            handler.post(new Runnable() {
                                public void run() { addClip(c); host.toast("Loaded " + secs(c.pcm.length, c.rate)); }
                            });
                        } catch (final Exception e) {
                            handler.post(new Runnable() { public void run() { host.toast("Could not read the audio: " + e.getMessage()); } });
                        }
                    }
                }).start();
            }
        });
    }

    private void songToClip() {
        if (song.noteCount() == 0) { host.toast("Add some notes first"); return; }
        host.toast("Rendering...");
        final SeqModel.Project snap = song;
        new Thread(new Runnable() {
            public void run() {
                final short[] pcm = NoteSynth.render(snap);
                handler.post(new Runnable() { public void run() { addClip(new AudioBuf.Clip("Song", pcm, NoteSynth.RATE)); } });
            }
        }).start();
    }

    private final Runnable clipTick = new Runnable() {
        public void run() {
            if (!clipPlayer.isPlaying()) return;
            wave.setPlayhead(clipPlayer.position());
            handler.postDelayed(this, 40);
        }
    };

    private void toggleClipPlay() {
        if (clipPlayer.isPlaying()) { stopClip(); return; }
        AudioBuf.Clip c = clip();
        if (c == null) return;
        stopSong();
        int from = wave.hasSelection() ? wave.selStart() : Math.max(0, seekPos);
        int to = wave.hasSelection() ? wave.selEnd() : c.pcm.length;
        clipPlayBtn.setText("Stop");
        clipPlayer.play(c.pcm, from, to, c.rate, new PcmPlayer.Done() {
            public void onDone() { handler.post(new Runnable() { public void run() { stopClip(); } }); }
        });
        handler.post(clipTick);
    }

    private void stopClip() {
        clipPlayer.stop();
        handler.removeCallbacks(clipTick);
        if (clipPlayBtn != null) clipPlayBtn.setText("Play");
        if (wave != null) wave.setPlayhead(-1);
    }

    // ------------------------------------------------------------------
    // editing sound
    // ------------------------------------------------------------------

    private void remember() {
        AudioBuf.Clip c = clip();
        if (c == null) return;
        undoPcm = c.pcm;
        undoRate = c.rate;
        undoClip = curClip;
    }

    private void replacePcm(short[] pcm) {
        AudioBuf.Clip c = clip();
        if (c == null) return;
        stopClip();
        remember();
        c.pcm = pcm;
        wave.refreshData(pcm);
        rebuildClips();
        updateAudioInfo();
    }

    private boolean needClip() {
        if (clip() == null) { host.toast("Record or import a sound first"); return false; }
        return true;
    }

    private void editKeep() {
        if (!needClip()) return;
        if (!wave.hasSelection()) { host.toast("Select a part of the wave first"); return; }
        replacePcm(AudioBuf.slice(clip().pcm, wave.selStart(), wave.selEnd()));
        wave.fit();
    }

    private void editDelete() {
        if (!needClip()) return;
        if (!wave.hasSelection()) { host.toast("Select a part of the wave first"); return; }
        replacePcm(AudioBuf.cut(clip().pcm, wave.selStart(), wave.selEnd()));
    }

    private short[] workCopy() {
        AudioBuf.Clip c = clip();
        return wave.hasSelection() ? AudioBuf.slice(c.pcm, wave.selStart(), wave.selEnd()) : c.pcm.clone();
    }

    /** Put an edited copy of the selection (or everything) back into the sound. */
    private void putBack(short[] part) {
        AudioBuf.Clip c = clip();
        if (!wave.hasSelection()) { replacePcm(part); return; }
        int a0 = wave.selStart(), b0 = wave.selEnd();
        short[] out = new short[c.pcm.length - (b0 - a0) + part.length];
        System.arraycopy(c.pcm, 0, out, 0, a0);
        System.arraycopy(part, 0, out, a0, part.length);
        System.arraycopy(c.pcm, b0, out, a0 + part.length, c.pcm.length - b0);
        replacePcm(out);
    }

    private void editNormalize() {
        if (!needClip()) return;
        short[] p = workCopy();
        AudioBuf.normalize(p, 0.95f);
        putBack(p);
    }

    private void editFade() {
        if (!needClip()) return;
        short[] p = workCopy();
        AudioBuf.fade(p, clip().rate, 150, 250);
        putBack(p);
    }

    private void editReverse() {
        if (!needClip()) return;
        short[] p = workCopy();
        for (int i = 0; i < p.length / 2; i++) { short t = p[i]; p[i] = p[p.length - 1 - i]; p[p.length - 1 - i] = t; }
        putBack(p);
    }

    private void editTrimSilence() {
        if (!needClip()) return;
        AudioBuf.Clip c = clip();
        short[] t = AudioBuf.trimSilence(c.pcm, c.rate, 1.5f);
        if (t.length == c.pcm.length) { host.toast("No silence at the start or end"); return; }
        replacePcm(t);
        wave.fit();
    }

    private void editUndo() {
        if (undoPcm == null || undoClip != curClip || clip() == null) { host.toast("Nothing to undo"); return; }
        stopClip();
        AudioBuf.Clip c = clip();
        short[] now = c.pcm;
        int nowRate = c.rate;
        c.pcm = undoPcm;
        c.rate = undoRate;
        undoPcm = now;
        undoRate = nowRate;
        showClip();
        rebuildClips();
    }

    private void deleteClip() {
        if (!needClip()) return;
        stopClip();
        clips.remove(curClip);
        curClip = clips.isEmpty() ? -1 : Math.min(curClip, clips.size() - 1);
        undoPcm = null;
        showClip();
        rebuildClips();
    }

    // ---------------------------------------------------------------- split

    private void addParts(String base, int rate, ArrayList<short[]> parts) {
        int first = clips.size();
        for (int i = 0; i < parts.size(); i++) clips.add(new AudioBuf.Clip(base + " " + (i + 1), parts.get(i), rate));
        if (parts.isEmpty()) return;
        curClip = first;
        undoPcm = null;
        showClip();
        rebuildClips();
        host.toast(parts.size() + " parts created");
    }

    private void splitAtSelection() {
        if (!needClip()) return;
        if (!wave.hasSelection()) { host.toast("Select a part first"); return; }
        AudioBuf.Clip c = clip();
        ArrayList<short[]> parts = new ArrayList<short[]>();
        int a0 = wave.selStart(), b0 = wave.selEnd();
        if (a0 > 0) parts.add(AudioBuf.slice(c.pcm, 0, a0));
        parts.add(AudioBuf.slice(c.pcm, a0, b0));
        if (b0 < c.pcm.length) parts.add(AudioBuf.slice(c.pcm, b0, c.pcm.length));
        addParts(c.name, c.rate, parts);
    }

    private void splitEqualDialog() {
        if (!needClip()) return;
        askNumber("Split into how many equal parts?", 4, 2, 64, new IntCb() {
            public void got(int n) {
                AudioBuf.Clip c = clip();
                ArrayList<short[]> parts = new ArrayList<short[]>();
                for (int i = 0; i < n; i++) parts.add(AudioBuf.slice(c.pcm, (int) ((long) c.pcm.length * i / n), (int) ((long) c.pcm.length * (i + 1) / n)));
                addParts(c.name, c.rate, parts);
            }
        });
    }

    private void splitSilenceDialog() {
        if (!needClip()) return;
        final EditText th = Ui.field(a, "Silence level %", "2");
        th.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        final EditText gap = Ui.field(a, "Silence length ms", "300");
        gap.setInputType(InputType.TYPE_CLASS_NUMBER);
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(Ui.dp(20), Ui.dp(8), Ui.dp(20), 0);
        box.addView(Ui.labeled(a, "Silence threshold (%)", th));
        box.addView(Ui.labeled(a, "Min. silence gap (ms)", gap));
        new AlertDialog.Builder(a, Ui.dialogTheme()).setTitle("Split on silence").setView(box)
            .setPositiveButton("Split", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int w) {
                    float pct = 2f;
                    int ms = 300;
                    try { pct = Float.parseFloat(th.getText().toString().trim()); } catch (NumberFormatException ignore) { }
                    try { ms = Integer.parseInt(gap.getText().toString().trim()); } catch (NumberFormatException ignore) { }
                    AudioBuf.Clip c = clip();
                    ArrayList<int[]> ranges = AudioBuf.splitOnSilence(c.pcm, c.rate, pct, Math.max(20, ms), 100);
                    if (ranges.size() < 2) { host.toast("No gaps found - try a higher level"); return; }
                    ArrayList<short[]> parts = new ArrayList<short[]>();
                    for (int i = 0; i < ranges.size(); i++) parts.add(AudioBuf.slice(c.pcm, ranges.get(i)[0], ranges.get(i)[1]));
                    addParts(c.name, c.rate, parts);
                }
            }).setNegativeButton("Cancel", null).show();
    }

    private void saveAllZip() {
        if (clips.isEmpty()) { host.toast("No sounds to save"); return; }
        try {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            ZipOutputStream z = new ZipOutputStream(bo);
            for (int i = 0; i < clips.size(); i++) {
                AudioBuf.Clip c = clips.get(i);
                short[] p = AudioBuf.resample(c.pcm, c.rate, outRate);
                z.putNextEntry(new ZipEntry(c.name.replace('/', '_') + ".wav"));
                z.write(AudioBuf.wav(p, outRate, outBits));
                z.closeEntry();
            }
            z.close();
            saveDialog("sounds.zip", "application/zip", bo.toByteArray());
        } catch (Exception e) {
            host.toast("ZIP failed: " + e.getMessage());
        }
    }

    // ---------------------------------------------------------------- compress

    /** The selection (or whole sound) at the chosen sample rate with the chosen clean-ups. */
    private short[] processed() {
        AudioBuf.Clip c = clip();
        short[] p = workCopy();
        if (optTrimSilence) p = AudioBuf.trimSilence(p, c.rate, 1.5f);
        p = AudioBuf.resample(p, c.rate, outRate);
        if (optNormalize) AudioBuf.normalize(p, 0.95f);
        return p;
    }

    private String baseName() {
        AudioBuf.Clip c = clip();
        return (c == null ? "sound" : c.name.trim().replace(' ', '_')).toLowerCase();
    }

    private void applyReduce() {
        if (!needClip()) return;
        AudioBuf.Clip c = clip();
        short[] p = processed();
        stopClip();
        remember();
        c.pcm = p;
        c.rate = outRate;
        showClip();
        rebuildClips();
        host.toast("Sound reduced to " + outRate + " Hz");
    }

    private void saveWav() {
        if (!needClip()) return;
        saveDialog(baseName() + ".wav", "audio/wav", AudioBuf.wav(processed(), outRate, outBits));
    }

    private void saveAac() {
        if (!needClip()) return;
        final short[] p = processed();
        host.toast("Compressing...");
        new Thread(new Runnable() {
            public void run() {
                try {
                    File tmp = new File(a.getCacheDir(), "encode.m4a");
                    AacEncoder.encode(p, outRate, aacKbps * 1000, tmp);
                    final byte[] data = readFile(tmp);
                    tmp.delete();
                    handler.post(new Runnable() { public void run() { saveDialog(baseName() + ".m4a", "audio/mp4", data); } });
                } catch (final Exception e) {
                    handler.post(new Runnable() { public void run() { host.toast("AAC failed: " + e.getMessage()); } });
                }
            }
        }).start();
    }

    // ---------------------------------------------------------------- audio -> midi

    private void convertToMidi() {
        if (!needClip()) return;
        final AudioBuf.Clip c = clip();
        final short[] part = workCopy();
        if (part.length < c.rate / 4) { host.toast("The sound is too short"); return; }
        final int bpm = song.bpm;
        final int grid = SNAP_TICKS[quantIdx];
        final int minMs = minNoteMs;
        final float sensitivity = sens / 100f;
        convCancel = false;
        final ProgressBar pb = new ProgressBar(a, null, android.R.attr.progressBarStyleHorizontal);
        pb.setMax(100);
        LinearLayout box = new LinearLayout(a);
        box.setPadding(Ui.dp(24), Ui.dp(16), Ui.dp(24), Ui.dp(4));
        box.addView(pb, Ui.lp(Ui.MATCH, Ui.WRAP));
        final AlertDialog dlg = new AlertDialog.Builder(a, Ui.dialogTheme()).setTitle("Finding notes...").setView(box)
            .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int w) { convCancel = true; }
            }).setCancelable(false).create();
        dlg.show();
        new Thread(new Runnable() {
            public void run() {
                final ArrayList<SeqModel.Note> notes = PitchTracker.detect(part, c.rate, bpm, sensitivity, minMs, grid, new PitchTracker.Progress() {
                    public boolean update(final int pct) {
                        handler.post(new Runnable() { public void run() { pb.setProgress(pct); } });
                        return !convCancel;
                    }
                });
                handler.post(new Runnable() {
                    public void run() {
                        try { dlg.dismiss(); } catch (Exception ignore) { }
                        if (convCancel) return;
                        if (notes.isEmpty()) {
                            host.toast("No melody found - try more sensitivity");
                            return;
                        }
                        SeqModel.Track t = song.addTrack("Audio " + (song.tracks.size() + 1), convProgram, false);
                        t.notes.addAll(notes);
                        song.fitBars();
                        dirty = true;
                        roll.setTrack(song.tracks.size() - 1);
                        roll.scrollToTick(0);
                        updateHeader();
                        rebuildRack();
                        showTab(TAB_ROLL);
                        host.toast(notes.size() + " notes found - edit them in the piano roll");
                    }
                });
            }
        }).start();
    }

    // ------------------------------------------------------------------
    // small dialogs
    // ------------------------------------------------------------------

    private void askNumber(String title, int initial, final int min, final int max, final IntCb cb) {
        final EditText f = Ui.field(a, title, String.valueOf(initial));
        f.setInputType(InputType.TYPE_CLASS_NUMBER);
        FrameLayout box = new FrameLayout(a);
        box.setPadding(Ui.dp(22), Ui.dp(8), Ui.dp(22), 0);
        box.addView(f);
        new AlertDialog.Builder(a, Ui.dialogTheme()).setTitle(title).setView(box)
            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int w) {
                    int v;
                    try { v = Integer.parseInt(f.getText().toString().trim()); } catch (NumberFormatException e) { return; }
                    cb.got(Math.max(min, Math.min(max, v)));
                }
            }).setNegativeButton("Cancel", null).show();
    }

    private void askText(String title, String initial, final StrCb cb) {
        final EditText f = Ui.field(a, title, initial);
        FrameLayout box = new FrameLayout(a);
        box.setPadding(Ui.dp(22), Ui.dp(8), Ui.dp(22), 0);
        box.addView(f);
        new AlertDialog.Builder(a, Ui.dialogTheme()).setTitle(title).setView(box)
            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int w) { cb.got(f.getText().toString()); }
            }).setNegativeButton("Cancel", null).show();
    }

    // ------------------------------------------------------------------
    // lifecycle
    // ------------------------------------------------------------------

    private boolean hasWork() { return dirty || !clips.isEmpty(); }

    private void stopAll() {
        stopSong();
        stopClip();
        auditPlayer.stop();
        if (recorder != null) finishRecording();
    }

    /** App went to the background: stop sound; a running recording is kept as a sound. */
    public void pause() { stopAll(); }

    /** Called when the screen is replaced. */
    public void release() {
        stopAll();
        handler.removeCallbacksAndMessages(null);
    }

    public void requestExit() {
        stopAll();
        if (!hasWork()) { host.exit(); return; }
        new AlertDialog.Builder(a, Ui.dialogTheme()).setTitle("Leave Audio Studio?")
            .setMessage("Not saved yet. Save a MIDI or WAV first.")
            .setPositiveButton("Leave", new DialogInterface.OnClickListener() { public void onClick(DialogInterface d, int w) { host.exit(); } })
            .setNegativeButton("Stay", null).show();
    }
}
