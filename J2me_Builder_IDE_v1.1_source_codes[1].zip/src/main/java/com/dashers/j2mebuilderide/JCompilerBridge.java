package com.dashers.j2mebuilderide;

import android.content.Context;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.ByteArrayInputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.Vector;

import com.dashers.j2mebuilderide.compiler.CompileError;
import com.dashers.j2mebuilderide.compiler.Compiler;
import com.dashers.j2mebuilderide.ide.Project;
import com.dashers.j2mebuilderide.ide.ProjectManager;

/**
 * Flat facade over the compiler/ide packages, written specifically to be
 * easy to call from Sketchware Pro blocks: every method takes and returns
 * plain types (String, boolean, int) rather than requiring blocks to pass
 * Project/ProjectManager objects around between block calls, since
 * Sketchware's block editor makes juggling custom object references
 * across blocks awkward.
 *
 * Typical wiring in Sketchware Pro:
 *   1. In your MainActivity (or an Application subclass) onCreate, call
 *      JCompilerBridge.init(this) once.
 *   2. Add a "Projects" Activity: call listProjects()/createProject()/
 *      deleteProject() from button-click blocks.
 *   3. Add an "Editor" Activity: call readFile()/writeFile() to load/save
 *      the text in an EditText, and compileFile() when the user taps
 *      Compile. Show its return value (or getLastCompileError()) in a
 *      TextView/dialog.
 *   4. Add a "Package" button on the project screen: call
 *      packageProject() and show its return value.
 *
 * If you need something this facade doesn't expose, the full
 * ProjectManager/Project/Compiler classes are still there to call
 * directly -- this class is a convenience layer, not a restriction.
 */
public class JCompilerBridge {

    private JCompilerBridge() {}

    private static boolean apiInitialized = false;
    private static Context appContext;
    private static String lastError = "";

    /** Call once, before anything else in this class, typically from your
     *  first Activity's onCreate(). Loads api_index_core.txt from the
     *  app's assets/ folder, and sets a default, always-writable projects
     *  folder under the app's own external files directory (no runtime
     *  storage permission needed for this location on any Android
     *  version) unless setProjectsRoot() has already been called with
     *  something else. Safe to call more than once. */
    public static void init(Context context) {
        appContext = context.getApplicationContext();
        com.dashers.j2mebuilderide.ide.EcjMessages.init(context);
        com.dashers.j2mebuilderide.ide.EcjLoader.init(context);
        com.dashers.j2mebuilderide.ide.ProGuardPreverifier.init(context);
        if (!apiInitialized) {
            try {
                InputStream in = context.getAssets().open("api_index_core.txt");
                try {
                    Compiler.initApiIndex(in);
                    apiInitialized = true;
                } finally {
                    in.close();
                }
            } catch (IOException e) {
                lastError = "Could not load api_index_core.txt from assets/: " + e.getMessage();
            } catch (CompileError e) {
                lastError = "Could not load api_index_core.txt: " + e.getMessage();
            }
        }

        if (apiInitialized) {
            // J2ME SDK API: assets/j2me-sdk-api.jar, else the decompressed assets/j2me/api/ folder.
            byte[] apiZip = com.dashers.j2mebuilderide.ide.ApiAssets.loadZipBytes(context);
            if (apiZip == null) {
                lastError = "J2ME SDK API not found (assets/j2me-sdk-api.jar or assets/j2me/api/)";
            } else {
                try {
                    // Built-in compiler: add API classes api_index_core.txt does not describe.
                    com.dashers.j2mebuilderide.ide.ApiAssets.fillIndex(Compiler.apiIndex(), apiZip);
                } catch (CompileError e) {
                    lastError = "Could not index J2ME SDK API: " + e.getMessage();
                }
                try {
                    com.dashers.j2mebuilderide.compiler.EcjCompiler.initApi(new java.io.ByteArrayInputStream(apiZip));
                } catch (IOException e) {
                    lastError = "Could not load embedded J2ME API: " + e.getMessage();
                }
            }
        }

        if (projectsRoot == null) {
            // getWritableRoot()'s System.getProperty("user.home") fallback
            // does NOT behave like a desktop JVM on Android -- it commonly
            // returns "/" (the filesystem root) rather than null, which
            // silently produced an unwritable path like "/JCompiler/
            // projects/" with no storage prefix at all. No amount of
            // granting storage permission or manually creating folders
            // elsewhere on the device's storage could fix that, because
            // the app was never even looking there -- it was trying (and
            // failing) to create a folder at the true OS root, which only
            // root/system can write to.
            //
            // getExternalFilesDir(null) is the reliable fix: it's a real,
            // app-specific folder on the device's shared/external storage
            // (typically
            // /storage/emulated/0/Android/data/com.dashers.j2mebuilderide/files)
            // that this app can always read/write without any runtime
            // permission at all, on every Android version from 5 through
            // 10 (and beyond). Projects won't be visible to other apps'
            // file browsers under this path, but they will actually work,
            // which the previous default did not.
            File extDir = context.getExternalFilesDir(null);
            String base = (extDir != null) ? extDir.getPath() : context.getFilesDir().getPath();
            setProjectsRoot(base + "/JCompiler/projects/");
        }
    }

    /** True once init() has successfully loaded the API index. Check this
     *  (or that compileFile()/packageProject() didn't immediately fail)
     *  before letting the user compile anything. */
    public static boolean isReady() {
        return apiInitialized;
    }

    /** Returns the projects root this bridge is currently using, creating
     *  it (and any missing parent folders) if it doesn't exist yet. Call
     *  setProjectsRoot() first if you don't want the default location. */
    private static String projectsRoot = null;

    /** Sets the folder under which all projects are stored, e.g.
     *  context.getExternalFilesDir(null).getPath() + "/projects/", or a
     *  path under a user-picked Storage Access Framework tree. Call this
     *  before any other method that touches projects. */
    public static void setProjectsRoot(String path) {
        if (!path.endsWith("/")) path = path + "/";
        projectsRoot = path;
        pm = new ProjectManager(projectsRoot);
    }

    private static ProjectManager pm;
    private static Project current;

    private static ProjectManager pm() {
        if (pm == null) {
            // Reaching here means a project method was called before
            // init(context) ran. There's no Context available at this
            // point to derive a real writable folder (see the comment in
            // init() about why System.getProperty("user.home") can't be
            // trusted on Android), so rather than silently falling back
            // to a path that might not be writable, fail loudly -- this
            // is a call-order bug in the caller, not a permissions
            // problem, and should be fixed by calling init() first.
            throw new IllegalStateException(
                "JCompilerBridge.init(context) must be called before any project method.");
        }
        return pm;
    }

    /** Comma-separated project names. Empty string if none / not
     *  accessible yet. Sketchware's blocks can split this on "," to fill
     *  a ListView. */
    public static String listProjects() {
        Vector names = pm().listProjectNames();
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < names.size(); i++) {
            if (i > 0) sb.append(",");
            sb.append((String) names.elementAt(i));
        }
        return sb.toString();
    }

    /** Creates a new project (with a starter Hello-world MIDlet source
     *  file) and makes it the "current" project for the other methods
     *  below. Returns "" on success, or an error message on failure. */
    public static String createProject(String name) {
        try {
            pm().ensureRoot();
            current = pm().createProject(name);
            return "";
        } catch (IOException e) {
            return "Could not create project: " + e.getMessage();
        }
    }

    /** Like createProject(name) but without the default-package starter file. */
    public static String createProjectBare(String name) {
        try {
            pm().ensureRoot();
            current = pm().createProject(name, false);
            return "";
        } catch (IOException e) {
            return "Could not create project: " + e.getMessage();
        }
    }

    /** Opens an existing project by folder name and makes it "current".
     *  Returns "" on success, or an error message on failure. */
    public static String openProject(String name) {
        try {
            current = pm().openProject(name);
            return "";
        } catch (IOException e) {
            return "Could not open project: " + e.getMessage();
        }
    }

    /** Deletes a project folder and everything in it. Returns "" on
     *  success, or an error message on failure. */
    public static String deleteProject(String name) {
        try {
            pm().deleteProject(name);
            if (current != null && name.equals(current.folderName)) { invalidateBuildCache(); current = null; }
            return "";
        } catch (IOException e) {
            return "Could not delete project: " + e.getMessage();
        }
    }

    /** Comma-separated .java file names in the current project's src/. */
    public static String listSourceFiles() {
        if (current == null) return "";
        Vector names = pm().listSourceFiles(current);
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < names.size(); i++) {
            if (i > 0) sb.append(",");
            sb.append((String) names.elementAt(i));
        }
        return sb.toString();
    }

    /** Reads a source file's full text (e.g. into an EditText). Returns
     *  "" if it doesn't exist or can't be read -- check listSourceFiles()
     *  first if you need to distinguish "empty file" from "missing". */
    public static String readFile(String fileName) {
        if (current == null) return "";
        try {
            byte[] data = Project.readWholeFile(current.srcUrl() + fileName);
            return (data != null) ? new String(data, "UTF-8") : "";
        } catch (IOException e) {
            return "";
        }
    }

    /** Writes a source file's full text. Returns "" on success, or an
     *  error message on failure. */
    public static String writeFile(String fileName, String content) {
        if (current == null) return "No project open";
        try {
            Project.writeWholeFile(current.srcUrl() + fileName, content.getBytes("UTF-8"));
            return "";
        } catch (IOException e) {
            return "Could not save file: " + e.getMessage();
        }
    }

    /** Compiles ONE source file within the current project (matching the
     *  original app's per-file Compile command) and writes its .class
     *  file(s) to bin/ on success. Returns a human-readable result string
     *  suitable for showing directly in a TextView/dialog -- either
     *  "Compiled OK\n..." or "Compile failed\n...". Use
     *  getLastCompileErrorLine() afterward if you want to highlight the
     *  offending line in your editor's EditText. */
    public static String compileFile(String fileName) {
        if (current == null) return "No project open";
        if (!apiInitialized) return "API index not loaded -- call JCompilerBridge.init(context) first";

        lastCompileErrorLine = -1;
        try {
            Vector siblingNames = pm().listSourceFiles(current);
            Compiler.ProjectFile[] fileArr = new Compiler.ProjectFile[siblingNames.size()];
            for (int i = 0; i < siblingNames.size(); i++) {
                String name = (String) siblingNames.elementAt(i);
                Compiler.ProjectFile pf = new Compiler.ProjectFile();
                pf.fileName = name;
                byte[] data = Project.readWholeFile(current.srcUrl() + name);
                pf.source = (data != null) ? new String(data, "UTF-8") : "";
                fileArr[i] = pf;
            }

            Compiler.ProjectResult unit = compileWithEcj(fileArr, current);

            StringBuffer written = new StringBuffer();
            int count = 0;
            for (int ci = 0; ci < unit.classBytes.length; ci++) {
                if (!fileName.equals(unit.fileNames[ci])) continue;
                String className = unit.names[ci];
                byte[] classBytes = unit.classBytes[ci];
                Project.writeWholeFile(current.binUrl() + className + ".class", classBytes);
                if (count > 0) written.append(", ");
                written.append(className).append(".class (").append(classBytes.length).append(" bytes)");
                count++;
            }
            return "Compiled OK\n" + written + "\nsaved to project bin/";

        } catch (CompileError ce) {
            lastCompileErrorLine = ce.line;
            String snippet = CompileError.sourceLine(readFile(fileName), ce.line);
            String msg = "Compile failed\nLine " + ce.line + ":\n" + ce.getMessage();
            if (snippet.length() > 0) msg = msg + "\n\n> " + snippet;
            if (ce.hint != null) msg = msg + "\n\nhint: " + ce.hint;
            return msg;
        } catch (IOException ioe) {
            return "Compile failed\nCould not write output:\n" + ioe.getMessage();
        } catch (RuntimeException re) {
            return "Compile failed\nInternal compiler error:\n" + re;
        }
    }

    private static int lastCompileErrorLine = -1;

    /** Line number (1-based) of the last compile error, or -1 if the last
     *  compileFile() call succeeded or none has run yet. */
    public static int getLastCompileErrorLine() {
        return lastCompileErrorLine;
    }

    /** Packages the current project into <name>.jar and <name>.jad in the
     *  project folder. Returns a human-readable result string suitable
     *  for showing directly in a TextView/dialog. Compile each source
     *  file first (via compileFile()) -- this does not compile for you,
     *  matching the original app's Package command. */
    public static String packageProject() {
        if (current == null) return "No project open";
        ProjectManager.PackageResult r = pm().packageProject(current);
        return r.message;
    }

    /** True if the current project's last packageProject() call
     *  succeeded. Call packageProject() first. */
    private static boolean lastPackageOk = false;

    /** Project property getters/setters, for a Properties screen. Call
     *  saveProperties() after any set* call to persist it to disk. */
    public static String getVendor() { return current != null ? current.vendor : ""; }
    public static String getVersion() { return current != null ? current.version : ""; }
    public static String getMainClass() { return current != null ? current.mainClass : ""; }
    public static String getMainClassFqcn() {
        if (current == null) return "";
        return current.packageName.length() > 0 ? current.packageName + "." + current.mainClass : current.mainClass;
    }
    public static String getIcon() { return current != null ? current.icon : ""; }
    public static String getPermissions() { return current != null ? current.permissions : ""; }
    public static String getPermissionsOpt() { return current != null ? current.permissionsOpt : ""; }
    public static String getDescription() { return current != null ? current.description : ""; }
    public static String getInfoUrl() { return current != null ? current.infoUrl : ""; }
    public static String getInstallNotify() { return current != null ? current.installNotify : ""; }
    public static String getDeleteNotify() { return current != null ? current.deleteNotify : ""; }
    public static int getDataSize() { return current != null ? current.dataSize : 0; }
    public static String getNokiaCategory() { return current != null ? current.nokiaCategory : "Application"; }
    public static String getNokiaName() { return current != null ? current.nokiaName : ""; }
    public static String getPushRegistration() { return current != null ? current.pushRegistration : ""; }

    public static void setVendor(String v) { if (current != null) current.vendor = v; }
    public static void setVersion(String v) { if (current != null) current.version = v; }
    public static void setMainClass(String v) { if (current != null) current.mainClass = v; }
    public static void setIcon(String v) { if (current != null) current.icon = v; }
    public static void setPermissions(String v) { if (current != null) current.permissions = v; }
    public static void setPermissionsOpt(String v) { if (current != null) current.permissionsOpt = v; }
    public static void setDescription(String v) { if (current != null) current.description = v; }
    public static void setInfoUrl(String v) { if (current != null) current.infoUrl = v; }
    public static void setInstallNotify(String v) { if (current != null) current.installNotify = v; }
    public static void setDeleteNotify(String v) { if (current != null) current.deleteNotify = v; }
    public static void setDataSize(int v) { if (current != null) current.dataSize = Math.max(0, v); }
    public static void setNokiaCategory(String v) { if (current != null) current.nokiaCategory = v; }
    public static void setNokiaName(String v) { if (current != null) current.nokiaName = v; }
    public static void setPushRegistration(String v) { if (current != null) current.pushRegistration = v; }

    /** Persists whatever setVendor()/setVersion()/etc. calls were made
     *  above. Returns "" on success, or an error message on failure. */
    public static String saveProperties() {
        if (current == null) return "No project open";
        try {
            current.save();
            return "";
        } catch (IOException e) {
            return "Could not save properties: " + e.getMessage();
        }
    }

    /** Human-readable message from the last init() failure, if any. */
    public static String getLastError() {
        return lastError;
    }

    // ------------------------------------------------------------------
    // Extra API used by the real UI (MainActivity)
    // ------------------------------------------------------------------

    /** One compiler error. */
    public static class Problem {
        public String file = "";
        public int line = -1;
        public String message = "";
        public String snippet = "";
        public String hint = "";
        /** 1-based column range of the error on its line (0 = unknown) and a ready-made "   ^^^" marker line. */
        public int col, endCol;
        public String caret = "";
        public String category = "";
    }

    /** Receives each build step while compileAll runs (called on the build thread). */
    public interface Progress { void step(String text, int level); }
    public static final int L_TEXT = 0, L_OK = 1, L_WARN = 2, L_MUTED = 3, L_ERR = 4;

    private static void say(Progress pg, String text, int level) { if (pg != null) pg.step(text, level); }

    private static String rawLine(String src, int line) {
        if (src == null || line <= 0) return "";
        int cur = 1, start = 0;
        for (int i = 0; i <= src.length(); i++) {
            if (i == src.length() || src.charAt(i) == '\n') {
                if (cur == line) return src.substring(start, i).replace("\r", "");
                cur++;
                start = i + 1;
            }
        }
        return "";
    }

    /** Result of compileAll(): problems, warnings and a printable message. */
    public static class BuildResult {
        public boolean ok;
        public String message = "";
        public String file = "";          // first error's file
        public int line = -1;             // first error's line
        public Vector problems = new Vector();   // Problem
        public Vector warnings = new Vector();   // Lint.Warning (line 0 = project-level)
        public int fileCount;
        public int classCount;
        /** Library lines for the build log ("M3G (JSR-184) - 19 classes", "foo.jar - ..."). */
        public Vector libsLoaded = new Vector();
        public Vector libsMissing = new Vector();
        public String jarPath = "";
        public String packageMessage = "";
        /** "How to fix" lines for a failed build (empty on success). */
        public Vector buildTips = new Vector();
        public boolean ecjFellBack;
        /** Classes that went through the ProGuard preverifier / classes it could not handle. */
        public int preverified, preverifyFailed;
        /** True when the smart build found nothing changed and reused the previous compile. */
        public boolean reused;
        /** Wall-clock time of the whole compileAll call, in milliseconds. */
        public long millis;
        /** Size of the packaged .jar in bytes (0 when no jar was built). */
        public long jarBytes;
    }

    /** Preverify step of a .jar build. ECJ output has no CLDC StackMap and may contain jsr/ret, so it goes through
     *  ProGuard-core (ide/ProGuardPreverifier). The built-in compiler already writes a StackMap itself. Never throws:
     *  a class that cannot be preverified keeps its bytes and is reported as a warning. */
    private static void preverifyUnit(Compiler.ProjectResult unit, boolean usedEcj, BuildResult r, Progress pg) {
        try {
            if (!usedEcj) {
                say(pg, "Preverify: the built-in compiler already wrote the CLDC StackMap (no extra pass needed).", L_OK);
                return;
            }
            if (appContext != null && !new com.dashers.j2mebuilderide.ide.AppSettings(appContext).proguardPreverify()) {
                say(pg, "Preverify: ProGuard preverifier is off (Settings > Build). ECJ classes carry no CLDC StackMap - "
                        + "emulators run them, real phones may reject them.", L_WARN);
                return;
            }
            say(pg, "Preverifying " + unit.classBytes.length + " class(es) with ProGuard-core 9.1.1 ...", L_TEXT);
            java.io.File[] a = com.dashers.j2mebuilderide.ide.Libraries.jars(current, false);
            java.io.File[] b = com.dashers.j2mebuilderide.ide.Libraries.jars(current, true);
            java.io.File[] all = new java.io.File[a.length + b.length];
            System.arraycopy(a, 0, all, 0, a.length);
            System.arraycopy(b, 0, all, a.length, b.length);
            // like TK's  -libraryjars cldcapi11.jar midpapi20.jar jsr*.jar : the real J2ME API jars from assets/j2me/jars/
            byte[] apiZip = appContext == null ? null : com.dashers.j2mebuilderide.ide.ApiAssets.loadPreverifyZipBytes(appContext);
            if (apiZip != null) {
                say(pg, "Preverify classpath: real CLDC 1.1 + MIDP 2.0 jars (+ JSR 75/184/226/234/238/239, MMAPI) + your project libraries", L_MUTED);
            } else {
                apiZip = appContext == null ? null : com.dashers.j2mebuilderide.ide.ApiAssets.loadZipBytes(appContext);
                say(pg, "Preverify classpath: bundled J2ME API (assets/j2me/jars/ not found)", L_WARN);
            }
            com.dashers.j2mebuilderide.ide.ProGuardPreverifier.Result pv =
                    com.dashers.j2mebuilderide.ide.ProGuardPreverifier.run(unit.names, unit.classBytes, apiZip, all);
            r.preverified = pv.ok;
            r.preverifyFailed = pv.failed;
            if (pv.ran && pv.failed == 0) {
                say(pg, pv.note, L_OK);
                return;
            }
            say(pg, pv.note + (pv.ran ? "" : "  Classes were left without a StackMap."), L_WARN);
            for (int i = 0; i < pv.errors.size(); i++) say(pg, "  " + pv.errors.elementAt(i), L_MUTED);
            com.dashers.j2mebuilderide.ide.Lint.Warning w = new com.dashers.j2mebuilderide.ide.Lint.Warning();
            w.file = "";
            w.line = 0;
            w.message = pv.ran ? "Preverify: " + pv.failed + " class(es) could not be preverified - real phones may reject them"
                    : pv.note;
            r.warnings.addElement(w);
        } catch (Throwable t) {
            say(pg, "Preverify skipped: " + t, L_WARN);
        }
    }

    /** Shared ECJ backend used by compileFile/compileAll. Legacy Compiler remains available
     *  as the fallback if the embedded ECJ assets are unavailable. Source errors are
     *  never silently retried through the legacy parser. */
    private static Compiler.ProjectResult compileWithEcj(Compiler.ProjectFile[] files, Project project) throws CompileError {
        java.io.File[] a = com.dashers.j2mebuilderide.ide.Libraries.jars(project, false);
        java.io.File[] b = com.dashers.j2mebuilderide.ide.Libraries.jars(project, true);
        java.io.File[] all = new java.io.File[a.length + b.length];
        System.arraycopy(a, 0, all, 0, a.length);
        System.arraycopy(b, 0, all, a.length, b.length);
        if (com.dashers.j2mebuilderide.compiler.EcjCompiler.isInitialized()) {
            return com.dashers.j2mebuilderide.compiler.EcjCompiler.compileProject(files, all);
        }
        if (!com.dashers.j2mebuilderide.compiler.EcjCompiler.isAvailable()) {
            lastError = "ECJ library not packaged; using built-in compiler";
            return Compiler.compileProject(files);
        }
        if (appContext == null) throw new CompileError("JCompilerBridge.init(context) must be called first", 0);
        byte[] apiZip = com.dashers.j2mebuilderide.ide.ApiAssets.loadZipBytes(appContext);
        if (apiZip == null) {
            lastError = "Embedded J2ME API not found; using built-in compiler";
            return Compiler.compileProject(files);
        }
        return com.dashers.j2mebuilderide.compiler.EcjCompiler.compileProject(files, new java.io.ByteArrayInputStream(apiZip), all);
    }

    public static String getRoot() { return projectsRoot == null ? "" : projectsRoot; }

    /** Switches the projects folder after proving it is really writable.
     *  Returns "" on success or the reason it could not be used (the
     *  previous folder stays active in that case). */
    public static String tryUseRoot(String path) {
        if (!path.endsWith("/")) path = path + "/";
        try {
            File dir = new File(path);
            if (!dir.exists() && !dir.mkdirs() && !dir.exists()) {
                return "Could not create " + path;
            }
            File probe = new File(dir, ".probe");
            java.io.FileOutputStream o = new java.io.FileOutputStream(probe);
            o.write(1);
            o.close();
            probe.delete();
        } catch (Exception e) {
            return "Not writable: " + e.getMessage();
        }
        setProjectsRoot(path);
        current = null;
        return "";
    }

    public static Project getCurrent() { return current; }

    /** Reads a project's saved properties WITHOUT making it the current project. */
    public static Project peekProject(String name) {
        try {
            return pm().openProject(name);
        } catch (Exception e) {
            return null;
        }
    }

    /** Default (always writable, no permission needed) projects folder for this app. */
    public static String defaultRoot(Context context) {
        File extDir = context.getExternalFilesDir(null);
        String base = (extDir != null) ? extDir.getPath() : context.getFilesDir().getPath();
        return base + "/JCompiler/projects/";
    }

    public static String createProject(String name, int template) {
        String err = createProject(name);
        if (err.length() > 0) return err;
        return writeFile(name + ".java", com.dashers.j2mebuilderide.ide.Templates.get(template, name));
    }

    public static String createFile(String fileName, String content) {
        if (current == null) return "No project open";
        if (new File(current.srcUrl() + fileName).exists()) return fileName + " already exists";
        return writeFile(fileName, content);
    }

    public static String deleteFile(String fileName) {
        if (current == null) return "No project open";
        File f = new File(current.srcUrl() + fileName);
        if (f.exists() && !f.delete()) return "Could not delete " + fileName;
        return "";
    }

    /** Best PNG in res/ to use as the MIDlet icon ("" when there is none): icon/logo names and small sizes win. */
    public static String autoIconCandidate() {
        if (current == null) return "";
        Vector res = pm().listResourceFiles(current);
        String best = ""; long bestScore = Long.MAX_VALUE;
        for (int i = 0; i < res.size(); i++) {
            String rel = (String) res.elementAt(i);
            String low = rel.toLowerCase();
            if (!low.endsWith(".png")) continue;
            String name = low.substring(low.lastIndexOf('/') + 1);
            int rank = name.indexOf("icon") >= 0 ? 0 : name.indexOf("logo") >= 0 ? 1
                    : (name.indexOf("launcher") >= 0 || name.indexOf("app") >= 0) ? 2 : 3;
            int w = 0, h = 0;
            try {
                android.graphics.BitmapFactory.Options o = new android.graphics.BitmapFactory.Options();
                o.inJustDecodeBounds = true;
                android.graphics.BitmapFactory.decodeFile(current.resUrl() + rel, o);
                w = o.outWidth; h = o.outHeight;
            } catch (Throwable t) { }
            if (w <= 0 || h <= 0) continue;
            long score = rank * 10000000L + (w > 128 || h > 128 ? 5000000L : 0)
                    + (rank == 3 ? (long) w * h : Math.abs(w - h)) + (rel.indexOf('/') >= 0 ? 1 : 0);
            if (score < bestScore) { bestScore = score; best = rel; }
        }
        return best;
    }

    public static Vector listResources() {
        if (current == null) return new Vector();
        return pm().listResourceFiles(current);
    }

    public static String writeResource(String relPath, byte[] data) {
        if (current == null) return "No project open";
        try {
            Project.writeWholeFile(current.resUrl() + relPath, data);
            return "";
        } catch (IOException e) {
            return "Could not save " + relPath + ": " + e.getMessage();
        }
    }

    public static String deleteResource(String relPath) {
        if (current == null) return "No project open";
        File f = new File(current.resUrl() + relPath);
        if (f.exists() && !f.delete()) return "Could not delete " + relPath;
        return "";
    }

    public static boolean jarExists() {
        return current != null && new File(current.jarUrl()).exists();
    }

    /** Compiles every source file in the project. On success writes all
     *  .class files to bin/ and, if makeJar is true, builds the .jar/.jad.
     *  On failure reports every error the compiler found (one per file at
     *  least) plus lint warnings. */
    // ------------------------------------------------------------------
    // Smart build: reuse the previous compile when nothing relevant changed
    // ------------------------------------------------------------------

    /** Last successful compile of the open project, kept in memory only. */
    private static String cacheFp;
    private static Compiler.ProjectResult cacheUnit;
    private static boolean cacheUsedEcj, cachePreverified;
    private static int cachePvOk;

    /** Forget the cached compile: the next build recompiles everything ("Clean rebuild"). */
    public static void invalidateBuildCache() {
        cacheFp = null;
        cacheUnit = null;
        cachePreverified = false;
        cachePvOk = 0;
        File f = cacheFile();
        if (f != null && f.isFile()) f.delete();
    }

    /** Serialises builds: the live check (background) and a manual build never run at the same time. */
    private static final Object BUILD_LOCK = new Object();

    /** Per-project cache file in the app's private storage (never inside the project, so exports stay clean). */
    private static File cacheFile() {
        if (appContext == null || current == null || current.rootUrl == null) return null;
        try {
            java.security.MessageDigest md = java.security.MessageDigest.getInstance("SHA-1");
            md.update(current.rootUrl.getBytes("UTF-8"));
            byte[] d = md.digest();
            StringBuffer hex = new StringBuffer();
            for (int i = 0; i < 8; i++) {
                int v = d[i] & 0xFF;
                if (v < 16) hex.append('0');
                hex.append(Integer.toHexString(v));
            }
            File dir = new File(appContext.getFilesDir(), "buildcache");
            if (!dir.isDirectory()) dir.mkdirs();
            return new File(dir, hex + ".bin");
        } catch (Throwable t) {
            return null;
        }
    }

    private static final int CACHE_MAGIC = 0x4A32434B, CACHE_VERSION = 1;

    /** Writes the in-memory cache to disk so the first build of the next session can be skipped too. Never throws. */
    private static void saveCacheToDisk() {
        File f = cacheFile();
        if (f == null || cacheUnit == null || cacheFp == null) return;
        File tmp = new File(f.getPath() + ".tmp");
        java.io.DataOutputStream out = null;
        try {
            out = new java.io.DataOutputStream(new java.io.BufferedOutputStream(new java.io.FileOutputStream(tmp)));
            out.writeInt(CACHE_MAGIC);
            out.writeInt(CACHE_VERSION);
            out.writeUTF(cacheFp);
            out.writeBoolean(cacheUsedEcj);
            out.writeBoolean(cachePreverified);
            out.writeInt(cachePvOk);
            int n = cacheUnit.names.length;
            out.writeInt(n);
            for (int i = 0; i < n; i++) {
                String fn = (cacheUnit.fileNames != null && i < cacheUnit.fileNames.length && cacheUnit.fileNames[i] != null)
                        ? cacheUnit.fileNames[i] : "";
                out.writeUTF(fn);
                out.writeUTF(cacheUnit.names[i]);
                out.writeInt(cacheUnit.classBytes[i].length);
                out.write(cacheUnit.classBytes[i]);
            }
            java.util.Iterator it = cacheUnit.privateMembers.iterator();
            out.writeInt(cacheUnit.privateMembers.size());
            while (it.hasNext()) out.writeUTF((String) it.next());
            out.flush();
            out.close();
            out = null;
            if (f.exists()) f.delete();
            tmp.renameTo(f);
        } catch (Throwable t) {
            if (out != null) try { out.close(); } catch (IOException ignored) { }
            tmp.delete();
        }
    }

    /** Loads the disk cache if it was written for exactly this fingerprint. Never throws. */
    private static boolean loadCacheFromDisk(String fp) {
        File f = cacheFile();
        if (f == null || !f.isFile()) return false;
        java.io.DataInputStream in = null;
        try {
            in = new java.io.DataInputStream(new java.io.BufferedInputStream(new java.io.FileInputStream(f)));
            if (in.readInt() != CACHE_MAGIC || in.readInt() != CACHE_VERSION) return false;
            if (!fp.equals(in.readUTF())) return false;
            boolean ecj = in.readBoolean();
            boolean pv = in.readBoolean();
            int pvOk = in.readInt();
            int n = in.readInt();
            if (n < 0 || n > 20000) return false;
            Compiler.ProjectResult u = new Compiler.ProjectResult();
            u.fileNames = new String[n];
            u.names = new String[n];
            u.classBytes = new byte[n][];
            for (int i = 0; i < n; i++) {
                u.fileNames[i] = in.readUTF();
                u.names[i] = in.readUTF();
                int len = in.readInt();
                if (len < 0 || len > 16 * 1024 * 1024) return false;
                u.classBytes[i] = new byte[len];
                in.readFully(u.classBytes[i]);
            }
            int pm = in.readInt();
            if (pm < 0 || pm > 1000000) return false;
            for (int i = 0; i < pm; i++) u.privateMembers.add(in.readUTF());
            cacheFp = fp;
            cacheUnit = u;
            cacheUsedEcj = ecj;
            cachePreverified = pv;
            cachePvOk = pvOk;
            return true;
        } catch (Throwable t) {
            return false;
        } finally {
            if (in != null) try { in.close(); } catch (IOException ignored) { }
        }
    }

    private static void upd(java.security.MessageDigest md, String t) throws java.io.UnsupportedEncodingException {
        if (t != null) md.update(t.getBytes("UTF-8"));
        md.update((byte) 0);
    }

    /** SHA-1 over everything that changes the compiled classes: sources, library jars, the compiler in
     *  use and the preverify setting. Null if it cannot be computed (then nothing is cached). */
    private static String buildFingerprint(Compiler.ProjectFile[] files, boolean tryEcj) {
        try {
            java.security.MessageDigest md = java.security.MessageDigest.getInstance("SHA-1");
            upd(md, current.rootUrl);
            upd(md, tryEcj ? "ecj" : "core");
            upd(md, current.packageName);
            boolean pv = appContext != null && new com.dashers.j2mebuilderide.ide.AppSettings(appContext).proguardPreverify();
            upd(md, pv ? "pv1" : "pv0");
            for (int i = 0; i < files.length; i++) {
                upd(md, files[i].fileName);
                upd(md, files[i].source);
            }
            for (int pass = 0; pass < 2; pass++) {
                File[] jars = com.dashers.j2mebuilderide.ide.Libraries.jars(current, pass == 1);
                for (int i = 0; jars != null && i < jars.length; i++) {
                    upd(md, jars[i].getPath() + "|" + jars[i].length() + "|" + jars[i].lastModified());
                }
            }
            byte[] d = md.digest();
            StringBuffer hex = new StringBuffer();
            for (int i = 0; i < d.length; i++) {
                int v = d[i] & 0xFF;
                if (v < 16) hex.append('0');
                hex.append(Integer.toHexString(v));
            }
            return hex.toString();
        } catch (Throwable t) {
            return null;
        }
    }

    /** True if bin/ already holds exactly these classes, byte-for-byte in size. */
    private static boolean binUpToDate(File bin, Compiler.ProjectResult unit) {
        File[] have = bin.listFiles();
        int classFiles = 0;
        if (have != null) for (int i = 0; i < have.length; i++) if (have[i].getName().endsWith(".class")) classFiles++;
        if (classFiles != unit.names.length) return false;
        for (int i = 0; i < unit.names.length; i++) {
            File f = new File(bin, unit.names[i] + ".class");
            if (!f.isFile() || f.length() != unit.classBytes[i].length) return false;
        }
        return true;
    }

    public static BuildResult compileAll(boolean makeJar) { return compileAll(makeJar, null); }

    public static BuildResult compileAll(boolean makeJar, Progress pg) {
        return compileAll(makeJar, pg, false);
    }

    /** Silent check used by the live "compile on save": same compiler and cache, but nothing is written to bin/
     *  and no .jar is made. */
    public static BuildResult checkProject() {
        return compileAll(false, null, true);
    }

    private static BuildResult compileAll(boolean makeJar, Progress pg, boolean dry) {
        BuildResult r;
        synchronized (BUILD_LOCK) {
            long t0 = System.currentTimeMillis();
            r = compileAllImpl(makeJar, pg, dry);
            r.millis = System.currentTimeMillis() - t0;
        }
        return r;
    }

    private static BuildResult compileAllImpl(boolean makeJar, Progress pg, boolean dry) {
        BuildResult r = new BuildResult();
        boolean usedEcj = false;
        if (current == null) { r.message = "No project open"; return r; }
        if (!apiInitialized) {
            r.message = "API index not loaded: " + lastError;
            return r;
        }
        java.util.Hashtable sources = new java.util.Hashtable();
        try {
            Vector names = pm().listSourceFiles(current);
            java.util.Collections.sort(names);
            r.fileCount = names.size();
            say(pg, "Found " + names.size() + " Java file(s) in src/", L_TEXT);
            if (names.size() == 0) {
                r.message = "No .java files in src/";
                Problem pr = new Problem();
                pr.message = r.message;
                r.problems.addElement(pr);
                return r;
            }
            Compiler.ProjectFile[] arr = new Compiler.ProjectFile[names.size()];
            for (int i = 0; i < arr.length; i++) {
                Compiler.ProjectFile pf = new Compiler.ProjectFile();
                pf.fileName = (String) names.elementAt(i);
                byte[] data = Project.readWholeFile(current.srcUrl() + pf.fileName);
                pf.source = (data != null) ? new String(data, "UTF-8") : "";
                sources.put(pf.fileName, pf.source);
                arr[i] = pf;
                Vector lw = com.dashers.j2mebuilderide.ide.Lint.check(pf.fileName, pf.source);
                for (int k = 0; k < lw.size() && r.warnings.size() < 60; k++) {
                    com.dashers.j2mebuilderide.ide.Lint.Warning lwk = (com.dashers.j2mebuilderide.ide.Lint.Warning) lw.elementAt(k);
                    lwk.message = com.dashers.j2mebuilderide.ide.EcjMessages.translate(lwk.message);
                    r.warnings.addElement(lwk);
                }
            }
            say(pg, "Checking imports and libraries...", L_TEXT);
            com.dashers.j2mebuilderide.ide.Libraries.Report libRep =
                    com.dashers.j2mebuilderide.ide.Libraries.prepare(current, sources);
            r.libsLoaded = libRep.loaded;
            for (int i = 0; i < libRep.jarLibs.size(); i++) r.libsLoaded.addElement(libRep.jarLibs.elementAt(i));
            for (int i = 0; i < libRep.missing.size(); i++) {
                com.dashers.j2mebuilderide.ide.Lint.Warning mw = new com.dashers.j2mebuilderide.ide.Lint.Warning();
                mw.file = (String) libRep.missingFiles.elementAt(i);
                mw.line = ((Integer) libRep.missingLines.elementAt(i)).intValue();
                mw.message = "Library not found for import " + libRep.missing.elementAt(i)
                        + " - add its .jar in Libraries";
                r.warnings.addElement(mw);
                r.libsMissing.addElement(libRep.missing.elementAt(i));
            }
            for (int i = 0; i < r.libsLoaded.size(); i++) say(pg, "Library loaded: " + r.libsLoaded.elementAt(i), L_OK);
            for (int i = 0; i < r.libsMissing.size(); i++) say(pg, "Library missing: import " + r.libsMissing.elementAt(i) + "  (add its .jar in Libraries)", L_WARN);
            boolean tryEcj = com.dashers.j2mebuilderide.compiler.EcjCompiler.isInitialized();
            final String fp = buildFingerprint(arr, tryEcj);
            Compiler.ProjectResult unit;
            boolean reused = fp != null && cacheUnit != null && fp.equals(cacheFp);
            boolean fromDisk = false;
            if (!reused && fp != null && loadCacheFromDisk(fp)) { reused = true; fromDisk = true; }
            if (reused) {
                unit = cacheUnit;
                usedEcj = cacheUsedEcj;
                r.reused = true;
                say(pg, "Smart build: " + (fromDisk ? "cache from the previous session" : "sources, libraries and settings unchanged")
                        + " - reusing " + unit.classBytes.length
                        + " compiled class" + (unit.classBytes.length == 1 ? "" : "es") + ".", L_OK);
            } else {
                cacheFp = null;
                cacheUnit = null;
                cachePreverified = false;
                cachePvOk = 0;
                say(pg, tryEcj ? "Compiling Java to .class with ECJ (Eclipse compiler)..." : "Compiling Java to .class with the built-in compiler...", L_TEXT);
                try {
                    unit = compileWithEcj(arr, current);
                } finally {
                    String ecjNote = com.dashers.j2mebuilderide.compiler.EcjCompiler.takeNote();
                    if (ecjNote != null) { r.ecjFellBack = true; say(pg, ecjNote, L_WARN); }
                }
                usedEcj = tryEcj && !r.ecjFellBack;
                say(pg, "Java to .class compile succeeded (" + unit.classBytes.length + " class" + (unit.classBytes.length == 1 ? "" : "es") + ").", L_OK);
            }
            boolean pvDone = reused && cachePreverified;
            final boolean pvBefore = pvDone;
            if (makeJar) {
                if (pvDone) {
                    r.preverified = cachePvOk;
                    say(pg, "Preverify: classes already preverified - skipped.", L_OK);
                } else {
                    preverifyUnit(unit, usedEcj, r, pg);
                    pvDone = !usedEcj || (r.preverified > 0 && r.preverifyFailed == 0);
                }
            }
            // keep the result for the next build, unless the preverifier choked on some class
            if (fp != null && r.preverifyFailed == 0 && !r.ecjFellBack) {
                cacheFp = fp;
                cacheUnit = unit;
                cacheUsedEcj = usedEcj;
                cachePreverified = pvDone;
                cachePvOk = r.preverified;
                if (!reused || pvDone != pvBefore) saveCacheToDisk();
            } else {
                invalidateBuildCache();
            }

            File bin = new File(current.binUrl());
            boolean binFresh = dry || (reused && binUpToDate(bin, unit));
            if (dry) {
                // live check: nothing to write
            } else if (binFresh) {
                say(pg, "bin/ is already up to date.", L_MUTED);
            } else {
                say(pg, "Writing class files to bin/ ...", L_TEXT);
                File[] old = bin.listFiles();
                if (old != null) for (int i = 0; i < old.length; i++) {
                    if (old[i].getName().endsWith(".class")) old[i].delete();
                }
            }
            StringBuffer sb = new StringBuffer();
            for (int i = 0; i < unit.classBytes.length; i++) {
                if (!binFresh) Project.writeWholeFile(current.binUrl() + unit.names[i] + ".class", unit.classBytes[i]);
                sb.append("  ").append(unit.names[i]).append(".class  ")
                  .append(unit.classBytes[i].length).append(" bytes\n");
                if (i < 10) say(pg, "  " + unit.names[i] + ".class  " + unit.classBytes[i].length + " bytes", L_MUTED);
            }
            if (unit.classBytes.length > 10) say(pg, "  ... and " + (unit.classBytes.length - 10) + " more classes", L_MUTED);
            r.ok = true;
            r.classCount = unit.classBytes.length;
            r.message = "Compiled " + unit.classBytes.length + " class"
                    + (unit.classBytes.length == 1 ? "" : "es") + "\n" + sb;
            if (makeJar) {
                say(pg, "Packaging classes, res/ and libraries into " + current.folderName + ".jar ...", L_TEXT);
                ProjectManager.PackageResult pr = pm().packageProject(current, unit);
                r.ok = pr.ok;
                r.packageMessage = pr.message == null ? "" : pr.message;
                r.message = r.message + "\n" + r.packageMessage;
                if (pr.ok) {
                    r.jarPath = current.jarUrl();
                    r.jarBytes = new File(r.jarPath).length();
                    say(pg, "Packaging into " + current.folderName + ".jar succeeded.", L_OK);
                    String[] pmLines = r.packageMessage.split("\n");
                    for (int i = 0; i < pmLines.length; i++) {
                        String ln = pmLines[i].trim();
                        if (ln.length() == 0 || ln.startsWith("warning:")) continue;
                        say(pg, "  " + ln, L_MUTED);
                    }
                    // packaging warnings ("warning: ...") count as warnings too
                    String[] lines = r.packageMessage.split("\n");
                    for (int i = 0; i < lines.length; i++) {
                        String ln = lines[i].trim();
                        if (ln.startsWith("warning:")) {
                            com.dashers.j2mebuilderide.ide.Lint.Warning w = new com.dashers.j2mebuilderide.ide.Lint.Warning();
                            w.file = "";
                            w.line = 0;
                            w.message = ln.substring(8).trim();
                            r.warnings.addElement(w);
                        }
                    }
                } else {
                    say(pg, "Packaging failed.", L_ERR);
                    Problem p = new Problem();
                    p.message = r.packageMessage;
                    r.problems.addElement(p);
                }
            }
        } catch (CompileError ce) {
            invalidateBuildCache();
            r.ok = false;
            Vector list = (ce.all != null && ce.all.size() > 0) ? ce.all : null;
            if (list == null) {
                list = new Vector();
                list.addElement(ce);
            }
            for (int i = 0; i < list.size(); i++) {
                CompileError e = (CompileError) list.elementAt(i);
                Problem p = new Problem();
                p.file = e.fileName != null ? e.fileName : "";
                p.line = e.line;
                p.message = e.getMessage() == null ? "" : com.dashers.j2mebuilderide.ide.EcjMessages.translate(e.getMessage());
                String src = p.file.length() > 0 ? (String) sources.get(p.file) : null;
                if (src != null) p.snippet = CompileError.sourceLine(src, e.line);
                p.category = com.dashers.j2mebuilderide.compiler.ErrorTips.category(p.message);
                String tip = com.dashers.j2mebuilderide.compiler.ErrorTips.tipFor(p.message, p.snippet);
                p.hint = (e.hint != null ? e.hint + (tip.length() > 0 ? "  " : "") : "") + tip;
                p.col = e.col;
                p.endCol = e.endCol;
                if (src != null && e.col > 0) {
                    String raw = rawLine(src, e.line);
                    int lead = 0;
                    while (lead < raw.length() && (raw.charAt(lead) == ' ' || raw.charAt(lead) == '\t')) lead++;
                    int at = Math.max(0, e.col - 1 - lead);
                    int len = Math.max(1, e.endCol - e.col + 1);
                    StringBuffer cb = new StringBuffer();
                    for (int k = 0; k < at; k++) cb.append(' ');
                    for (int k = 0; k < len && k < 40; k++) cb.append('^');
                    p.caret = cb.toString();
                }
                r.problems.addElement(p);
            }
            Problem first = (Problem) r.problems.elementAt(0);
            r.file = first.file;
            r.line = first.line;
            StringBuffer sb = new StringBuffer();
            for (int i = 0; i < r.problems.size(); i++) {
                Problem p = (Problem) r.problems.elementAt(i);
                sb.append(p.file.length() > 0 ? p.file : "error").append(":").append(p.line)
                  .append("  ").append(p.message);
                if (p.snippet.length() > 0) sb.append("\n\n  > ").append(p.snippet);
                if (p.hint.length() > 0) sb.append("\n\n  hint: ").append(p.hint);
                if (i + 1 < r.problems.size()) sb.append("\n\n");
            }
            r.message = sb.toString();
            say(pg, "Java to .class compile failed.", L_ERR);
        } catch (IOException ioe) {
            Problem p = new Problem();
            p.message = "Could not read/write project files: " + ioe.getMessage();
            r.problems.addElement(p);
            r.message = p.message;
        } catch (RuntimeException re) {
            Problem p = new Problem();
            p.message = "Internal compiler error: " + re;
            r.problems.addElement(p);
            r.message = p.message;
        }
        if (!r.ok) {
            Vector msgs = new Vector();
            for (int i = 0; i < r.problems.size(); i++) msgs.addElement(((Problem) r.problems.elementAt(i)).message);
            r.buildTips = com.dashers.j2mebuilderide.compiler.ErrorTips.buildTips(msgs, r.packageMessage, r.ecjFellBack, r.libsMissing.size());
        }
        return r;
    }

    // ------------------------------------------------------------------
    // New-project / properties / file management (used by the redesigned UI)
    // ------------------------------------------------------------------

    /** Reserved words are rejected as class names. */
    private static final String[] RESERVED = {
        "abstract", "boolean", "break", "byte", "case", "catch", "char", "class", "continue", "default",
        "do", "double", "else", "extends", "final", "finally", "float", "for", "if", "implements", "import",
        "instanceof", "int", "interface", "long", "native", "new", "package", "private", "protected", "public",
        "return", "short", "static", "super", "switch", "synchronized", "this", "throw", "throws", "try",
        "void", "volatile", "while", "true", "false", "null", "assert", "strictfp"
    };

    /** "" if `n` is a legal Java class name, otherwise the reason it is not. */
    public static String validateClassName(String n) {
        if (n == null || n.length() == 0) return "Enter a name";
        if (!Character.isLetter(n.charAt(0)) || n.charAt(0) > 127) return "Must start with a letter";
        for (int i = 0; i < n.length(); i++) {
            char c = n.charAt(i);
            if (!(Character.isLetterOrDigit(c) || c == '_') || c > 127) return "Only letters, digits and _";
        }
        for (int i = 0; i < RESERVED.length; i++) if (RESERVED[i].equals(n)) return "'" + n + "' is a Java keyword";
        return "";
    }

    /** "" if n is a valid dotted Java package, otherwise a reason. */
    public static String validatePackageName(String n) {
        if (n == null || n.trim().length() == 0) return "";
        String[] parts = n.trim().split("\\.");
        for (int i = 0; i < parts.length; i++) {
            String bad = validateIdentifier(parts[i]);
            if (bad.length() > 0) return "Invalid package segment: " + parts[i];
            for (int r = 0; r < RESERVED.length; r++) if (RESERVED[r].equals(parts[i])) return "'" + parts[i] + "' is a Java keyword";
        }
        return "";
    }

    private static String validateIdentifier(String n) {
        if (n == null || n.length() == 0) return "Empty identifier";
        if (!Character.isLetter(n.charAt(0)) && n.charAt(0) != '_') return "Must start with a letter or _";
        for (int i = 0; i < n.length(); i++) {
            char c = n.charAt(i);
            if (!(Character.isLetterOrDigit(c) || c == '_') || c > 127) return "Only ASCII letters, digits and _";
        }
        return "";
    }

    public static String getPackageName() { return current != null ? current.packageName : ""; }
    public static void setPackageName(String v) { if (current != null) current.packageName = v == null ? "" : v.trim(); }

    /** Turns any text ("My Cool Game!") into a usable class/folder name ("MyCoolGame"). */
    public static String sanitize(String text) {
        StringBuffer sb = new StringBuffer();
        boolean upNext = true;
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c < 128 && Character.isLetterOrDigit(c)) {
                sb.append(upNext ? Character.toUpperCase(c) : c);
                upNext = false;
            } else if (c == '_') {
                sb.append('_');
                upNext = false;
            } else {
                upNext = true;
            }
        }
        while (sb.length() > 0 && !Character.isLetter(sb.charAt(0))) sb.deleteCharAt(0);
        return sb.toString();
    }

    /** Creates a fully configured project. `iconBytes` may be null. Returns "" or an error. */
    public static String createProjectFull(String folder, int template, String midletName, String version,
                                           String vendor, String mainClass, int obfuscation,
                                           String iconName, byte[] iconBytes) {
        return createProjectFull(folder, template, midletName, version, vendor, "", mainClass, obfuscation, iconName, iconBytes);
    }

    public static String createProjectFull(String folder, int template, String midletName, String version,
                                           String vendor, String packageName, String mainClass, int obfuscation,
                                           String iconName, byte[] iconBytes) {
        String pkg = packageName == null ? "" : packageName.trim();
        String pkgErr = validatePackageName(pkg);
        if (pkgErr.length() > 0) return pkgErr;
        String err = createProjectBare(folder);
        if (err.length() > 0) return err;
        try {
            String sourcePath = pkg.length() == 0 ? mainClass + ".java" : pkg.replace('.', '/') + "/" + mainClass + ".java";
            err = writeFile(sourcePath, com.dashers.j2mebuilderide.ide.Templates.get(template, pkg, mainClass));
            if (err.length() > 0) return err;
            current.midletName = midletName;
            current.version = version;
            current.vendor = vendor;
            current.mainClass = mainClass;
            current.packageName = pkg;
            current.obfuscation = obfuscation;
            if (iconBytes != null && iconName != null && iconName.length() > 0) {
                err = writeResource(iconName, iconBytes);
                if (err.length() > 0) return err;
                current.icon = iconName;
            }
            current.save();
            return "";
        } catch (IOException e) {
            return "Could not save project: " + e.getMessage();
        }
    }

    /** Applies optional MIDlet/JAD descriptor metadata from the New Project UI. */
    public static void configureDescriptor(String description, String infoUrl, String permissions,
                                           String permissionsOpt, String installNotify, String deleteNotify,
                                           String dataSize, String nokiaCategory, String nokiaName,
                                           String pushRegistration) {
        if (current == null) return;
        current.description = description == null ? "" : description.trim();
        current.infoUrl = infoUrl == null ? "" : infoUrl.trim();
        current.permissions = permissions == null ? "" : permissions.trim();
        current.permissionsOpt = permissionsOpt == null ? "" : permissionsOpt.trim();
        current.installNotify = installNotify == null ? "" : installNotify.trim();
        current.deleteNotify = deleteNotify == null ? "" : deleteNotify.trim();
        current.nokiaCategory = nokiaCategory == null ? "" : nokiaCategory.trim();
        current.nokiaName = nokiaName == null ? "" : nokiaName.trim();
        current.pushRegistration = pushRegistration == null ? "" : pushRegistration.trim();
        try {
            current.dataSize = dataSize == null || dataSize.trim().length() == 0 ? 0 : Integer.parseInt(dataSize.trim());
            if (current.dataSize < 0) current.dataSize = 0;
        } catch (NumberFormatException e) {
            current.dataSize = 0;
        }
        try { current.save(); } catch (IOException ignored) {}
    }

    public static String getMidletName() { return current != null ? current.midletName : ""; }
    public static int getObfuscation() { return current != null ? current.obfuscation : 0; }
    public static void setMidletName(String v) { if (current != null) current.midletName = v; }
    public static void setObfuscation(int v) { if (current != null) current.obfuscation = v; }

    /** Classes in the open project that extend MIDlet (declaration scan, not a full parse). */
    public static Vector detectMidletClasses() {
        Vector out = new Vector();
        if (current == null) return out;
        java.util.regex.Pattern pat = java.util.regex.Pattern.compile("class\\s+(\\w+)\\s+extends\\s+(?:javax\\.microedition\\.midlet\\.)?MIDlet\\b");
        Vector files = pm().listSourceFiles(current);
        java.util.Collections.sort(files);
        for (int i = 0; i < files.size(); i++) {
            String src = readFile((String) files.elementAt(i));
            java.util.regex.Matcher m = pat.matcher(com.dashers.j2mebuilderide.ide.Lint.blank(src));
            while (m.find()) out.addElement(m.group(1));
        }
        return out;
    }

    public static int sourceSize(String fileName) {
        if (current == null) return 0;
        File f = new File(current.srcUrl() + fileName);
        return f.exists() ? (int) f.length() : 0;
    }

    public static byte[] sourceBytes(String fileName) {
        if (current == null) return null;
        try {
            return Project.readWholeFile(current.srcUrl() + fileName);
        } catch (IOException e) {
            return null;
        }
    }

    /**
     * Imports a project ZIP exported by this IDE (or a compatible WTK-style
     * archive containing src/, res/ and optionally project.properties).
     * The archive is extracted into a new project folder and path traversal
     * entries are rejected. Returns "" on success or an error message.
     */
    public static String importProjectZip(byte[] zipBytes, String preferredName) {
        if (zipBytes == null || zipBytes.length == 0) return "Empty ZIP file";
        try {
            ZipInputStream zin = new ZipInputStream(new ByteArrayInputStream(zipBytes));
            java.util.Vector entries = new java.util.Vector();
            String projectName = preferredName == null ? "" : sanitize(preferredName);
            byte[] buf = new byte[8192];
            ZipEntry e;
            while ((e = zin.getNextEntry()) != null) {
                String n = e.getName().replace('\\', '/');
                while (n.startsWith("/")) n = n.substring(1);
                if (n.length() == 0) continue;
                if (n.indexOf("../") >= 0 || n.equals("..") || n.startsWith("../") || n.indexOf(':') == 1) {
                    zin.close();
                    return "Unsafe ZIP entry: " + n;
                }
                java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
                int r; while ((r = zin.read(buf)) > 0) bos.write(buf, 0, r);
                entries.addElement(new Object[]{n, Boolean.valueOf(e.isDirectory()), bos.toByteArray()});
                if (n.endsWith("/")) {
                    String[] parts=n.split("/");
                    if (parts.length>0 && projectName.length()==0) projectName=sanitize(parts[0]);
                }
            }
            zin.close();
            if (projectName.length()==0) projectName="ImportedProject";
            String base = projectName;
            int suffix=2;
            while (new File(getRoot()+projectName).exists()) projectName=base+suffix++;
            String err=createProject(projectName);
            if (err.length()>0) return err;
            current = pm().openProject(projectName);
            // ---- classify: .java -> src/<package path>/, everything else -> res/ ----
            String root = importCommonRoot(entries);
            boolean strip = root.length() > 0
                    && (root.equalsIgnoreCase(base) || root.equalsIgnoreCase(projectName) || importHasMarker(entries, root));
            boolean sawProps=false;
            int nJava=0, nRes=0;
            java.util.HashSet pkgs=new java.util.HashSet();
            for (int i=0;i<entries.size();i++) {
                Object[] a=(Object[])entries.elementAt(i);
                String rel=(String)a[0];
                boolean dir=((Boolean)a[1]).booleanValue();
                byte[] data=(byte[])a[2];
                if (strip && rel.startsWith(root+"/")) rel=rel.substring(root.length()+1);
                else if (strip && rel.equals(root)) continue;
                if (rel.length()==0 || isImportJunk(rel)) continue;
                String low=rel.toLowerCase();
                if (!dir && low.equals("project.properties")) {
                    Project.writeWholeFile(current.propsUrl(), data); current.load(); sawProps=true; continue;
                }
                if (low.startsWith("src/main/java/")) { rel="src/"+rel.substring(14); low=rel.toLowerCase(); }
                if (dir) {
                    // keep empty folders too
                    if (low.startsWith("res/")) new File(current.resUrl()+rel.substring(4)).mkdirs();
                    else if (low.startsWith("src/")) new File(current.srcUrl()+rel.substring(4)).mkdirs();
                    continue;
                }
                if (low.endsWith(".java")) {
                    String name=rel.substring(rel.lastIndexOf('/')+1);
                    String text=new String(data,"UTF-8");
                    java.util.regex.Matcher m=IMPORT_PKG.matcher(text);
                    String dest;
                    if (m.find()) {
                        String pk=m.group(1);
                        dest=pk.replace('.','/')+"/"+name;   // creates every sub folder of the package
                        pkgs.add(pk);
                    } else {
                        dest=name;                            // no package line: src root
                        if (new File(current.srcUrl()+dest).exists()) dest=low.startsWith("src/") ? rel.substring(4) : rel;
                    }
                    Project.writeWholeFile(current.srcUrl()+dest, data);
                    nJava++;
                } else {
                    String dest=importResPath(rel);
                    if (dest.length()==0) continue;
                    Project.writeWholeFile(current.resUrl()+dest, data);   // any non-java file is a resource
                    nRes++;
                }
            }
            lastImportInfo="Imported "+nJava+" source"+(nJava==1?"":"s")+" in "+pkgs.size()+" package"+(pkgs.size()==1?"":"s")+", "+nRes+" resource"+(nRes==1?"":"s");
            if (!sawProps) inferProjectProperties(current);
            current.save();
            return "";
        } catch (Exception ex) {
            return "Could not import project ZIP: " + ex.getMessage();
        }
    }

    /** True for build output / IDE junk that a folder walk should not even read (".git/", "bin/", "x.class" ...). */
    public static boolean importSkipsPath(String rel) { return isImportJunk(rel); }

    /**
     * Imports a project FOLDER (picked with the system folder picker) as a NEW project. entries are
     * Object[]{relative path, Boolean isDirectory, byte[] data} relative to the picked folder. The files are
     * packed into an in-memory ZIP and go through importProjectZip(), so folders and ZIPs are placed identically
     * (.java -> src/<package>/, everything else -> res/).
     */
    public static String importProjectFolder(Vector entries, String folderName) {
        if (entries == null || entries.size() == 0) return "The folder is empty";
        try {
            java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
            java.util.zip.ZipOutputStream zos = new java.util.zip.ZipOutputStream(bos);
            for (int i = 0; i < entries.size(); i++) {
                Object[] a = (Object[]) entries.elementAt(i);
                String n = (String) a[0];
                boolean dir = ((Boolean) a[1]).booleanValue();
                if (dir && !n.endsWith("/")) n = n + "/";
                zos.putNextEntry(new ZipEntry(n));
                if (!dir) zos.write((byte[]) a[2]);
                zos.closeEntry();
            }
            zos.close();
            return importProjectZip(bos.toByteArray(), folderName);
        } catch (Exception ex) {
            return "Could not import folder: " + ex.getMessage();
        }
    }

    /** Merges a picked folder into the OPEN project (same placement rules; project.properties is never replaced). */
    public static String importFolderIntoProject(Vector entries) {
        if (current == null) return "No project open";
        if (entries == null || entries.size() == 0) return "The folder is empty";
        int nJava = 0, nRes = 0;
        java.util.HashSet pkgs = new java.util.HashSet();
        try {
            for (int i = 0; i < entries.size(); i++) {
                Object[] a = (Object[]) entries.elementAt(i);
                String rel = (String) a[0];
                boolean dir = ((Boolean) a[1]).booleanValue();
                byte[] data = (byte[]) a[2];
                while (rel.endsWith("/")) rel = rel.substring(0, rel.length() - 1);
                if (rel.length() == 0 || isImportJunk(rel + (dir ? "/" : ""))) continue;
                String low = rel.toLowerCase();
                if (low.startsWith("src/main/java/")) { rel = "src/" + rel.substring(14); low = rel.toLowerCase(); }
                if (dir) {
                    if (low.startsWith("res/")) new File(current.resUrl() + rel.substring(4)).mkdirs();
                    else if (low.startsWith("src/")) new File(current.srcUrl() + rel.substring(4)).mkdirs();
                    continue;
                }
                if (low.equals("project.properties")) continue;
                if (low.endsWith(".java")) {
                    String name = rel.substring(rel.lastIndexOf('/') + 1);
                    java.util.regex.Matcher m = IMPORT_PKG.matcher(new String(data, "UTF-8"));
                    String dest;
                    if (m.find()) { dest = m.group(1).replace('.', '/') + "/" + name; pkgs.add(m.group(1)); }
                    else dest = low.startsWith("src/") ? rel.substring(4) : name;
                    Project.writeWholeFile(current.srcUrl() + dest, data);
                    nJava++;
                } else {
                    String dest = importResPath(rel);
                    if (dest.length() == 0) continue;
                    Project.writeWholeFile(current.resUrl() + dest, data);
                    nRes++;
                }
            }
            lastImportInfo = "Imported " + nJava + " source" + (nJava == 1 ? "" : "s") + " in " + pkgs.size()
                    + " package" + (pkgs.size() == 1 ? "" : "s") + ", " + nRes + " resource" + (nRes == 1 ? "" : "s");
            return "";
        } catch (Exception ex) {
            return "Could not import folder: " + ex.getMessage();
        }
    }

    /** Short summary of the last successful importProjectZip(). */
    public static String lastImportInfo = "";
    private static final java.util.regex.Pattern IMPORT_PKG = java.util.regex.Pattern.compile(
            "(?m)^[\\s\\uFEFF]*package\\s+([A-Za-z_][\\w]*(?:\\.[A-Za-z_][\\w]*)*)\\s*;");

    /** Single top-level folder shared by every entry, or "" when there is none. */
    private static String importCommonRoot(Vector entries) {
        String root=null;
        for (int i=0;i<entries.size();i++) {
            String n=(String)((Object[])entries.elementAt(i))[0];
            if (n.startsWith("__MACOSX/")) continue;
            int sl=n.indexOf('/');
            if (sl<0) return "";
            String first=n.substring(0,sl);
            if (root==null) root=first; else if (!root.equals(first)) return "";
        }
        return root==null ? "" : root;
    }

    /** True when the shared root folder looks like a project folder (holds src/, res/, project.properties ...). */
    private static boolean importHasMarker(Vector entries, String root) {
        String pre=root+"/";
        for (int i=0;i<entries.size();i++) {
            String n=(String)((Object[])entries.elementAt(i))[0];
            if (!n.startsWith(pre)) continue;
            String rest=n.substring(pre.length()).toLowerCase();
            int sl=rest.indexOf('/');
            String top=sl<0 ? rest : rest.substring(0,sl);
            if (top.equals("src")||top.equals("res")||top.equals("project.properties")||top.equals("bin")
                    ||top.equals("build")||top.equals("dist")||top.equals("deployed")||top.equals("manifest.mf")
                    ||top.equals(".classpath")||top.equals(".project")||top.equals("nbproject")) return true;
        }
        return false;
    }

    /** Build output, IDE metadata and OS junk that must not become resources. */
    private static boolean isImportJunk(String rel) {
        String low=rel.toLowerCase();
        if (low.startsWith("__macosx/")||low.startsWith(".git/")||low.startsWith(".idea/")||low.startsWith(".settings/")
                ||low.startsWith(".gradle/")||low.startsWith("nbproject/")||low.startsWith("meta-inf/")) return true;
        int sl=low.indexOf('/');
        String top=sl<0 ? "" : low.substring(0,sl);
        if (top.equals("bin")||top.equals("build")||top.equals("dist")||top.equals("deployed")||top.equals("classes")
                ||top.equals("out")||top.equals("obj")) return true;
        String name=low.substring(low.lastIndexOf('/')+1);
        if (name.equals(".ds_store")||name.equals("thumbs.db")||name.equals(".gitignore")||name.equals(".classpath")
                ||name.equals(".project")||name.endsWith(".class")) return true;
        if (sl<0 && (name.equals("manifest.mf")||name.endsWith(".jad")||name.endsWith(".jar"))) return true;
        return false;
    }

    /** Path of a non-java file relative to res/ ("" = skip). */
    private static String importResPath(String rel) {
        String low=rel.toLowerCase();
        String[] pre={"src/main/resources/","src/main/res/","res/","src/","resources/"};
        for (int i=0;i<pre.length;i++) if (low.startsWith(pre[i])) return rel.substring(pre[i].length());
        return rel;
    }

    private static void inferProjectProperties(Project p) throws IOException {
        Vector files=pm().listSourceFiles(p);
        String main=""; String pkg="";
        java.util.regex.Pattern pat=java.util.regex.Pattern.compile("(?s)(?:^|\\n)\\s*package\\s+([A-Za-z_][\\w]*(?:\\.[A-Za-z_][\\w]*)*)\\s*;");
        java.util.regex.Pattern mid=java.util.regex.Pattern.compile("class\\s+([A-Za-z_][\\w]*)\\s+extends\\s+(?:javax\\.microedition\\.midlet\\.)?MIDlet\\b");
        for(int i=0;i<files.size();i++){
            String fn=(String)files.elementAt(i); String src=readFile(fn);
            java.util.regex.Matcher m=mid.matcher(src);
            if(m.find()){main=m.group(1); java.util.regex.Matcher q=pat.matcher(src); if(q.find()) pkg=q.group(1); break;}
        }
        if(main.length()==0 && files.size()>0){String fn=(String)files.elementAt(0); int slash=fn.lastIndexOf('/'); String base=slash>=0?fn.substring(slash+1):fn; if(base.endsWith(".java")) main=base.substring(0,base.length()-5);}
        p.mainClass=main; p.packageName=pkg; p.midletName=p.folderName;
    }

    /** Renames a source folder and updates package declarations/imports when possible. */
    public static String renameSourceFolder(String oldFolder, String newName) {
        if(current==null) return "No project open";
        if(oldFolder==null) oldFolder="";
        oldFolder=oldFolder.replace('\\','/');
        while(oldFolder.startsWith("/")) oldFolder=oldFolder.substring(1);
        if(oldFolder.length()==0) return "Cannot rename the source root";
        String bad=validateIdentifier(newName==null?"":newName.trim());
        if(bad.length()>0) return bad;
        int slash=oldFolder.lastIndexOf('/');
        String parent=slash>=0?oldFolder.substring(0,slash):"";
        String oldName=slash>=0?oldFolder.substring(slash+1):oldFolder;
        File from=new File(current.srcUrl()+oldFolder);
        File to=new File(current.srcUrl()+(parent.length()>0?parent+"/":"")+newName);
        if(!from.isDirectory()) return "Folder not found: "+oldFolder;
        if(to.exists()) return "A folder named "+newName+" already exists";
        // Update package declarations/imports for Java files inside the renamed package.
        String oldPkg=oldFolder.replace('/','.');
        String newPkg=(parent.length()>0?parent.replace('/','.')+".":"")+newName;
        Vector files=pm().listSourceFiles(current);
        try {
            java.util.regex.Pattern pkgPat=java.util.regex.Pattern.compile("(^|\\n)([ \\t]*package\\s+)"+java.util.regex.Pattern.quote(oldPkg)+"(\\s*;)");
            for(int i=0;i<files.size();i++){
                String fn=(String)files.elementAt(i);
                String src=readFile(fn);
                String out=src;
                if(fn.startsWith(oldFolder+"/")) {
                    out=out.replaceAll("(?m)^(\\s*package\\s+)"+java.util.regex.Pattern.quote(oldPkg)+"(\\s*;)", "$1"+newPkg+"$2");
                }
                out=out.replaceAll("(?m)^(\\s*import\\s+)"+java.util.regex.Pattern.quote(oldPkg)+"\\.", "$1"+newPkg+".");
                if(!out.equals(src)) { String er=writeFile(fn,out); if(er.length()>0) return er; }
            }
            if(!from.renameTo(to)) return "Could not rename folder "+oldFolder;
            if(current.packageName.equals(oldPkg)) current.packageName=newPkg;
            current.save();
            return "";
        } catch(Exception ex){ return "Folder rename failed: "+ex.getMessage(); }
    }

    /** Relative source directories, recursively, sorted. */
    public static Vector listSourceFolders() {
        Vector out=new Vector();
        if(current==null) return out;
        collectSourceFolders(new File(current.srcUrl()), "", out);
        java.util.Collections.sort(out);
        return out;
    }
    private static void collectSourceFolders(File dir, String rel, Vector out) {
        if(dir==null || !dir.isDirectory()) return;
        File[] fs=dir.listFiles(); if(fs==null) return;
        for(int i=0;i<fs.length;i++) if(fs[i].isDirectory()) {
            String r=rel.length()==0?fs[i].getName():rel+"/"+fs[i].getName();
            out.addElement(r); collectSourceFolders(fs[i],r,out);
        }
    }

    /** All sources (and res/) as one zip, for "export project". */
    public static byte[] projectZip() {
        if (current == null) return null;
        try {
            com.dashers.j2mebuilderide.ide.ZipWriter zip = new com.dashers.j2mebuilderide.ide.ZipWriter();
            Vector files = pm().listSourceFiles(current);
            for (int i = 0; i < files.size(); i++) {
                String n = (String) files.elementAt(i);
                byte[] b = Project.readWholeFile(current.srcUrl() + n);
                if (b != null) zip.addEntry("src/" + n, b);
            }
            Vector res = pm().listResourceFiles(current);
            for (int i = 0; i < res.size(); i++) {
                String n = (String) res.elementAt(i);
                byte[] b = Project.readWholeFile(current.resUrl() + n);
                if (b != null) zip.addEntry("res/" + n, b);
            }
            byte[] props = Project.readWholeFile(current.propsUrl());
            if (props != null) zip.addEntry("project.properties", props);
            return zip.toByteArray();
        } catch (IOException e) {
            return null;
        }
    }

    /** Renames a source file AND the class inside it (whole-word, code only -- never
     *  inside strings or comments) in every file of the project. Returns "" or an error. */
    public static String renameSourceFile(String oldFile, String newClass) {
        if (current == null) return "No project open";
        String bad = validateClassName(newClass);
        if (bad.length() > 0) return bad;
        if (!oldFile.endsWith(".java")) return "Not a .java file";
        String oldPathNoExt = oldFile.substring(0, oldFile.length() - 5);
        int slash = Math.max(oldPathNoExt.lastIndexOf('/'), oldPathNoExt.lastIndexOf('\\'));
        String oldClass = slash >= 0 ? oldPathNoExt.substring(slash + 1) : oldPathNoExt;
        String dir = slash >= 0 ? oldPathNoExt.substring(0, slash + 1) : "";
        if (oldClass.equals(newClass)) return "";
        if (new File(current.srcUrl() + dir + newClass + ".java").exists()) return newClass + ".java already exists";
        try {
            Vector files = pm().listSourceFiles(current);
            java.util.regex.Pattern word = java.util.regex.Pattern.compile("\\b" + java.util.regex.Pattern.quote(oldClass) + "\\b");
            for (int i = 0; i < files.size(); i++) {
                String fn = (String) files.elementAt(i);
                String src = readFile(fn);
                String masked = com.dashers.j2mebuilderide.ide.Lint.blank(src);
                java.util.regex.Matcher m = word.matcher(masked);
                StringBuffer out = new StringBuffer();
                int last = 0;
                boolean changed = false;
                while (m.find()) {
                    out.append(src, last, m.start()).append(newClass);
                    last = m.end();
                    changed = true;
                }
                if (changed) {
                    out.append(src, last, src.length());
                    String e = writeFile(fn, out.toString());
                    if (e.length() > 0) return e;
                }
            }
            File from = new File(current.srcUrl() + oldFile);
            File to = new File(current.srcUrl() + dir + newClass + ".java");
            if (!from.renameTo(to)) return "Could not rename " + oldFile;
            if (oldClass.equals(current.mainClass)) {
                current.mainClass = newClass;
                current.save();
            }
            return "";
        } catch (IOException e) {
            return "Rename failed: " + e.getMessage();
        }
    }

    public static String renameProject(String oldName, String newName) {
        String bad = validateClassName(newName);
        if (bad.length() > 0) return bad;
        File from = new File(getRoot() + oldName);
        File to = new File(getRoot() + newName);
        if (to.exists()) return "A project named " + newName + " already exists";
        if (!from.renameTo(to)) return "Could not rename the project folder";
        if (current != null && oldName.equals(current.folderName)) current = null;
        return "";
    }

    /** Copies the built jar/jad into the public Download folder. "OK:path" or "ERR:reason". */
    public static String copyToDownloads() {
        if (current == null) return "ERR:No project open";
        try {
            File dl = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS);
            if (dl == null) return "ERR:No Download folder on this device";
            if (!dl.exists() && !dl.mkdirs()) return "ERR:Could not create " + dl.getPath();
            byte[] jar = Project.readWholeFile(current.jarUrl());
            if (jar == null) return "ERR:No jar to copy";
            Project.writeWholeFile(dl.getPath() + "/" + current.folderName + ".jar", jar);
            byte[] jad = Project.readWholeFile(current.jadUrl());
            if (jad != null) Project.writeWholeFile(dl.getPath() + "/" + current.folderName + ".jad", jad);
            return "OK:" + dl.getPath() + "/" + current.folderName + ".jar";
        } catch (Exception e) {
            return "ERR:" + e.getMessage();
        }
    }

    /** The API index (for autocomplete); null until init() has loaded it. */
    public static com.dashers.j2mebuilderide.compiler.ApiIndex api() {
        try {
            return apiInitialized ? Compiler.apiIndex() : null;
        } catch (CompileError e) {
            return null;
        }
    }
}
