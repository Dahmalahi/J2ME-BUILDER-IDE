package com.dashers.j2mebuilderide.compiler;

import static org.junit.Assert.assertTrue;

import java.util.List;
import org.junit.BeforeClass;
import org.junit.Test;

/** Run with: gradlew testDebugUnitTest (working directory = project root). */
public class FixturesTest {

    @BeforeClass
    public static void init() throws Exception {
        FixtureChecks.init();
    }

    private static void assertNone(List<String> fails) {
        assertTrue(fails.toString(), fails.isEmpty());
    }

    @Test public void fixturesCompileAndVerify() throws Exception { assertNone(FixtureChecks.checkFixtures(true)); }

    @Test public void fixturesCompileAndVerifyWithTwoEntryLongDouble() throws Exception { assertNone(FixtureChecks.checkFixtures(false)); }

    @Test public void errorFixturesAreRejected() throws Exception { assertNone(FixtureChecks.checkErrorFixtures()); }

    @Test public void oversizedMethodIsRejected() throws Exception { assertNone(FixtureChecks.checkMethodTooLarge()); }
}
