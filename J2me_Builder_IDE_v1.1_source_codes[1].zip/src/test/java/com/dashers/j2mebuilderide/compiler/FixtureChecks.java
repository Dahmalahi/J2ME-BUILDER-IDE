package com.dashers.j2mebuilderide.compiler;

import java.io.File;
import java.io.FileInputStream;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Shared checks used by the JUnit tests and runnable by hand:
 *   java -cp <classes> com.dashers.j2mebuilderide.compiler.FixtureChecks   (from the project root)
 * Every method returns a list of failure messages (empty = pass).
 */
public class FixtureChecks {

    static File root() {
        for (String d : new String[]{".", ".."}) {
            if (new File(d, "tests/fixes").isDirectory()) return new File(d);
        }
        throw new IllegalStateException("run from the project root (tests/fixes not found)");
    }

    public static void init() throws Exception {
        Compiler.initApiIndex(new FileInputStream(new File(root(), "src/main/assets/api_index_core.txt")));
    }

    /** Fixtures that must be REJECTED by the compiler (deliberate errors). */
    private static final List<String> EXPECT_ERROR = Arrays.asList("E1.java");

    private static File[] fixtures(final boolean errorCases) {
        File[] fs = new File(root(), "tests/fixes").listFiles();
        List<File> out = new ArrayList<File>();
        for (File f : fs) {
            String n = f.getName();
            if (!n.endsWith(".java") || n.equals("Harness.java")) continue;
            boolean isCase = n.startsWith("T") || n.startsWith("E");
            if (isCase && EXPECT_ERROR.contains(n) == errorCases) out.add(f);
        }
        File[] arr = out.toArray(new File[0]);
        Arrays.sort(arr);
        return arr;
    }

    private static Compiler.ProjectResult compile(String name, String src) throws CompileError {
        Compiler.ProjectFile pf = new Compiler.ProjectFile();
        pf.fileName = name;
        pf.source = src;
        return Compiler.compileProject(new Compiler.ProjectFile[]{pf});
    }

    /** Compile every tests/fixes/T*.java and verify the class files it produces. */
    public static List<String> checkFixtures(boolean longDoubleOneEntry) throws Exception {
        List<String> fails = new ArrayList<String>();
        Compiler.setStackMapLongDoubleOneEntry(longDoubleOneEntry);
        Compiler.setVerifyOutput(false); // verify explicitly below to collect full messages
        try {
            for (File f : fixtures(false)) {
                String src = new String(Files.readAllBytes(f.toPath()), "UTF-8");
                try {
                    Compiler.ProjectResult r = compile(f.getName(), src);
                    for (int i = 0; i < r.names.length; i++) {
                        ClassVerifier.Result vr = ClassVerifier.verify(r.classBytes[i]);
                        for (String e : vr.errors) fails.add(f.getName() + " [" + r.names[i] + "] " + e);
                    }
                } catch (CompileError ce) {
                    fails.add(f.getName() + ": does not compile: " + ce.getMessage());
                }
            }
        } finally {
            Compiler.setVerifyOutput(true);
            Compiler.setStackMapLongDoubleOneEntry(true);
        }
        return fails;
    }

    /** Fixtures listed in EXPECT_ERROR contain deliberate errors: they must be rejected. */
    public static List<String> checkErrorFixtures() throws Exception {
        List<String> fails = new ArrayList<String>();
        for (File f : fixtures(true)) {
            String src = new String(Files.readAllBytes(f.toPath()), "UTF-8");
            try {
                compile(f.getName(), src);
                fails.add(f.getName() + ": should have been rejected but compiled");
            } catch (CompileError expected) {
                // ok
            }
        }
        return fails;
    }

    /** A method far over 32KB must give a clear "too large" error, not wrong bytecode. */
    public static List<String> checkMethodTooLarge() throws Exception {
        List<String> fails = new ArrayList<String>();
        StringBuilder sb = new StringBuilder("public class Big {\n  static int f(int x) {\n    while (x > 0) {\n");
        for (int i = 0; i < 9000; i++) sb.append("      x = x + 1 - 1;\n");
        sb.append("      x--;\n    }\n    return x;\n  }\n}\n");
        try {
            compile("Big.java", sb.toString());
            fails.add("Big.java: oversized method compiled without an error");
        } catch (CompileError ce) {
            if (ce.getMessage() == null || !ce.getMessage().contains("too large")) {
                fails.add("Big.java: expected a 'too large' error but got: " + ce.getMessage());
            }
        }
        return fails;
    }

    public static void main(String[] args) throws Exception {
        init();
        List<String> all = new ArrayList<String>();
        all.addAll(checkFixtures(true));
        all.addAll(checkFixtures(false));
        all.addAll(checkErrorFixtures());
        all.addAll(checkMethodTooLarge());
        if (all.isEmpty()) {
            System.out.println("ALL FIXTURE CHECKS PASSED");
        } else {
            for (String s : all) System.out.println("FAIL " + s);
            System.exit(1);
        }
    }
}
