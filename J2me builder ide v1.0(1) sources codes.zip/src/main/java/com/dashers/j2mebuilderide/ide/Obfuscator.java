package com.dashers.j2mebuilderide.ide;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

/**
 * Small, dependency-free class-file obfuscator that runs on the finished
 * .class bytes just before they are zipped into the JAR.
 *
 *   level 0  none
 *   level 1  LOW   - rename your classes to short names (the MIDlet main class
 *                    stays as it is, because the manifest refers to it)
 *   level 2  HIGH  - level 1, plus rename every PRIVATE field and PRIVATE method
 *                    of your own classes
 *
 * It never edits an existing constant-pool entry in place and never renumbers
 * anything: new Utf8 / NameAndType entries are appended and the references
 * that need to change are re-pointed. Code, StackMap and exception tables
 * therefore stay valid byte-for-byte. The result is parsed again before it is
 * returned; ProjectManager falls back to the untouched classes on any error.
 *
 * Not handled (by design): names used as strings, e.g. Class.forName("Foo").
 */
public final class Obfuscator {
    private Obfuscator() {}

    public static final int ACC_PRIVATE = 0x0002;

    public static final class Result {
        public String[] names;      // internal names (use '/' separators), same order as the input
        public byte[][] classes;
        public int classesRenamed;
        public int membersRenamed;
        public String mapping = "";
    }

    // ------------------------------------------------------------------
    // class-file model
    // ------------------------------------------------------------------

    private static final class Mem {
        int access, name, desc;
        byte[] attrs;           // starts with attributes_count
    }

    private static final class CF {
        int minor, major, count;
        int[] tag, a, b;
        byte[][] raw;
        int access, thisIdx, superIdx;
        int[] ifaces;
        Mem[] fields, methods;
        byte[] tail;            // class attributes (count + data)

        HashMap utf8Cache = new HashMap(); // String -> Integer (only for entries we add)

        String utf(int i) {
            try {
                return new String(raw[i], "UTF-8");
            } catch (java.io.UnsupportedEncodingException e) {
                return new String(raw[i]);
            }
        }

        String className(int classIdx) {
            return utf(a[classIdx]);
        }

        String internalName() {
            return className(thisIdx);
        }

        void grow() {
            if (count < tag.length) return;
            int n = tag.length * 2 + 8;
            tag = copyOf(tag, n);
            a = copyOf(a, n);
            b = copyOf(b, n);
            byte[][] r2 = new byte[n][];
            System.arraycopy(raw, 0, r2, 0, raw.length);
            raw = r2;
        }

        int addUtf8(String s) throws IOException {
            Integer hit = (Integer) utf8Cache.get(s);
            if (hit != null) return hit.intValue();
            grow();
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            new DataOutputStream(bos).writeUTF(s);
            byte[] all = bos.toByteArray();
            byte[] payload = new byte[all.length - 2];
            System.arraycopy(all, 2, payload, 0, payload.length);
            int idx = count++;
            tag[idx] = 1;
            raw[idx] = payload;
            utf8Cache.put(s, new Integer(idx));
            return idx;
        }

        int addNameAndType(int nameIdx, int descIdx) {
            grow();
            int idx = count++;
            tag[idx] = 12;
            a[idx] = nameIdx;
            b[idx] = descIdx;
            return idx;
        }
    }

    private static int[] copyOf(int[] src, int n) {
        int[] d = new int[n];
        System.arraycopy(src, 0, d, 0, src.length);
        return d;
    }

    // ------------------------------------------------------------------
    // parse / write
    // ------------------------------------------------------------------

    private static CF parse(byte[] data) throws IOException {
        DataInputStream in = new DataInputStream(new ByteArrayInputStream(data));
        if (in.readInt() != 0xCAFEBABE) throw new IOException("bad magic");
        CF c = new CF();
        c.minor = in.readUnsignedShort();
        c.major = in.readUnsignedShort();
        c.count = in.readUnsignedShort();
        int cap = c.count + 4;
        c.tag = new int[cap];
        c.a = new int[cap];
        c.b = new int[cap];
        c.raw = new byte[cap][];
        for (int i = 1; i < c.count; i++) {
            int t = in.readUnsignedByte();
            c.tag[i] = t;
            switch (t) {
                case 1: {
                    int len = in.readUnsignedShort();
                    byte[] r = new byte[len];
                    in.readFully(r);
                    c.raw[i] = r;
                    break;
                }
                case 3:
                case 4: {
                    byte[] r = new byte[4];
                    in.readFully(r);
                    c.raw[i] = r;
                    break;
                }
                case 5:
                case 6: {
                    byte[] r = new byte[8];
                    in.readFully(r);
                    c.raw[i] = r;
                    i++; // long/double occupy two slots
                    break;
                }
                case 7:
                case 8:
                    c.a[i] = in.readUnsignedShort();
                    break;
                case 9:
                case 10:
                case 11:
                case 12:
                    c.a[i] = in.readUnsignedShort();
                    c.b[i] = in.readUnsignedShort();
                    break;
                default:
                    throw new IOException("unsupported constant pool tag " + t);
            }
        }
        c.access = in.readUnsignedShort();
        c.thisIdx = in.readUnsignedShort();
        c.superIdx = in.readUnsignedShort();
        int ni = in.readUnsignedShort();
        c.ifaces = new int[ni];
        for (int i = 0; i < ni; i++) c.ifaces[i] = in.readUnsignedShort();
        c.fields = readMembers(in);
        c.methods = readMembers(in);

        ByteArrayOutputStream rest = new ByteArrayOutputStream();
        byte[] buf = new byte[512];
        int n;
        while ((n = in.read(buf)) > 0) rest.write(buf, 0, n);
        c.tail = rest.toByteArray();
        checkAttributes(c.tail);
        return c;
    }

    private static Mem[] readMembers(DataInputStream in) throws IOException {
        int n = in.readUnsignedShort();
        Mem[] out = new Mem[n];
        for (int i = 0; i < n; i++) {
            Mem m = new Mem();
            m.access = in.readUnsignedShort();
            m.name = in.readUnsignedShort();
            m.desc = in.readUnsignedShort();
            int ac = in.readUnsignedShort();
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            DataOutputStream out2 = new DataOutputStream(bos);
            out2.writeShort(ac);
            for (int k = 0; k < ac; k++) {
                int an = in.readUnsignedShort();
                int len = in.readInt();
                if (len < 0) throw new IOException("bad attribute length");
                byte[] body = new byte[len];
                in.readFully(body);
                out2.writeShort(an);
                out2.writeInt(len);
                out2.write(body);
            }
            m.attrs = bos.toByteArray();
            out[i] = m;
        }
        return out;
    }

    /** Throws unless `attrs` is exactly one attributes_count + that many attributes. */
    private static void checkAttributes(byte[] attrs) throws IOException {
        DataInputStream in = new DataInputStream(new ByteArrayInputStream(attrs));
        int ac = in.readUnsignedShort();
        for (int k = 0; k < ac; k++) {
            in.readUnsignedShort();
            int len = in.readInt();
            if (len < 0 || in.skipBytes(len) != len) throw new IOException("truncated attribute");
        }
        if (in.available() != 0) throw new IOException("trailing bytes after class attributes");
    }

    private static byte[] write(CF c) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        DataOutputStream out = new DataOutputStream(bos);
        out.writeInt(0xCAFEBABE);
        out.writeShort(c.minor);
        out.writeShort(c.major);
        out.writeShort(c.count);
        for (int i = 1; i < c.count; i++) {
            int t = c.tag[i];
            if (t == 0) continue; // second slot of a long/double
            out.writeByte(t);
            switch (t) {
                case 1:
                    out.writeShort(c.raw[i].length);
                    out.write(c.raw[i]);
                    break;
                case 3:
                case 4:
                case 5:
                case 6:
                    out.write(c.raw[i]);
                    break;
                case 7:
                case 8:
                    out.writeShort(c.a[i]);
                    break;
                default:
                    out.writeShort(c.a[i]);
                    out.writeShort(c.b[i]);
                    break;
            }
        }
        out.writeShort(c.access);
        out.writeShort(c.thisIdx);
        out.writeShort(c.superIdx);
        out.writeShort(c.ifaces.length);
        for (int i = 0; i < c.ifaces.length; i++) out.writeShort(c.ifaces[i]);
        writeMembers(out, c.fields);
        writeMembers(out, c.methods);
        out.write(c.tail);
        out.flush();
        return bos.toByteArray();
    }

    private static void writeMembers(DataOutputStream out, Mem[] ms) throws IOException {
        out.writeShort(ms.length);
        for (int i = 0; i < ms.length; i++) {
            out.writeShort(ms[i].access);
            out.writeShort(ms[i].name);
            out.writeShort(ms[i].desc);
            out.write(ms[i].attrs);
        }
    }

    // ------------------------------------------------------------------
    // renaming
    // ------------------------------------------------------------------

    /** Short lowercase names: a..z, aa..az, ba.. */
    private static String shortName(int k) {
        StringBuffer sb = new StringBuffer();
        k++;
        while (k > 0) {
            k--;
            sb.insert(0, (char) ('a' + (k % 26)));
            k /= 26;
        }
        return sb.toString();
    }

    private static String packageOf(String internal) {
        int s = internal.lastIndexOf('/');
        return s < 0 ? "" : internal.substring(0, s + 1);
    }

    /** Rewrites every class reference inside a field/method descriptor (or array class name). */
    private static String mapDesc(String d, Map classMap) {
        if (d.indexOf('L') < 0) return d;
        StringBuffer sb = new StringBuffer();
        int i = 0;
        while (i < d.length()) {
            char ch = d.charAt(i);
            if (ch == 'L') {
                int semi = d.indexOf(';', i);
                if (semi < 0) { sb.append(d.substring(i)); break; }
                String name = d.substring(i + 1, semi);
                String repl = (String) classMap.get(name);
                sb.append('L').append(repl != null ? repl : name).append(';');
                i = semi + 1;
            } else {
                sb.append(ch);
                i++;
            }
        }
        return sb.toString();
    }

    /**
     * @param names      class names as produced by the compiler (parallel to bytes)
     * @param bytes      the compiled .class files
     * @param mainClass  MIDlet-1 class; never renamed
     * @param level      1 = classes, 2 = classes + private members
     */
    public static Result run(String[] names, byte[][] bytes, String mainClass, int level,
                             java.util.Set privateMembers) throws IOException {
        int n = bytes.length;
        CF[] cf = new CF[n];
        String[] internal = new String[n];
        HashSet taken = new HashSet();
        for (int i = 0; i < n; i++) {
            cf[i] = parse(bytes[i]);
            internal[i] = cf[i].internalName();
            taken.add(internal[i]);
        }
        String mainInternal = mainClass == null ? "" : mainClass.replace('.', '/');

        // ---- class map ----
        HashMap classMap = new HashMap();
        StringBuffer mapping = new StringBuffer();
        HashMap counters = new HashMap(); // package -> next index
        for (int i = 0; i < n; i++) {
            if (internal[i].equals(mainInternal)) continue;
            String pkg = packageOf(internal[i]);
            Integer start = (Integer) counters.get(pkg);
            int k = start == null ? 0 : start.intValue();
            String cand;
            do {
                cand = pkg + shortName(k);
                k++;
            } while (taken.contains(cand));
            counters.put(pkg, new Integer(k));
            taken.add(cand);
            classMap.put(internal[i], cand);
            mapping.append(internal[i]).append(" -> ").append(cand).append('\n');
        }

        // ---- private member map (level 2) ----
        HashMap memberMap = new HashMap(); // owner.name:desc -> new name
        int memberCount = 0;
        if (level >= 2) {
            for (int i = 0; i < n; i++) {
                CF c = cf[i];
                HashSet used = new HashSet();
                collectNames(c, c.fields, used);
                collectNames(c, c.methods, used);
                int k = 0;
                for (int pass = 0; pass < 2; pass++) {
                    Mem[] list = pass == 0 ? c.fields : c.methods;
                    for (int j = 0; j < list.length; j++) {
                        Mem m = list[j];
                        String nm = c.utf(m.name);
                        boolean priv = (m.access & ACC_PRIVATE) != 0
                                || (privateMembers != null && privateMembers.contains(internal[i] + "." + nm));
                        if (!priv) continue;
                        if (nm.startsWith("<")) continue;
                        String cand;
                        do {
                            cand = shortName(k);
                            k++;
                        } while (used.contains(cand));
                        used.add(cand);
                        String key = internal[i] + "." + nm + ":" + c.utf(m.desc);
                        memberMap.put(key, cand);
                        mapping.append(internal[i]).append('.').append(nm).append(" -> ").append(cand).append('\n');
                        memberCount++;
                    }
                }
            }
        }

        // ---- rewrite each class ----
        Result res = new Result();
        res.names = new String[n];
        res.classes = new byte[n][];
        for (int i = 0; i < n; i++) {
            CF c = cf[i];
            String owner = internal[i];

            // (1) member references (uses ORIGINAL owner names, so do this first)
            if (!memberMap.isEmpty()) {
                HashMap natCache = new HashMap();
                int pool = c.count;
                for (int e = 1; e < pool; e++) {
                    int t = c.tag[e];
                    if (t != 9 && t != 10 && t != 11) continue;
                    String refOwner = c.className(c.a[e]);
                    int nat = c.b[e];
                    String nm = c.utf(c.a[nat]);
                    String ds = c.utf(c.b[nat]);
                    String nn = (String) memberMap.get(refOwner + "." + nm + ":" + ds);
                    if (nn == null) continue;
                    String ck = nat + "/" + nn;
                    Integer hit = (Integer) natCache.get(ck);
                    if (hit == null) {
                        hit = new Integer(c.addNameAndType(c.addUtf8(nn), c.b[nat]));
                        natCache.put(ck, hit);
                    }
                    c.b[e] = hit.intValue();
                }
                // (2) own declarations
                for (int pass = 0; pass < 2; pass++) {
                    Mem[] list = pass == 0 ? c.fields : c.methods;
                    for (int j = 0; j < list.length; j++) {
                        Mem m = list[j];
                        String nn = (String) memberMap.get(owner + "." + c.utf(m.name) + ":" + c.utf(m.desc));
                        if (nn != null) m.name = c.addUtf8(nn);
                    }
                }
            }

            // (3) descriptors
            int pool = c.count;
            for (int e = 1; e < pool; e++) {
                if (c.tag[e] != 12) continue;
                String d = c.utf(c.b[e]);
                String nd = mapDesc(d, classMap);
                if (!nd.equals(d)) c.b[e] = c.addUtf8(nd);
            }
            for (int pass = 0; pass < 2; pass++) {
                Mem[] list = pass == 0 ? c.fields : c.methods;
                for (int j = 0; j < list.length; j++) {
                    String d = c.utf(list[j].desc);
                    String nd = mapDesc(d, classMap);
                    if (!nd.equals(d)) list[j].desc = c.addUtf8(nd);
                }
            }

            // (4) class names
            pool = c.count;
            for (int e = 1; e < pool; e++) {
                if (c.tag[e] != 7) continue;
                String nm = c.utf(c.a[e]);
                String nn;
                if (nm.length() > 0 && nm.charAt(0) == '[') {
                    nn = mapDesc(nm, classMap);
                } else {
                    nn = (String) classMap.get(nm);
                    if (nn == null) nn = nm;
                }
                if (!nn.equals(nm)) c.a[e] = c.addUtf8(nn);
            }

            byte[] out = write(c);
            // sanity: the result must parse again and keep its shape
            CF check = parse(out);
            if (check.fields.length != c.fields.length || check.methods.length != c.methods.length) {
                throw new IOException("verification failed for " + owner);
            }
            res.classes[i] = out;
            res.names[i] = check.internalName();
        }
        res.classesRenamed = classMap.size();
        res.membersRenamed = memberCount;
        res.mapping = mapping.toString();
        return res;
    }

    private static void collectNames(CF c, Mem[] list, HashSet used) {
        for (int j = 0; j < list.length; j++) used.add(c.utf(list[j].name));
    }
}
