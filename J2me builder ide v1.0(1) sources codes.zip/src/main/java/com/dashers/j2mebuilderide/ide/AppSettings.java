package com.dashers.j2mebuilderide.ide;

import android.content.Context;
import android.content.SharedPreferences;

/** App-wide options, backed by SharedPreferences("ide"). */
public final class AppSettings {
    private final SharedPreferences sp;

    public AppSettings(Context c) {
        sp = c.getSharedPreferences("ide", Context.MODE_PRIVATE);
    }

    public SharedPreferences raw() { return sp; }

    // ---- appearance ----
    public boolean dark()               { return sp.getBoolean("dark", true); }
    public void setDark(boolean v)      { sp.edit().putBoolean("dark", v).apply(); }
    /** App theme id (see ui.Themes). Falls back to the old dark/light switch. */
    public String theme()               { return sp.getString("theme", sp.getBoolean("dark", true) ? "midnight" : "light"); }
    public void setTheme(String id)     { sp.edit().putString("theme", id).apply(); }
    /** Editor colour scheme id, or "auto" to follow the app theme. */
    public String syntaxTheme()         { return sp.getString("syntax", "auto"); }
    public void setSyntaxTheme(String id){ sp.edit().putString("syntax", id).apply(); }
    public boolean showSplash()         { return sp.getBoolean("splash", true); }
    public void setShowSplash(boolean v){ sp.edit().putBoolean("splash", v).apply(); }
    public int fontSize()               { return sp.getInt("fontSize", 13); }
    public void setFontSize(int v)      { sp.edit().putInt("fontSize", Math.max(9, Math.min(24, v))).apply(); }

    // ---- editor ----
    public boolean wordWrap()           { return sp.getBoolean("wrap", true); }
    public void setWordWrap(boolean v)  { sp.edit().putBoolean("wrap", v).apply(); }
    public boolean lineNumbers()        { return sp.getBoolean("lineNumbers", true); }
    public void setLineNumbers(boolean v){ sp.edit().putBoolean("lineNumbers", v).apply(); }
    public boolean autoPair()           { return sp.getBoolean("autoPair", true); }
    public void setAutoPair(boolean v)  { sp.edit().putBoolean("autoPair", v).apply(); }
    public boolean autoIndent()         { return sp.getBoolean("autoIndent", true); }
    public void setAutoIndent(boolean v){ sp.edit().putBoolean("autoIndent", v).apply(); }
    public boolean suggestions()        { return sp.getBoolean("suggest", true); }
    public void setSuggestions(boolean v){ sp.edit().putBoolean("suggest", v).apply(); }
    public int tabSize()                { return sp.getInt("tabSize", 4); }
    public void setTabSize(int v)       { sp.edit().putInt("tabSize", v == 2 ? 2 : 4).apply(); }
    public boolean autoSave()           { return sp.getBoolean("autoSave", true); }
    public void setAutoSave(boolean v)  { sp.edit().putBoolean("autoSave", v).apply(); }
    public boolean keepScreenOn()       { return sp.getBoolean("keepOn", false); }
    public void setKeepScreenOn(boolean v){ sp.edit().putBoolean("keepOn", v).apply(); }

    // ---- build ----
    public boolean animatedLog()        { return sp.getBoolean("animLog", true); }
    public void setAnimatedLog(boolean v){ sp.edit().putBoolean("animLog", v).apply(); }
    public boolean autoOpenLog()        { return sp.getBoolean("autoLog", true); }
    public void setAutoOpenLog(boolean v){ sp.edit().putBoolean("autoLog", v).apply(); }
    public boolean copyToDownloads()    { return sp.getBoolean("copyDl", false); }
    public void setCopyToDownloads(boolean v){ sp.edit().putBoolean("copyDl", v).apply(); }

    /** After a successful build, open the .jar in a J2ME emulator app (J2ME Loader, ...). */
    public boolean autoOpenEmulator()   { return sp.getBoolean("autoEmu", false); }
    public void setAutoOpenEmulator(boolean v){ sp.edit().putBoolean("autoEmu", v).apply(); }
    /** Package of the chosen emulator; "" = let Android show its app chooser. */
    public String emulatorPkg()         { return sp.getString("emuPkg", ""); }
    public void setEmulatorPkg(String v){ sp.edit().putString("emuPkg", v == null ? "" : v).apply(); }

    /** CLDC StackMap: long/double local = one entry (true, default) or (Long/Double, Top) pair (false). */
    public boolean stackMapLongDoubleOneEntry()     { return sp.getBoolean("smLongOne", true); }
    public void setStackMapLongDoubleOneEntry(boolean v) { sp.edit().putBoolean("smLongOne", v).apply(); }

    /** Run ECJ class files through ProGuard-core's CLDC preverifier (inline jsr/ret + StackMap) when building a .jar. */
    public boolean proguardPreverify()  { return sp.getBoolean("pgPreverify", true); }
    public void setProguardPreverify(boolean v) { sp.edit().putBoolean("pgPreverify", v).apply(); }

    // ---- storage ----
    public boolean sharedStorage()      { return sp.getBoolean("shared", false); }
    public void setSharedStorage(boolean v){ sp.edit().putBoolean("shared", v).apply(); }
    /** User chose "Don't ask again" on the start-up shared-storage question. */
    public boolean sharedPromptDisabled()      { return sp.getBoolean("sharedNoAsk", false); }
    public void setSharedPromptDisabled(boolean v){ sp.edit().putBoolean("sharedNoAsk", v).apply(); }

    // ---- recent projects (most recent first, comma separated) ----
    public String[] recent() {
        String s = sp.getString("recent", "");
        if (s.length() == 0) return new String[0];
        return s.split(",");
    }

    public void pushRecent(String name) {
        String[] cur = recent();
        StringBuffer sb = new StringBuffer(name);
        int kept = 1;
        for (int i = 0; i < cur.length && kept < 5; i++) {
            if (cur[i].equals(name) || cur[i].length() == 0) continue;
            sb.append(',').append(cur[i]);
            kept++;
        }
        sp.edit().putString("recent", sb.toString()).apply();
    }

    public void dropRecent(String name) {
        String[] cur = recent();
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < cur.length; i++) {
            if (cur[i].equals(name) || cur[i].length() == 0) continue;
            if (sb.length() > 0) sb.append(',');
            sb.append(cur[i]);
        }
        sp.edit().putString("recent", sb.toString()).apply();
    }
}
