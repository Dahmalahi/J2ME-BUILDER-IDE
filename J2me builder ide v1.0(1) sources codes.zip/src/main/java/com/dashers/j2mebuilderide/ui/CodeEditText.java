package com.dashers.j2mebuilderide.ui;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.text.Editable;
import android.text.InputType;
import android.text.Layout;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.widget.EditText;

/**
 * Monospace code editor:
 *  - soft word-wrap (on by default, so long lines on a phone are never cut off)
 *  - line-number gutter that numbers LOGICAL lines (a wrapped line keeps one number)
 *  - current-line and error-line highlight
 *  - find / replace / go-to-line helpers
 */
public class CodeEditText extends EditText {

    private final Paint numPaint;
    private final Paint gutterPaint;
    private final Paint sepPaint;
    private final Paint errPaint;
    private final Paint curPaint;
    private int errorLine = -1;
    private int gutter = 0;
    private boolean wrap = true;
    private boolean showNumbers = true;
    private boolean keyboardOpen = false;
    private ScaleGestureDetector scaleDetector;
    private float zoomTextSp = 13f;
    // line-start index: rebuilt once after an edit instead of scanning the whole text on every frame
    // (this is what keeps scrolling and typing smooth in files with 4000+ lines)
    private int[] lineIdx = new int[512];
    private int lineIdxCount;
    private boolean lineIdxDirty = true;
    private Runnable scrollHook;

    public CodeEditText(Context c) {
        super(c);
        numPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        numPaint.setTypeface(Typeface.MONOSPACE);
        numPaint.setTextAlign(Paint.Align.RIGHT);
        gutterPaint = new Paint();
        sepPaint = new Paint();
        errPaint = new Paint();
        curPaint = new Paint();

        setTypeface(Typeface.MONOSPACE);
        setGravity(Gravity.TOP | Gravity.START);
        setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
        applyTheme();
        scaleDetector = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            public boolean onScale(ScaleGestureDetector d) {
                float factor = d.getScaleFactor();
                if (factor < 0.94f || factor > 1.06f) {
                    zoomTextSp = Math.max(8f, Math.min(28f, zoomTextSp * factor));
                    applyZoomSize();
                }
                return true;
            }
        });
        configure(13, true, true);
    }

    /** Re-reads the colours from Ui (call after a theme switch). */
    public void applyTheme() {
        gutterPaint.setColor(Ui.SURFACE);
        sepPaint.setColor(Ui.STROKE);
        errPaint.setColor((Ui.RED & 0x00FFFFFF) | 0x33000000);
        curPaint.setColor(Ui.dark ? 0x14FFFFFF : 0x0F000000);
        setTextColor(Ui.EDITOR_TEXT);
        setBackgroundColor(Ui.EDITOR);
        setHighlightColor(Ui.ACCENT_SELECT);
        invalidate();
    }

    public void configure(int fontSp, boolean wrapLines, boolean lineNumbers) {
        zoomTextSp = fontSp;
        setTextSize(TypedValue.COMPLEX_UNIT_SP, fontSp);
        numPaint.setTextSize(getTextSize() * 0.85f);
        wrap = wrapLines;
        showNumbers = lineNumbers;
        setHorizontallyScrolling(!wrap);
        if (wrap) scrollTo(0, getScrollY());
        gutter = -1;
        updateGutter();
        invalidate();
    }

    private void applyZoomSize() {
        setTextSize(TypedValue.COMPLEX_UNIT_SP, zoomTextSp);
        numPaint.setTextSize(getTextSize() * 0.85f);
        gutter = -1; updateGutter(); invalidate();
    }

    public float getZoomTextSp() { return zoomTextSp; }

    @Override public boolean onTouchEvent(MotionEvent event) {
        if (scaleDetector != null) scaleDetector.onTouchEvent(event);
        return super.onTouchEvent(event);
    }

    public void setErrorLine(int line) {
        errorLine = line;
        invalidate();
    }

    public int getErrorLine() {
        return errorLine;
    }

    private void updateGutter() {
        int g = 0;
        if (showNumbers) {
            int lines = Math.max(getLineCount(), 1);
            int digits = Math.max(3, String.valueOf(lines).length());
            g = (int) (numPaint.measureText("0") * digits) + Ui.dp(14);
        }
        if (g != gutter) {
            gutter = g;
            applyPadding();
        }
    }

    /** Small bottom padding (32dp closed, 6dp with keyboard): a big one ate the visible area when the keyboard was up and
     *  hid the line being edited. Extra scroll-past-end room only when the keyboard is closed. */
    private void applyPadding() {
        setPadding(gutter + Ui.dp(10), Ui.dp(8), wrap ? Ui.dp(14) : Ui.dp(60),
                keyboardOpen ? Ui.dp(6) : Ui.dp(32));
    }

    public void setKeyboardOpen(boolean open) {
        if (keyboardOpen == open) return;
        keyboardOpen = open;
        applyPadding();
    }

    /** Scrolls so the caret line is fully visible above the keyboard. */
    public void revealCaret() {
        try {
            int sel = getSelectionStart();
            int n = getText() == null ? 0 : getText().length();
            if (sel >= 0 && getLayout() != null) bringPointIntoView(Math.min(sel, n));
        } catch (RuntimeException ignore) { }
    }

    // ---- clipboard: plain-text, crash-proof cut / copy / paste / select all ----

    @Override
    public boolean onTextContextMenuItem(int id) {
        try {
            if (id == android.R.id.paste || id == android.R.id.pasteAsPlainText) {
                pastePlain();
                return true;
            }
            if (id == android.R.id.cut) {
                int a = Math.min(getSelectionStart(), getSelectionEnd());
                int b = Math.max(getSelectionStart(), getSelectionEnd());
                if (a >= 0 && b > a) {
                    putClip(getText().subSequence(a, b).toString());
                    getText().delete(a, b);
                }
                return true;
            }
            if (id == android.R.id.copy) {
                int a = Math.min(getSelectionStart(), getSelectionEnd());
                int b = Math.max(getSelectionStart(), getSelectionEnd());
                if (a >= 0 && b > a) putClip(getText().subSequence(a, b).toString());
                return true;
            }
            if (id == android.R.id.selectAll) {
                setSelection(0, getText().length());
                return true;
            }
            return super.onTextContextMenuItem(id);
        } catch (RuntimeException e) {
            return true;   // never let a clipboard problem close the app
        }
    }

    private void putClip(String text) {
        ClipboardManager cm = (ClipboardManager) getContext().getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("code", text));
    }

    /** Pastes the clipboard as PLAIN text (no rich-text spans), replacing the selection. */
    private void pastePlain() {
        ClipboardManager cm = (ClipboardManager) getContext().getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm == null || !cm.hasPrimaryClip()) return;
        ClipData cd = cm.getPrimaryClip();
        if (cd == null || cd.getItemCount() == 0) return;
        CharSequence cs = cd.getItemAt(0).coerceToText(getContext());
        if (cs == null) return;
        String text = cs.toString().replace("\r\n", "\n").replace('\r', '\n');
        Editable e = getText();
        int a = Math.max(0, Math.min(getSelectionStart(), getSelectionEnd()));
        int b = Math.max(0, Math.max(getSelectionStart(), getSelectionEnd()));
        a = Math.min(a, e.length());
        b = Math.min(b, e.length());
        e.replace(a, b, text);
        int caret = Math.min(a + text.length(), getText().length());
        setSelection(caret);
    }

    @Override
    protected void onTextChanged(CharSequence text, int start, int lengthBefore, int lengthAfter) {
        super.onTextChanged(text, start, lengthBefore, lengthAfter);
        lineIdxDirty = true;
        updateGutter();
    }

    @Override
    protected void onScrollChanged(int l, int t, int oldl, int oldt) {
        super.onScrollChanged(l, t, oldl, oldt);
        if (scrollHook != null && t != oldt) scrollHook.run();
    }

    /** Called (on the UI thread) whenever the editor scrolls vertically; keep it cheap / debounce inside. */
    public void setScrollHook(Runnable r) { scrollHook = r; }

    /** [start, end) char range of the lines on screen plus about one screen above and two below. */
    public int[] visibleRange() {
        int n = getText() == null ? 0 : getText().length();
        Layout l = getLayout();
        if (l == null || n == 0 || getHeight() <= 0) return new int[] { 0, Math.min(n, 8000) };
        int top = getExtendedPaddingTop();
        int sy = getScrollY(), h = getHeight();
        int f = l.getLineForVertical(Math.max(0, sy - top - h));
        int g = l.getLineForVertical(Math.max(0, sy - top + 2 * h));
        g = Math.min(g, l.getLineCount() - 1);
        return new int[] { l.getLineStart(f), l.getLineEnd(g) };
    }

    private void ensureLineIndex() {
        if (!lineIdxDirty) return;
        CharSequence t = getText();
        int n = t.length();
        int c = 0;
        lineIdx[c++] = 0;
        for (int i = 0; i < n; i++) {
            if (t.charAt(i) == '\n') {
                if (c == lineIdx.length) {
                    int[] g = new int[c * 2];
                    System.arraycopy(lineIdx, 0, g, 0, c);
                    lineIdx = g;
                }
                lineIdx[c++] = i + 1;
            }
        }
        lineIdxCount = c;
        lineIdxDirty = false;
    }

    /** 1-based logical line that contains the char offset. */
    public int logicalLineOf(int offset) {
        ensureLineIndex();
        int lo = 0, hi = lineIdxCount - 1;
        while (lo < hi) {
            int mid = (lo + hi + 1) >>> 1;
            if (lineIdx[mid] <= offset) lo = mid; else hi = mid - 1;
        }
        return lo + 1;
    }

    @Override
    protected void onSelectionChanged(int selStart, int selEnd) {
        super.onSelectionChanged(selStart, selEnd);
        invalidate();
        if (keyboardOpen && selStart == selEnd && selStart >= 0) {
            final int pos = selStart;
            post(new Runnable() {
                public void run() {
                    try {
                        int n = getText() == null ? 0 : getText().length();
                        if (getLayout() != null) bringPointIntoView(Math.max(0, Math.min(pos, n)));
                    } catch (RuntimeException ignore) { }
                }
            });
        }
    }

    // ---- text helpers (logical lines = split by '\n', unaffected by wrapping) ----

    /** 0-based offset of the first char of the 1-based logical line, or -1. */
    public int lineStartOffset(int line) {
        if (line < 1) return -1;
        if (line == 1) return 0;
        ensureLineIndex();
        return line <= lineIdxCount ? lineIdx[line - 1] : -1;
    }

    public int lineCountLogical() {
        ensureLineIndex();
        return lineIdxCount;
    }

    public boolean goToLine(int line) {
        int off = lineStartOffset(line);
        if (off < 0) return false;
        requestFocus();
        setSelection(off);
        bringPointIntoView(off);
        return true;
    }

    /** Case-insensitive search; selects the hit. Wraps around. */
    public boolean find(String query, boolean forward) {
        if (query == null || query.length() == 0) return false;
        String t = getText().toString().toLowerCase();
        String q = query.toLowerCase();
        int idx;
        if (forward) {
            int from = Math.max(0, getSelectionEnd());
            idx = t.indexOf(q, from);
            if (idx < 0) idx = t.indexOf(q);
        } else {
            int from = getSelectionStart() - 1;
            idx = from >= 0 ? t.lastIndexOf(q, from) : -1;
            if (idx < 0) idx = t.lastIndexOf(q);
        }
        if (idx < 0) return false;
        requestFocus();
        setSelection(idx, idx + q.length());
        bringPointIntoView(idx);
        return true;
    }

    /** Replaces every case-insensitive match; returns how many. */
    public int replaceAll(String query, String with) {
        if (query == null || query.length() == 0) return 0;
        Editable e = getText();
        String t = e.toString().toLowerCase();
        String q = query.toLowerCase();
        int count = 0;
        int idx = t.lastIndexOf(q);
        while (idx >= 0) {
            e.replace(idx, idx + q.length(), with);
            count++;
            idx = idx == 0 ? -1 : t.lastIndexOf(q, idx - 1);
        }
        return count;
    }

    // ---- drawing ----

    @Override
    protected void onDraw(Canvas canvas) {
        try {
            drawCode(canvas);
        } catch (RuntimeException e) {
            // layout out of sync with the text for one frame (e.g. right after a big paste)
            try { super.onDraw(canvas); } catch (RuntimeException ignore) { }
            postInvalidate();
        }
    }

    private void drawCode(Canvas canvas) {
        Layout l = getLayout();
        int sx = getScrollX(), sy = getScrollY(), w = getWidth(), h = getHeight();
        int top = getExtendedPaddingTop();
        CharSequence t = getText();
        int sel = getSelectionStart();
        if (l != null) {
            if (errorLine > 0) {
                int off = lineStartOffset(errorLine);
                if (off >= 0 && off <= t.length()) {
                    int end = off;
                    while (end < t.length() && t.charAt(end) != '\n') end++;
                    int a = l.getLineForOffset(off);
                    int b = l.getLineForOffset(end);
                    canvas.drawRect(sx, top + l.getLineTop(a), sx + w, top + l.getLineBottom(b), errPaint);
                }
            }
            if (sel >= 0 && sel == getSelectionEnd() && sel <= t.length()) {
                int cl = l.getLineForOffset(sel);
                canvas.drawRect(sx, top + l.getLineTop(cl), sx + w, top + l.getLineBottom(cl), curPaint);
            }
        }
        super.onDraw(canvas);
        if (l != null && showNumbers && gutter > 0) {
            canvas.drawRect(sx, sy, sx + gutter, sy + h, gutterPaint);
            canvas.drawLine(sx + gutter, sy, sx + gutter, sy + h, sepPaint);

            int lc = l.getLineCount();
            int first = l.getLineForVertical(Math.max(0, sy - top));
            int last = l.getLineForVertical(Math.max(0, sy + h - top));

            int firstStart = l.getLineStart(first);
            int logical = logicalLineOf(firstStart);

            int caretLogical = -1;
            if (sel >= 0 && sel <= t.length()) caretLogical = logicalLineOf(sel);

            for (int i = first; i <= last && i < lc; i++) {
                int ls = l.getLineStart(i);
                boolean start = ls == 0 || t.charAt(ls - 1) == '\n';
                if (!start) continue;
                if (i > first) logical++;
                numPaint.setColor(logical == errorLine ? Ui.RED : (logical == caretLogical ? Ui.EDITOR_TEXT : Ui.MUTED));
                canvas.drawText(String.valueOf(logical), sx + gutter - Ui.dp(8), top + l.getLineBaseline(i), numPaint);
            }
        }
    }
}
