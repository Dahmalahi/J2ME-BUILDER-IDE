package com.dashers.j2mebuilderide.emu.android;

import android.content.Context;

import com.dashers.j2mebuilderide.emu.nat.NativeLoader;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.MessageDigest;

import dalvik.system.DexClassLoader;

/**
 * Native engine on Android: converts the MIDlet jar to dex once (Android dx, with the Instrumenter rewriting each class,
 * as J2ME-Loader does) and loads it with a DexClassLoader, so the phone's runtime executes the MIDlet directly.
 * Result is cached per jar content. Needs a device test.
 */
public final class AndroidNativeSupport {
    private AndroidNativeSupport() { }

    public static NativeLoader prepare(Context ctx, byte[] jar) throws Exception {
        String key = sha1(jar);
        File dir = new File(new File(ctx.getFilesDir(), "emu_dex"), key);
        final File dex = new File(dir, "classes.dex");
        if (!dex.isFile() || dex.length() < 100) {
            if (!dir.isDirectory() && !dir.mkdirs()) throw new IOException("cannot create " + dir);
            final File tmpJar = new File(dir, "in.jar");
            FileOutputStream o = new FileOutputStream(tmpJar);
            try { o.write(jar); } finally { o.close(); }
            final File tmpDex = new File(dir, "classes.tmp.dex");
            final Throwable[] err = new Throwable[1];
            final ByteArrayOutputStream dxLog = new ByteArrayOutputStream();
            Thread t = new Thread(null, new Runnable() {
                public void run() {
                    try {
                        com.android.dx.command.dexer.DxContext dctx = new com.android.dx.command.dexer.DxContext(dxLog, dxLog);
                        int rc = com.android.dx.command.dexer.Main.runCaptured(new String[]{"--no-optimize", "--core-library", "--output=" + tmpDex.getAbsolutePath(), tmpJar.getAbsolutePath()}, dctx);
                        dctx.out.flush();
                        dctx.err.flush();
                        if (rc != 0) throw new IOException("dx returned " + rc);
                    } catch (Throwable e) { err[0] = e; }
                }
            }, "dx", 64L << 20);   // dx recurses deeply on big methods
            t.start();
            t.join();
            tmpJar.delete();
            if (err[0] != null || !tmpDex.isFile()) {
                tmpDex.delete();
                String msg = dxLog.toString().trim();
                if (msg.length() > 1500) msg = msg.substring(0, 1500) + "...";
                throw new IOException("dex conversion failed: " + err[0] + (msg.length() > 0 ? "\n" + msg : ""));
            }
            if (!tmpDex.renameTo(dex)) throw new IOException("cannot store " + dex);
        }
        dex.setReadOnly();   // Android 14+ refuses to load writable dex files
        File odex = new File(ctx.getCodeCacheDir(), "emu_odex");
        odex.mkdirs();
        final DexClassLoader cl = new DexClassLoader(dex.getAbsolutePath(), odex.getAbsolutePath(), null, AndroidNativeSupport.class.getClassLoader());
        return new NativeLoader() { public Class<?> loadClass(String n) throws ClassNotFoundException { return cl.loadClass(n); } };
    }

    private static String sha1(byte[] b) throws Exception {
        byte[] h = MessageDigest.getInstance("SHA-1").digest(b);
        StringBuilder sb = new StringBuilder();
        for (byte x : h) sb.append(String.format("%02x", x & 255));
        return sb.toString();
    }
}
