package com.dashers.j2mebuilderide.emu.midp;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;

/**
 * Bluetooth of the host (RFCOMM / SPP only). Addresses are 12 upper-case hex digits without colons, UUIDs are 32 hex digits.
 * Implementations: {@link SimulatedBluetooth} (default, a virtual echo device) and AndroidBluetooth (asks before it scans or connects).
 */
public interface BluetoothProvider {
    final class Dev {
        public final String address, name;
        public final int deviceClass;
        public Dev(String address, String name, int deviceClass) { this.address = address; this.name = name; this.deviceClass = deviceClass; }
    }

    interface InquiryListener {
        void found(Dev d);
        /** cancelled = stopped by cancelInquiry; error = the phone gave up. */
        void finished(boolean cancelled, boolean error);
    }

    interface Link {
        InputStream in();
        OutputStream out();
        String remoteAddress();
        void close();
    }

    interface Server {
        /** Blocks until a device connects; throws IOException when closed. */
        Link accept() throws IOException;
        void close();
    }

    String name();
    boolean real();
    boolean available();
    boolean isPowerOn();
    String address();
    String friendlyName();
    /** Paired devices. May throw SecurityException when the user refuses access. */
    List<Dev> bonded();
    void startInquiry(InquiryListener l) throws IOException;
    void cancelInquiry();
    /** Service UUIDs (32 hex digits) the device advertises, or null when unknown. */
    String[] services(String address);
    Link connect(String address, String uuid) throws IOException;
    Server listen(String uuid, String serviceName) throws IOException;
}
