package com.dashers.j2mebuilderide.emu.midp;

import com.dashers.j2mebuilderide.emu.gfx.Frame;

import java.util.ArrayList;
import java.util.List;

public abstract class Displayable {
    private String title;
    private final List<Command> commands = new ArrayList<Command>();
    private CommandListener listener;
    volatile boolean shown;

    public String getTitle() { return title; }
    public void setTitle(String t) { title = t; refresh(); }
    public boolean isShown() { return shown; }
    public int getWidth() { return Device.current().width(); }
    public int getHeight() { return Device.current().height(); }

    public synchronized void addCommand(Command c) {
        if (c == null) throw new NullPointerException();
        if (!commands.contains(c)) { commands.add(c); }
        refresh();
    }
    public synchronized void removeCommand(Command c) { commands.remove(c); refresh(); }
    public void setCommandListener(CommandListener l) { listener = l; }
    public CommandListener listener() { return listener; }
    public synchronized List<Command> commandsSnapshot() { return new ArrayList<Command>(commands); }

    private Ticker ticker;
    public Ticker getTicker() { return ticker; }
    public void setTicker(Ticker t) { ticker = t; refresh(); }
    /** Host input (type 0 pressed / 1 released / 2 repeated) for non-Canvas screens. */
    void keyEvent(Device d, int type, int code) { }
    void pointerEvent(Device d, int type, int x, int y) { }

    void refresh() { try { Device.current().display.requestRepaint(); } catch (IllegalStateException e) { /* not in a session */ } }

    abstract void render(Device d, Frame f);
    void showNotifyInternal() { shown = true; }
    void hideNotifyInternal() { shown = false; }
}
