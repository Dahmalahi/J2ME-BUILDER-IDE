package com.dashers.j2mebuilderide.emu.android;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Looper;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/** A yes/no question for the user, asked from a MIDlet thread: blocks until answered (never from the UI thread). */
final class Ask {
    private Ask() { }

    static boolean confirm(final Activity act, final String title, final String message, final String yes, final String no) {
        if (Looper.myLooper() == Looper.getMainLooper()) return false;
        final CountDownLatch latch = new CountDownLatch(1);
        final boolean[] ok = new boolean[1];
        act.runOnUiThread(new Runnable() {
            public void run() {
                try {
                    new Ui.Dlg(act).setTitle(title).setMessage(message).setCancelable(false)
                            .setPositiveButton(yes, new DialogInterface.OnClickListener() { public void onClick(DialogInterface d, int w) { ok[0] = true; latch.countDown(); } })
                            .setNegativeButton(no, new DialogInterface.OnClickListener() { public void onClick(DialogInterface d, int w) { latch.countDown(); } })
                            .show();
                } catch (RuntimeException e) { latch.countDown(); }
            }
        });
        try { latch.await(120, TimeUnit.SECONDS); } catch (InterruptedException e) { return false; }
        return ok[0];
    }
}
