package com.dashers.j2mebuilderide.emu.android;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.Bundle;
import android.os.Looper;
import android.telephony.SmsManager;
import android.telephony.SmsMessage;

import com.dashers.j2mebuilderide.emu.midp.SmsProvider;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/**
 * SMS for sms:// connections. Simulated by default (nothing leaves the phone). In "real" mode every send needs SEND_SMS
 * (asked at run time) AND the user's tap on a confirmation dialog - never silent. Real receiving is limited to binary
 * (data) SMS addressed to the port a MIDlet listens on; the phone's ordinary text messages are never handed to a MIDlet.
 * Needs a phone test.
 */
public final class AndroidSms implements SmsProvider {
    private final Activity act;
    private volatile boolean real;
    private final Map<Integer, BroadcastReceiver> receivers = new HashMap<Integer, BroadcastReceiver>();

    public AndroidSms(Activity a, boolean realMode) { act = a; real = realMode; }

    public void setReal(boolean on) { real = on; }
    public boolean real() { return real; }
    public String name() { return real ? "real SMS (asks before every message)" : "simulated SMS (nothing is sent)"; }

    public void send(String number, int port, String text, byte[] data, int segments) throws IOException {
        if (!real) return;
        if (!Permissions.ensure(act, "android.permission.SEND_SMS", 60000))
            throw new SecurityException("the SEND_SMS permission was refused - allow it in the phone's app settings, or use More > SMS > Simulated");
        String preview = text != null ? (text.length() > 160 ? text.substring(0, 160) + "..." : text) : data.length + " bytes of binary data (port " + port + ")";
        if (!confirm(number, preview, segments)) throw new SecurityException("the user refused to send the message");
        try {
            SmsManager sm = SmsManager.getDefault();
            if (text != null) {
                ArrayList<String> parts = sm.divideMessage(text);
                sm.sendMultipartTextMessage(number, null, parts, null, null);
            } else {
                sm.sendDataMessage(number, null, (short) Math.max(0, port), data, null, null);
            }
        } catch (RuntimeException e) {
            throw new IOException("the phone could not send the message: " + e.getMessage());
        }
    }

    /** Blocks the MIDlet thread until the user answers. */
    private boolean confirm(final String number, final String preview, final int segments) {
        if (Looper.myLooper() == Looper.getMainLooper()) return false;
        final CountDownLatch latch = new CountDownLatch(1);
        final boolean[] ok = new boolean[1];
        act.runOnUiThread(new Runnable() {
            public void run() {
                try {
                    new Ui.Dlg(act).setTitle("Send an SMS?")
                            .setMessage("A MIDlet wants to send " + segments + " message(s) to " + number + ":\n\n" + preview + "\n\nThis may cost money.")
                            .setCancelable(false)
                            .setPositiveButton("Send", new DialogInterface.OnClickListener() { public void onClick(DialogInterface d, int w) { ok[0] = true; latch.countDown(); } })
                            .setNegativeButton("Don't send", new DialogInterface.OnClickListener() { public void onClick(DialogInterface d, int w) { latch.countDown(); } })
                            .show();
                } catch (RuntimeException e) { latch.countDown(); }
            }
        });
        try { latch.await(120, TimeUnit.SECONDS); } catch (InterruptedException e) { return false; }
        return ok[0];
    }

    public void listen(final int port, final Sink sink) {
        if (!real) return;
        if (!Permissions.ensure(act, "android.permission.RECEIVE_SMS", 60000))
            throw new SecurityException("the RECEIVE_SMS permission was refused - allow it in the phone's app settings, or use More > SMS > Simulated");
        IntentFilter f = new IntentFilter("android.intent.action.DATA_SMS_RECEIVED");
        f.addDataScheme("sms");
        f.addDataAuthority("localhost", String.valueOf(port));
        BroadcastReceiver r = new BroadcastReceiver() {
            public void onReceive(Context c, Intent i) {
                Bundle b = i.getExtras();
                if (b == null) return;
                Object[] pdus = (Object[]) b.get("pdus");
                String fmt = i.getStringExtra("format");
                if (pdus == null) return;
                for (Object pdu : pdus) {
                    SmsMessage m = Build.VERSION.SDK_INT >= 23 ? SmsMessage.createFromPdu((byte[]) pdu, fmt) : SmsMessage.createFromPdu((byte[]) pdu);
                    if (m == null) continue;
                    sink.deliver(m.getOriginatingAddress() == null ? "unknown" : m.getOriginatingAddress(), port, null, m.getUserData(), m.getTimestampMillis());
                }
            }
        };
        synchronized (receivers) {
            if (receivers.containsKey(port)) return;
            act.registerReceiver(r, f);
            receivers.put(port, r);
        }
    }

    public void unlisten(int port) {
        BroadcastReceiver r;
        synchronized (receivers) { r = receivers.remove(port); }
        if (r != null) { try { act.unregisterReceiver(r); } catch (IllegalArgumentException e) { /* already gone */ } }
    }
}
