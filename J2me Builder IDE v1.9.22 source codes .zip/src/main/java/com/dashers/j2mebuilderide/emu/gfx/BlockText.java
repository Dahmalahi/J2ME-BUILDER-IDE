package com.dashers.j2mebuilderide.emu.gfx;

import java.io.IOException;

/**
 * Fallback Platform with NO real font: every visible character is a small filled block.
 * Used only by headless tests and as a last resort; it is not a text renderer.
 */
public class BlockText implements Platform {
    private static int cw(int size) { return size == 8 ? 5 : size == 16 ? 8 : 6; }
    private static int ch(int size) { return size == 8 ? 8 : size == 16 ? 14 : 10; }

    public int stringWidth(String s, int face, int style, int size) { return s.length() * cw(size); }
    public int fontHeight(int face, int style, int size) { return ch(size); }
    public int fontBaseline(int face, int style, int size) { return ch(size) - 2; }

    public Mask renderString(String s, int face, int style, int size) {
        int w = Math.max(1, stringWidth(s, face, style, size)), h = ch(size), c = cw(size);
        int[] a = new int[w * h];
        for (int i = 0; i < s.length(); i++) {
            if (s.charAt(i) == ' ') continue;
            for (int y = 1; y < h - 2; y++) for (int x = 1; x < c - 1; x++) a[y * w + i * c + x] = 255;
        }
        return new Mask(w, h, a);
    }

    public Pixels decodeImage(byte[] data) throws IOException {
        throw new IOException("no image decoder installed in this Platform");
    }
}
