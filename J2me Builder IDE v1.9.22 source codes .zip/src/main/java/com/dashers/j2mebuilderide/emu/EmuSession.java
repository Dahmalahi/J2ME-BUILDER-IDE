package com.dashers.j2mebuilderide.emu;

import com.dashers.j2mebuilderide.emu.gfx.Platform;
import com.dashers.j2mebuilderide.emu.midp.Audio;
import com.dashers.j2mebuilderide.emu.midp.Delegates;
import com.dashers.j2mebuilderide.emu.midp.Device;
import com.dashers.j2mebuilderide.emu.midp.MIDlet;
import com.dashers.j2mebuilderide.emu.midp.MIDletStateChangeException;
import com.dashers.j2mebuilderide.emu.midp.Names;
import com.dashers.j2mebuilderide.emu.vm.Vm;

import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/**
 * One run of one MIDlet inside the IDE. This is the runtime's whole public surface: the IDE hands over the built jar
 * (and JAD text), then drives start / pause / resume / stop, reads the console and the last frame.
 *
 * Experimental proof of concept: see docs/EMULATOR_RUNTIME.md for what is and is not supported.
 */
public final class EmuSession {

    public enum State { CREATED, ACTIVE, PAUSED, DESTROYED, CRASHED }

    public interface Listener { void onState(State s); void onFrame(); }

    private final AppDescriptor app;
    private final Platform platform;
    private final ConsoleLog console = new ConsoleLog(2000);
    private volatile State state = State.CREATED;
    private volatile Listener listener;
    private Device device;
    private Vm vm;
    private com.dashers.j2mebuilderide.emu.nat.NativeLoader nativeLoader;
    private MidletInfo running;
    private int width, height;
    private volatile boolean tornDown;
    private final CountDownLatch done = new CountDownLatch(1);
    private java.io.File storageDir;
    private Device.TextInput textInput;
    private final CompatScan compat;
    private final Diagnostics diag;
    private final ResourceIndex res;
    private final AppProfile profile;
    private volatile boolean startReturned;
    private boolean networkEnabled;
    private java.io.File fileRoot;
    private Audio audio;
    private double[] simLocation;
    private com.dashers.j2mebuilderide.emu.midp.CameraProvider camera;
    private com.dashers.j2mebuilderide.emu.midp.MicProvider mic;
    private com.dashers.j2mebuilderide.emu.midp.SmsProvider sms;
    private com.dashers.j2mebuilderide.emu.midp.PimHost pimHost;
    private com.dashers.j2mebuilderide.emu.midp.SensorProvider sensors;
    private com.dashers.j2mebuilderide.emu.midp.BluetoothProvider bluetooth;

    public EmuSession(byte[] jar, String jadText, Platform platform, int width, int height) throws EmuException {
        this.app = AppDescriptor.parse(jar, jadText);
        this.platform = platform;
        this.width = width;
        this.height = height;
        for (String w : app.warnings) console.add(ConsoleLog.WARN, w);
        compat = CompatScan.scan(app.files);
        console.add(ConsoleLog.INFO, "Jar: " + compat.classCount + " classes, " + app.files.size() + " files");
        if (!compat.unsupportedClasses.isEmpty()) {
            console.add(ConsoleLog.WARN, "Compatibility: classes the built-in runtime does not provide: " + join(compat.unsupportedClasses));
            java.util.TreeSet<String> notes = new java.util.TreeSet<String>();
            for (String c : compat.unsupportedClasses) { Capabilities.Row r = Capabilities.forClass(c); if (r != null) notes.add(r.status + " - " + r.api); }
            for (String n : notes) console.add(ConsoleLog.WARN, "  " + n);
        }
        if (!compat.missingMembers.isEmpty())
            console.add(ConsoleLog.WARN, "Compatibility: methods/fields not implemented: " + join(compat.missingMembers));
        for (String u : compat.unreadable) console.add(ConsoleLog.ERROR, "Cannot read class " + u);
        diag = new Diagnostics(console, app, compat);
        console.setTap(new ConsoleLog.Listener() { public void onEntry(ConsoleLog.Entry e) { diag.observe(e); } });
        res = new ResourceIndex(app.files, new ResourceIndex.Sink() {
            public void log(int lv, String m) { console.add(lv, m); }
            public void missing(String requested, String suggestion) { diag.noteResourceMiss(requested, suggestion); }
        });
        diag.setResources(res);
        profile = AppProfile.analyze(app, compat);
        for (String l : profile.lines()) console.add(ConsoleLog.INFO, l);
        diag.noteProfile(profile);
    }

    /** What was learned about the app (name, design resolution, assets, APIs used). */
    public AppProfile profile() { return profile; }
    public Diagnostics diagnostics() { return diag; }
    /** Plain-language problems found so far, with suggested fixes. */
    public String analysisReport() { return diag.report(); }

    private static String join(List<String> l) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < l.size(); i++) { if (i > 0) sb.append(", "); sb.append(l.get(i)); }
        return sb.toString();
    }

    public CompatScan compat() { return compat; }

    /** Stable id of this suite (vendor + name): the directory under which its record stores live. */
    public String suiteId() {
        String v = String.valueOf(app.props.get("MIDlet-Vendor")), n = String.valueOf(app.props.get("MIDlet-Name"));
        return (v + "_" + n).replaceAll("[^A-Za-z0-9._-]", "_");
    }

    /** Directory for this suite's record stores; without it they live in memory only. Call before start(). */
    public void setStorageDir(java.io.File dir) { storageDir = dir; }
    /** Network is OFF by default; MIDlets get "network access is switched off" until the user enables it. */
    public void setNetworkEnabled(boolean on) { networkEnabled = on; if (device != null) device.networkAllowed = on; }
    /** Private folder that file:///root1/ maps to (null = no FileConnection). */
    public void setFileRoot(java.io.File dir) { fileRoot = dir; if (device != null) device.fileRoot = dir; }
    /** Run the MIDlet natively (converted classes) instead of through the interpreter. Must be set before start(). */
    public void setNativeLoader(com.dashers.j2mebuilderide.emu.nat.NativeLoader l) { nativeLoader = l; }
    public boolean isNative() { return nativeLoader != null; }
    private String trace(Throwable t) {
        if (vm != null) return vm.formatTrace(t);
        java.io.StringWriter w = new java.io.StringWriter();
        t.printStackTrace(new java.io.PrintWriter(w));
        return w.toString();
    }
    /** Camera / microphone the MIDlet gets through capture:// locators (null = none). Takes effect for players opened afterwards. */
    public void setCamera(com.dashers.j2mebuilderide.emu.midp.CameraProvider c) { camera = c; if (device != null) device.camera = c; }
    public void setMic(com.dashers.j2mebuilderide.emu.midp.MicProvider m) { mic = m; if (device != null) device.mic = m; }
    /** SMS the MIDlet gets through sms:// connections (null = simulated, nothing is sent). */
    public void setSms(com.dashers.j2mebuilderide.emu.midp.SmsProvider p) { sms = p; if (device != null) device.sms = p; }
    /** Puts an incoming message into the MIDlet's server connection on that port. Returns how many connections got it (0 = nobody listens). */
    public int injectSms(String fromNumber, int port, String text, byte[] data) { Device d = device; return d == null ? 0 : d.deliverSms(fromNumber, port, text, data); }
    /** Chooses sandbox or real phone data for contacts / events (null = sandbox). To-do lists are always sandbox. */
    public void setPimHost(com.dashers.j2mebuilderide.emu.midp.PimHost h) { pimHost = h; if (device != null) device.pimHost = h; }
    /** Sensors for javax.microedition.sensor (null = none). Takes effect for connections opened afterwards. */
    public void setSensors(com.dashers.j2mebuilderide.emu.midp.SensorProvider p) { sensors = p; if (device != null) device.sensors = p; }
    /** Bluetooth for javax.bluetooth and btspp:// (null = none). Takes effect for connections opened afterwards. */
    public void setBluetooth(com.dashers.j2mebuilderide.emu.midp.BluetoothProvider p) { bluetooth = p; if (device != null) device.bluetooth = p; }
    public void setAudio(Audio a) { audio = a; if (device != null) device.audio = a; }
    /** Position returned by the simulated Location API; null = no position. */
    public void setSimulatedLocation(double lat, double lon, double alt, double accuracyMeters) { simLocation = new double[]{lat, lon, alt, accuracyMeters}; if (device != null) device.simLocation = simLocation; }
    public void clearSimulatedLocation() { simLocation = null; if (device != null) device.simLocation = null; }
    public void setTextInput(Device.TextInput ti) { textInput = ti; if (device != null) device.textInput = ti; }

    /** Record stores currently saved for this suite: "name: N records, M bytes". */
    public List<String> rmsReport() {
        List<String> r = new java.util.ArrayList<String>();
        if (storageDir == null) return r;
        FileStorage fs = new FileStorage(storageDir);
        for (String n : fs.list()) {
            byte[] raw = fs.read(n);
            int[] sum = raw == null ? null : com.dashers.j2mebuilderide.emu.midp.RecordStore.summary(raw);
            r.add(n + ": " + (sum == null ? "damaged" : sum[0] + " records, " + sum[1] + " bytes"));
        }
        return r;
    }

    /** Deletes this suite's saved data (never another suite's). Refused while the MIDlet runs. */
    public int clearData() {
        if (state == State.ACTIVE || state == State.PAUSED) throw new IllegalStateException("stop the MIDlet first");
        return storageDir == null ? 0 : new FileStorage(storageDir).clear();
    }

    /** Plain-text report for bug reports: app, state, console. */
    public String crashReport() {
        StringBuilder sb = new StringBuilder();
        sb.append("J2ME Builder IDE - built-in emulator report\n");
        sb.append("time: ").append(new java.util.Date()).append('\n');
        sb.append("state: ").append(state).append('\n');
        sb.append("midlet: ").append(running == null ? "(not started)" : running.className).append('\n');
        for (java.util.Map.Entry<String, String> e : app.props.entrySet()) sb.append("  ").append(e.getKey()).append(": ").append(e.getValue()).append('\n');
        sb.append("screen: ").append(width).append('x').append(height).append('\n');
        sb.append("java: ").append(System.getProperty("java.vm.name")).append(' ').append(System.getProperty("java.version")).append('\n');
        sb.append("--- app ---\n");
        for (String l : profile.lines()) sb.append(l).append('\n');
        sb.append("--- analysis ---\n").append(diag.report());
        sb.append("--- console ---\n").append(console.text());
        return sb.toString();
    }

    public List<MidletInfo> midlets() { return app.midlets; }
    public java.util.Map<String, String> properties() { return app.props; }
    public ConsoleLog console() { return console; }
    public State state() { return state; }
    public void setListener(Listener l) { listener = l; }
    public Device device() { return device; }

    private void setState(State s) {
        state = s;
        Listener l = listener;
        if (l != null) l.onState(s);
    }

    /** Starts the MIDlet asynchronously. Errors are reported to the console and move the session to CRASHED. */
    public synchronized void start(int midletIndex) {
        if (state != State.CREATED) throw new IllegalStateException("session already started (" + state + ")");
        if (midletIndex < 0 || midletIndex >= app.midlets.size()) throw new IllegalArgumentException("no such MIDlet");
        running = app.midlets.get(midletIndex);
        if (!running.classInJar) {
            console.add(ConsoleLog.ERROR, "MIDlet class " + running.className + " is not in the jar");
            setState(State.CRASHED);
            done.countDown();
            return;
        }
        device = new Device(platform, width, height, app.props, new Device.Resources() {
            public byte[] find(String path) { return res.find(path); }
        });
        device.setStorage(storageDir == null ? null : new FileStorage(storageDir));
        device.textInput = textInput;
        device.networkAllowed = networkEnabled;
        device.fileRoot = fileRoot;
        device.audio = audio;
        device.camera = camera;
        device.mic = mic;
        device.sms = sms;
        device.pimHost = pimHost;
        device.sensors = sensors;
        device.bluetooth = bluetooth;
        device.simLocation = simLocation;
        device.logger = new Device.Logger() { public void log(int lv, String m) { console.add(lv, m); } };
        device.errorSink = new Device.ErrorSink() {
            public void onError(String where, Throwable t) {
                String tr = trace(t);
                console.add(ConsoleLog.ERROR, "Uncaught exception (" + where + "):\n" + tr);
                diag.analyze(where, t, tr);
            }
        };
        device.probe = new Device.Probe() { public void propertyAsked(String k, boolean known) { diag.noteProperty(k, known); } };
        device.frameListener = new Device.FrameListener() {
            public void onFrame() { Listener l = listener; if (l != null) l.onFrame(); }
        };
        device.onDestroyed = new Runnable() { public void run() { console.add(ConsoleLog.INFO, "MIDlet called notifyDestroyed()"); teardown(State.DESTROYED); } };
        device.onPausedByMidlet = new Runnable() { public void run() { console.add(ConsoleLog.INFO, "MIDlet called notifyPaused()"); pause(); } };

        if (nativeLoader == null) {
            console.add(ConsoleLog.INFO, "Engine: interpreter");
            initVm();
        } else {
            console.add(ConsoleLog.INFO, "Engine: native (converted classes run directly on the phone's runtime)");
            installUncaughtHandler();
        }

        diag.markStart();
        device.start();
        setState(State.ACTIVE);
        console.add(ConsoleLog.INFO, "Starting " + running.className);
        device.post(new Runnable() {
            public void run() {
                try {
                    Object host;
                    if (nativeLoader != null) {
                        try { host = nativeLoader.loadClass(running.className).newInstance(); }
                        catch (LinkageError e) { host = fallbackToInterpreter(e); }
                        catch (ClassNotFoundException e) { host = fallbackToInterpreter(e); }
                    } else host = vm.newInstance(running.className).host;
                    if (!(host instanceof MIDlet)) throw new IllegalStateException(running.className + " does not extend javax.microedition.midlet.MIDlet");
                    ((MIDlet) host).startApp();
                    console.add(ConsoleLog.INFO, "startApp() returned");
                    startReturned = true;
                } catch (MIDletStateChangeException e) {
                    console.add(ConsoleLog.WARN, "startApp() threw MIDletStateChangeException: MIDlet stays paused");
                    synchronized (EmuSession.this) { if (state == State.ACTIVE) setState(State.PAUSED); }
                } catch (com.dashers.j2mebuilderide.emu.nat.GuestSystem.Exit e) {
                    // System.exit
                } catch (Vm.VmExit e) {
                    // halted by stop()
                } catch (Throwable t) {
                    String tr = trace(t);
                    console.add(ConsoleLog.ERROR, "MIDlet failed to start:\n" + tr);
                    diag.analyze("startApp", t, tr);
                    teardown(State.CRASHED);
                }
            }
        });
        scheduleWatchdog();
    }

    /** Checks 4 s and 9 s after start that the app is not stuck, has shown a screen and has drawn something. */
    private void scheduleWatchdog() {
        final Device d = device;
        java.util.Timer t = d.timerFor();
        t.schedule(new java.util.TimerTask() { public void run() { watch(d, false); } }, 4000);
        t.schedule(new java.util.TimerTask() { public void run() { watch(d, true); } }, 9000);
    }

    private void watch(Device d, boolean late) {
        if (d != device || tornDown || state != State.ACTIVE) return;
        if (!startReturned) { diag.startStuck(); return; }
        if (d.display.getCurrent() == null) { diag.noScreen(); return; }
        int[] wh = new int[2];
        int[] px = d.copyFrame(wh);
        if (px == null || px.length == 0) return;
        int first = px[0];
        for (int i = 1; i < px.length; i++) if (px[i] != first) return;
        if (late) diag.blankScreen();
    }

    /** The converted classes could not be loaded (for example bytecode dx cannot translate): run through the interpreter instead. */
    private Object fallbackToInterpreter(Throwable why) throws Throwable {
        console.add(ConsoleLog.WARN, "Native engine could not load " + running.className + " (" + why + "): using the interpreter instead");
        nativeLoader = null;
        initVm();
        return vm.newInstance(running.className).host;
    }

    private void initVm() {
        vm = new Vm(new Vm.ClassSource() {
            public byte[] findClass(String n) { return app.files.get(n + ".class"); }
            public byte[] findResource(String p) { return res.find(p); }
        }, new Names(), new Vm.Log() { public void log(int lv, String m) { console.add(lv, m); } });
        vm.out = stream(ConsoleLog.INFO);
        vm.err = stream(ConsoleLog.ERROR);
        vm.propProbe = new Vm.PropProbe() { public void asked(String k, boolean known) { diag.noteProperty(k, known); } };
        Delegates.register(vm);
        vm.setProperty("microedition.platform", "J2ME-Builder-Emulator (experimental)");
    }

    private void installUncaughtHandler() {
        final Thread.UncaughtExceptionHandler prev = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            public void uncaughtException(Thread t, Throwable e) {
                if (e instanceof com.dashers.j2mebuilderide.emu.nat.GuestSystem.Exit) return;
                boolean mine = false;
                try { mine = Device.current() == device; } catch (IllegalStateException x) { /* not a MIDlet thread */ }
                if (mine) {
                    String tr = trace(e);
                    console.add(ConsoleLog.ERROR, "Uncaught exception in thread " + t.getName() + ":\n" + tr);
                    diag.analyze("thread " + t.getName(), e, tr);
                }
                else if (prev != null) prev.uncaughtException(t, e);
            }
        });
    }

    private PrintStream stream(final int level) {
        OutputStream os = new OutputStream() {
            private final ByteArrayOutputStream buf = new ByteArrayOutputStream();
            @Override public synchronized void write(int b) {
                if (b == '\n') flushLine(); else if (b != '\r') buf.write(b);
            }
            private void flushLine() {
                String s;
                try { s = buf.toString("UTF-8"); } catch (java.io.UnsupportedEncodingException e) { s = buf.toString(); }
                buf.reset();
                console.add(level, s);
            }
        };
        try { return new PrintStream(os, true, "UTF-8"); } catch (java.io.UnsupportedEncodingException e) { return new PrintStream(os, true); }
    }

    private MIDlet midlet() {
        Device d = device;
        return d == null ? null : d.midlet;
    }

    /** Pauses an active MIDlet (pauseApp once). Ignored in any other state, so callbacks never duplicate. */
    public void pause() {
        synchronized (this) {
            if (state != State.ACTIVE) return;
            state = State.PAUSED;
        }
        console.add(ConsoleLog.INFO, "pause");
        Listener l = listener;
        if (l != null) l.onState(State.PAUSED);
        device.post(new Runnable() {
            public void run() {
                try { MIDlet m = midlet(); if (m != null) m.pauseApp(); }
                catch (Vm.VmExit e) { /* stopping */ } catch (com.dashers.j2mebuilderide.emu.nat.GuestSystem.Exit e) { /* System.exit */ }
                catch (Throwable t) { console.add(ConsoleLog.ERROR, "pauseApp() failed:\n" + trace(t)); }
            }
        });
    }

    /** Resumes a paused MIDlet (startApp once). Ignored unless paused. */
    public void resume() {
        synchronized (this) {
            if (state != State.PAUSED) return;
            state = State.ACTIVE;
        }
        console.add(ConsoleLog.INFO, "resume");
        Listener l = listener;
        if (l != null) l.onState(State.ACTIVE);
        device.post(new Runnable() {
            public void run() {
                try { MIDlet m = midlet(); if (m != null) m.startApp(); }
                catch (MIDletStateChangeException e) { console.add(ConsoleLog.WARN, "startApp() refused to resume"); }
                catch (Vm.VmExit e) { /* stopping */ } catch (com.dashers.j2mebuilderide.emu.nat.GuestSystem.Exit e) { /* System.exit */ }
                catch (Throwable t) { String tr = trace(t); console.add(ConsoleLog.ERROR, "startApp() failed on resume:\n" + tr); diag.analyze("resume", t, tr); teardown(State.CRASHED); }
            }
        });
    }

    /** Destroys the MIDlet (destroyApp(true)) and releases the session. Blocks up to ~2 s: call off the UI thread. */
    public void stop() {
        State prev;
        synchronized (this) {
            prev = state;
            if (prev == State.CREATED || prev == State.DESTROYED || prev == State.CRASHED || device == null) {
                if (prev == State.CREATED) setState(State.DESTROYED);
                return;
            }
        }
        console.add(ConsoleLog.INFO, "stop");
        device.post(new Runnable() {
            public void run() {
                try { MIDlet m = midlet(); if (m != null) m.destroyApp(true); }
                catch (MIDletStateChangeException e) { console.add(ConsoleLog.WARN, "destroyApp(true) threw MIDletStateChangeException (ignored: stop is unconditional)"); }
                catch (Vm.VmExit e) { /* stopping */ } catch (com.dashers.j2mebuilderide.emu.nat.GuestSystem.Exit e) { /* System.exit */ }
                catch (Throwable t) { console.add(ConsoleLog.ERROR, "destroyApp() failed:\n" + trace(t)); }
                teardown(State.DESTROYED);
            }
        });
        boolean ok = false;
        try { ok = done.await(2, TimeUnit.SECONDS); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        if (!ok) {
            console.add(ConsoleLog.WARN, "MIDlet did not stop in time (busy loop?) - forcing it to halt");
            teardown(State.DESTROYED);
        }
    }

    private void teardown(State end) {
        synchronized (this) {
            if (tornDown) return;
            tornDown = true;
        }
        if (vm != null) vm.halt();
        if (device != null) device.stop();
        setState(end);
        console.add(ConsoleLog.INFO, end == State.CRASHED ? "session ended (crashed)" : "session ended");
        done.countDown();
    }

    // ---- input and frames (thread-safe)

    /** Changes the screen size (device profile or rotation); the MIDlet gets sizeChanged(). */
    public void resize(int w, int h) {
        width = w; height = h;
        Device d = device;
        if (d != null) d.setSize(w, h);
    }
    public int screenWidth() { return width; }
    public int screenHeight() { return height; }
    public void pointer(int type, int x, int y) { Device d = device; if (d != null && state == State.ACTIVE) d.display.dispatchPointer(type, x, y); }
    public int fps() { Device d = device; return d == null ? 0 : d.fps(); }
    public void key(int type, int code) { Device d = device; if (d != null && state == State.ACTIVE) d.display.dispatchKey(type, code); }
    public void command(int index) { Device d = device; if (d != null && state == State.ACTIVE) d.display.fireCommand(index); }
    public List<String> commandLabels() { Device d = device; return d == null ? new java.util.ArrayList<String>() : d.display.commandLabels(); }
    public int[] frame(int[] whOut) { Device d = device; return d == null ? null : d.copyFrame(whOut); }
}
