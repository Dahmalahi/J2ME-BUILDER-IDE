package com.dashers.j2mebuilderide.emu.android;

import android.app.Activity;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;

import com.dashers.j2mebuilderide.emu.midp.MicProvider;

import java.io.IOException;

/** Phone microphone for capture://audio (AudioRecord, 16-bit mono). RECORD_AUDIO is requested at run time on first use. Needs a phone test. */
public final class AndroidMic implements MicProvider {
    private final Activity act;

    public AndroidMic(Activity a) { act = a; }

    public Session open(int rate) throws IOException {
        if (!Permissions.ensure(act, "android.permission.RECORD_AUDIO", 60000))
            throw new SecurityException("the RECORD_AUDIO permission was refused - allow it for J2ME Builder IDE in the phone's app settings");
        int min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
        if (min <= 0) throw new IOException("this phone cannot record at " + rate + " Hz");
        final AudioRecord ar;
        try { ar = new AudioRecord(MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, Math.max(min, rate / 2)); }
        catch (RuntimeException e) { throw new IOException("cannot create the recorder: " + e.getMessage()); }
        if (ar.getState() != AudioRecord.STATE_INITIALIZED) { ar.release(); throw new IOException("the microphone could not be opened (used by another app?)"); }
        try { ar.startRecording(); } catch (RuntimeException e) { ar.release(); throw new IOException("cannot start recording: " + e.getMessage()); }
        return new Session() {
            private volatile boolean closed;
            public int read(short[] buf, int off, int len) {
                if (closed) return -1;
                int n = ar.read(buf, off, len);
                return n < 0 ? -1 : n;
            }
            public void close() {
                if (closed) return;
                closed = true;
                try { ar.stop(); } catch (RuntimeException e) { /* already stopped */ }
                ar.release();
            }
        };
    }
}
