package com.dashers.j2mebuilderide.emu.midp;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Inquiry (device search) and service search for RFCOMM services. */
public class DiscoveryAgent {
    public static final int NOT_DISCOVERABLE = 0, GIAC = 0x9E8B33, LIAC = 0x9E8B00;
    public static final int CACHED = 0, PREKNOWN = 1;

    private final BtState st;
    private DiscoveryListener inquiry;
    private int nextTrans = 1;
    private final Set<Integer> running = new HashSet<Integer>();

    DiscoveryAgent(BtState st) { this.st = st; }

    private static boolean iac(int c) { return c == GIAC || c == LIAC || (c >= 0x9E8B00 && c <= 0x9E8B3F); }

    public RemoteDevice[] retrieveDevices(int option) {
        if (option != CACHED && option != PREKNOWN) throw new IllegalArgumentException("option must be CACHED or PREKNOWN");
        List<RemoteDevice> out = new ArrayList<RemoteDevice>();
        if (option == PREKNOWN) {
            for (BluetoothProvider.Dev d : st.provider().bonded()) out.add(new RemoteDevice(d, true));
        } else {
            synchronized (st.known) { for (BluetoothProvider.Dev d : st.known.values()) out.add(new RemoteDevice(d, false)); }
        }
        return out.isEmpty() ? null : out.toArray(new RemoteDevice[0]);
    }

    public boolean startInquiry(int accessCode, final DiscoveryListener listener) throws BluetoothStateException {
        if (listener == null) throw new NullPointerException("listener");
        if (!iac(accessCode)) throw new IllegalArgumentException("bad access code");
        synchronized (this) {
            if (inquiry != null) throw new BluetoothStateException("an inquiry is already running");
            inquiry = listener;
        }
        BluetoothProvider p = st.provider();
        try {
            p.startInquiry(new BluetoothProvider.InquiryListener() {
                public void found(final BluetoothProvider.Dev d) {
                    synchronized (st.known) { st.known.put(d.address, d); }
                    st.post(new Runnable() { public void run() { listener.deviceDiscovered(new RemoteDevice(d, false), new DeviceClass(d.deviceClass & ~3)); } });
                }
                public void finished(final boolean cancelled, final boolean error) {
                    st.post(new Runnable() {
                        public void run() {
                            synchronized (DiscoveryAgent.this) { inquiry = null; }
                            listener.inquiryCompleted(cancelled ? DiscoveryListener.INQUIRY_TERMINATED : error ? DiscoveryListener.INQUIRY_ERROR : DiscoveryListener.INQUIRY_COMPLETED);
                        }
                    });
                }
            });
        } catch (SecurityException e) {
            synchronized (this) { inquiry = null; }
            st.device.log(2, "Bluetooth inquiry refused: " + e.getMessage());
            throw e;
        } catch (IOException e) {
            synchronized (this) { inquiry = null; }
            throw new BluetoothStateException(e.getMessage());
        }
        st.device.log(0, "Bluetooth inquiry started - " + p.name());
        return true;
    }

    public boolean cancelInquiry(DiscoveryListener listener) {
        if (listener == null) throw new NullPointerException("listener");
        synchronized (this) { if (inquiry != listener) return false; }
        st.provider().cancelInquiry();
        return true;
    }

    /** The first non-protocol UUID of the set (0x0003 RFCOMM and 0x0100 L2CAP are protocols); SPP when there is none. */
    private static String serviceUuid(UUID[] set) {
        for (UUID u : set) {
            String s = u.toString();
            if (!s.equals("3") && !s.equals("0003") && !s.equals("0100") && !s.equals("100")) return u.hex();
        }
        return new UUID(0x1101).hex();
    }

    public int searchServices(int[] attrSet, final UUID[] uuidSet, final RemoteDevice btDev, final DiscoveryListener listener) throws BluetoothStateException {
        if (uuidSet == null || btDev == null || listener == null) throw new NullPointerException("uuidSet/btDev/listener");
        if (uuidSet.length == 0) throw new IllegalArgumentException("uuidSet is empty");
        final int trans;
        synchronized (this) { trans = nextTrans++; running.add(Integer.valueOf(trans)); }
        final String uuid = serviceUuid(uuidSet);
        st.device.log(0, "Bluetooth service search on " + btDev.getBluetoothAddress() + " for " + uuid);
        st.post(new Runnable() {
            public void run() {
                int result;
                ServiceRecord[] recs = null;
                try {
                    String[] have = st.provider().services(btDev.getBluetoothAddress());
                    boolean present = have == null;
                    if (have != null) for (String h : have) if (h.equalsIgnoreCase(uuid)) present = true;
                    if (present) recs = new ServiceRecord[]{new ServiceRecordImpl(btDev, uuid, "Serial Port")};
                    result = present ? DiscoveryListener.SERVICE_SEARCH_COMPLETED : DiscoveryListener.SERVICE_SEARCH_NO_RECORDS;
                } catch (SecurityException e) {
                    st.device.log(2, "Bluetooth service search refused: " + e.getMessage());
                    result = DiscoveryListener.SERVICE_SEARCH_ERROR;
                }
                boolean cancelled;
                synchronized (DiscoveryAgent.this) { cancelled = !running.remove(Integer.valueOf(trans)); }
                if (cancelled) { listener.serviceSearchCompleted(trans, DiscoveryListener.SERVICE_SEARCH_TERMINATED); return; }
                if (recs != null) listener.servicesDiscovered(trans, recs);
                listener.serviceSearchCompleted(trans, result);
            }
        });
        return trans;
    }

    public boolean cancelServiceSearch(int transID) {
        synchronized (this) { return running.remove(Integer.valueOf(transID)); }
    }

    /** Looks through the paired devices for the service and returns its connection URL, or null. */
    public String selectService(UUID uuid, int security, boolean master) throws BluetoothStateException {
        if (uuid == null) throw new NullPointerException("uuid");
        if (security < ServiceRecord.NOAUTHENTICATE_NOENCRYPT || security > ServiceRecord.AUTHENTICATE_ENCRYPT) throw new IllegalArgumentException("bad security level");
        for (BluetoothProvider.Dev d : st.provider().bonded()) {
            String[] have = st.provider().services(d.address);
            boolean present = have == null;
            if (have != null) for (String h : have) if (h.equalsIgnoreCase(uuid.hex())) present = true;
            if (present) return new ServiceRecordImpl(new RemoteDevice(d, true), uuid.hex(), "Serial Port").getConnectionURL(security, master);
        }
        return null;
    }
}
