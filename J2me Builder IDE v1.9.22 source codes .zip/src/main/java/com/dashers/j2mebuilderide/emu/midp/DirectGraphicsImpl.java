package com.dashers.j2mebuilderide.emu.midp;

import com.dashers.j2mebuilderide.emu.gfx.Frame;

/** Nokia DirectGraphics on top of a Graphics: alpha polygons/triangles, pixel arrays in several formats, flips and rotations. */
final class DirectGraphicsImpl implements DirectGraphics {
    private final Graphics g;
    private int argb;

    DirectGraphicsImpl(Graphics g) { this.g = g; argb = 0xFF000000 | g.getColor(); }

    public void setARGBColor(int c) { argb = c; g.setColor(c & 0xFFFFFF); }
    public int getAlphaComponent() { return argb >>> 24; }
    public int getNativePixelFormat() { return TYPE_INT_8888_ARGB; }

    // ---- pixel formats

    private static int expand(int v, int bits) { return bits == 4 ? v * 17 : bits == 5 ? (v << 3) | (v >> 2) : bits == 6 ? (v << 2) | (v >> 4) : v; }

    private static int fromShort(int s, int format, boolean alpha) {
        switch (format) {
            case TYPE_USHORT_4444_ARGB: return ((alpha ? expand((s >> 12) & 15, 4) : 255) << 24) | expand((s >> 8) & 15, 4) << 16 | expand((s >> 4) & 15, 4) << 8 | expand(s & 15, 4);
            case TYPE_USHORT_444_RGB: return 0xFF000000 | expand((s >> 8) & 15, 4) << 16 | expand((s >> 4) & 15, 4) << 8 | expand(s & 15, 4);
            case TYPE_USHORT_555_RGB: return 0xFF000000 | expand((s >> 10) & 31, 5) << 16 | expand((s >> 5) & 31, 5) << 8 | expand(s & 31, 5);
            case TYPE_USHORT_565_RGB: return 0xFF000000 | expand((s >> 11) & 31, 5) << 16 | expand((s >> 5) & 63, 6) << 8 | expand(s & 31, 5);
            default: throw new IllegalArgumentException("pixel format " + format + " is not a short format");
        }
    }

    private static int toShort(int c, int format) {
        int r = (c >> 16) & 255, gr = (c >> 8) & 255, b = c & 255, a = c >>> 24;
        switch (format) {
            case TYPE_USHORT_4444_ARGB: return ((a >> 4) << 12) | ((r >> 4) << 8) | ((gr >> 4) << 4) | (b >> 4);
            case TYPE_USHORT_444_RGB: return ((r >> 4) << 8) | ((gr >> 4) << 4) | (b >> 4);
            case TYPE_USHORT_555_RGB: return ((r >> 3) << 10) | ((gr >> 3) << 5) | (b >> 3);
            case TYPE_USHORT_565_RGB: return ((r >> 3) << 11) | ((gr >> 2) << 5) | (b >> 3);
            default: throw new IllegalArgumentException("pixel format " + format + " is not a short format");
        }
    }

    private static int fromByte(int v, int format) {
        v &= 255;
        if (format == TYPE_BYTE_8_GRAY) return 0xFF000000 | v << 16 | v << 8 | v;
        if (format == TYPE_BYTE_332_RGB) return 0xFF000000 | (((v >> 5) & 7) * 255 / 7) << 16 | (((v >> 2) & 7) * 255 / 7) << 8 | ((v & 3) * 255 / 3);
        throw new IllegalArgumentException("pixel format " + format + " is not supported for byte arrays (use TYPE_BYTE_8_GRAY or TYPE_BYTE_332_RGB)");
    }

    // ---- drawing of pixel arrays

    private void drawArgb(int[] src, int w, int h, int x, int y, int anchor, int manip) {
        int[] out = src;
        int ow = w, oh = h;
        boolean fh = (manip & FLIP_HORIZONTAL) != 0, fv = (manip & FLIP_VERTICAL) != 0;
        int rot = manip & 0x0FFF;
        if (rot != 0 && rot != 90 && rot != 180 && rot != 270) throw new IllegalArgumentException("bad manipulation " + manip);
        if (fh || fv) {
            out = new int[w * h];
            for (int j = 0; j < h; j++) for (int i = 0; i < w; i++) out[j * w + i] = src[(fv ? h - 1 - j : j) * w + (fh ? w - 1 - i : i)];
        }
        if (rot == 180) {
            int[] r = new int[w * h];
            for (int k = 0; k < r.length; k++) r[r.length - 1 - k] = out[k];
            out = r;
        } else if (rot != 0) {      // counter-clockwise, as Nokia defines it
            int[] r = new int[w * h];
            ow = h; oh = w;
            for (int j = 0; j < h; j++) for (int i = 0; i < w; i++) {
                int dx = rot == 90 ? j : h - 1 - j, dy = rot == 90 ? w - 1 - i : i;
                r[dy * ow + dx] = out[j * w + i];
            }
            out = r;
        }
        if ((anchor & Graphics.HCENTER) != 0) x -= ow / 2; else if ((anchor & Graphics.RIGHT) != 0) x -= ow;
        if ((anchor & Graphics.VCENTER) != 0) y -= oh / 2; else if ((anchor & Graphics.BOTTOM) != 0) y -= oh;
        g.drawRGB(out, 0, ow, x, y, ow, oh, true);
    }

    private static void check(int w, int h, int scan, int off, int len) {
        if (w < 0 || h < 0) throw new IllegalArgumentException("negative size");
        if (w == 0 || h == 0) return;
        if (scan < w && scan > -w) throw new IllegalArgumentException("scanlength is smaller than the width");
        if (off < 0 || off + (h - 1) * scan + w > len) throw new ArrayIndexOutOfBoundsException("pixel array is too short");
    }

    public void drawImage(Image img, int x, int y, int anchor, int manipulation) {
        if (img == null) throw new NullPointerException("img");
        int w = img.getWidth(), h = img.getHeight();
        int[] p = new int[w * h];
        img.getRGB(p, 0, w, 0, 0, w, h);
        drawArgb(p, w, h, x, y, anchor, manipulation);
    }

    public void drawPixels(int[] pixels, boolean transparency, int offset, int scanlength, int x, int y, int width, int height, int manipulation, int format) {
        if (pixels == null) throw new NullPointerException("pixels");
        if (format != TYPE_INT_8888_ARGB && format != TYPE_INT_888_RGB) throw new IllegalArgumentException("int arrays use TYPE_INT_8888_ARGB or TYPE_INT_888_RGB");
        check(width, height, scanlength, offset, pixels.length);
        int[] t = new int[width * height];
        for (int j = 0; j < height; j++) for (int i = 0; i < width; i++) {
            int c = pixels[offset + j * scanlength + i];
            t[j * width + i] = format == TYPE_INT_888_RGB || !transparency ? 0xFF000000 | c : c;
        }
        if (width > 0 && height > 0) drawArgb(t, width, height, x, y, 0, manipulation);
    }

    public void drawPixels(short[] pixels, boolean transparency, int offset, int scanlength, int x, int y, int width, int height, int manipulation, int format) {
        if (pixels == null) throw new NullPointerException("pixels");
        check(width, height, scanlength, offset, pixels.length);
        int[] t = new int[width * height];
        for (int j = 0; j < height; j++) for (int i = 0; i < width; i++) t[j * width + i] = fromShort(pixels[offset + j * scanlength + i] & 0xFFFF, format, transparency);
        if (width > 0 && height > 0) drawArgb(t, width, height, x, y, 0, manipulation);
    }

    /** One byte per pixel (8-bit gray or 3-3-2 colour); a transparency mask, when given, has one byte per pixel too (0 = transparent). */
    public void drawPixels(byte[] pixels, byte[] mask, int offset, int scanlength, int x, int y, int width, int height, int manipulation, int format) {
        if (pixels == null) throw new NullPointerException("pixels");
        check(width, height, scanlength, offset, pixels.length);
        int[] t = new int[width * height];
        for (int j = 0; j < height; j++) for (int i = 0; i < width; i++) {
            int k = offset + j * scanlength + i;
            int c = fromByte(pixels[k], format);
            if (mask != null && k < mask.length && mask[k] == 0) c &= 0x00FFFFFF;
            t[j * width + i] = c;
        }
        if (width > 0 && height > 0) drawArgb(t, width, height, x, y, 0, manipulation);
    }


    // ---- reading

    private int pixelAt(Frame f, int x, int y) {
        int fx = x + g.getTranslateX(), fy = y + g.getTranslateY();
        return fx < 0 || fy < 0 || fx >= f.w || fy >= f.h ? 0 : f.px[fy * f.w + fx];
    }

    public void getPixels(int[] pixels, int offset, int scanlength, int x, int y, int width, int height, int format) {
        if (pixels == null) throw new NullPointerException("pixels");
        if (format != TYPE_INT_8888_ARGB && format != TYPE_INT_888_RGB) throw new IllegalArgumentException("int arrays use TYPE_INT_8888_ARGB or TYPE_INT_888_RGB");
        check(width, height, scanlength, offset, pixels.length);
        Frame f = g.frameOf();
        for (int j = 0; j < height; j++) for (int i = 0; i < width; i++) {
            int c = pixelAt(f, x + i, y + j);
            pixels[offset + j * scanlength + i] = format == TYPE_INT_888_RGB ? c & 0xFFFFFF : c;
        }
    }

    public void getPixels(short[] pixels, int offset, int scanlength, int x, int y, int width, int height, int format) {
        if (pixels == null) throw new NullPointerException("pixels");
        check(width, height, scanlength, offset, pixels.length);
        Frame f = g.frameOf();
        for (int j = 0; j < height; j++) for (int i = 0; i < width; i++) pixels[offset + j * scanlength + i] = (short) toShort(pixelAt(f, x + i, y + j), format);
    }

    public void getPixels(byte[] pixels, byte[] mask, int offset, int scanlength, int x, int y, int width, int height, int format) {
        throw new UnsupportedOperationException("getPixels with a byte array is not supported by the built-in emulator");
    }

    // ---- polygons

    private void blendPixel(Frame f, int x, int y, int c) {
        if (x < f.cx || y < f.cy || x >= f.cx + f.cw || y >= f.cy + f.ch) return;
        int a = c >>> 24, i = y * f.w + x;
        if (a == 255) f.px[i] = c;
        else if (a > 0) {
            int d = f.px[i], ia = 255 - a;
            int r = (((c >> 16) & 255) * a + ((d >> 16) & 255) * ia) / 255, gg = (((c >> 8) & 255) * a + ((d >> 8) & 255) * ia) / 255, b = ((c & 255) * a + (d & 255) * ia) / 255;
            f.px[i] = 0xFF000000 | r << 16 | gg << 8 | b;
        }
    }

    private void line(Frame f, int x0, int y0, int x1, int y1, int c) {
        int dx = Math.abs(x1 - x0), dy = -Math.abs(y1 - y0), sx = x0 < x1 ? 1 : -1, sy = y0 < y1 ? 1 : -1, err = dx + dy;
        for (int guard = 0; guard < 100000; guard++) {
            blendPixel(f, x0, y0, c);
            if (x0 == x1 && y0 == y1) break;
            int e2 = 2 * err;
            if (e2 >= dy) { err += dy; x0 += sx; }
            if (e2 <= dx) { err += dx; y0 += sy; }
        }
    }

    private void polyCheck(int[] xs, int xo, int[] ys, int yo, int n) {
        if (xs == null || ys == null) throw new NullPointerException("points");
        if (n < 0 || xo < 0 || yo < 0 || xo + n > xs.length || yo + n > ys.length) throw new ArrayIndexOutOfBoundsException("point arrays are too short");
    }

    public void drawPolygon(int[] xs, int xo, int[] ys, int yo, int n, int c) {
        polyCheck(xs, xo, ys, yo, n);
        Frame f = g.frameOf();
        int tx = g.getTranslateX(), ty = g.getTranslateY();
        for (int i = 0; i < n; i++) {
            int j = (i + 1) % n;
            line(f, xs[xo + i] + tx, ys[yo + i] + ty, xs[xo + j] + tx, ys[yo + j] + ty, c);
        }
    }

    public void fillPolygon(int[] xs, int xo, int[] ys, int yo, int n, int c) {
        polyCheck(xs, xo, ys, yo, n);
        if (n < 3) return;
        Frame f = g.frameOf();
        int tx = g.getTranslateX(), ty = g.getTranslateY();
        int minY = Integer.MAX_VALUE, maxY = Integer.MIN_VALUE;
        for (int i = 0; i < n; i++) { minY = Math.min(minY, ys[yo + i] + ty); maxY = Math.max(maxY, ys[yo + i] + ty); }
        float[] cross = new float[n];
        for (int y = Math.max(minY, f.cy); y <= Math.min(maxY, f.cy + f.ch - 1); y++) {
            float yy = y + 0.5f;
            int cnt = 0;
            for (int i = 0; i < n; i++) {
                int j = (i + 1) % n;
                float x0 = xs[xo + i] + tx, y0 = ys[yo + i] + ty, x1 = xs[xo + j] + tx, y1 = ys[yo + j] + ty;
                if ((y0 <= yy && yy < y1) || (y1 <= yy && yy < y0)) {
                    float x = x0 + (yy - y0) * (x1 - x0) / (y1 - y0);
                    int k = cnt++;
                    while (k > 0 && cross[k - 1] > x) { cross[k] = cross[k - 1]; k--; }
                    cross[k] = x;
                }
            }
            for (int k = 0; k + 1 < cnt; k += 2) {
                int xa = (int) Math.ceil(cross[k] - 0.5f), xb = (int) Math.ceil(cross[k + 1] - 0.5f);
                for (int x = xa; x < xb; x++) blendPixel(f, x, y, c);
            }
        }
    }

    public void drawTriangle(int x1, int y1, int x2, int y2, int x3, int y3, int c) { drawPolygon(new int[]{x1, x2, x3}, 0, new int[]{y1, y2, y3}, 0, 3, c); }
    public void fillTriangle(int x1, int y1, int x2, int y2, int x3, int y3, int c) { fillPolygon(new int[]{x1, x2, x3}, 0, new int[]{y1, y2, y3}, 0, 3, c); }
}
