package com.dashers.j2mebuilderide.emu.midp;

public class Criteria {
    public static final int NO_REQUIREMENT = 0, POWER_USAGE_LOW = 1, POWER_USAGE_MEDIUM = 2, POWER_USAGE_HIGH = 3;
    private int hAcc = NO_REQUIREMENT, vAcc = NO_REQUIREMENT, resp = NO_REQUIREMENT, power = NO_REQUIREMENT;
    private boolean cost = true, speed, course, address, altitude;
    public Criteria() { }
    public void setHorizontalAccuracy(int a) { hAcc = a; }
    public int getHorizontalAccuracy() { return hAcc; }
    public void setVerticalAccuracy(int a) { vAcc = a; }
    public int getVerticalAccuracy() { return vAcc; }
    public void setPreferredResponseTime(int t) { resp = t; }
    public int getPreferredResponseTime() { return resp; }
    public void setPreferredPowerConsumption(int p) { power = p; }
    public int getPreferredPowerConsumption() { return power; }
    public void setCostAllowed(boolean c) { cost = c; }
    public boolean isAllowedToCost() { return cost; }
    public void setSpeedAndCourseRequired(boolean b) { speed = b; course = b; }
    public boolean isSpeedAndCourseRequired() { return speed; }
    public void setAddressInfoRequired(boolean b) { address = b; }
    public boolean isAddressInfoRequired() { return address; }
    public void setAltitudeRequired(boolean b) { altitude = b; }
    public boolean isAltitudeRequired() { return altitude; }
}
