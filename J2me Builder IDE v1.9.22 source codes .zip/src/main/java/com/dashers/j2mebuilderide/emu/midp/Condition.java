package com.dashers.j2mebuilderide.emu.midp;

public interface Condition {
    java.lang.String OP_EQUALS = "eq";
    java.lang.String OP_GREATER_THAN = "gt";
    java.lang.String OP_GREATER_THAN_OR_EQUALS = "ge";
    java.lang.String OP_LESS_THAN = "lt";
    java.lang.String OP_LESS_THAN_OR_EQUALS = "le";
    boolean isMet(double a0);
    boolean isMet(java.lang.Object a0);
}
