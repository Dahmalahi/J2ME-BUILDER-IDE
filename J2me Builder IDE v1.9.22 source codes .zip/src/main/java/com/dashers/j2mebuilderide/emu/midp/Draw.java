package com.dashers.j2mebuilderide.emu.midp;

import com.dashers.j2mebuilderide.emu.gfx.Frame;
import com.dashers.j2mebuilderide.emu.gfx.Platform;

/** Text helpers for the high-level (non-Canvas) screens. */
final class Draw {
    private Draw() { }
    static final int FACE = Font.FACE_SYSTEM;

    static int lineHeight(Device d, boolean bold) { return d.platform.fontHeight(FACE, bold ? Font.STYLE_BOLD : Font.STYLE_PLAIN, Font.SIZE_MEDIUM); }
    static int width(Device d, String s, boolean bold) { return d.platform.stringWidth(s, FACE, bold ? Font.STYLE_BOLD : Font.STYLE_PLAIN, Font.SIZE_MEDIUM); }

    static void text(Device d, Frame f, String s, int x, int y, int rgb, boolean bold) {
        if (s == null || s.length() == 0) return;
        f.blitMask(d.platform.renderString(s, FACE, bold ? Font.STYLE_BOLD : Font.STYLE_PLAIN, Font.SIZE_MEDIUM), x, y, rgb);
    }

    /** Word-wraps (also breaking over-long words) and returns the y after the last line. */
    static int wrapped(Device d, Frame f, String text, int x, int y, int width, int rgb, boolean bold) {
        int lh = lineHeight(d, bold);
        if (text == null || text.length() == 0) return y;
        for (String para : text.split("\n", -1)) {
            StringBuilder line = new StringBuilder();
            for (String word : para.split(" ", -1)) {
                String cand = line.length() == 0 ? word : line + " " + word;
                if (line.length() > 0 && width(d, cand, bold) > width) {
                    if (f != null) text(d, f, line.toString(), x, y, rgb, bold);
                    y += lh;
                    cand = word;
                }
                while (width(d, cand, bold) > width && cand.length() > 1) {
                    int k = cand.length() - 1;
                    while (k > 1 && width(d, cand.substring(0, k), bold) > width) k--;
                    if (f != null) text(d, f, cand.substring(0, k), x, y, rgb, bold);
                    y += lh;
                    cand = cand.substring(k);
                }
                line.setLength(0);
                line.append(cand);
            }
            if (f != null) text(d, f, line.toString(), x, y, rgb, bold);
            y += lh;
        }
        return y;
    }

    static void image(Frame f, Image img, int x, int y) {
        if (img != null) f.blit(img.frame.px, img.getWidth(), 0, 0, img.getWidth(), img.getHeight(), x, y, img.hasAlpha);
    }
}
