package com.dashers.j2mebuilderide.emu.midp;

final class ContactListImpl extends PimListImpl implements ContactList {
    ContactListImpl(Device d, PimData data, int mode, String name) { super(d, data, mode, name); }
    PimItemImpl newItem(PimRecord r, boolean modified) { return new ContactImpl(this, r, modified); }
    public Contact createContact() { return (Contact) newItem(new PimRecord(), false); }
    public Contact importContact(Contact c) { return (Contact) importItem(c); }
    public void removeContact(Contact c) throws PIMException { remove(c); }
}
