package com.dashers.j2mebuilderide.emu.midp;

public class AnimationController extends Object3D {
    private float speed = 1f, weight = 1f, refSeq;
    private int refWorld, activeStart, activeEnd;

    public AnimationController() { }

    public void setActiveInterval(int start, int end) {
        if (start > end) throw new IllegalArgumentException("start is after end");
        activeStart = start; activeEnd = end;
    }

    public int getActiveIntervalStart() { return activeStart; }
    public int getActiveIntervalEnd() { return activeEnd; }

    public void setSpeed(float s, int worldTime) {
        refSeq = getPosition(worldTime);
        refWorld = worldTime;
        speed = s;
    }

    public float getSpeed() { return speed; }
    public void setPosition(float sequenceTime, int worldTime) { refSeq = sequenceTime; refWorld = worldTime; }
    public float getPosition(int worldTime) { return refSeq + speed * (worldTime - refWorld); }
    public int getRefWorldTime() { return refWorld; }

    public void setWeight(float w) {
        if (w < 0f) throw new IllegalArgumentException("weight must not be negative");
        weight = w;
    }

    public float getWeight() { return weight; }

    boolean activeAt(int worldTime) { return activeStart == activeEnd || (worldTime >= activeStart && worldTime < activeEnd); }
}
