package com.dashers.j2mebuilderide.emu.midp;

public class BluetoothStateException extends java.io.IOException {
    public BluetoothStateException() { super(); }
    public BluetoothStateException(String m) { super(m); }
}
