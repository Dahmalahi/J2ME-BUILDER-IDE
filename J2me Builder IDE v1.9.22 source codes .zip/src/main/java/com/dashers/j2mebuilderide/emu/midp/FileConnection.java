package com.dashers.j2mebuilderide.emu.midp;

import java.io.IOException;

public interface FileConnection extends Connection {
    boolean isOpen();
    java.io.InputStream openInputStream() throws IOException;
    java.io.DataInputStream openDataInputStream() throws IOException;
    java.io.OutputStream openOutputStream() throws IOException;
    java.io.DataOutputStream openDataOutputStream() throws IOException;
    java.io.OutputStream openOutputStream(long byteOffset) throws IOException;
    long totalSize();
    long availableSize();
    long usedSize();
    long directorySize(boolean includeSubDirs) throws IOException;
    long fileSize() throws IOException;
    boolean canRead();
    boolean canWrite();
    boolean isHidden();
    void setReadable(boolean b) throws IOException;
    void setWritable(boolean b) throws IOException;
    void setHidden(boolean b) throws IOException;
    java.util.Enumeration list() throws IOException;
    java.util.Enumeration list(String filter, boolean includeHidden) throws IOException;
    void create() throws IOException;
    boolean exists();
    boolean isDirectory();
    void delete() throws IOException;
    void rename(String newName) throws IOException;
    void truncate(long byteOffset) throws IOException;
    void setFileConnection(String fileName) throws IOException;
    String getName();
    String getPath();
    String getURL();
    long lastModified();
    void mkdir() throws IOException;
}
