package com.dashers.j2mebuilderide.emu.midp;

public interface Connection { void close() throws java.io.IOException; }
