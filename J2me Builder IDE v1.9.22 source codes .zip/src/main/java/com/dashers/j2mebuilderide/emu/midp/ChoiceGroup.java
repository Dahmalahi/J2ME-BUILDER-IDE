package com.dashers.j2mebuilderide.emu.midp;

import com.dashers.j2mebuilderide.emu.gfx.Frame;

public class ChoiceGroup extends Item implements Choice {
    private final ChoiceModel m;
    private int cursor;

    public ChoiceGroup(String label, int type) { super(label); m = new ChoiceModel(type == IMPLICIT ? EXCLUSIVE : type); }
    public ChoiceGroup(String label, int type, String[] strings, Image[] images) {
        this(label, type);
        for (int i = 0; i < strings.length; i++) m.append(strings[i], images == null ? null : images[i]);
    }
    public int size() { return m.size(); }
    public String getString(int i) { return m.getString(i); }
    public Image getImage(int i) { return m.getImage(i); }
    public int append(String s, Image img) { int r = m.append(s, img); changed(); return r; }
    public void insert(int i, String s, Image img) { m.insert(i, s, img); changed(); }
    public void delete(int i) { m.delete(i); cursor = Math.min(cursor, Math.max(0, m.size() - 1)); changed(); }
    public void deleteAll() { m.deleteAll(); cursor = 0; changed(); }
    public void set(int i, String s, Image img) { m.set(i, s, img); changed(); }
    public boolean isSelected(int i) { return m.isSelected(i); }
    public int getSelectedIndex() { return m.getSelectedIndex(); }
    public void setSelectedIndex(int i, boolean on) { m.setSelectedIndex(i, on); changed(); }
    public int getSelectedFlags(boolean[] o) { return m.getSelectedFlags(o); }
    public void setSelectedFlags(boolean[] i) { m.setSelectedFlags(i); changed(); }
    public void setFitPolicy(int p) { }
    public int getFitPolicy() { return 0; }
    public void setFont(int i, Font f) { }

    @Override boolean focusable() { return m.size() > 0; }
    @Override boolean key(Device d, int code) {
        if (code == Canvas.CODE_UP && cursor > 0) { cursor--; changed(); return true; }
        if (code == Canvas.CODE_DOWN && cursor < m.size() - 1) { cursor++; changed(); return true; }
        return false;
    }
    @Override void activate(Device d) {
        if (m.size() == 0) return;
        if (m.multiple()) m.setSelectedIndex(cursor, !m.isSelected(cursor)); else m.setSelectedIndex(cursor, true);
        changed();
        notifyStateChanged();
    }
    @Override int paint(Device d, Frame f, int x, int y, int w, boolean focused) {
        int y0 = y;
        y = paintLabel(d, f, x, y, w);
        int lh = Draw.lineHeight(d, false);
        for (int i = 0; i < m.size(); i++) {
            if (focused && i == cursor) f.fillRect(x, y, w, lh + 1, 0xCFE3FA);
            int bx = x + 2, by = y + 2, bs = Math.max(6, lh - 5);
            if (m.multiple()) f.drawRect(bx, by, bs, bs, 0); else f.ellipse(bx, by, bs, bs, 0, false, 0, 360);
            if (m.isSelected(i)) f.fillRect(bx + 2, by + 2, bs - 3, bs - 3, 0x000000);
            Draw.text(d, f, m.getString(i), x + bs + 8, y, 0, false);
            y += lh + 1;
        }
        return y - y0;
    }
}
