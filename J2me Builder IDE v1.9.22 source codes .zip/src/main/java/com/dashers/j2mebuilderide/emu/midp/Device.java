package com.dashers.j2mebuilderide.emu.midp;

import com.dashers.j2mebuilderide.emu.gfx.Frame;
import com.dashers.j2mebuilderide.emu.gfx.Platform;

import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

/**
 * The virtual phone one MIDlet session runs on: screen size, the single event thread (all MIDlet callbacks,
 * paints and key events run there, like a real MIDP implementation), and the frame the host view displays.
 * Code running inside a session finds its device with {@link #current()} (inherited by threads the MIDlet starts).
 */
public final class Device {

    public interface Resources { byte[] find(String path); }
    public interface FrameListener { void onFrame(); }
    public interface ErrorSink { void onError(String where, Throwable t); }
    public interface Logger { void log(int level, String msg); }

    private static final InheritableThreadLocal<Device> CURRENT = new InheritableThreadLocal<Device>();

    public static Device current() {
        Device d = CURRENT.get();
        if (d == null) throw new IllegalStateException("MIDP API used outside of an emulator session");
        return d;
    }

    public final Platform platform;
    public final Display display;
    private final Map<String, String> props;
    private final Resources resources;
    private final LinkedBlockingQueue<Runnable> events = new LinkedBlockingQueue<Runnable>();
    private volatile Thread loop;
    private volatile boolean running;
    private volatile int width, height;
    private Frame back;
    private int[] snapshot;
    private int snapW, snapH;
    private final Object snapLock = new Object();
    private volatile boolean repaintPending;
    public volatile FrameListener frameListener;
    public volatile ErrorSink errorSink;
    public volatile Logger logger;
    /** Lets the analyser see which system properties the app asks for. */
    public interface Probe { void propertyAsked(String key, boolean known); }
    public volatile Probe probe;
    public void probeProperty(String key, boolean known) { Probe p = probe; if (p != null) p.propertyAsked(key, known); }
    public volatile MIDlet midlet;
    public volatile Runnable onDestroyed;
    public volatile Runnable onPausedByMidlet;
    public volatile TextInput textInput;
    private java.util.Timer timer;
    public volatile Audio audio;
    volatile boolean audioNoticeShown;
    public volatile boolean networkAllowed;
    public volatile java.io.File fileRoot;
    /** Host camera / microphone (null = none). See CameraProvider, MicProvider. */
    public volatile CameraProvider camera;
    public volatile MicProvider mic;
    /** Short messages (null = simulated: nothing is sent). */
    public volatile SmsProvider sms;
    final SmsBus smsBus = new SmsBus();
    /** Chooses sandbox or real phone data for PIM lists (null = sandbox everywhere). */
    public volatile PimHost pimHost;
    /** Sensors of the host (null = this device has none, findSensors returns an empty array). */
    public volatile SensorProvider sensors;
    /** Bluetooth of the host (null = none: LocalDevice.getLocalDevice throws BluetoothStateException). */
    public volatile BluetoothProvider bluetooth;
    private BtState btState;
    private Graphics3D g3d;
    synchronized Graphics3D graphics3D() { if (g3d == null) g3d = new Graphics3D(this); return g3d; }
    synchronized BtState btState() { if (btState == null) btState = new BtState(this); return btState; }
    private SensorHub sensorHub;
    synchronized SensorHub sensorHub() { if (sensorHub == null) sensorHub = new SensorHub(this); return sensorHub; }
    final java.util.Map<Integer, PimData> pimData = new java.util.HashMap<Integer, PimData>();
    /** Host entry for an incoming message (the simulated inbox in More > SMS, or a real data SMS). Returns how many connections received it. */
    public int deliverSms(String fromNumber, int port, String text, byte[] data) {
        return smsBus.deliver(this, fromNumber, port, text, data, System.currentTimeMillis());
    }
    private final java.util.concurrent.CopyOnWriteArrayList<VideoView> overlays = new java.util.concurrent.CopyOnWriteArrayList<VideoView>();
    private final java.util.concurrent.CopyOnWriteArrayList<Player> owned = new java.util.concurrent.CopyOnWriteArrayList<Player>();
    void addOverlay(VideoView v) { if (!overlays.contains(v)) overlays.add(v); }
    void removeOverlay(VideoView v) { overlays.remove(v); }
    /** Players holding hardware (camera, microphone): closed when the session stops so the camera is never left on. */
    void own(Player p) { owned.add(p); }
    void disown(Player p) { owned.remove(p); }
    public volatile double[] simLocation;   // {lat, lon, alt, horizontalAccuracy} or null
    public synchronized java.util.Timer timerFor() {
        if (timer == null) timer = new java.util.Timer("emu-delay", true);
        return timer;
    }
    private long fpsStart, lastFrame;
    private int fpsFrames, fpsValue;

    /** Host-provided text entry (Android shows a dialog). */
    public interface TextInput {
        interface Callback { void done(String textOrNull); }
        void request(String title, String initial, int maxSize, int constraints, Callback cb);
    }
    interface TextResult { void accept(String s); }

    /** Where record stores live; one instance per MIDlet suite so sessions cannot touch each other's data. */
    public interface Storage {
        byte[] read(String name);
        void write(String name, byte[] data);
        boolean delete(String name);
        String[] list();
    }
    private volatile Storage storage;
    public void setStorage(Storage s) { storage = s; }
    public synchronized Storage storage() { if (storage == null) storage = new MemoryStorage(); return storage; }

    void requestText(String title, String initial, int max, int constraints, final TextResult r) {
        TextInput ti = textInput;
        if (ti == null) { log(2, "Text input requested but this host has no text input handler"); return; }
        ti.request(title, initial, max, constraints, new TextInput.Callback() {
            public void done(final String s) {
                if (s != null) post(new Runnable() { public void run() { r.accept(s); } });
            }
        });
    }

    public synchronized void postDelayed(final Runnable r, long ms) {
        if (!running) return;
        if (timer == null) timer = new java.util.Timer("emu-delay", true);
        timer.schedule(new java.util.TimerTask() { public void run() { post(r); } }, Math.max(0, ms));
    }

    /** Frames per second over the last full second, 0 when idle. */
    public synchronized int fps() { return System.currentTimeMillis() - lastFrame > 2000 ? 0 : fpsValue; }

    public Device(Platform p, int w, int h, Map<String, String> appProps, Resources res) {
        platform = p;
        width = w;
        height = h;
        props = appProps;
        resources = res;
        display = new Display(this);
    }

    public int width() { return width; }
    public int height() { return height; }

    public void setSize(int w, int h) {
        width = w;
        height = h;
        post(new Runnable() {
            public void run() {
                Displayable d = display.getCurrent();
                if (d instanceof Canvas) ((Canvas) d).sizeChangedInternal(width, height);
                display.requestRepaint();
            }
        });
    }

    public String appProperty(String k) { return props.get(k); }
    public byte[] resource(String path) { return resources == null ? null : resources.find(path); }
    public void log(int level, String m) { Logger l = logger; if (l != null) l.log(level, m); }

    // ---- event thread

    public void start() {
        if (running) return;
        running = true;
        Thread t = new Thread(null, new Runnable() {
            public void run() {
                CURRENT.set(Device.this);
                while (running) {
                    Runnable r;
                    try { r = events.poll(200, TimeUnit.MILLISECONDS); } catch (InterruptedException e) { break; }
                    if (r == null) continue;
                    try { r.run(); }
                    catch (Throwable t) {
                        if (t instanceof com.dashers.j2mebuilderide.emu.vm.Vm.VmExit) continue;
                        ErrorSink s = errorSink;
                        if (s != null) s.onError("event thread", t);
                    }
                }
            }
        }, "emu-events", 8L * 1024 * 1024);
        t.setDaemon(true);
        loop = t;
        t.start();
    }

    /** Stops the event thread; pending events are dropped. */
    public void stop() {
        running = false;
        events.clear();
        smsBus.closeAll();
        SensorHub sh;
        synchronized (this) { sh = sensorHub; }
        if (sh != null) sh.closeAll();
        BtState bs;
        synchronized (this) { bs = btState; }
        if (bs != null) bs.closeAll();
        for (Player p : owned) { try { p.close(); } catch (RuntimeException e) { /* releasing hardware, keep going */ } }
        owned.clear();
        overlays.clear();
        synchronized (this) { if (timer != null) { timer.cancel(); timer = null; } }
        Thread t = loop;
        if (t != null && t != Thread.currentThread()) t.interrupt();
    }

    public boolean onEventThread() { return Thread.currentThread() == loop; }

    public void post(Runnable r) { if (running) events.add(r); }

    /** Runs r on the event thread and waits (bounded) for it; runs inline when already there. */
    public boolean postAndWait(final Runnable r, long timeoutMs) {
        if (onEventThread()) { r.run(); return true; }
        final CountDownLatch l = new CountDownLatch(1);
        post(new Runnable() { public void run() { try { r.run(); } finally { l.countDown(); } } });
        try { return l.await(timeoutMs, TimeUnit.MILLISECONDS); } catch (InterruptedException e) { return false; }
    }

    // ---- frames

    /** Draws the current displayable into a new frame and hands it to the host view. Event thread only. */
    void renderNow() {
        repaintPending = false;
        int w = width, h = height;
        if (back == null || back.w != w || back.h != h) back = new Frame(w, h);
        back.resetClip();
        back.fillRect(0, 0, w, h, 0xFFFFFF);
        Displayable d = display.getCurrent();
        if (d != null) d.render(this, back);
        if (!overlays.isEmpty()) { back.resetClip(); for (VideoView v : overlays) v.drawOverlay(back, d); }
        synchronized (snapLock) {
            if (snapshot == null || snapshot.length != back.px.length) snapshot = new int[back.px.length];
            System.arraycopy(back.px, 0, snapshot, 0, snapshot.length);
            snapW = w;
            snapH = h;
        }
        synchronized (this) {
            long now = System.currentTimeMillis();
            lastFrame = now;
            if (fpsStart == 0) fpsStart = now;
            fpsFrames++;
            if (now - fpsStart >= 1000) { fpsValue = (int) (fpsFrames * 1000L / (now - fpsStart)); fpsFrames = 0; fpsStart = now; }
        }
        FrameListener fl = frameListener;
        if (fl != null) fl.onFrame();
    }

    void scheduleRepaint() {
        if (repaintPending) return;
        repaintPending = true;
        post(new Runnable() { public void run() { if (repaintPending) renderNow(); } });
    }

    /** Copy of the last completed frame as {w, h} + pixels, or null before the first frame. */
    public int[] copyFrame(int[] whOut) {
        synchronized (snapLock) {
            if (snapshot == null) return null;
            whOut[0] = snapW;
            whOut[1] = snapH;
            return snapshot.clone();
        }
    }

    // ---- lifecycle callbacks from the MIDlet

    public void midletDestroyed() { Runnable r = onDestroyed; if (r != null) r.run(); }
    void midletPaused() { Runnable r = onPausedByMidlet; if (r != null) r.run(); }
}
