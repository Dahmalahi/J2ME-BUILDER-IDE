package com.dashers.j2mebuilderide.emu.midp;

/** Generated from the JSR-184 class list (tools in docs); properties are stored, rendering lives in Graphics3D. */
public class CompositingMode extends Object3D {
    public static final int ALPHA = 64;
    public static final int ALPHA_ADD = 65;
    public static final int MODULATE = 66;
    public static final int MODULATE_X2 = 67;
    public static final int REPLACE = 68;
    int blending = 68;
    float alphaThreshold;
    boolean alphaWriteEnabled = true;
    boolean colorWriteEnabled = true;
    boolean depthWriteEnabled = true;
    boolean depthTestEnabled = true;
    float depthOffsetFactor;
    float depthOffsetUnits;
    public CompositingMode() { }

    public void setBlending(int v) { blending = v; }
    public int getBlending() { return blending; }
    public void setAlphaThreshold(float v) { alphaThreshold = v; }
    public float getAlphaThreshold() { return alphaThreshold; }
    public void setAlphaWriteEnable(boolean v) { alphaWriteEnabled = v; }
    public boolean isAlphaWriteEnabled() { return alphaWriteEnabled; }
    public void setColorWriteEnable(boolean v) { colorWriteEnabled = v; }
    public boolean isColorWriteEnabled() { return colorWriteEnabled; }
    public void setDepthWriteEnable(boolean v) { depthWriteEnabled = v; }
    public boolean isDepthWriteEnabled() { return depthWriteEnabled; }
    public void setDepthTestEnable(boolean v) { depthTestEnabled = v; }
    public boolean isDepthTestEnabled() { return depthTestEnabled; }
    public void setDepthOffset(float a0, float a1) { depthOffsetFactor = a0; depthOffsetUnits = a1; }
    public float getDepthOffsetFactor() { return depthOffsetFactor; }
    public float getDepthOffsetUnits() { return depthOffsetUnits; }
}
