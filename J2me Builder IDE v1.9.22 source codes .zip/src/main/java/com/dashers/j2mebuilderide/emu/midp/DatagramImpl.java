package com.dashers.j2mebuilderide.emu.midp;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;

/** Datagram with a data buffer; reads start at the offset, writes fill the buffer from the offset. */
final class DatagramImpl implements Datagram {
    byte[] buf;
    int off, len;
    String addr;
    private int rpos, wpos;
    private final DataInputStream din = new DataInputStream(new java.io.InputStream() {
        @Override public int read() { return rpos < len ? buf[off + rpos++] & 255 : -1; }
        @Override public int read(byte[] b, int o, int n) {
            if (n == 0) return 0;
            int k = Math.min(n, len - rpos);
            if (k <= 0) return -1;
            System.arraycopy(buf, off + rpos, b, o, k);
            rpos += k;
            return k;
        }
    });
    private final java.io.DataOutputStream dout = new java.io.DataOutputStream(new java.io.OutputStream() {
        @Override public void write(int b) throws IOException {
            if (off + wpos >= buf.length) throw new IOException("datagram buffer full");
            buf[off + wpos++] = (byte) b;
            if (wpos > len) len = wpos;
        }
    });

    DatagramImpl(byte[] b, int size, String a) { buf = b; off = 0; len = size; addr = a; }

    public String getAddress() { return addr; }
    public byte[] getData() { return buf; }
    public int getLength() { return len; }
    public int getOffset() { return off; }
    public void reset() { rpos = 0; wpos = 0; off = 0; len = 0; }
    public void setAddress(String a) throws IOException { addr = a; }
    public void setAddress(Datagram r) { addr = r.getAddress(); }
    public void setData(byte[] b, int o, int l) { buf = b; off = o; len = l; rpos = 0; wpos = 0; }
    public void setLength(int l) { if (l < 0 || off + l > buf.length) throw new IllegalArgumentException("length"); len = l; }

    public void readFully(byte[] b) throws IOException { din.readFully(b); }
    public void readFully(byte[] b, int o, int l) throws IOException { din.readFully(b, o, l); }
    public int skipBytes(int n) throws IOException { return din.skipBytes(n); }
    public boolean readBoolean() throws IOException { return din.readBoolean(); }
    public byte readByte() throws IOException { return din.readByte(); }
    public int readUnsignedByte() throws IOException { return din.readUnsignedByte(); }
    public short readShort() throws IOException { return din.readShort(); }
    public int readUnsignedShort() throws IOException { return din.readUnsignedShort(); }
    public char readChar() throws IOException { return din.readChar(); }
    public int readInt() throws IOException { return din.readInt(); }
    public long readLong() throws IOException { return din.readLong(); }
    public float readFloat() throws IOException { return din.readFloat(); }
    public double readDouble() throws IOException { return din.readDouble(); }
    public String readUTF() throws IOException { return din.readUTF(); }
    @SuppressWarnings("deprecation")
    public String readLine() throws IOException { return din.readLine(); }

    public void write(int b) throws IOException { dout.write(b); }
    public void write(byte[] b) throws IOException { dout.write(b, 0, b.length); }
    public void write(byte[] b, int o, int l) throws IOException { dout.write(b, o, l); }
    public void writeBoolean(boolean v) throws IOException { dout.writeBoolean(v); }
    public void writeByte(int v) throws IOException { dout.writeByte(v); }
    public void writeShort(int v) throws IOException { dout.writeShort(v); }
    public void writeChar(int v) throws IOException { dout.writeChar(v); }
    public void writeInt(int v) throws IOException { dout.writeInt(v); }
    public void writeLong(long v) throws IOException { dout.writeLong(v); }
    public void writeFloat(float v) throws IOException { dout.writeFloat(v); }
    public void writeDouble(double v) throws IOException { dout.writeDouble(v); }
    public void writeBytes(String s) throws IOException { dout.writeBytes(s); }
    public void writeChars(String s) throws IOException { dout.writeChars(s); }
    public void writeUTF(String s) throws IOException { dout.writeUTF(s); }
}
