package com.dashers.j2mebuilderide.emu.midp;

import com.dashers.j2mebuilderide.emu.gfx.Frame;

public abstract class Canvas extends Displayable {
    public static final int UP = 1, DOWN = 6, LEFT = 2, RIGHT = 5, FIRE = 8, GAME_A = 9, GAME_B = 10, GAME_C = 11, GAME_D = 12;
    public static final int KEY_NUM0 = 48, KEY_NUM1 = 49, KEY_NUM2 = 50, KEY_NUM3 = 51, KEY_NUM4 = 52, KEY_NUM5 = 53,
            KEY_NUM6 = 54, KEY_NUM7 = 55, KEY_NUM8 = 56, KEY_NUM9 = 57, KEY_STAR = 42, KEY_POUND = 35;

    /** Key codes the emulator sends for the navigation keys (Nokia / Sun WTK convention). */
    public static final int CODE_UP = -1, CODE_DOWN = -2, CODE_LEFT = -3, CODE_RIGHT = -4, CODE_SELECT = -5,
            CODE_SOFT1 = -6, CODE_SOFT2 = -7;

    private boolean fullScreen;

    protected Canvas() { }

    protected abstract void paint(Graphics g);

    public void keyPressed(int keyCode) { }
    public void keyReleased(int keyCode) { }
    public void keyRepeated(int keyCode) { }
    public void pointerPressed(int x, int y) { }
    public void pointerReleased(int x, int y) { }
    public void pointerDragged(int x, int y) { }
    public void showNotify() { }
    public void hideNotify() { }
    public void sizeChanged(int w, int h) { }

    void sizeChangedInternal(int w, int h) { sizeChanged(w, h); }
    boolean suppressKeys() { return false; }
    void trackKey(int type, int code) { }
    @Override void showNotifyInternal() { super.showNotifyInternal(); showNotify(); }
    @Override void hideNotifyInternal() { super.hideNotifyInternal(); hideNotify(); }

    public boolean isDoubleBuffered() { return true; }
    public boolean hasPointerEvents() { return true; }
    public boolean hasPointerMotionEvents() { return true; }
    public boolean hasRepeatEvents() { return true; }
    public void setFullScreenMode(boolean m) { fullScreen = m; refresh(); }
    public boolean fullScreen() { return fullScreen; }

    public final void repaint() { Device.current().display.requestRepaint(); }
    public final void repaint(int x, int y, int w, int h) { Device.current().display.requestRepaint(); }
    public final void serviceRepaints() { Device.current().display.serviceRepaints(); }

    public int getGameAction(int k) {
        switch (k) {
            case CODE_UP: case KEY_NUM2: return UP;
            case CODE_DOWN: case KEY_NUM8: return DOWN;
            case CODE_LEFT: case KEY_NUM4: return LEFT;
            case CODE_RIGHT: case KEY_NUM6: return RIGHT;
            case CODE_SELECT: case KEY_NUM5: return FIRE;
            case KEY_NUM1: return GAME_A;
            case KEY_NUM3: return GAME_B;
            case KEY_NUM7: return GAME_C;
            case KEY_NUM9: return GAME_D;
            default: throw new IllegalArgumentException("not a valid key code: " + k);
        }
    }

    public int getKeyCode(int a) {
        switch (a) {
            case UP: return CODE_UP;
            case DOWN: return CODE_DOWN;
            case LEFT: return CODE_LEFT;
            case RIGHT: return CODE_RIGHT;
            case FIRE: return CODE_SELECT;
            case GAME_A: return KEY_NUM1;
            case GAME_B: return KEY_NUM3;
            case GAME_C: return KEY_NUM7;
            case GAME_D: return KEY_NUM9;
            default: throw new IllegalArgumentException("not a valid game action: " + a);
        }
    }

    public String getKeyName(int k) {
        if (k >= KEY_NUM0 && k <= KEY_NUM9) return "NUM" + (k - KEY_NUM0);
        switch (k) {
            case KEY_STAR: return "STAR";
            case KEY_POUND: return "POUND";
            case CODE_UP: return "UP";
            case CODE_DOWN: return "DOWN";
            case CODE_LEFT: return "LEFT";
            case CODE_RIGHT: return "RIGHT";
            case CODE_SELECT: return "SELECT";
            case CODE_SOFT1: return "SOFT1";
            case CODE_SOFT2: return "SOFT2";
            default: throw new IllegalArgumentException("not a valid key code: " + k);
        }
    }

    @Override void render(Device d, Frame f) {
        Graphics g = new Graphics(f);
        g.setColor(0);
        paint(g);
    }
}
