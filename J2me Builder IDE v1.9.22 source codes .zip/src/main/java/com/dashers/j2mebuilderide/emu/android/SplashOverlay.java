package com.dashers.j2mebuilderide.emu.android;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.LinearInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Start-up screen shown over the emulator while the MIDlet loads: the IDE's wallpaper (or the emulator's own sunset
 * backdrop) filling any screen, a frosted card with the app icon and the game's name, and a sliding progress pill.
 */
final class SplashOverlay {
    final FrameLayout view;
    private final TextView title;
    private boolean gone;

    SplashOverlay(Context c, Bitmap wallpaper) {
        view = new FrameLayout(c);
        view.setBackground(wallpaper != null ? Ui.wallpaperDrawable(wallpaper) : Ui.backdrop());
        view.setClickable(true);              // swallow touches until the game is on screen

        LinearLayout card = new LinearLayout(c);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER_HORIZONTAL);
        card.setBackground(Ui.glassPanel(c, 34));
        card.setPadding(Ui.dp(c, 28), Ui.dp(c, 30), Ui.dp(c, 28), Ui.dp(c, 26));

        ImageView icon = new ImageView(c);
        try { icon.setImageDrawable(c.getPackageManager().getApplicationIcon(c.getPackageName())); } catch (Exception ignore) { }
        card.addView(icon, new LinearLayout.LayoutParams(Ui.dp(c, 76), Ui.dp(c, 76)));
        ObjectAnimator sx = ObjectAnimator.ofFloat(icon, "scaleX", 1f, 1.07f);
        ObjectAnimator sy = ObjectAnimator.ofFloat(icon, "scaleY", 1f, 1.07f);
        for (ObjectAnimator a : new ObjectAnimator[]{sx, sy}) {
            a.setDuration(900);
            a.setRepeatCount(ValueAnimator.INFINITE);
            a.setRepeatMode(ValueAnimator.REVERSE);
            a.start();
        }

        title = new TextView(c);
        title.setText("Starting\u2026");
        title.setTextColor(Ui.TEXT);
        title.setTextSize(20);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER);
        title.setMaxLines(2);
        title.setPadding(0, Ui.dp(c, 18), 0, 0);
        card.addView(title, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView sub = new TextView(c);
        sub.setText("J2ME Builder IDE  \u00B7  built-in emulator");
        sub.setTextColor(Ui.MUTED);
        sub.setTextSize(12);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, Ui.dp(c, 6), 0, Ui.dp(c, 22));
        card.addView(sub, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        card.addView(new Slider(c), new LinearLayout.LayoutParams(Ui.dp(c, 170), Ui.dp(c, 5)));

        int maxW = Math.min(Ui.dp(c, 340), (int) (c.getResources().getDisplayMetrics().widthPixels * 0.82f));
        view.addView(card, new FrameLayout.LayoutParams(maxW, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER));

        card.setAlpha(0f);
        card.setScaleX(0.92f);
        card.setScaleY(0.92f);
        card.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(420).start();
    }

    void setTitle(String t) {
        if (t != null && t.length() > 0) title.setText(t);
    }

    /** Fades the splash out and removes it. Safe to call more than once. */
    void hide() {
        if (gone) return;
        gone = true;
        view.animate().alpha(0f).setDuration(380).withEndAction(new Runnable() {
            public void run() {
                if (view.getParent() instanceof ViewGroup) ((ViewGroup) view.getParent()).removeView(view);
            }
        }).start();
    }

    /** A pill that slides back and forth along a faint track. */
    private static final class Slider extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF r = new RectF();
        private float t;
        private ValueAnimator anim;

        Slider(Context c) { super(c); }

        @Override protected void onAttachedToWindow() {
            super.onAttachedToWindow();
            anim = ValueAnimator.ofFloat(0f, 1f);
            anim.setDuration(1100);
            anim.setRepeatCount(ValueAnimator.INFINITE);
            anim.setRepeatMode(ValueAnimator.REVERSE);
            anim.setInterpolator(new LinearInterpolator());
            anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                public void onAnimationUpdate(ValueAnimator a) { t = ((Float) a.getAnimatedValue()).floatValue(); invalidate(); }
            });
            anim.start();
        }

        @Override protected void onDetachedFromWindow() {
            super.onDetachedFromWindow();
            if (anim != null) anim.cancel();
        }

        @Override protected void onDraw(Canvas cv) {
            float w = getWidth(), h = getHeight();
            p.setColor(0x33FFFFFF);
            r.set(0, 0, w, h);
            cv.drawRoundRect(r, h / 2, h / 2, p);
            float bw = w * 0.38f, x = (w - bw) * t;
            p.setColor(Ui.ACCENT);
            r.set(x, 0, x + bw, h);
            cv.drawRoundRect(r, h / 2, h / 2, p);
        }
    }
}
