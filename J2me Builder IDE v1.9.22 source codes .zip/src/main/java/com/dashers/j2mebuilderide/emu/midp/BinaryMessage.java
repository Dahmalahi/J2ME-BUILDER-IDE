package com.dashers.j2mebuilderide.emu.midp;

public interface BinaryMessage extends Message {
    byte[] getPayloadData();
    void setPayloadData(byte[] data);
}
