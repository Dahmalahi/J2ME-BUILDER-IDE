package com.dashers.j2mebuilderide.emu.midp;

final class EventImpl extends PimItemImpl implements Event {
    EventImpl(PimListImpl l, PimRecord r, boolean modified) { super(l, r, modified); }

    public RepeatRule getRepeat() { synchronized (list.data) { return rec.repeat == null ? null : rec.repeat.copy(); } }

    public void setRepeat(RepeatRule rule) {
        synchronized (list.data) {
            rec.repeat = rule == null ? null : rule.copy();
            modified = true;
        }
    }
}
