package com.dashers.j2mebuilderide.emu.midp;

public interface Control { }
