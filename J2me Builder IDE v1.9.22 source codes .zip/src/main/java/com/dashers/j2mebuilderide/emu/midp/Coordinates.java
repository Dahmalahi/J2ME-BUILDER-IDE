package com.dashers.j2mebuilderide.emu.midp;

public class Coordinates {
    private double lat, lon;
    private float alt;
    public Coordinates(double latitude, double longitude, float altitude) { setLatitude(latitude); setLongitude(longitude); alt = altitude; }
    public double getLatitude() { return lat; }
    public double getLongitude() { return lon; }
    public float getAltitude() { return alt; }
    public void setLatitude(double v) { if (v < -90 || v > 90 || v != v) throw new IllegalArgumentException("latitude"); lat = v; }
    public void setLongitude(double v) { if (v < -180 || v >= 180 || v != v) throw new IllegalArgumentException("longitude"); lon = v; }
    public void setAltitude(float v) { alt = v; }
    public float distance(Coordinates to) {
        double p1 = Math.toRadians(lat), p2 = Math.toRadians(to.lat), dp = p2 - p1, dl = Math.toRadians(to.lon - lon);
        double a = Math.sin(dp / 2) * Math.sin(dp / 2) + Math.cos(p1) * Math.cos(p2) * Math.sin(dl / 2) * Math.sin(dl / 2);
        return (float) (6371000.0 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a)));
    }
    public float azimuthTo(Coordinates to) {
        double p1 = Math.toRadians(lat), p2 = Math.toRadians(to.lat), dl = Math.toRadians(to.lon - lon);
        double y = Math.sin(dl) * Math.cos(p2), x = Math.cos(p1) * Math.sin(p2) - Math.sin(p1) * Math.cos(p2) * Math.cos(dl);
        return (float) ((Math.toDegrees(Math.atan2(y, x)) + 360) % 360);
    }
}
