package com.dashers.j2mebuilderide.emu;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

/** Host key code -> MIDP key code. Host codes are Android KeyEvent values; the table is editable and persistable. */
public final class KeyMap {
    public static final int NONE = Integer.MIN_VALUE;
    public static final int UP = -1, DOWN = -2, LEFT = -3, RIGHT = -4, SELECT = -5, SOFT1 = -6, SOFT2 = -7, CALL = -10, END = -11;

    private final Map<Integer, Integer> m = new HashMap<Integer, Integer>();

    public KeyMap() { reset(); }

    public void reset() {
        m.clear();
        int[][] d = {
            {19, UP}, {20, DOWN}, {21, LEFT}, {22, RIGHT}, {23, SELECT}, {66, SELECT}, {62, SELECT},
            {51, UP}, {47, DOWN}, {29, LEFT}, {32, RIGHT},          // W S A D
            {45, SOFT1}, {33, SOFT2}, {1, SOFT1}, {2, SOFT2},        // Q E, hardware soft keys
            {17, 42}, {18, 35},                                      // * #
            {5, CALL}, {6, END},
        };
        for (int[] e : d) m.put(Integer.valueOf(e[0]), Integer.valueOf(e[1]));
        for (int i = 0; i <= 9; i++) m.put(Integer.valueOf(7 + i), Integer.valueOf(48 + i));   // KEYCODE_0..9
    }

    public int map(int hostKey) { Integer v = m.get(Integer.valueOf(hostKey)); return v == null ? NONE : v.intValue(); }
    public void set(int hostKey, int midpKey) { m.put(Integer.valueOf(hostKey), Integer.valueOf(midpKey)); }
    public void remove(int hostKey) { m.remove(Integer.valueOf(hostKey)); }

    /** "19=-1,20=-2" - sorted, so the saved string is stable. */
    @Override public String toString() {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<Integer, Integer> e : new TreeMap<Integer, Integer>(m).entrySet()) {
            if (sb.length() > 0) sb.append(',');
            sb.append(e.getKey()).append('=').append(e.getValue());
        }
        return sb.toString();
    }

    public static KeyMap parse(String s) {
        KeyMap k = new KeyMap();
        if (s == null || s.trim().length() == 0) return k;
        k.m.clear();
        for (String part : s.split(",")) {
            int eq = part.indexOf('=');
            if (eq <= 0) continue;
            try { k.m.put(Integer.valueOf(part.substring(0, eq).trim()), Integer.valueOf(part.substring(eq + 1).trim())); }
            catch (NumberFormatException ignored) { /* skip a damaged entry */ }
        }
        return k;
    }

    public static String nameOf(int midp) {
        switch (midp) {
            case UP: return "Up"; case DOWN: return "Down"; case LEFT: return "Left"; case RIGHT: return "Right";
            case SELECT: return "Select"; case SOFT1: return "Left soft key"; case SOFT2: return "Right soft key";
            case CALL: return "Call"; case END: return "End"; case 42: return "*"; case 35: return "#";
            default: return midp >= 48 && midp <= 57 ? String.valueOf(midp - 48) : String.valueOf(midp);
        }
    }
}
