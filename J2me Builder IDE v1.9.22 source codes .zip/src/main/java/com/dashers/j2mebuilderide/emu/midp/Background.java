package com.dashers.j2mebuilderide.emu.midp;

/** Generated from the JSR-184 class list (tools in docs); properties are stored, rendering lives in Graphics3D. */
public class Background extends Object3D {
    public static final int BORDER = 32;
    public static final int REPEAT = 33;
    int color;
    Image2D image;
    int imageModeX = 32;
    int imageModeY = 32;
    boolean colorClearEnabled = true;
    boolean depthClearEnabled = true;
    int cropX;
    int cropY;
    int cropWidth;
    int cropHeight;
    public Background() { }

    public void setColor(int v) { color = v; }
    public int getColor() { return color; }
    public void setImage(Image2D v) { image = v; }
    public Image2D getImage() { return image; }
    public void setImageMode(int a0, int a1) { imageModeX = a0; imageModeY = a1; }
    public int getImageModeX() { return imageModeX; }
    public int getImageModeY() { return imageModeY; }
    public void setColorClearEnable(boolean v) { colorClearEnabled = v; }
    public boolean isColorClearEnabled() { return colorClearEnabled; }
    public void setDepthClearEnable(boolean v) { depthClearEnabled = v; }
    public boolean isDepthClearEnabled() { return depthClearEnabled; }
    public void setCrop(int a0, int a1, int a2, int a3) { cropX = a0; cropY = a1; cropWidth = a2; cropHeight = a3; }
    public int getCropX() { return cropX; }
    public int getCropY() { return cropY; }
    public int getCropWidth() { return cropWidth; }
    public int getCropHeight() { return cropHeight; }
}
