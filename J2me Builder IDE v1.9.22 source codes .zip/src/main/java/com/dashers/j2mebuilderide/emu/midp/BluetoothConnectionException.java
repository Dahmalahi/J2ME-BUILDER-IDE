package com.dashers.j2mebuilderide.emu.midp;

public class BluetoothConnectionException extends java.io.IOException {
    public static final int UNKNOWN_PSM = 1, SECURITY_BLOCK = 2, NO_RESOURCES = 3, FAILED_NOINFO = 4, TIMEOUT = 5, UNACCEPTABLE_PARAMS = 6;
    private final int status;
    public BluetoothConnectionException(int error) { super(); status = error; }
    public BluetoothConnectionException(int error, String msg) { super(msg); status = error; }
    public int getStatus() { return status; }
}
