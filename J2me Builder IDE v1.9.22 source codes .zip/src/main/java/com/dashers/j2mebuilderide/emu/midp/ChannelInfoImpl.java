package com.dashers.j2mebuilderide.emu.midp;

final class ChannelInfoImpl implements ChannelInfo {
    private final String name;
    private final Unit unit;
    private final int type, scale;
    private final float accuracy;
    private final MeasurementRange[] ranges;

    ChannelInfoImpl(String name, String unit, int type, int scale, float accuracy, double min, double max, double res) {
        this.name = name; this.unit = Unit.getUnit(unit); this.type = type; this.scale = scale; this.accuracy = accuracy;
        ranges = new MeasurementRange[]{new MeasurementRange(min, max, res)};
    }

    public float getAccuracy() { return accuracy; }
    public int getDataType() { return type; }
    public MeasurementRange[] getMeasurementRanges() { return ranges.clone(); }
    public String getName() { return name; }
    public int getScale() { return scale; }
    public Unit getUnit() { return unit; }

    double factor() { return Math.pow(10, scale); }
}
