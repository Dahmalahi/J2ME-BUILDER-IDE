package com.dashers.j2mebuilderide.emu.android;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothClass;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.ParcelUuid;

import com.dashers.j2mebuilderide.emu.midp.BluetoothProvider;
import com.dashers.j2mebuilderide.emu.midp.SimulatedBluetooth;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Bluetooth for javax.bluetooth (JSR-82, RFCOMM serial port only). Simulated by default (a virtual echo device, see
 * SimulatedBluetooth). In "real" mode the phone's Bluetooth is used, with run-time permissions (BLUETOOTH_CONNECT / BLUETOOTH_SCAN
 * on Android 12+, location for scanning) and a dialog asking before the MIDlet lists paired devices, scans, connects to a device
 * or offers a service. Pairing and switching Bluetooth on are done by the user in Android's settings. Needs a phone test.
 */
public final class AndroidBluetooth implements BluetoothProvider {
    private final Activity act;
    private volatile boolean real;
    private final SimulatedBluetooth sim = new SimulatedBluetooth();
    private final Set<String> consent = new HashSet<String>();
    private BroadcastReceiver inquiryReceiver;
    private volatile boolean cancelled;

    public AndroidBluetooth(Activity a, boolean realMode) { act = a; real = realMode; }

    public void setReal(boolean on) { real = on; }
    /** Simulated mode only: a virtual device connects to the MIDlet's service. */
    public boolean simulateIncoming(String uuid) { return sim.incoming(uuid); }

    public String name() { return real ? "real Bluetooth (asks before it scans or connects)" : sim.name(); }
    public boolean real() { return real; }

    private BluetoothAdapter adapter() { return BluetoothAdapter.getDefaultAdapter(); }

    private void permission(String perm, String what) {
        if (!Permissions.ensure(act, perm, 60000))
            throw new SecurityException("the " + perm.substring(perm.lastIndexOf('.') + 1) + " permission was refused (" + what + ") - allow it in the phone's app settings, or use More > Bluetooth > Simulated");
    }

    private void needConnect() { if (Build.VERSION.SDK_INT >= 31) permission("android.permission.BLUETOOTH_CONNECT", "connect to Bluetooth devices"); }

    private void needScan() {
        if (Build.VERSION.SDK_INT >= 31) permission("android.permission.BLUETOOTH_SCAN", "search for Bluetooth devices");
        if (Build.VERSION.SDK_INT >= 23) permission("android.permission.ACCESS_FINE_LOCATION", "Android ties Bluetooth scanning to location");
    }

    private void ask(String key, String title, String message) {
        synchronized (consent) { if (consent.contains(key)) return; }
        if (!Ask.confirm(act, title, message, "Allow", "Don't allow")) throw new SecurityException("the user refused: " + title);
        synchronized (consent) { consent.add(key); }
    }

    private static String clean(String a) { return a == null ? "" : a.replace(":", "").toUpperCase(); }

    private static String colons(String a) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 12; i += 2) { if (i > 0) sb.append(':'); sb.append(a, i, i + 2); }
        return sb.toString();
    }

    private static String dashed(String h) { return h.substring(0, 8) + "-" + h.substring(8, 12) + "-" + h.substring(12, 16) + "-" + h.substring(16, 20) + "-" + h.substring(20); }

    public boolean available() { return !real || adapter() != null; }
    public boolean isPowerOn() { return real ? adapter() != null && adapter().isEnabled() : sim.isPowerOn(); }

    public String address() {
        if (!real) return sim.address();
        needConnect();
        String a = clean(adapter().getAddress());
        return a.length() == 12 ? a : "000000000000";
    }

    public String friendlyName() {
        if (!real) return sim.friendlyName();
        needConnect();
        String n = adapter().getName();
        return n == null ? "Android phone" : n;
    }

    public List<Dev> bonded() {
        if (!real) return sim.bonded();
        ask("list", "Share paired Bluetooth devices?", "A MIDlet wants to see the list of your paired Bluetooth devices.");
        needConnect();
        List<Dev> out = new ArrayList<Dev>();
        for (BluetoothDevice d : adapter().getBondedDevices()) {
            BluetoothClass c = d.getBluetoothClass();
            out.add(new Dev(clean(d.getAddress()), d.getName() == null ? clean(d.getAddress()) : d.getName(), c == null ? 0x1F00 : c.getDeviceClass()));
        }
        return out;
    }

    public void startInquiry(final InquiryListener l) throws IOException {
        if (!real) { sim.startInquiry(l); return; }
        if (!isPowerOn()) throw new IOException("Bluetooth is off: switch it on in Android's settings");
        ask("scan", "Search for Bluetooth devices?", "A MIDlet wants to search for Bluetooth devices around you.");
        needScan();
        needConnect();
        cancelled = false;
        BroadcastReceiver r = new BroadcastReceiver() {
            public void onReceive(Context c, Intent i) {
                String action = i.getAction();
                if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                    BluetoothDevice d = (BluetoothDevice) i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                    if (d == null) return;
                    BluetoothClass bc = d.getBluetoothClass();
                    String n = d.getName();
                    l.found(new Dev(clean(d.getAddress()), n == null ? clean(d.getAddress()) : n, bc == null ? 0x1F00 : bc.getDeviceClass()));
                } else if (BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(action)) {
                    stopReceiver();
                    l.finished(cancelled, false);
                }
            }
        };
        IntentFilter f = new IntentFilter(BluetoothDevice.ACTION_FOUND);
        f.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
        synchronized (this) { stopReceiver(); inquiryReceiver = r; act.registerReceiver(r, f); }
        if (!adapter().startDiscovery()) {
            stopReceiver();
            throw new IOException("the phone refused to start the search");
        }
    }

    private synchronized void stopReceiver() {
        if (inquiryReceiver != null) {
            try { act.unregisterReceiver(inquiryReceiver); } catch (IllegalArgumentException e) { /* already gone */ }
            inquiryReceiver = null;
        }
    }

    public void cancelInquiry() {
        if (!real) { sim.cancelInquiry(); return; }
        cancelled = true;
        try { adapter().cancelDiscovery(); } catch (SecurityException e) { /* nothing running */ }
    }

    public String[] services(String address) {
        if (!real) return sim.services(address);
        needConnect();
        ParcelUuid[] u = adapter().getRemoteDevice(colons(address)).getUuids();
        if (u == null) return null;
        String[] out = new String[u.length];
        for (int i = 0; i < u.length; i++) out[i] = u[i].getUuid().toString().replace("-", "").toUpperCase();
        return out;
    }

    private static final class Sock implements Link {
        private final BluetoothSocket s;
        private final InputStream in;
        private final OutputStream out;
        Sock(BluetoothSocket s) throws IOException { this.s = s; in = s.getInputStream(); out = s.getOutputStream(); }
        public InputStream in() { return in; }
        public OutputStream out() { return out; }
        public String remoteAddress() { return clean(s.getRemoteDevice().getAddress()); }
        public void close() { try { s.close(); } catch (IOException e) { /* already closed */ } }
    }

    public Link connect(String address, String uuid) throws IOException {
        if (!real) return sim.connect(address, uuid);
        if (!isPowerOn()) throw new IOException("Bluetooth is off: switch it on in Android's settings");
        needConnect();
        BluetoothDevice d = adapter().getRemoteDevice(colons(address));
        String label = d.getName() == null ? address : d.getName() + " (" + address + ")";
        ask("connect:" + address, "Connect to a Bluetooth device?", "A MIDlet wants to open a connection to " + label + ".");
        try { adapter().cancelDiscovery(); } catch (SecurityException e) { /* not scanning */ }
        BluetoothSocket s = null;
        try {
            s = d.createRfcommSocketToServiceRecord(java.util.UUID.fromString(dashed(uuid)));
            s.connect();
            return new Sock(s);
        } catch (IOException e) {
            if (s != null) { try { s.close(); } catch (IOException e2) { /* failed anyway */ } }
            throw new IOException("could not connect to " + label + ": " + e.getMessage() + " (is the device paired and its service running?)");
        }
    }

    public Server listen(String uuid, String serviceName) throws IOException {
        if (!real) return sim.listen(uuid, serviceName);
        if (!isPowerOn()) throw new IOException("Bluetooth is off: switch it on in Android's settings");
        needConnect();
        ask("listen:" + uuid, "Offer a Bluetooth service?", "A MIDlet wants this phone to offer the Bluetooth service \"" + serviceName + "\". Only paired devices can connect.");
        final BluetoothServerSocket ss = adapter().listenUsingRfcommWithServiceRecord(serviceName, java.util.UUID.fromString(dashed(uuid)));
        return new Server() {
            public Link accept() throws IOException { return new Sock(ss.accept()); }
            public void close() { try { ss.close(); } catch (IOException e) { /* already closed */ } }
        };
    }
}
