package com.dashers.j2mebuilderide.emu.midp;

/** Nokia lights and vibration: forwarded to the emulator display (which shows them as a toast-less no-op on devices without them). */
public class DeviceControl {
    protected DeviceControl() { }

    public static void setLights(int num, int level) {
        if (num < 0) throw new IllegalArgumentException("light number " + num);
        if (level < 0 || level > 100) throw new IllegalArgumentException("level must be 0..100");
        if (level > 0) Device.current().display.flashBacklight(1000);
    }

    public static void flashLights(long duration) {
        if (duration < 0) throw new IllegalArgumentException("negative duration");
        Device.current().display.flashBacklight((int) Math.min(duration, 60000));
    }

    public static void startVibra(int freq, long timeout) {
        if (freq < 0 || freq > 100) throw new IllegalArgumentException("frequency must be 0..100");
        if (timeout < 0) throw new IllegalArgumentException("negative timeout");
        Device.current().display.vibrate((int) Math.min(timeout, 60000));
    }

    public static void stopVibra() { Device.current().display.vibrate(0); }
}
