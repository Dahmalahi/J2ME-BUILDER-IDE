package com.dashers.j2mebuilderide.emu.midp;

final class ContactImpl extends PimItemImpl implements Contact {
    ContactImpl(PimListImpl l, PimRecord r, boolean modified) { super(l, r, modified); }

    public int getPreferredIndex(int field) {
        synchronized (list.data) {
            if (!list.schema.supports(field)) throw new UnsupportedFieldException("field " + field + " is not supported by this list", field);
            java.util.ArrayList<PimRecord.Val> l = rec.fields.get(Integer.valueOf(field));
            if (l != null) for (int i = 0; i < l.size(); i++) if ((l.get(i).attrs & ATTR_PREFERRED) != 0) return i;
            return -1;
        }
    }
}
