package com.dashers.j2mebuilderide.emu;

import com.dashers.j2mebuilderide.emu.midp.Names;
import com.dashers.j2mebuilderide.emu.vm.ClassFile;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;

/**
 * Looks at every class of the jar before it runs and lists the MIDP classes and members the runtime does not
 * provide, so problems show up as one readable list instead of a failure halfway through the game.
 */
public final class CompatScan {
    public final List<String> unsupportedClasses = new ArrayList<String>();
    public final List<String> missingMembers = new ArrayList<String>();
    public final List<String> unreadable = new ArrayList<String>();
    public int classCount;
    /** Every javax.microedition.* / vendor class the jar refers to (dotted names). */
    public final TreeSet<String> used = new TreeSet<String>();

    public boolean clean() { return unsupportedClasses.isEmpty() && missingMembers.isEmpty() && unreadable.isEmpty(); }

    public static CompatScan scan(Map<String, byte[]> files) {
        CompatScan r = new CompatScan();
        Names names = new Names();
        TreeSet<String> badClasses = new TreeSet<String>(), badMembers = new TreeSet<String>();
        for (Map.Entry<String, byte[]> e : files.entrySet()) {
            if (!e.getKey().endsWith(".class")) continue;
            r.classCount++;
            ClassFile cf;
            try { cf = ClassFile.parse(e.getValue()); }
            catch (Exception ex) { r.unreadable.add(e.getKey() + ": " + ex.getMessage()); continue; }
            for (int i = 1; i < cf.tag.length; i++) {
                int t = cf.tag[i];
                if (t != 7 && t != 9 && t != 10 && t != 11) continue;
                String owner = t == 7 ? cf.utf[cf.a[i]] : cf.className(cf.a[i]);
                if (owner.startsWith("[") || files.containsKey(owner + ".class")) continue;
                if (owner.startsWith("javax/") || owner.startsWith("com/nokia/") || owner.startsWith("com/siemens/") || owner.startsWith("com/samsung/") || owner.startsWith("com/motorola/") || owner.startsWith("com/sonyericsson/") || owner.startsWith("com/mascotcapsule/") || owner.startsWith("com/vodafone/")) r.used.add(owner.replace('/', '.'));
                Class<?> hc;
                try {
                    hc = names.map(owner);
                    if (hc == null) {
                        if (owner.startsWith("java/")) hc = Class.forName(owner.replace('/', '.'));
                        else continue;
                    }
                } catch (ClassNotFoundException ex) {
                    badClasses.add(owner.replace('/', '.'));
                    continue;
                } catch (Throwable ex) { continue; }
                if (t == 7) continue;
                int nt = cf.b[i];
                String member = cf.utf[cf.a[nt]], desc = cf.utf[cf.b[nt]];
                if (!owner.startsWith("javax/")) continue;      // java.* members are the host JDK's business
                if (!has(hc, member, t == 9, desc)) badMembers.add(owner.replace('/', '.') + "." + member + (t == 9 ? "" : "(...)"));
            }
        }
        r.unsupportedClasses.addAll(badClasses);
        r.missingMembers.addAll(badMembers);
        return r;
    }

    private static int paramCount(String desc) { return ClassFile.argSlotsLogical(desc); }

    private static boolean has(Class<?> c, String name, boolean field, String desc) {
        try {
            if (field) {
                for (Class<?> k = c; k != null; k = k.getSuperclass()) {
                    try { k.getDeclaredField(name); return true; } catch (NoSuchFieldException ignore) { /* next */ }
                }
                try { c.getField(name); return true; } catch (NoSuchFieldException ignore) { return false; }
            }
            if (name.equals("<init>")) {
                int n = paramCount(desc);
                for (java.lang.reflect.Constructor<?> k : c.getDeclaredConstructors()) if (k.getParameterTypes().length == n) return true;
                return false;
            }
            int n = paramCount(desc);
            for (Class<?> k = c; k != null; k = k.getSuperclass()) {
                for (Method m : k.getDeclaredMethods()) if (m.getName().equals(name) && m.getParameterTypes().length == n) return true;
            }
            for (Method m : c.getMethods()) if (m.getName().equals(name) && m.getParameterTypes().length == n) return true;
            return false;
        } catch (Throwable t) {
            return true;       // never block a run because the scan itself failed
        }
    }
}
