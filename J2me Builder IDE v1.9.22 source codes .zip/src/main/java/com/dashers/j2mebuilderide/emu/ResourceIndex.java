package com.dashers.j2mebuilderide.emu;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Resolves getResourceAsStream / Image.createImage paths against the jar the way MIDlets expect, but more tolerantly than
 * a real phone: "./", "../", "\", doubled slashes, wrong letter case and a wrong folder (when the file name is unique) are
 * all resolved, and each of those cases is reported so the developer can fix the path. Missing files are reported once,
 * with a "did you mean" suggestion.
 */
public final class ResourceIndex {
    public interface Sink {
        void log(int level, String message);
        void missing(String requested, String suggestion);
    }

    private final Map<String, byte[]> files;
    private final Map<String, String> lower = new HashMap<String, String>();
    private final Map<String, List<String>> byName = new HashMap<String, List<String>>();
    private final Set<String> reported = new HashSet<String>();
    private final Sink sink;
    private int hits, misses, fuzzy;

    public ResourceIndex(Map<String, byte[]> files, Sink sink) {
        this.files = files;
        this.sink = sink;
        for (String k : files.keySet()) {
            if (k.endsWith(".class") || k.startsWith("META-INF/")) continue;
            lower.put(k.toLowerCase(), k);
            String b = baseName(k).toLowerCase();
            List<String> l = byName.get(b);
            if (l == null) { l = new ArrayList<String>(); byName.put(b, l); }
            l.add(k);
        }
    }

    public synchronized int hits() { return hits; }
    public synchronized int misses() { return misses; }
    public synchronized int fuzzy() { return fuzzy; }

    static String baseName(String p) { int i = p.lastIndexOf('/'); return i < 0 ? p : p.substring(i + 1); }

    /** "/a/./b\\c.png" -> "a/b/c.png". */
    public static String normalize(String p) {
        String s = p.replace('\\', '/').trim();
        LinkedList<String> st = new LinkedList<String>();
        for (String part : s.split("/")) {
            if (part.length() == 0 || part.equals(".")) continue;
            if (part.equals("..")) { if (!st.isEmpty()) st.removeLast(); continue; }
            st.add(part);
        }
        StringBuilder sb = new StringBuilder();
        for (String x : st) { if (sb.length() > 0) sb.append('/'); sb.append(x); }
        return sb.toString();
    }

    public synchronized byte[] find(String path) {
        if (path == null) return null;
        String n = normalize(path);
        byte[] b = files.get(n);
        if (b != null) { hits++; return b; }
        String real = lower.get(n.toLowerCase());
        String how = "the letter case differs";
        if (real == null) {
            List<String> c = byName.get(baseName(n).toLowerCase());
            if (c != null && c.size() == 1) { real = c.get(0); how = "it is in another folder"; }
        }
        if (real != null) {
            fuzzy++;
            hits++;
            if (reported.add("f:" + n)) sink.log(ConsoleLog.WARN, "Resource \"/" + n + "\" was found as \"/" + real + "\" (" + how + "). A real phone would not find it: fix the path in the code.");
            return files.get(real);
        }
        misses++;
        if (reported.add(n)) sink.missing("/" + n, suggest(n));
        return null;
    }

    private String suggest(String n) {
        String base = baseName(n).toLowerCase();
        List<String> same = byName.get(base);
        if (same != null && same.size() > 1) {
            StringBuilder sb = new StringBuilder("Several files have this name: ");
            for (int i = 0; i < same.size() && i < 4; i++) { if (i > 0) sb.append(", "); sb.append('/').append(same.get(i)); }
            return sb.append(". Use the full path of the right one.").toString();
        }
        String best = null;
        int bestD = Integer.MAX_VALUE;
        for (Map.Entry<String, List<String>> e : byName.entrySet()) {
            int d = distance(base, e.getKey());
            if (d < bestD) { bestD = d; best = e.getValue().get(0); }
        }
        if (best != null && bestD <= Math.max(2, base.length() / 4)) return "Did you mean /" + best + " ?";
        int dot = base.lastIndexOf('.');
        if (dot > 0) {
            String ext = base.substring(dot);
            for (String k : lower.keySet()) if (k.endsWith(ext)) return "The jar has other " + ext + " files, for example /" + lower.get(k) + " - check the file name and folder.";
        }
        return null;
    }

    static int distance(String a, String b) {
        if (Math.abs(a.length() - b.length()) > 6) return 99;
        int[] p = new int[b.length() + 1], c = new int[b.length() + 1];
        for (int j = 0; j <= b.length(); j++) p[j] = j;
        for (int i = 1; i <= a.length(); i++) {
            c[0] = i;
            for (int j = 1; j <= b.length(); j++) {
                int cost = a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1;
                c[j] = Math.min(Math.min(c[j - 1] + 1, p[j] + 1), p[j - 1] + cost);
            }
            int[] t = p; p = c; c = t;
        }
        return p[b.length()];
    }
}
