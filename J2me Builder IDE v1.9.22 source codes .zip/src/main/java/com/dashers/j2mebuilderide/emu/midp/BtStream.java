package com.dashers.j2mebuilderide.emu.midp;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/** An open btspp:// RFCOMM connection. */
final class BtStream implements StreamConnection {
    private final BtState st;
    private final BluetoothProvider.Link link;
    private boolean closed;

    BtStream(BtState st, BluetoothProvider.Link link) { this.st = st; this.link = link; st.add(this); }

    String remote() { return link.remoteAddress(); }

    private void check() throws IOException { synchronized (this) { if (closed) throw new IOException("the Bluetooth connection is closed"); } }

    public InputStream openInputStream() throws IOException { check(); return link.in(); }
    public DataInputStream openDataInputStream() throws IOException { return new DataInputStream(openInputStream()); }
    public OutputStream openOutputStream() throws IOException { check(); return link.out(); }
    public DataOutputStream openDataOutputStream() throws IOException { return new DataOutputStream(openOutputStream()); }

    public void close() throws IOException {
        synchronized (this) { if (closed) return; closed = true; }
        st.remove(this);
        link.close();
        st.device.log(0, "Bluetooth connection to " + link.remoteAddress() + " closed");
    }
}
