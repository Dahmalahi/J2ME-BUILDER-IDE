package com.dashers.j2mebuilderide.emu.midp;

public class DirectUtils {
    protected DirectUtils() { }

    public static DirectGraphics getDirectGraphics(Graphics g) {
        if (g == null) throw new NullPointerException("g");
        return new DirectGraphicsImpl(g);
    }

    /** A mutable image filled with an ARGB colour (alpha is kept). */
    public static Image createImage(int width, int height, int argb) {
        if (width <= 0 || height <= 0) throw new IllegalArgumentException("size must be positive");
        int[] p = new int[width * height];
        java.util.Arrays.fill(p, argb);
        return Image.fromPixels(width, height, p, true);
    }

    /** A mutable image from encoded data (PNG, JPEG, ...). */
    public static Image createImage(byte[] data, int offset, int length) {
        Image src = Image.createImage(data, offset, length);
        int w = src.getWidth(), h = src.getHeight();
        int[] p = new int[w * h];
        src.getRGB(p, 0, w, 0, 0, w, h);
        return Image.fromPixels(w, h, p, true);
    }

    /** A font whose height is close to the requested pixel height. */
    public static Font getFont(int face, int style, int height) {
        int size = height <= 10 ? Font.SIZE_SMALL : height <= 14 ? Font.SIZE_MEDIUM : Font.SIZE_LARGE;
        return Font.getFont(face, style, size);
    }
}
