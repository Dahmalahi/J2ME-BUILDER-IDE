package com.dashers.j2mebuilderide.emu.midp;

public interface DataListener {
    void dataReceived(SensorConnection a0, Data[] a1, boolean a2);
}
