package com.dashers.j2mebuilderide.emu.midp;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.concurrent.LinkedBlockingQueue;

/** Per running MIDlet: the provider, the callback thread (DiscoveryListener callbacks run on it, with the MIDlet's context) and open connections. */
final class BtState {
    final Device device;
    private final LinkedBlockingQueue<Runnable> queue = new LinkedBlockingQueue<Runnable>();
    private Thread callbacks;
    private LocalDevice local;
    final List<Object> open = new ArrayList<Object>();
    final LinkedHashMap<String, BluetoothProvider.Dev> known = new LinkedHashMap<String, BluetoothProvider.Dev>();

    BtState(Device d) { device = d; }

    BluetoothProvider provider() { return device.bluetooth; }

    /** Must first be called from a MIDlet thread: the callback thread inherits its context. */
    synchronized LocalDevice local() throws BluetoothStateException {
        BluetoothProvider p = provider();
        if (p == null || !p.available()) throw new BluetoothStateException("Bluetooth is not available (More > Bluetooth)");
        if (local == null) {
            local = new LocalDevice(this);
            callbacks = new Thread(new Runnable() {
                public void run() {
                    while (true) {
                        Runnable r;
                        try { r = queue.take(); } catch (InterruptedException e) { return; }
                        try { r.run(); } catch (Throwable t) { device.log(2, "Bluetooth listener threw " + t); }
                    }
                }
            }, "bt-callbacks");
            callbacks.setDaemon(true);
            callbacks.start();
        }
        return local;
    }

    void post(Runnable r) { queue.add(r); }

    void add(Object conn) { synchronized (open) { open.add(conn); } }
    void remove(Object conn) { synchronized (open) { open.remove(conn); } }

    void closeAll() {
        List<Object> copy;
        synchronized (open) { copy = new ArrayList<Object>(open); open.clear(); }
        for (Object o : copy) {
            try {
                if (o instanceof BtStream) ((BtStream) o).close();
                else if (o instanceof BtServerConn) ((BtServerConn) o).close();
            } catch (java.io.IOException e) { /* closing anyway */ }
        }
        BluetoothProvider p = provider();
        if (p != null) { try { p.cancelInquiry(); } catch (RuntimeException e) { /* nothing running */ } }
        Thread t;
        synchronized (this) { t = callbacks; callbacks = null; local = null; }
        if (t != null) t.interrupt();
    }
}
