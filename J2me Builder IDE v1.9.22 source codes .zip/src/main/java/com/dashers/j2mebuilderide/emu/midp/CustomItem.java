package com.dashers.j2mebuilderide.emu.midp;

import com.dashers.j2mebuilderide.emu.gfx.Frame;

/** MIDP 2.0 CustomItem. Layout is the runtime's single column; the item gets the width it asks for, up to the column. */
public abstract class CustomItem extends Item {
    public static final int TRAVERSE_HORIZONTAL = 1, TRAVERSE_VERTICAL = 2,
            KEY_PRESS = 4, KEY_RELEASE = 8, KEY_REPEAT = 0x10,
            POINTER_PRESS = 0x20, POINTER_RELEASE = 0x40, POINTER_DRAG = 0x80, NONE = 0;

    protected CustomItem(String label) { super(label); }

    public int getGameAction(int keyCode) { return GAMEKEYS.getGameAction(keyCode); }
    private static final Canvas GAMEKEYS = new Canvas() { protected void paint(Graphics g) { } };
    protected final void invalidate() { changed(); }
    protected final void repaint() { changed(); }
    protected final void repaint(int x, int y, int w, int h) { changed(); }
    protected int getInteractionModes() { return KEY_PRESS | KEY_RELEASE | POINTER_PRESS | POINTER_RELEASE | POINTER_DRAG | TRAVERSE_HORIZONTAL | TRAVERSE_VERTICAL; }

    protected abstract int getMinContentWidth();
    protected abstract int getMinContentHeight();
    protected abstract int getPrefContentWidth(int height);
    protected abstract int getPrefContentHeight(int width);
    protected abstract void paint(Graphics g, int w, int h);

    protected void sizeChanged(int w, int h) { }
    protected boolean traverse(int dir, int viewportWidth, int viewportHeight, int[] visRect_inout) { return false; }
    protected void traverseOut() { }
    protected void keyPressed(int keyCode) { }
    protected void keyReleased(int keyCode) { }
    protected void keyRepeated(int keyCode) { }
    protected void pointerPressed(int x, int y) { }
    protected void pointerReleased(int x, int y) { }
    protected void pointerDragged(int x, int y) { }
    protected void showNotify() { }
    protected void hideNotify() { }

    private int lastW = -1, lastH = -1;
    private boolean wasFocused;

    @Override boolean focusable() { return true; }

    @Override int paint(Device d, Frame f, int x, int y, int w, boolean focused) {
        int y0 = y;
        y = paintLabel(d, f, x, y, w);
        int cw = Math.max(getMinContentWidth(), Math.min(w, getPrefContentWidth(-1)));
        int ch = Math.max(getMinContentHeight(), getPrefContentHeight(cw));
        if (cw != lastW || ch != lastH) { lastW = cw; lastH = ch; sizeChanged(cw, ch); }
        if (focused != wasFocused) { wasFocused = focused; if (!focused) traverseOut(); }
        if (f.cw > 0 && f.ch > 0) {
            int sx = f.cx, sy = f.cy, sw = f.cw, sh = f.ch;
            Graphics g = new Graphics(f);
            g.translate(x, y);
            f.intersectClip(x, y, cw, ch);
            try { paint(g, cw, ch); } finally { f.setClip(sx, sy, sw, sh); }
        }
        return y + ch - y0;
    }

    private static int dirOf(int code) {
        switch (code) {
            case Canvas.CODE_UP: return Canvas.UP;
            case Canvas.CODE_DOWN: return Canvas.DOWN;
            case Canvas.CODE_LEFT: return Canvas.LEFT;
            case Canvas.CODE_RIGHT: return Canvas.RIGHT;
            default: return 0;
        }
    }

    @Override boolean key(Device d, int code) {
        int dir = dirOf(code);
        if (dir != 0) {
            int[] vis = {0, 0, Math.max(1, lastW), Math.max(1, lastH)};
            return traverse(dir, Math.max(1, lastW), Math.max(1, lastH), vis);
        }
        keyPressed(code);
        keyReleased(code);
        return true;
    }

    @Override void pointer(Device d, int ix, int iy) {
        pointerPressed(ix, iy);
        pointerReleased(ix, iy);
    }
}
