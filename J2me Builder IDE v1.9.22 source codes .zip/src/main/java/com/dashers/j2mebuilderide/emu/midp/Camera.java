package com.dashers.j2mebuilderide.emu.midp;

public class Camera extends Node {
    public static final int GENERIC = 48, PARALLEL = 49, PERSPECTIVE = 50;
    private int type = GENERIC;
    private final Transform proj = new Transform();
    private float pFovy, pAspect = 1f, pNear = 0.1f, pFar = 100f;

    public Camera() { }

    public void setParallel(float height, float aspect, float near, float far) {
        if (height <= 0 || aspect <= 0) throw new IllegalArgumentException("height and aspect must be positive");
        if (near >= far) throw new IllegalArgumentException("near must be smaller than far");
        pFovy = height; pAspect = aspect; pNear = near; pFar = far;
        float w = height * aspect;
        proj.setIdentity();
        proj.m[0] = 2f / w; proj.m[5] = 2f / height; proj.m[10] = -2f / (far - near); proj.m[11] = -(far + near) / (far - near);
        type = PARALLEL;
    }

    public void setPerspective(float fovy, float aspect, float near, float far) {
        if (fovy <= 0 || fovy >= 180 || aspect <= 0) throw new IllegalArgumentException("bad field of view or aspect");
        if (near <= 0 || far <= 0 || near == far) throw new IllegalArgumentException("near and far must be positive and different");
        pFovy = fovy; pAspect = aspect; pNear = near; pFar = far;
        float t = (float) Math.tan(Math.toRadians(fovy) / 2);
        java.util.Arrays.fill(proj.m, 0f);
        proj.m[0] = 1f / (aspect * t); proj.m[5] = 1f / t;
        proj.m[10] = -(near + far) / (far - near); proj.m[11] = -2f * near * far / (far - near);
        proj.m[14] = -1f;
        type = PERSPECTIVE;
    }

    public void setGeneric(Transform t) {
        if (t == null) throw new NullPointerException("transform");
        proj.set(t);
        type = GENERIC;
    }

    public int getProjection(Transform t) {
        if (t == null) throw new NullPointerException("transform");
        t.set(proj);
        return type;
    }

    public int getProjection(float[] a) {
        if (a == null) return type;
        if (a.length < 4) throw new IllegalArgumentException("the array needs 4 elements");
        a[0] = 0; a[1] = 0; a[2] = 0; a[3] = 0;
        if (type == PERSPECTIVE) { a[0] = (float) Math.toDegrees(2 * Math.atan(1f / proj.m[5])); a[1] = proj.m[5] / proj.m[0]; a[2] = proj.m[11] / (proj.m[10] - 1f); a[3] = proj.m[11] / (proj.m[10] + 1f); }
        else if (type == PARALLEL) { a[0] = 2f / proj.m[5]; a[1] = proj.m[5] / proj.m[0]; a[2] = (proj.m[11] + 1f) / proj.m[10]; a[3] = (proj.m[11] - 1f) / proj.m[10]; }
        return type;
    }

    Transform projection() { return proj; }

    /** Animation hooks: change one parameter of a perspective or parallel camera (a generic camera ignores them). */
    void animParam(int which, float v) {
        if (type == GENERIC) return;
        float f = pFovy, n = pNear, fa = pFar;
        if (which == 0) f = v; else if (which == 1) n = v; else fa = v;
        try {
            if (type == PERSPECTIVE) setPerspective(f, pAspect, n, fa); else setParallel(f, pAspect, n, fa);
        } catch (IllegalArgumentException e) { /* an animation value outside the legal range is ignored */ }
    }
}
