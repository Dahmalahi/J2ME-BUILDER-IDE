package com.dashers.j2mebuilderide.emu.midp;

import java.io.IOException;

/** Opens btspp://ADDRESS:channel[;uuid=HEX] (client) and btspp://localhost:UUID[;name=...] (server). */
final class BtConnect {
    private BtConnect() { }

    static Connection open(Device d, String url) throws IOException {
        BtState st = d.btState();
        BluetoothProvider p = st.provider();
        if (p == null || !p.available()) throw new ConnectionNotFoundException("Bluetooth is not available (More > Bluetooth)");
        String rest = url.substring(url.indexOf("://") + 3);
        String params = "";
        int semi = rest.indexOf(';');
        if (semi >= 0) { params = rest.substring(semi + 1); rest = rest.substring(0, semi); }
        int colon = rest.indexOf(':');
        if (colon < 0) throw new IllegalArgumentException("btspp URL needs address:channel or localhost:UUID");
        String host = rest.substring(0, colon), tail = rest.substring(colon + 1);
        String uuidParam = null, name = null;
        for (String kv : params.split(";")) {
            int e = kv.indexOf('=');
            if (e < 0) continue;
            String k = kv.substring(0, e), v = kv.substring(e + 1);
            if (k.equals("uuid")) uuidParam = v;
            else if (k.equals("name")) name = v;
        }
        if (host.equalsIgnoreCase("localhost")) {
            String uuid = new UUID(tail, false).hex();
            d.log(0, "Bluetooth service " + uuid + " registered (" + p.name() + ")");
            BluetoothProvider.Server s = p.listen(uuid, name == null ? "J2ME service" : name);
            return new BtServerConn(st, s, new ServiceRecordImpl(null, uuid, name == null ? "J2ME service" : name));
        }
        RemoteDevice dev = new RemoteDevice(host);   // validates the address
        String uuid;
        if (uuidParam != null) uuid = new UUID(uuidParam, false).hex();
        else if (tail.length() == 32) uuid = new UUID(tail, false).hex();
        else uuid = new UUID(0x1101).hex();
        if (d.onEventThread()) d.log(1, "Bluetooth connect on the MIDlet's event thread: the UI freezes while connecting (use a Thread)");
        d.log(0, "Bluetooth connecting to " + dev.getBluetoothAddress() + " (service " + uuid + ") - " + p.name());
        try {
            return new BtStream(st, p.connect(dev.getBluetoothAddress(), uuid));
        } catch (SecurityException e) {
            d.log(2, "Bluetooth connection refused: " + e.getMessage());
            throw e;
        }
    }
}
