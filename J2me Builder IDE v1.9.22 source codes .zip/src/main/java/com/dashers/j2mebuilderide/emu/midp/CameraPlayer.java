package com.dashers.j2mebuilderide.emu.midp;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/** Player for capture://video, capture://image and capture://devcamN. The camera is opened at prefetch (that is when the permission is asked). */
final class CameraPlayer implements Player {
    private final Device device;
    private final boolean front;
    private int wantW, wantH;
    private final String locator;
    private volatile int state = UNREALIZED;
    private volatile CameraProvider.Session cam;
    private final VideoView video;
    private final VideoRec rec = new VideoRec();
    private final List<PlayerListener> listeners = new ArrayList<PlayerListener>();

    CameraPlayer(Device d, boolean front, int w, int h, String locator) {
        device = d; this.front = front; wantW = w; wantH = h; this.locator = locator;
        video = new VideoView(d, new FrameSource() {
            public int[] frame(int[] o) { CameraProvider.Session s = cam; return s == null ? null : s.frame(o); }
            public int width() { CameraProvider.Session s = cam; return s != null ? s.width() : (wantW > 0 ? wantW : 320); }
            public int height() { CameraProvider.Session s = cam; return s != null ? s.height() : (wantH > 0 ? wantH : 240); }
            public byte[] jpeg(int[] a, int w2, int h2, int q) { CameraProvider.Session s = cam; return s == null ? null : s.jpeg(a, w2, h2, q); }
        });
        d.own(this);
    }

    private void ensureOpen() { if (state == CLOSED) throw new IllegalStateException("player is closed"); }

    public synchronized void realize() throws MediaException { ensureOpen(); if (state < REALIZED) state = REALIZED; }

    public synchronized void prefetch() throws MediaException {
        realize();
        if (state >= PREFETCHED) return;
        CameraProvider p = device.camera;
        if (p == null) throw new MediaException("this host provides no camera");
        try {
            cam = p.open(front, wantW, wantH);
            device.log(0, "Camera opened (" + p.name() + ") for " + locator);
        } catch (SecurityException e) {
            device.log(2, "Camera refused: " + e.getMessage());
            throw e;
        } catch (IOException e) {
            device.log(2, "Camera failed: " + e.getMessage());
            throw new MediaException("cannot open the camera: " + e.getMessage());
        }
        state = PREFETCHED;
    }

    public synchronized void start() throws MediaException {
        ensureOpen();
        prefetch();
        if (state == STARTED) return;
        state = STARTED;
        video.setRunning(true);
        fire(PlayerListener.STARTED, Long.valueOf(0));
    }

    public synchronized void stop() throws MediaException {
        ensureOpen();
        if (state != STARTED) return;
        rec.abort();
        video.setRunning(false);
        state = PREFETCHED;
        fire(PlayerListener.STOPPED, Long.valueOf(0));
    }

    public synchronized void deallocate() {
        if (state == CLOSED) return;
        try { stop(); } catch (MediaException e) { /* closing anyway */ }
        releaseCamera();
        if (state > REALIZED) state = REALIZED;
    }

    public void close() {
        synchronized (this) {
            if (state == CLOSED) return;
            video.dispose();
            rec.abort();
            releaseCamera();
            state = CLOSED;
        }
        device.disown(this);
        fire(PlayerListener.CLOSED, null);
    }

    private void releaseCamera() {
        rec.abort();
        CameraProvider.Session s = cam;
        cam = null;
        if (s != null) { try { s.close(); } catch (RuntimeException e) { /* already gone */ } }
    }

    public long setMediaTime(long now) throws MediaException { ensureOpen(); return 0; }
    public long getMediaTime() { return 0; }
    public synchronized int getState() { return state; }
    public long getDuration() { return TIME_UNKNOWN; }
    public String getContentType() { return "video/uncompressed"; }
    public void setLoopCount(int c) { if (c == 0) throw new IllegalArgumentException("loop count must not be 0"); }
    public void addPlayerListener(PlayerListener l) { synchronized (listeners) { if (l != null && !listeners.contains(l)) listeners.add(l); } }
    public void removePlayerListener(PlayerListener l) { synchronized (listeners) { listeners.remove(l); } }

    private void fire(final String ev, final Object data) {
        final List<PlayerListener> ls;
        synchronized (listeners) { ls = new ArrayList<PlayerListener>(listeners); }
        if (ls.isEmpty()) return;
        device.post(new Runnable() { public void run() { for (PlayerListener l : ls) l.playerUpdate(CameraPlayer.this, ev, data); } });
    }

    public Control[] getControls() { return new Control[]{video, rec}; }
    public Control getControl(String t) {
        if (t == null) throw new IllegalArgumentException();
        String n = t.startsWith("javax.microedition.media.control.") ? t.substring(33) : t;
        if (n.equals("VideoControl") || n.equals("GUIControl")) return video;
        if (n.equals("RecordControl")) return rec;
        return null;
    }

    /** RecordControl for video: the phone camera records an MP4 into a temporary file, commit() copies it to the MIDlet's target. */
    private final class VideoRec implements RecordControl {
        private final RecordSink sink = new RecordSink();
        private java.io.File tmp;
        private boolean recording;

        public void setRecordStream(java.io.OutputStream s) { sink.setStream(s); }
        public void setRecordLocation(String l) throws IOException, MediaException { sink.setLocation(l); }
        public String getContentType() { return "video/mp4"; }

        public synchronized void startRecord() {
            if (recording) return;
            CameraProvider.Session s = cam;
            if (s == null || state != STARTED) throw new IllegalStateException("start the player before startRecord()");
            if (!(s instanceof Recordable)) {
                String m = "this camera source cannot record video (choose the phone camera in More > Camera)";
                device.log(2, m);
                fire("recordError", m);
                throw new IllegalStateException(m);
            }
            try {
                discard();
                tmp = java.io.File.createTempFile("emu_rec", ".mp4");
                ((Recordable) s).startRecording(tmp);
                recording = true;
                fire("recordStarted", null);
            } catch (IOException e) {
                device.log(2, "Video recording failed: " + e.getMessage());
                fire("recordError", e.getMessage());
                discard();
            }
        }

        public synchronized void stopRecord() {
            if (!recording) return;
            recording = false;
            CameraProvider.Session s = cam;
            try {
                if (s instanceof Recordable) ((Recordable) s).stopRecording();
                fire("recordStopped", null);
            } catch (IOException e) {
                device.log(2, "Video recording failed: " + e.getMessage());
                fire("recordError", e.getMessage());
            }
        }

        public synchronized void commit() throws IOException {
            stopRecord();
            if (tmp == null || !tmp.exists()) return;
            sink.write(tmp);
            device.log(0, "Video recording committed (" + tmp.length() + " bytes, MP4)");
            discard();
        }

        public int setRecordSizeLimit(int size) throws MediaException { throw new MediaException("a size limit is not supported for video recording"); }

        public synchronized void reset() throws IOException { stopRecord(); discard(); }

        synchronized void abort() { stopRecord(); discard(); }

        private void discard() { if (tmp != null) { tmp.delete(); tmp = null; } }
    }
}
