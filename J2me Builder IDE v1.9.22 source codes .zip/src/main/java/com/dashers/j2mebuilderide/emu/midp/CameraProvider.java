package com.dashers.j2mebuilderide.emu.midp;

import java.io.IOException;

/** Camera of the host. The Android implementation lives in emu/android; tests and the "virtual camera" use {@link VirtualCamera}. */
public interface CameraProvider {
    interface Session extends FrameSource {
        void close();
    }
    String name();
    /**
     * Opens a camera and starts its preview. front = user-facing camera (used when the app asks for capture://devcam1).
     * wantW/wantH are hints (0 = any). Throws SecurityException when the user refuses the permission, IOException otherwise.
     */
    Session open(boolean front, int wantW, int wantH) throws IOException;
}
