package com.dashers.j2mebuilderide.emu.midp;

/** Host audio output. The Android front-end implements it; without one, playback is simulated (timing only). */
public interface Audio {
    interface Handle {
        /** loops: 1 = once, -1 = forever. volume 0..100. onEnd runs when the last loop finished (not on stop). */
        void start(int loops, int volume, Runnable onEnd);
        void stop();
        void setVolume(int volume);
        long durationMs();       // -1 if unknown
        long positionMs();
        void close();
    }
    Handle openPcm(short[] mono, int sampleRate) throws java.io.IOException;
    Handle openEncoded(byte[] data, String mimeType) throws java.io.IOException;
}
