package com.dashers.j2mebuilderide.emu.midp;

import java.util.ArrayList;
import java.util.Enumeration;

final class EventListImpl extends PimListImpl implements EventList {
    EventListImpl(Device d, PimData data, int mode, String name) { super(d, data, mode, name); }
    PimItemImpl newItem(PimRecord r, boolean modified) { return new EventImpl(this, r, modified); }
    public Event createEvent() { return (Event) newItem(new PimRecord(), false); }
    public Event importEvent(Event e) { return (Event) importItem(e); }
    public void removeEvent(Event e) throws PIMException { remove(e); }

    private static Long date(PimRecord r, int field) {
        ArrayList<PimRecord.Val> l = r.fields.get(Integer.valueOf(field));
        return l == null || l.isEmpty() ? null : (Long) l.get(0).v;
    }

    public Enumeration items(final int searchType, final long startDate, final long endDate, final boolean initialEventOnly) throws PIMException {
        if (searchType < STARTING || searchType > OCCURRING) throw new IllegalArgumentException("bad search type " + searchType);
        if (endDate < startDate) throw new IllegalArgumentException("endDate is before startDate");
        return select(new Filter() {
            public boolean ok(PimRecord r) {
                Long st = date(r, Event.START), en = date(r, Event.END);
                if (searchType == STARTING) return st != null && st.longValue() >= startDate && st.longValue() <= endDate;
                if (searchType == ENDING) return en != null && en.longValue() >= startDate && en.longValue() <= endDate;
                if (st == null && en == null) return false;
                long a = st != null ? st.longValue() : en.longValue();
                long b = en != null ? en.longValue() : a;
                if (a <= endDate && b >= startDate) return true;
                if (initialEventOnly || r.repeat == null || st == null) return false;
                return r.repeat.dates(a, startDate - (b - a), endDate).hasMoreElements();
            }
        });
    }

    public int[] getSupportedRepeatRuleFields(int frequency) {
        switch (frequency) {
            case RepeatRule.DAILY: return new int[]{RepeatRule.INTERVAL, RepeatRule.COUNT, RepeatRule.END};
            case RepeatRule.WEEKLY: return new int[]{RepeatRule.DAY_IN_WEEK, RepeatRule.INTERVAL, RepeatRule.COUNT, RepeatRule.END};
            case RepeatRule.MONTHLY: return new int[]{RepeatRule.DAY_IN_MONTH, RepeatRule.INTERVAL, RepeatRule.COUNT, RepeatRule.END};
            case RepeatRule.YEARLY: return new int[]{RepeatRule.MONTH_IN_YEAR, RepeatRule.DAY_IN_MONTH, RepeatRule.INTERVAL, RepeatRule.COUNT, RepeatRule.END};
            default: return null;
        }
    }
}
