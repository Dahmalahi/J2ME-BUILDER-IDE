package com.dashers.j2mebuilderide.emu.midp;

import java.util.ArrayList;
import java.util.List;

/** Shared storage and selection rules for List and ChoiceGroup. */
final class ChoiceModel {
    final int type;
    final List<String> strings = new ArrayList<String>();
    final List<Image> images = new ArrayList<Image>();
    final List<Boolean> sel = new ArrayList<Boolean>();
    int implicitIndex;

    ChoiceModel(int type) {
        if (type < Choice.EXCLUSIVE || type > Choice.POPUP) throw new IllegalArgumentException("choice type " + type);
        this.type = type;
    }

    private void idx(int i) { if (i < 0 || i >= strings.size()) throw new IndexOutOfBoundsException("index " + i); }
    boolean multiple() { return type == Choice.MULTIPLE; }

    int size() { return strings.size(); }
    String getString(int i) { idx(i); return strings.get(i); }
    Image getImage(int i) { idx(i); return images.get(i); }

    int append(String s, Image img) { insert(strings.size(), s, img); return strings.size() - 1; }
    void insert(int i, String s, Image img) {
        if (s == null) throw new NullPointerException();
        if (i < 0 || i > strings.size()) throw new IndexOutOfBoundsException("index " + i);
        boolean first = strings.isEmpty();
        strings.add(i, s); images.add(i, img); sel.add(i, Boolean.FALSE);
        if (first && !multiple()) { sel.set(0, Boolean.TRUE); implicitIndex = 0; }
        else if (!multiple() && i <= implicitIndex && strings.size() > 1) { implicitIndex++; }
    }
    void delete(int i) {
        idx(i);
        boolean was = sel.get(i).booleanValue();
        strings.remove(i); images.remove(i); sel.remove(i);
        if (!multiple() && !strings.isEmpty()) {
            if (was || implicitIndex >= strings.size() || implicitIndex > i) {
                implicitIndex = Math.min(Math.max(implicitIndex - (implicitIndex > i ? 1 : 0), 0), strings.size() - 1);
                for (int k = 0; k < sel.size(); k++) sel.set(k, Boolean.valueOf(k == implicitIndex));
            }
        }
    }
    void deleteAll() { strings.clear(); images.clear(); sel.clear(); implicitIndex = 0; }
    void set(int i, String s, Image img) { idx(i); if (s == null) throw new NullPointerException(); strings.set(i, s); images.set(i, img); }
    boolean isSelected(int i) { idx(i); return sel.get(i).booleanValue(); }
    int getSelectedIndex() {
        if (multiple()) return -1;
        for (int i = 0; i < sel.size(); i++) if (sel.get(i).booleanValue()) return i;
        return -1;
    }
    void setSelectedIndex(int i, boolean on) {
        idx(i);
        if (multiple()) { sel.set(i, Boolean.valueOf(on)); return; }
        if (!on) return;
        for (int k = 0; k < sel.size(); k++) sel.set(k, Boolean.valueOf(k == i));
        implicitIndex = i;
    }
    int getSelectedFlags(boolean[] out) {
        if (out.length < size()) throw new IllegalArgumentException("array too short");
        int n = 0;
        for (int i = 0; i < out.length; i++) {
            boolean v = i < size() && sel.get(i).booleanValue();
            out[i] = v;
            if (v) n++;
        }
        return n;
    }
    void setSelectedFlags(boolean[] in) {
        if (in.length < size()) throw new IllegalArgumentException("array too short");
        if (multiple()) { for (int i = 0; i < size(); i++) sel.set(i, Boolean.valueOf(in[i])); return; }
        for (int i = 0; i < size(); i++) if (in[i]) { setSelectedIndex(i, true); return; }
        if (size() > 0) setSelectedIndex(0, true);
    }
}
