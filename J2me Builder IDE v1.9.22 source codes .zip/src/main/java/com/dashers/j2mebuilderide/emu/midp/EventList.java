package com.dashers.j2mebuilderide.emu.midp;

public interface EventList extends PIMList {
    int STARTING = 0;
    int ENDING = 1;
    int OCCURRING = 2;
    Event createEvent();
    Event importEvent(Event a0);
    void removeEvent(Event a0) throws PIMException;
    java.util.Enumeration items(int a0, long a1, long a2, boolean a3) throws PIMException;
    int[] getSupportedRepeatRuleFields(int a0);
}
