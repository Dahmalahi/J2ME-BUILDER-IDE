package com.dashers.j2mebuilderide.emu.midp;

public interface ContactList extends PIMList {
    Contact createContact();
    Contact importContact(Contact a0);
    void removeContact(Contact a0) throws PIMException;
}
