package com.dashers.j2mebuilderide.emu.android;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.os.Handler;
import android.os.HandlerThread;

import com.dashers.j2mebuilderide.emu.midp.SensorProvider;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Phone sensors for javax.microedition.sensor: accelerometer, magnetic field, orientation (rotation vector, or accelerometer +
 * magnetometer), light and proximity, sampled at 50 Hz on a background thread. No permission is needed at this rate.
 * Needs a phone test.
 */
public final class AndroidSensors implements SensorProvider {
    private final android.hardware.SensorManager sm;
    private final HandlerThread thread;
    private final Handler handler;
    private final Map<Integer, Integer> refs = new HashMap<Integer, Integer>();
    private final Map<Integer, float[]> latest = new ConcurrentHashMap<Integer, float[]>();

    private final SensorEventListener listener = new SensorEventListener() {
        public void onSensorChanged(SensorEvent e) { latest.put(Integer.valueOf(e.sensor.getType()), e.values.clone()); }
        public void onAccuracyChanged(Sensor s, int accuracy) { }
    };

    public AndroidSensors(Context c) {
        sm = (android.hardware.SensorManager) c.getSystemService(Context.SENSOR_SERVICE);
        thread = new HandlerThread("emu-sensors");
        thread.start();
        handler = new Handler(thread.getLooper());
    }

    public String name() { return "phone sensors"; }

    private boolean present(int type) { return sm != null && sm.getDefaultSensor(type) != null; }

    private int[] types(String q) {
        if (q.equals("acceleration")) return new int[]{Sensor.TYPE_ACCELEROMETER};
        if (q.equals("magnetic_field")) return new int[]{Sensor.TYPE_MAGNETIC_FIELD};
        if (q.equals("orientation")) return present(Sensor.TYPE_ROTATION_VECTOR) ? new int[]{Sensor.TYPE_ROTATION_VECTOR} : new int[]{Sensor.TYPE_ACCELEROMETER, Sensor.TYPE_MAGNETIC_FIELD};
        if (q.equals("light")) return new int[]{Sensor.TYPE_LIGHT};
        if (q.equals("proximity")) return new int[]{Sensor.TYPE_PROXIMITY};
        return new int[0];
    }

    public boolean has(String q) {
        int[] t = types(q);
        if (t.length == 0) return false;
        for (int x : t) if (!present(x)) return false;
        return true;
    }

    public void acquire(String q) throws IOException {
        synchronized (refs) {
            for (int t : types(q)) {
                Integer n = refs.get(Integer.valueOf(t));
                if (n == null || n.intValue() == 0) {
                    Sensor s = sm.getDefaultSensor(t);
                    if (s == null || !sm.registerListener(listener, s, 20000, handler)) throw new IOException("the phone could not start the " + q + " sensor");
                    refs.put(Integer.valueOf(t), Integer.valueOf(1));
                } else refs.put(Integer.valueOf(t), Integer.valueOf(n.intValue() + 1));
            }
        }
    }

    public void release(String q) {
        synchronized (refs) {
            for (int t : types(q)) {
                Integer n = refs.get(Integer.valueOf(t));
                if (n == null) continue;
                if (n.intValue() <= 1) {
                    Sensor s = sm.getDefaultSensor(t);
                    if (s != null) sm.unregisterListener(listener, s);
                    refs.remove(Integer.valueOf(t));
                    latest.remove(Integer.valueOf(t));
                } else refs.put(Integer.valueOf(t), Integer.valueOf(n.intValue() - 1));
            }
        }
    }

    public double[] read(String q) {
        if (q.equals("acceleration")) { float[] v = latest.get(Integer.valueOf(Sensor.TYPE_ACCELEROMETER)); return v == null ? null : new double[]{v[0], v[1], v[2]}; }
        if (q.equals("magnetic_field")) { float[] v = latest.get(Integer.valueOf(Sensor.TYPE_MAGNETIC_FIELD)); return v == null ? null : new double[]{v[0] * 1e-6, v[1] * 1e-6, v[2] * 1e-6}; }
        if (q.equals("light")) { float[] v = latest.get(Integer.valueOf(Sensor.TYPE_LIGHT)); return v == null ? null : new double[]{v[0]}; }
        if (q.equals("proximity")) { float[] v = latest.get(Integer.valueOf(Sensor.TYPE_PROXIMITY)); return v == null ? null : new double[]{v[0] / 100.0}; }
        if (q.equals("orientation")) {
            float[] r = new float[9], o = new float[3];
            float[] rv = latest.get(Integer.valueOf(Sensor.TYPE_ROTATION_VECTOR));
            if (rv != null) android.hardware.SensorManager.getRotationMatrixFromVector(r, rv);
            else {
                float[] a = latest.get(Integer.valueOf(Sensor.TYPE_ACCELEROMETER)), m = latest.get(Integer.valueOf(Sensor.TYPE_MAGNETIC_FIELD));
                if (a == null || m == null || !android.hardware.SensorManager.getRotationMatrix(r, null, a, m)) return null;
            }
            android.hardware.SensorManager.getOrientation(r, o);
            return new double[]{(Math.toDegrees(o[0]) + 360) % 360, Math.toDegrees(o[1]), Math.toDegrees(o[2])};
        }
        return null;
    }

    /** Stops every sensor and the sampling thread (activity closing). */
    public void close() {
        synchronized (refs) {
            sm.unregisterListener(listener);
            refs.clear();
        }
        thread.quitSafely();
    }
}
