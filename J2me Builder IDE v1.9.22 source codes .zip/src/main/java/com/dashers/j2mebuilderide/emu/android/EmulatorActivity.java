package com.dashers.j2mebuilderide.emu.android;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.InputType;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.dashers.j2mebuilderide.emu.ConsoleLog;
import com.dashers.j2mebuilderide.emu.EmuException;
import com.dashers.j2mebuilderide.emu.EmuSession;
import com.dashers.j2mebuilderide.emu.KeyMap;
import com.dashers.j2mebuilderide.emu.MidletInfo;
import com.dashers.j2mebuilderide.emu.midp.Device;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Experimental in-app emulator screen. Runs the last built jar in the built-in runtime, shows its screen,
 * and offers device profiles, rotation, keypad / d-pad / soft keys, touch, external keyboard with an editable
 * key map, screenshots, FPS, saved-data tools and a console that is separate from the build console.
 * The runtime runs in this process; MIDlet crashes are caught and shown in the console.
 */
public class EmulatorActivity extends Activity {
    public static final String EXTRA_JAR = "jar";
    public static final String EXTRA_JAD = "jad";

    private static final int[][] PROFILES = {{128, 160}, {176, 208}, {240, 320}, {320, 480}};

    private EmulatorView view;
    private TextView statusChip, titleView, subtitleView, btnPause, btnLog, btnKeys;
    private LinearLayout softRow, keyPanel;
    private LogPanel log;
    private static final String SIZE_KEY = "size_";
    private boolean logBig;
    private EmuSession session;
    private byte[] jar;
    private String jad;
    private boolean autoPaused;
    private final android.os.Handler ui = new android.os.Handler(android.os.Looper.getMainLooper());
    private SplashOverlay splash;
    private LinearLayout rootView, headView, ctlView;
    private TextView btnStop, btnRestart;
    private final java.util.HashMap<View, int[]> keyBase = new java.util.HashMap<View, int[]>();
    private android.graphics.Bitmap wallpaper;
    private boolean logVisible = false;     // the log opens on demand (or by itself on a crash): the game comes first
    private SharedPreferences prefs;
    private volatile boolean usedNative;
    private int screenW = 240, screenH = 320;
    private boolean landscape;
    private KeyMap keyMap;
    private int capturingFor = KeyMap.NONE;
    private int lastFps = -1;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("builtin_emulator", MODE_PRIVATE);
        Ui.configure(prefs);
        screenW = prefs.getInt("w", 240);
        screenH = prefs.getInt("h", 320);
        landscape = prefs.getBoolean("landscape", false);
        keyMap = KeyMap.parse(prefs.getString("keymap", ""));
        buildUi();
        String jp = getIntent().getStringExtra(EXTRA_JAR);
        String dp = getIntent().getStringExtra(EXTRA_JAD);
        if (jp == null) { appendLine(ConsoleLog.ERROR, "No jar was given to the emulator."); return; }
        try {
            jar = readFile(new File(jp));
            jad = dp == null || !new File(dp).exists() ? null : new String(readFile(new File(dp)), "UTF-8");
        } catch (IOException e) {
            appendLine(ConsoleLog.ERROR, "Cannot read " + jp + ": " + e.getMessage());
            return;
        }
        launch();
        ui.postDelayed(fpsTick, 1000);
    }

    private final Runnable fpsTick = new Runnable() {
        public void run() {
            EmuSession s = session;
            if (s != null) {
                int f = s.fps();
                if (f != lastFps) { lastFps = f; showState(s, s.state()); }
            }
            ui.postDelayed(this, 1000);
        }
    };

    private static byte[] readFile(File f) throws IOException {
        FileInputStream in = new FileInputStream(f);
        try {
            ByteArrayOutputStream o = new ByteArrayOutputStream();
            byte[] t = new byte[8192];
            int n;
            while ((n = in.read(t)) > 0) o.write(t, 0, n);
            return o.toByteArray();
        } finally { in.close(); }
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private LinearLayout row() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER);
        return r;
    }

    private TextView pill(String label, int style, View.OnClickListener l) { return Ui.pill(this, label, style, l); }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        wallpaper = Ui.loadWallpaper(this);
        rootView = root;
        applyBackdrop();
        root.setPadding(dp(8), dp(6), dp(8), dp(6));
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG_BOTTOM);

        // header: app name + engine on the left, state chip and the menu button on the right
        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setBackground(Ui.glassPanel(this, 100));
        headView = head;
        head.setPadding(dp(18), dp(6), dp(8), dp(6));
        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        titleView = new TextView(this);
        titleView.setText("Emulator");
        titleView.setTextColor(Ui.TEXT);
        titleView.setTextSize(17);
        titleView.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        titleView.setSingleLine(true);
        titleView.setEllipsize(android.text.TextUtils.TruncateAt.END);
        subtitleView = new TextView(this);
        subtitleView.setText("experimental built-in runtime");
        subtitleView.setTextColor(Ui.MUTED);
        subtitleView.setTextSize(11);
        subtitleView.setSingleLine(true);
        subtitleView.setEllipsize(android.text.TextUtils.TruncateAt.END);
        titles.addView(titleView);
        titles.addView(subtitleView);
        head.addView(titles, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        statusChip = Ui.chip(this, "starting\u2026", null);
        statusChip.setClickable(false);
        head.addView(statusChip);
        TextView more = Ui.roundKey(this, "\u22EF", 36);
        more.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { showMore(); } });
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        mp.leftMargin = dp(8);
        head.addView(more, mp);
        root.addView(head);

        // the phone screen, drawn directly on the window background
        FrameLayout card = new FrameLayout(this);
        card.setPadding(0, 0, 0, 0);        // the screen only: no card, frame or placeholder around it
        view = new EmulatorView(this);
        view.setSmooth(prefs.getBoolean("smooth", false));
        view.setScaleMode(prefs.getInt("scale_mode", 0));
        view.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent e) {
                EmuSession s = session;
                if (s == null) return false;
                int[] p = view.toScreen(e.getX(), e.getY());
                if (p == null) return true;
                int a = e.getActionMasked();
                if (a == MotionEvent.ACTION_DOWN) s.pointer(0, p[0], p[1]);
                else if (a == MotionEvent.ACTION_MOVE) s.pointer(2, p[0], p[1]);
                else if (a == MotionEvent.ACTION_UP) s.pointer(1, p[0], p[1]);
                return true;
            }
        });
        card.addView(view, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        cp.topMargin = dp(6);
        cp.bottomMargin = dp(4);
        card.setMinimumHeight(dp(120));
        root.addView(card, cp);

        softRow = row();
        softRow.setVisibility(View.GONE);
        root.addView(softRow, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // key pad (hidden until the "Keys" pill is pressed): soft keys, d-pad, digits
        keyPanel = new LinearLayout(this);
        keyPanel.setOrientation(LinearLayout.VERTICAL);
        keyPanel.setBackground(Ui.glassPanel(this, 26));
        keyPanel.setPadding(dp(8), dp(6), dp(8), dp(6));
        keyPanel.setVisibility(prefs.getBoolean("keypad", false) ? View.VISIBLE : View.GONE);
        LinearLayout softKeys = row();
        softKeys.addView(keyPill("\u25C2 Soft", KeyMap.SOFT1), Ui.weight(this, 36, 2));
        softKeys.addView(keyPill("Soft \u25B8", KeyMap.SOFT2), Ui.weight(this, 36, 2));
        keyPanel.addView(softKeys);
        LinearLayout both = row();
        LinearLayout dpad = new LinearLayout(this);
        dpad.setOrientation(LinearLayout.VERTICAL);
        dpad.setGravity(Gravity.CENTER);
        LinearLayout r1 = row(), r2 = row(), r3 = row();
        r1.addView(spacer()); r1.addView(roundKey("\u25B2", KeyMap.UP)); r1.addView(spacer());
        r2.addView(roundKey("\u25C0", KeyMap.LEFT)); r2.addView(roundKey("OK", KeyMap.SELECT)); r2.addView(roundKey("\u25B6", KeyMap.RIGHT));
        r3.addView(spacer()); r3.addView(roundKey("\u25BC", KeyMap.DOWN)); r3.addView(spacer());
        dpad.addView(r1); dpad.addView(r2); dpad.addView(r3);
        LinearLayout pad = new LinearLayout(this);
        pad.setOrientation(LinearLayout.VERTICAL);
        int[][] rows = {{49, 50, 51}, {52, 53, 54}, {55, 56, 57}, {42, 48, 35}};
        for (int[] rr : rows) {
            LinearLayout pr = row();
            for (int k : rr) pr.addView(keyPill(KeyMap.nameOf(k), k), Ui.weight(this, 34, 2));
            pad.addView(pr);
        }
        both.addView(dpad, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        both.addView(pad, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        keyPanel.addView(both);
        LinearLayout.LayoutParams kpp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        kpp.bottomMargin = dp(6);
        root.addView(keyPanel, kpp);

        // control pills
        LinearLayout ctl = row();
        ctl.setBackground(Ui.glassPanel(this, 100));
        ctlView = ctl;
        ctl.setPadding(dp(6), dp(4), dp(6), dp(4));
        btnPause = pill("Pause", Ui.PRIMARY, new View.OnClickListener() { public void onClick(View v) { togglePause(); } });
        ctl.addView(btnPause, Ui.weight(this, 40, 2));
        btnStop = pill("Stop", Ui.DANGER, new View.OnClickListener() { public void onClick(View v) { stopAsync(null); } });
        ctl.addView(btnStop, Ui.weight(this, 40, 2));
        btnRestart = pill("Restart", Ui.NORMAL, new View.OnClickListener() {
            public void onClick(View v) { stopAsync(new Runnable() { public void run() { launch(); } }); }
        });
        ctl.addView(btnRestart, Ui.weight(this, 40, 2));
        btnKeys = pill("Keys", Ui.NORMAL, new View.OnClickListener() {
            public void onClick(View v) {
                boolean show = keyPanel.getVisibility() != View.VISIBLE;
                keyPanel.setVisibility(show ? View.VISIBLE : View.GONE);
                btnKeys.setSelected(show);
                prefs.edit().putBoolean("keypad", show).apply();
            }
        });
        btnKeys.setSelected(keyPanel.getVisibility() == View.VISIBLE);
        ctl.addView(btnKeys, Ui.weight(this, 40, 2));
        btnLog = pill("Log", Ui.NORMAL, new View.OnClickListener() { public void onClick(View v) { showLog(!logVisible); } });
        btnLog.setSelected(false);
        ctl.addView(btnLog, Ui.weight(this, 40, 2));
        root.addView(ctl, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // log card
        log = new LogPanel(this, new LogPanel.Host() {
            public void copyText(String text) {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm != null) { cm.setPrimaryClip(ClipData.newPlainText("emulator log", text)); Toast.makeText(EmulatorActivity.this, "Log copied", Toast.LENGTH_SHORT).show(); }
            }
            public void sizeChanged(boolean big) { logBig = big; applyLogHeight(); }
            public void countsChanged(final int errors, final int warnings) {
                ui.post(new Runnable() { public void run() { if (btnLog != null) btnLog.setText(errors > 0 ? "Log \u00B7 " + errors + "!" : warnings > 0 ? "Log \u00B7 " + warnings : "Log"); } });
            }
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(170));
        lp.topMargin = dp(6);
        root.addView(log.view(), lp);
        log.view().setVisibility(View.GONE);      // hidden at launch: only the game and the buttons; the Log pill opens it
        FrameLayout stack = new FrameLayout(this);
        stack.addView(root, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        splash = new SplashOverlay(this, wallpaper);
        stack.addView(splash.view, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(stack);
        applyChrome();
        ui.postDelayed(new Runnable() { public void run() { hideSplash(); } }, 9000);     // never stays up if no frame ever comes
    }

    private View spacer() {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(dp(52), dp(40)));
        return v;
    }

    private void hideSplash() {
        if (splash != null) splash.hide();
    }

    /** Hides the status and navigation bars so the game gets the whole screen (swipe from an edge to show them). */
    private void applyFullscreen() {
        if (!prefs.getBoolean("fullscreen", true)) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
            return;
        }
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) applyFullscreen();
    }

    private void showLog(boolean show) {
        logVisible = show;
        log.view().setVisibility(show ? View.VISIBLE : View.GONE);
        btnLog.setSelected(show);
    }

    private void applyLogHeight() {
        ViewGroup.LayoutParams p = log.view().getLayoutParams();
        p.height = dp(logBig ? 340 : 170);
        log.view().setLayoutParams(p);
    }

    private TextView roundKey(String label, int code) {
        TextView t = Ui.roundKey(this, label, 44);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(44), dp(40));
        p.setMargins(dp(4), dp(3), dp(4), dp(3));
        t.setLayoutParams(p);
        attachKey(t, code);
        return t;
    }

    private TextView keyPill(String label, int code) {
        TextView t = pill(label, Ui.NORMAL, null);
        t.setPadding(0, 0, 0, 0);
        t.setMinHeight(0);
        t.setMinimumHeight(0);
        attachKey(t, code);
        return t;
    }

    /** On-screen key: press on touch down, release on up, repeat while held. */
    private void attachKey(final TextView x, final int code) {
        final Runnable[] repeat = new Runnable[1];
        x.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent e) {
                final EmuSession s = session;
                if (s == null) return false;
                int a = e.getActionMasked();
                if (a == MotionEvent.ACTION_DOWN) {
                    v.setPressed(true);
                    if (prefs.getBoolean("emu_haptic", false)) v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
                    s.key(0, code);
                    repeat[0] = new Runnable() { public void run() { s.key(2, code); ui.postDelayed(this, 90); } };
                    ui.postDelayed(repeat[0], 400);
                    return true;
                }
                if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                    v.setPressed(false);
                    if (repeat[0] != null) { ui.removeCallbacks(repeat[0]); repeat[0] = null; }
                    s.key(1, code);
                }
                return true;
            }
        });
    }

    // ---- external keyboard with an editable map

    @Override public boolean onKeyDown(int keyCode, KeyEvent e) {
        if (tiltKey(keyCode, true)) return true;
        if (capturingFor != KeyMap.NONE) {
            if (keyCode == KeyEvent.KEYCODE_BACK) { capturingFor = KeyMap.NONE; return true; }
            keyMap.set(keyCode, capturingFor);
            prefs.edit().putString("keymap", keyMap.toString()).apply();
            Toast.makeText(this, KeyEvent.keyCodeToString(keyCode) + " → " + KeyMap.nameOf(capturingFor), Toast.LENGTH_SHORT).show();
            capturingFor = KeyMap.NONE;
            return true;
        }
        int m = keyCode == KeyEvent.KEYCODE_BACK ? KeyMap.NONE : keyMap.map(keyCode);
        EmuSession s = session;
        if (m != KeyMap.NONE && s != null) { s.key(e.getRepeatCount() > 0 ? 2 : 0, m); return true; }
        return super.onKeyDown(keyCode, e);
    }

    @Override public boolean onKeyUp(int keyCode, KeyEvent e) {
        if (tiltKey(keyCode, false)) return true;
        int m = keyCode == KeyEvent.KEYCODE_BACK ? KeyMap.NONE : keyMap.map(keyCode);
        EmuSession s = session;
        if (m != KeyMap.NONE && s != null) { s.key(1, m); return true; }
        return super.onKeyUp(keyCode, e);
    }

    // ---- console

    private void appendLine(int level, String text) { log.add(System.currentTimeMillis(), level, text); }

    private void setStatus(String text) { setStatus(text, Ui.MUTED); }

    private void setStatus(String text, int dot) {
        SpannableStringBuilder b = new SpannableStringBuilder("\u25CF ");
        b.setSpan(new ForegroundColorSpan(dot), 0, 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        b.append(text);
        statusChip.setText(b);
    }

    // ---- session

    private int curW() { return landscape ? Math.max(screenW, screenH) : Math.min(screenW, screenH); }
    private int curH() { return landscape ? Math.min(screenW, screenH) : Math.max(screenW, screenH); }

    private void launch() {
        final EmuSession s;
        try {
            s = new EmuSession(jar, jad, new AndroidPlatform(), curW(), curH());
        } catch (EmuException e) {
            appendLine(ConsoleLog.ERROR, "Cannot start: " + e.getMessage());
            showLog(true);
            setStatus("not started", Ui.ERR);
            hideSplash();
            view.setMessage("Could not start - see the log");
            return;
        }
        session = s;
        applySuiteSize(s);
        titleView.setText(s.profile().name.length() > 0 ? s.profile().name : "Emulator");
        if (splash != null) splash.setTitle(s.profile().name);
        subtitleView.setText((s.profile().vendor.length() > 0 ? s.profile().vendor + "  \u00B7  " : "") + "starting");
        s.setStorageDir(new File(new File(getFilesDir(), "emu_rms"), s.suiteId()));
        s.setAudio(new AndroidAudio(this));
        s.setCamera(makeCamera());
        s.setMic(makeMic());
        androidSms = new AndroidSms(this, prefs.getBoolean("sms_real", false));
        s.setSms(androidSms);
        androidPim = new AndroidPimHost(this, prefs.getBoolean("pim_real", false));
        s.setPimHost(androidPim);
        s.setSensors(makeSensors());
        androidBt = new AndroidBluetooth(this, prefs.getBoolean("bt_real", false));
        s.setBluetooth(androidBt);
        s.console().add(ConsoleLog.INFO, "Camera: " + cameraModeName() + "; microphone: " + (prefs.getBoolean("mic_test", false) ? "test tone" : "phone microphone") + "; SMS: " + androidSms.name() + "; sensors: " + sensorModeName() + "; Bluetooth: " + androidBt.name() + "; contacts/calendar: " + (androidPim.real() ? "real phone data, read-only" : "sandbox") + " (permissions are asked the first time a MIDlet uses them; change in More)");
        s.setFileRoot(fileRootFor(s));
        s.setNetworkEnabled(prefs.getBoolean("net", true));
        s.console().add(ConsoleLog.INFO, "Network access: " + (prefs.getBoolean("net", true) ? "ON (http, https, socket, ssl, serversocket, datagram)" : "OFF - switch it on in More > Network access"));          // OFF by default, per user decision
        if (prefs.getBoolean("hasloc", false))
            s.setSimulatedLocation(Double.parseDouble(prefs.getString("lat", "0")), Double.parseDouble(prefs.getString("lon", "0")), 0, 25);
        s.setTextInput(new Device.TextInput() {
            public void request(final String title, final String initial, final int max, final int constraints, final Callback cb) {
                ui.post(new Runnable() { public void run() { askText(title, initial, max, constraints, cb); } });
            }
        });
        s.console().setListener(new ConsoleLog.Listener() {
            public void onEntry(final ConsoleLog.Entry e) {
                ui.post(new Runnable() { public void run() { log.add(e.time, e.level, e.text); } });
            }
        });
        for (ConsoleLog.Entry e : s.console().snapshot()) log.add(e.time, e.level, e.text);
        s.setListener(new EmuSession.Listener() {
            public void onState(final EmuSession.State st) {
                ui.post(new Runnable() { public void run() { showState(s, st); } });
            }
            public void onFrame() {
                ui.post(new Runnable() {
                    public void run() {
                        if (s != session) return;
                        int[] wh = new int[2];
                        int[] px = s.frame(wh);
                        if (px != null) { view.setFrame(px, wh[0], wh[1]); hideSplash(); }
                        refreshSoftKeys(s);
                    }
                });
            }
        });
        view.clear();
        view.setMessage("Starting\u2026");
        final List<MidletInfo> ms = s.midlets();
        if (ms.size() == 1) { startEngine(s, 0); return; }
        String[] names = new String[ms.size()];
        for (int i = 0; i < names.length; i++) names[i] = ms.get(i).name;
        new Ui.Dlg(this).setTitle("Which MIDlet?").setItems(names, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface d, int which) { startEngine(s, which); }
        }).setOnCancelListener(new DialogInterface.OnCancelListener() {
            public void onCancel(DialogInterface d) { setStatus("not started"); }
        }).show();
    }

    /** Native engine (dex conversion, J2ME-Loader style) when enabled; falls back to the interpreter if conversion fails. */
    private void startEngine(final EmuSession s, final int idx) {
        if (!prefs.getBoolean("native", true)) { s.start(idx); return; }
        setStatus("converting\u2026", Ui.ACCENT);
        appendLine(ConsoleLog.INFO, "Converting the MIDlet for native execution (first run of this jar only)…");
        new Thread(null, new Runnable() {
            public void run() {
                com.dashers.j2mebuilderide.emu.nat.NativeLoader l = null;
                String err = null;
                try { l = AndroidNativeSupport.prepare(EmulatorActivity.this, jar); } catch (Throwable t) { err = String.valueOf(t); }
                final com.dashers.j2mebuilderide.emu.nat.NativeLoader fl = l;
                final String fe = err;
                ui.post(new Runnable() {
                    public void run() {
                        if (s != session) return;
                        if (fl != null) { s.setNativeLoader(fl); usedNative = true; }
                        else {
                            String m = "Native conversion failed (" + fe + "): using the slower interpreter instead";
                            appendLine(ConsoleLog.WARN, m);
                            s.console().add(ConsoleLog.WARN, m);   // also in the session console / copied report
                        }
                        s.start(idx);
                    }
                });
            }
        }, "dex-convert", 16L << 20).start();
    }

    /** file:///root1/ = shared storage J2MEBuilder/root1 when the app may write there, else a private folder. */
    private File fileRootFor(EmuSession s) {
        try {
            boolean ok;
            if (android.os.Build.VERSION.SDK_INT >= 30) {
                ok = (Boolean) android.os.Environment.class.getMethod("isExternalStorageManager").invoke(null);
            } else if (android.os.Build.VERSION.SDK_INT >= 23) {
                ok = checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == android.content.pm.PackageManager.PERMISSION_GRANTED;
            } else ok = true;
            if (ok) {
                File d = new File(android.os.Environment.getExternalStorageDirectory(), "J2MEBuilder/root1");
                if (d.isDirectory() || d.mkdirs()) { s.console().add(ConsoleLog.INFO, "file:///root1/ = " + d.getPath()); return d; }
            }
        } catch (Throwable t) { /* fall through */ }
        s.console().add(ConsoleLog.WARN, "Storage permission missing: file:///root1/ is private to the app. Grant file access to the IDE to use J2MEBuilder/root1.");
        return new File(new File(getFilesDir(), "emu_files"), s.suiteId());
    }

    private void askText(String title, String initial, final int max, int constraints, final Device.TextInput.Callback cb) {
        final EditText et = new EditText(this);
        et.setText(initial == null ? "" : initial);
        int c = constraints & 0xFFFF;
        int type = c == 2 ? InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_SIGNED
                : c == 5 ? InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED
                : c == 3 ? InputType.TYPE_CLASS_PHONE : c == 1 ? InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS | InputType.TYPE_CLASS_TEXT
                : InputType.TYPE_CLASS_TEXT;
        if ((constraints & 0x10000) != 0) type |= InputType.TYPE_TEXT_VARIATION_PASSWORD;
        et.setInputType(type);
        et.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(Math.max(1, max))});
        new Ui.Dlg(this).setTitle(title == null || title.length() == 0 ? "Enter text" : title).setView(et)
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) { cb.done(et.getText().toString()); }
                }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) { cb.done(null); }
                }).show();
    }

    private void showState(EmuSession s, EmuSession.State st) {
        if (s != session) return;
        int dot = st == EmuSession.State.ACTIVE ? Ui.OK : st == EmuSession.State.PAUSED ? Ui.WARN : st == EmuSession.State.CRASHED ? Ui.ERR : st == EmuSession.State.DESTROYED ? Ui.MUTED : Ui.ACCENT;
        String fps = st == EmuSession.State.ACTIVE ? "  \u00B7  " + s.fps() + " fps" : "";
        setStatus(st.name().toLowerCase() + "  \u00B7  " + curW() + "\u00D7" + curH() + (landscape ? " land." : "") + fps, dot);
        subtitleView.setText((s.profile().vendor.length() > 0 ? s.profile().vendor + "  \u00B7  " : "") + (s.isNative() ? "native engine" : "interpreter"));
        btnPause.setText(st == EmuSession.State.PAUSED ? "Resume" : "Pause");
        btnPause.setEnabled(st == EmuSession.State.ACTIVE || st == EmuSession.State.PAUSED);
        if (st == EmuSession.State.CRASHED) view.setMessage("The app crashed - see the log");
        else if (st == EmuSession.State.DESTROYED) view.setMessage("The app has ended");
        if ((st == EmuSession.State.CRASHED || st == EmuSession.State.DESTROYED) && s.diagnostics().hasProblems()) {
            hideSplash();
            showLog(true);
            log.showAnalysis();
        }
    }

    private void refreshSoftKeys(final EmuSession s) {
        List<String> labels = s.commandLabels();
        softRow.removeAllViews();
        softRow.setVisibility(labels.isEmpty() ? View.GONE : View.VISIBLE);
        for (int i = 0; i < labels.size() && i < 4; i++) {
            final int idx = i;
            softRow.addView(pill(labels.get(i), Ui.NORMAL, new View.OnClickListener() { public void onClick(View v) { s.command(idx); } }), Ui.weight(this, 38, 2));
        }
    }

    private void togglePause() {
        EmuSession s = session;
        if (s == null) return;
        autoPaused = false;
        if (s.state() == EmuSession.State.ACTIVE) s.pause(); else s.resume();
    }

    /** stop() can wait up to ~2 s, so it never runs on the UI thread. */
    private void stopAsync(final Runnable then) {
        final EmuSession s = session;
        if (s == null) { if (then != null) then.run(); return; }
        new Thread(new Runnable() {
            public void run() {
                try { s.stop(); } catch (Throwable t) { /* contained: never crash the IDE */ }
                if (then != null) ui.post(then);
            }
        }, "emu-stop").start();
    }

    // ---- "More" menu

    private void showMore() {
        final boolean net = prefs.getBoolean("net", true), nat = prefs.getBoolean("native", true);
        final String[] labels = {"Analysis report", "App info", "Screen size", "Rotate", "Smooth scaling", "Key mapping", "Screenshot",
                "Saved data (RMS)", "Copy full report", "Network access", "Simulated location", "Supported APIs", "Engine", "Camera", "Microphone", "SMS", "Contacts & calendar", "Sensors", "Bluetooth", "Customize look & controls", "Screen scaling", "Full screen", "Clear log"};
        final String[] values = {"", "", curW() + "\u00D7" + curH(), landscape ? "landscape" : "portrait", prefs.getBoolean("smooth", false) ? "ON" : "OFF",
                "", "", "", "", net ? "ON" : "OFF", "", "", nat ? "Native" : "Interpreter", cameraModeName(), prefs.getBoolean("mic_test", false) ? "test tone" : "phone", prefs.getBoolean("sms_real", false) ? "real (asks)" : "simulated", prefs.getBoolean("pim_real", false) ? "real, read-only" : "sandbox", sensorModeName(), prefs.getBoolean("bt_real", false) ? "real (asks)" : "simulated",
                "",
                new String[]{"Fill", "Whole numbers", "Stretch"}[Math.max(0, Math.min(2, prefs.getInt("scale_mode", 0)))],
                prefs.getBoolean("fullscreen", true) ? "ON" : "OFF", ""};
        Ui.sheet(this, "Emulator", labels, values, new Ui.Pick() {
            public void pick(int which) {
                switch (which) {
                    case 0: analysisDialog(); break;
                    case 1: appInfoDialog(); break;
                    case 2: pickSize(); break;
                    case 3: landscape = !landscape; applySize(); break;
                    case 4:
                        boolean on = !prefs.getBoolean("smooth", false);
                        prefs.edit().putBoolean("smooth", on).apply();
                        view.setSmooth(on);
                        break;
                    case 5: keyMapDialog(); break;
                    case 6: screenshot(); break;
                    case 7: dataDialog(); break;
                    case 8: copyReport(); break;
                    case 9: toggleNetwork(); break;
                    case 10: locationDialog(); break;
                    case 11:
                        new Ui.Dlg(EmulatorActivity.this).setTitle("Supported APIs")
                                .setMessage(com.dashers.j2mebuilderide.emu.Capabilities.report()).setPositiveButton("OK", null).show();
                        break;
                    case 12:
                        prefs.edit().putBoolean("native", !prefs.getBoolean("native", true)).apply();
                        Toast.makeText(EmulatorActivity.this, "Engine changes at the next Restart", Toast.LENGTH_SHORT).show();
                        break;
                    case 13: cameraDialog(); break;
                    case 14: micDialog(); break;
                    case 15: smsDialog(); break;
                    case 16: pimDialog(); break;
                    case 17: sensorDialog(); break;
                    case 18: btDialog(); break;
                    case 19: customizeDialog(); break;
                    case 20: scaleDialog(); break;
                    case 21:
                        prefs.edit().putBoolean("fullscreen", !prefs.getBoolean("fullscreen", true)).apply();
                        applyFullscreen();
                        break;
                    default: log.clear(); break;
                }
            }
        }).show();
    }

    // ------------------------------------------------------------------
    // customisation: everything here applies live and is remembered
    // ------------------------------------------------------------------

    private void applyBackdrop() {
        if (rootView == null) return;
        rootView.setBackground(Ui.backdropStyle == 0 && wallpaper != null ? Ui.wallpaperDrawable(wallpaper) : Ui.backdrop());
    }

    private void applyLook() {
        if (view == null) return;
        int fr = prefs.getInt("emu_frame", 1);                 // 0 square, 1 rounded, 2 rounded + accent glow
        int[] bright = {80, 100, 120, 140};
        view.setLook(fr == 0 ? 0 : 14, fr == 2, Ui.ACCENT, prefs.getBoolean("emu_lcd", false),
                bright[Math.max(0, Math.min(3, prefs.getInt("emu_bright", 1)))]);
    }

    private void scaleKeys(ViewGroup g, float f) {
        for (int i = 0; i < g.getChildCount(); i++) {
            View c = g.getChildAt(i);
            ViewGroup.LayoutParams lp = c.getLayoutParams();
            if (lp != null && (lp.width > 0 || lp.height > 0)) {
                int[] base = keyBase.get(c);
                if (base == null) { base = new int[]{lp.width, lp.height}; keyBase.put(c, base); }
                if (base[0] > 0) lp.width = Math.round(base[0] * f);
                if (base[1] > 0) lp.height = Math.round(base[1] * f);
                c.setLayoutParams(lp);
            }
            if (c instanceof ViewGroup) scaleKeys((ViewGroup) c, f);
        }
    }

    /** Re-applies colours, glass, sizes and which buttons are shown from the saved choices. */
    private void applyChrome() {
        Ui.configure(prefs);
        applyBackdrop();
        if (headView != null) headView.setBackground(Ui.glassPanel(this, 100));
        if (ctlView != null) ctlView.setBackground(Ui.glassPanel(this, 100));
        if (keyPanel != null) keyPanel.setBackground(Ui.glassPanel(this, 26));
        if (log != null) log.view().setBackground(Ui.glassPanel(this, 22));
        if (rootView != null) Ui.restyle(rootView);
        applyLook();
        int[] heights = {34, 40, 48};
        int bh = heights[Math.max(0, Math.min(2, prefs.getInt("emu_btn", 1)))];
        if (ctlView != null) {
            for (int i = 0; i < ctlView.getChildCount(); i++) {
                View c = ctlView.getChildAt(i);
                ViewGroup.LayoutParams lp = c.getLayoutParams();
                if (lp != null) { lp.height = dp(bh); c.setLayoutParams(lp); }
            }
        }
        if (btnPause != null) btnPause.setVisibility(prefs.getBoolean("show_pause", true) ? View.VISIBLE : View.GONE);
        if (btnRestart != null) btnRestart.setVisibility(prefs.getBoolean("show_restart", true) ? View.VISIBLE : View.GONE);
        if (btnKeys != null) {
            boolean keysOn = prefs.getBoolean("show_keys", true);
            btnKeys.setVisibility(keysOn ? View.VISIBLE : View.GONE);
            if (!keysOn && keyPanel != null) keyPanel.setVisibility(View.GONE);
        }
        float[] ks = {0.85f, 1f, 1.2f};
        if (keyPanel != null) scaleKeys(keyPanel, ks[Math.max(0, Math.min(2, prefs.getInt("emu_keys", 1)))]);
    }

    private interface Pick { void pick(int i); }

    private TextView sectionTitle(String t) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextColor(Ui.MUTED);
        v.setTextSize(12);
        v.setTypeface(Typeface.DEFAULT_BOLD);
        v.setPadding(dp(2), dp(14), 0, dp(6));
        return v;
    }

    /** A row of exclusive pills; the chosen one is highlighted and cb is called with its index. */
    private View optionRow(String[] names, int selected, final Pick cb) {
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this);
        final ArrayList<TextView> pills = new ArrayList<TextView>();
        for (int i = 0; i < names.length; i++) {
            final int idx = i;
            TextView p = Ui.chip(this, names[i], new View.OnClickListener() {
                public void onClick(View v) {
                    for (int j = 0; j < pills.size(); j++) pills.get(j).setSelected(j == idx);
                    cb.pick(idx);
                }
            });
            p.setSelected(i == selected);
            pills.add(p);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.rightMargin = dp(6);
            row.addView(p, lp);
        }
        hs.addView(row);
        return hs;
    }

    private TextView toggleChip(String label, final String key, boolean def) {
        final TextView p = Ui.chip(this, label, null);
        p.setSelected(prefs.getBoolean(key, def));
        p.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                boolean now = !prefs.getBoolean(key, p.isSelected());
                prefs.edit().putBoolean(key, now).apply();
                p.setSelected(now);
                applyChrome();
            }
        });
        return p;
    }

    private void customizeDialog() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(2), dp(20), dp(6));

        // accent colour: round swatches
        box.addView(sectionTitle("Accent color"));
        final int[] accents = {0xFFFF6FA8, 0xFFFFA24C, 0xFFFFD166, 0xFF4FE3B0, 0xFF40C8E0, 0xFF6FA8FF, 0xFFB58CFF, 0xFFFF5470};
        HorizontalScrollView ahs = new HorizontalScrollView(this);
        ahs.setHorizontalScrollBarEnabled(false);
        LinearLayout arow = new LinearLayout(this);
        final ArrayList<View> dots = new ArrayList<View>();
        for (int i = 0; i < accents.length; i++) {
            final int col = accents[i];
            View dot = new View(this);
            dot.setClickable(true);
            dots.add(dot);
            dot.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    prefs.edit().putInt("emu_accent", col).apply();
                    applyChrome();
                    for (int j = 0; j < dots.size(); j++) {
                        boolean on = accents[j] == col;
                        dots.get(j).setBackground(Ui.shape(accents[j], 2000f, on ? 0xFFFFFFFF : 0x00000000, on ? dp(3) : 0));
                    }
                }
            });
            boolean on = prefs.getInt("emu_accent", 0xFFFF6FA8) == col;
            dot.setBackground(Ui.shape(col, 2000f, on ? 0xFFFFFFFF : 0x00000000, on ? dp(3) : 0));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(34), dp(34));
            lp.rightMargin = dp(10);
            arow.addView(dot, lp);
        }
        ahs.addView(arow);
        box.addView(ahs);

        box.addView(sectionTitle("Background"));
        box.addView(optionRow(new String[]{"Auto", "Sunset", "Night", "Black"}, Math.max(0, Math.min(3, prefs.getInt("emu_backdrop", 0))), new Pick() {
            public void pick(int i) { prefs.edit().putInt("emu_backdrop", i).apply(); applyChrome(); }
        }));
        box.addView(sectionTitle("Glass strength"));
        box.addView(optionRow(new String[]{"Light", "Medium", "Strong"}, Math.max(0, Math.min(2, prefs.getInt("emu_glass", 1))), new Pick() {
            public void pick(int i) { prefs.edit().putInt("emu_glass", i).apply(); applyChrome(); }
        }));
        box.addView(sectionTitle("Screen frame"));
        box.addView(optionRow(new String[]{"Square", "Rounded", "Rounded + glow"}, Math.max(0, Math.min(2, prefs.getInt("emu_frame", 1))), new Pick() {
            public void pick(int i) { prefs.edit().putInt("emu_frame", i).apply(); applyChrome(); }
        }));
        box.addView(sectionTitle("Screen brightness"));
        box.addView(optionRow(new String[]{"Dim", "Normal", "Bright", "Extra bright"}, Math.max(0, Math.min(3, prefs.getInt("emu_bright", 1))), new Pick() {
            public void pick(int i) { prefs.edit().putInt("emu_bright", i).apply(); applyChrome(); }
        }));
        box.addView(sectionTitle("Button size"));
        box.addView(optionRow(new String[]{"Small", "Normal", "Large"}, Math.max(0, Math.min(2, prefs.getInt("emu_btn", 1))), new Pick() {
            public void pick(int i) { prefs.edit().putInt("emu_btn", i).apply(); applyChrome(); }
        }));
        box.addView(sectionTitle("On-screen keypad size"));
        box.addView(optionRow(new String[]{"Small", "Normal", "Large"}, Math.max(0, Math.min(2, prefs.getInt("emu_keys", 1))), new Pick() {
            public void pick(int i) { prefs.edit().putInt("emu_keys", i).apply(); applyChrome(); }
        }));

        box.addView(sectionTitle("Buttons and effects"));
        HorizontalScrollView ths = new HorizontalScrollView(this);
        ths.setHorizontalScrollBarEnabled(false);
        LinearLayout trow = new LinearLayout(this);
        String[] labels = {"Pause button", "Restart button", "Keys button", "LCD pixel grid", "Key vibration"};
        String[] keys = {"show_pause", "show_restart", "show_keys", "emu_lcd", "emu_haptic"};
        boolean[] defs = {true, true, true, false, false};
        for (int i = 0; i < labels.length; i++) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.rightMargin = dp(6);
            trow.addView(toggleChip(labels[i], keys[i], defs[i]), lp);
        }
        ths.addView(trow);
        box.addView(ths);
        TextView note = new TextView(this);
        note.setText("Stop and Log always stay visible. Changes apply immediately and are remembered.");
        note.setTextColor(Ui.MUTED);
        note.setTextSize(11.5f);
        note.setPadding(dp(2), dp(12), 0, 0);
        box.addView(note);

        ScrollView sv = new ScrollView(this);
        sv.addView(box);
        new Ui.Dlg(this).setTitle("Customize").setView(sv)
            .setPositiveButton("Done", null)
            .setNeutralButton("Reset", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int w) {
                    prefs.edit().remove("emu_accent").remove("emu_backdrop").remove("emu_glass").remove("emu_frame").remove("emu_bright")
                        .remove("emu_btn").remove("emu_keys").remove("emu_lcd").remove("emu_haptic")
                        .remove("show_pause").remove("show_restart").remove("show_keys").apply();
                    applyChrome();
                }
            }).show();
    }

    private void scaleDialog() {
        final String[] names = {"Fill  (biggest, keeps the shape)", "Whole numbers  (crisp pixels, smaller)", "Stretch  (fills the whole area)"};
        new Ui.Dlg(this).setTitle("Screen scaling").setItems(names, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface d, int which) {
                prefs.edit().putInt("scale_mode", which).apply();
                view.setScaleMode(which);
            }
        }).show();
    }

    private void analysisDialog() {
        final EmuSession s = session;
        if (s == null) return;
        final String text = s.analysisReport();
        new Ui.Dlg(this).setTitle("What the emulator found").setMessage(text)
                .setPositiveButton("Close", null)
                .setNeutralButton("Copy", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) {
                        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                        if (cm != null) { cm.setPrimaryClip(ClipData.newPlainText("analysis", text)); Toast.makeText(EmulatorActivity.this, "Copied", Toast.LENGTH_SHORT).show(); }
                    }
                }).show();
    }

    private void appInfoDialog() {
        EmuSession s = session;
        if (s == null) return;
        StringBuilder sb = new StringBuilder();
        for (String l : s.profile().lines()) sb.append(l).append('\n');
        if (!s.profile().problems.isEmpty()) {
            sb.append("\nNot available in the emulator:\n");
            for (String p : s.profile().problems) sb.append("  - ").append(p).append('\n');
        }
        sb.append("\nManifest / JAD:\n");
        for (java.util.Map.Entry<String, String> e : s.properties().entrySet()) sb.append("  ").append(e.getKey()).append(": ").append(e.getValue()).append('\n');
        new Ui.Dlg(this).setTitle("App info").setMessage(sb.toString()).setPositiveButton("Close", null).show();
    }

    /** Screen size for this app: the size the user chose for it before, else the one it was designed for, else the last global choice. */
    private void applySuiteSize(EmuSession s) {
        String saved = prefs.getString(SIZE_KEY + s.suiteId(), null);
        int w = 0, h = 0;
        boolean land = false;
        String why = null;
        if (saved != null && saved.length() > 3) {
            try {
                String[] p = saved.substring(0, saved.length() - 1).split("x");
                w = Integer.parseInt(p[0]);
                h = Integer.parseInt(p[1]);
                land = saved.endsWith("L");
                why = "the size you chose for this app";
            } catch (RuntimeException e) { w = 0; }
        }
        if (w == 0 && s.profile().suggestedW > 0) {
            w = s.profile().suggestedW;
            h = s.profile().suggestedH;
            land = w > h;
            why = "the app was designed for it (" + s.profile().suggestedFrom + ")";
        }
        if (w > 0) {
            screenW = w;
            screenH = h;
            landscape = land;
            s.console().add(ConsoleLog.INFO, "Screen " + curW() + "x" + curH() + ": " + why + ". Change it in More > Screen size.");
        }
        s.resize(curW(), curH());
    }

    // ---- camera / microphone (capture:// in MIDlets)

    private static final int REQ_PICK_IMAGE = 4218;
    private AndroidSms androidSms;
    private AndroidPimHost androidPim;
    private AndroidSensors realSensors;
    private AndroidBluetooth androidBt;
    private final com.dashers.j2mebuilderide.emu.midp.SimulatedSensors simSensors = new com.dashers.j2mebuilderide.emu.midp.SimulatedSensors();
    private final double[] simAcc = {0, 0, 9.80665}, simOri = {0, 0, 0};
    private double simLight = 300, simProxCm = 5;
    private boolean tiltLeft, tiltRight, tiltUp, tiltDown;
    private AndroidCamera androidCam;

    private String cameraModeName() {
        String m = prefs.getString("cam", "real");
        return m.equals("test") ? "test pattern" : m.equals("image") ? "chosen picture" : "phone camera";
    }

    private com.dashers.j2mebuilderide.emu.midp.CameraProvider makeCamera() {
        String m = prefs.getString("cam", "real");
        if (m.equals("test")) return new com.dashers.j2mebuilderide.emu.midp.VirtualCamera();
        if (m.equals("image")) {
            int[] wh = new int[2];
            int[] px = loadStill(wh);
            if (px != null) return new com.dashers.j2mebuilderide.emu.midp.VirtualCamera(px, wh[0], wh[1]);
        }
        androidCam = new AndroidCamera(this, prefs.getInt("cam_zoom", 100), prefs.getBoolean("cam_torch", false));
        return androidCam;
    }

    private com.dashers.j2mebuilderide.emu.midp.MicProvider makeMic() {
        return prefs.getBoolean("mic_test", false) ? (com.dashers.j2mebuilderide.emu.midp.MicProvider) new com.dashers.j2mebuilderide.emu.midp.TestToneMic() : new AndroidMic(this);
    }

    private int[] loadStill(int[] whOut) {
        File f = new File(getFilesDir(), "cam_still.png");
        if (!f.exists()) return null;
        Bitmap b = android.graphics.BitmapFactory.decodeFile(f.getPath());
        if (b == null) return null;
        int w = b.getWidth(), h = b.getHeight();
        int[] px = new int[w * h];
        b.getPixels(px, 0, w, 0, 0, w, h);
        b.recycle();
        whOut[0] = w; whOut[1] = h;
        return px;
    }

    private void applyCameraChoice() {
        EmuSession s = session;
        if (s != null) s.setCamera(makeCamera());
        Toast.makeText(this, "Camera: " + cameraModeName() + " (used the next time a MIDlet opens the camera)", Toast.LENGTH_SHORT).show();
    }

    private void applyCameraTuning() {
        if (androidCam != null) androidCam.setTuning(prefs.getInt("cam_zoom", 100), prefs.getBoolean("cam_torch", false));
        Toast.makeText(this, "Flash light " + (prefs.getBoolean("cam_torch", false) ? "ON" : "OFF") + ", zoom " + prefs.getInt("cam_zoom", 100) + " % (phone camera only)", Toast.LENGTH_SHORT).show();
    }

    private void zoomDialog() {
        final int[] levels = {100, 150, 200, 300, 400};
        String[] names = new String[levels.length];
        for (int i = 0; i < levels.length; i++) names[i] = levels[i] + " %";
        new Ui.Dlg(this).setTitle("Camera zoom").setItems(names, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface d, int which) { prefs.edit().putInt("cam_zoom", levels[which]).apply(); applyCameraTuning(); }
        }).setNegativeButton("Close", null).show();
    }

    private void cameraDialog() {
        final String[] items = {"Phone camera", "Test pattern (no permission)", "Picture from gallery", "Flash light: " + (prefs.getBoolean("cam_torch", false) ? "ON" : "OFF"), "Zoom: " + prefs.getInt("cam_zoom", 100) + " %"};
        new Ui.Dlg(this).setTitle("Camera for MIDlets").setItems(items, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface d, int which) {
                if (which == 0) { prefs.edit().putString("cam", "real").apply(); applyCameraChoice(); }
                else if (which == 1) { prefs.edit().putString("cam", "test").apply(); applyCameraChoice(); }
                else if (which == 3) { prefs.edit().putBoolean("cam_torch", !prefs.getBoolean("cam_torch", false)).apply(); applyCameraTuning(); }
                else if (which == 4) zoomDialog();
                else {
                    android.content.Intent i = new android.content.Intent(android.content.Intent.ACTION_GET_CONTENT);
                    i.setType("image/" + "*");
                    try { startActivityForResult(i, REQ_PICK_IMAGE); }
                    catch (RuntimeException e) { Toast.makeText(EmulatorActivity.this, "No gallery app found", Toast.LENGTH_SHORT).show(); }
                }
            }
        }).setNegativeButton("Close", null).show();
    }

    private void btDialog() {
        final boolean real = prefs.getBoolean("bt_real", false);
        final String[] items = {real ? "Switch to simulated Bluetooth (a virtual echo device)" : "Switch to real Bluetooth (asks before it scans or connects)",
            "Simulated: a device connects to the MIDlet's service"};
        new Ui.Dlg(this).setTitle("Bluetooth for MIDlets: " + (real ? "real" : "simulated"))
                .setMessage("Simulated: one virtual device \"Emulator BT Echo\" sends back what the MIDlet writes; nothing leaves the phone. Real: serial-port (btspp://) connections with your paired devices; pairing and switching Bluetooth on are done in Android's settings.")
                .setItems(items, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int which) {
                        if (which == 0) {
                            prefs.edit().putBoolean("bt_real", !real).apply();
                            if (androidBt != null) androidBt.setReal(!real);
                            Toast.makeText(EmulatorActivity.this, !real ? "Real Bluetooth: you are asked before scans and connections" : "Simulated Bluetooth", Toast.LENGTH_SHORT).show();
                        } else {
                            boolean ok = androidBt != null && !prefs.getBoolean("bt_real", false) && androidBt.simulateIncoming(null);
                            Toast.makeText(EmulatorActivity.this, ok ? "A virtual device connected" : "No MIDlet service is waiting (simulated mode, open btspp://localhost:UUID first)", Toast.LENGTH_LONG).show();
                        }
                    }
                }).setNegativeButton("Close", null).show();
    }

    // ---- sensors (javax.microedition.sensor)

    private String sensorModeName() {
        String m = prefs.getString("sensor_mode", "real");
        return m.equals("sim") ? "simulated" : m.equals("keys") ? "simulated + arrow keys" : "phone sensors";
    }

    private com.dashers.j2mebuilderide.emu.midp.SensorProvider makeSensors() {
        if (prefs.getString("sensor_mode", "real").equals("real")) {
            if (realSensors == null) realSensors = new AndroidSensors(this);
            return realSensors;
        }
        applySim();
        return simSensors;
    }

    private void applySim() {
        simSensors.set("acceleration", simAcc[0], simAcc[1], simAcc[2]);
        simSensors.set("orientation", simOri[0], simOri[1], simOri[2]);
        simSensors.set("light", simLight);
        simSensors.set("proximity", simProxCm / 100.0);
    }

    private void setSensorMode(String mode) {
        prefs.edit().putString("sensor_mode", mode).apply();
        EmuSession s = session;
        if (s != null) s.setSensors(makeSensors());
        Toast.makeText(this, "Sensors: " + sensorModeName() + " (used by sensors a MIDlet opens from now on)", Toast.LENGTH_SHORT).show();
    }

    private void sensorDialog() {
        final String[] items = {"Phone sensors", "Simulated (sliders)", "Simulated + tilt with the arrow keys of a keyboard", "Sliders..."};
        new Ui.Dlg(this).setTitle("Sensors for MIDlets: " + sensorModeName()).setItems(items, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface d, int which) {
                if (which == 0) setSensorMode("real");
                else if (which == 1) setSensorMode("sim");
                else if (which == 2) setSensorMode("keys");
                else {
                    if (prefs.getString("sensor_mode", "real").equals("real")) setSensorMode("sim");
                    slidersDialog();
                }
            }
        }).setNegativeButton("Close", null).show();
    }

    private void addSlider(android.widget.LinearLayout box, final String label, final double min, final double max, final double step, double start, final SliderSink sink) {
        final android.widget.TextView t = new android.widget.TextView(this);
        final android.widget.SeekBar bar = new android.widget.SeekBar(this);
        bar.setMax((int) Math.round((max - min) / step));
        bar.setProgress((int) Math.round((start - min) / step));
        t.setText(label + ": " + (Math.round(start * 100) / 100.0));
        bar.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(android.widget.SeekBar b, int p, boolean user) {
                double v = min + p * step;
                t.setText(label + ": " + (Math.round(v * 100) / 100.0));
                sink.set(v);
                applySim();
            }
            public void onStartTrackingTouch(android.widget.SeekBar b) { }
            public void onStopTrackingTouch(android.widget.SeekBar b) { }
        });
        box.addView(t);
        box.addView(bar);
    }

    private interface SliderSink { void set(double v); }

    private void slidersDialog() {
        android.widget.ScrollView sv = new android.widget.ScrollView(this);
        android.widget.LinearLayout box = new android.widget.LinearLayout(this);
        box.setOrientation(android.widget.LinearLayout.VERTICAL);
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        box.setPadding(pad, pad / 2, pad, 0);
        sv.addView(box);
        addSlider(box, "Acceleration X (m/s2)", -20, 20, 0.1, simAcc[0], new SliderSink() { public void set(double v) { simAcc[0] = v; } });
        addSlider(box, "Acceleration Y (m/s2)", -20, 20, 0.1, simAcc[1], new SliderSink() { public void set(double v) { simAcc[1] = v; } });
        addSlider(box, "Acceleration Z (m/s2)", -20, 20, 0.1, simAcc[2], new SliderSink() { public void set(double v) { simAcc[2] = v; } });
        addSlider(box, "Azimuth (degrees)", 0, 360, 1, simOri[0], new SliderSink() { public void set(double v) { simOri[0] = v; } });
        addSlider(box, "Pitch (degrees)", -180, 180, 1, simOri[1], new SliderSink() { public void set(double v) { simOri[1] = v; } });
        addSlider(box, "Roll (degrees)", -90, 90, 1, simOri[2], new SliderSink() { public void set(double v) { simOri[2] = v; } });
        addSlider(box, "Light (lux)", 0, 10000, 10, simLight, new SliderSink() { public void set(double v) { simLight = v; } });
        addSlider(box, "Proximity (cm)", 0, 50, 1, simProxCm, new SliderSink() { public void set(double v) { simProxCm = v; } });
        new Ui.Dlg(this).setTitle("Simulated sensors").setView(sv).setPositiveButton("Done", null).show();
    }

    /** Arrow keys of an external keyboard tilt the simulated phone (mode "simulated + arrow keys"). */
    private boolean tiltKey(int keyCode, boolean down) {
        if (!prefs.getString("sensor_mode", "real").equals("keys")) return false;
        if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT) tiltLeft = down;
        else if (keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) tiltRight = down;
        else if (keyCode == KeyEvent.KEYCODE_DPAD_UP) tiltUp = down;
        else if (keyCode == KeyEvent.KEYCODE_DPAD_DOWN) tiltDown = down;
        else return false;
        simAcc[0] = tiltRight ? 6 : tiltLeft ? -6 : 0;
        simAcc[1] = tiltUp ? 6 : tiltDown ? -6 : 0;
        simAcc[2] = Math.sqrt(Math.max(0, 9.80665 * 9.80665 - simAcc[0] * simAcc[0] - simAcc[1] * simAcc[1]));
        applySim();
        return true;
    }

    private void pimDialog() {
        final boolean real = prefs.getBoolean("pim_real", false);
        final String[] items = {real ? "Use the sandbox (internal, default)" : "Show real phone contacts and calendar (read-only, asks first)"};
        new Ui.Dlg(this).setTitle("Contacts & calendar for MIDlets: " + (real ? "real, read-only" : "sandbox"))
                .setMessage("The sandbox is an address book, calendar and to-do list of its own that MIDlets may change. Real mode only reads your phone's data, after you allow it; to-do lists stay in the sandbox. Applies the next time a MIDlet starts.")
                .setItems(items, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int which) {
                        prefs.edit().putBoolean("pim_real", !real).apply();
                        if (androidPim != null) androidPim.setReal(!real);
                        Toast.makeText(EmulatorActivity.this, !real ? "Real phone data, read-only (next MIDlet start)" : "Sandbox (next MIDlet start)", Toast.LENGTH_SHORT).show();
                    }
                }).setNegativeButton("Close", null).show();
    }

    private void smsDialog() {
        final boolean real = prefs.getBoolean("sms_real", false);
        final String[] items = {real ? "Switch to simulated SMS (nothing is sent)" : "Switch to real SMS (asks before every message)", "Simulate an incoming SMS..."};
        new Ui.Dlg(this).setTitle("SMS for MIDlets: " + (real ? "real" : "simulated")).setItems(items, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface d, int which) {
                if (which == 0) {
                    prefs.edit().putBoolean("sms_real", !real).apply();
                    if (androidSms != null) androidSms.setReal(!real);
                    Toast.makeText(EmulatorActivity.this, !real ? "Real SMS: you are asked before every message" : "Simulated SMS: nothing is sent", Toast.LENGTH_SHORT).show();
                } else incomingSmsDialog();
            }
        }).setNegativeButton("Close", null).show();
    }

    private void incomingSmsDialog() {
        final android.widget.EditText from = new android.widget.EditText(this), port = new android.widget.EditText(this), text = new android.widget.EditText(this);
        from.setHint("From, e.g. +15551234567");
        from.setText("+15551234567");
        port.setHint("Port the MIDlet listens on, e.g. 5000");
        port.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        text.setHint("Text");
        android.widget.LinearLayout box = new android.widget.LinearLayout(this);
        box.setOrientation(android.widget.LinearLayout.VERTICAL);
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        box.setPadding(pad, pad / 2, pad, 0);
        box.addView(from);
        box.addView(port);
        box.addView(text);
        new Ui.Dlg(this).setTitle("Simulate an incoming SMS").setView(box)
                .setPositiveButton("Deliver", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) {
                        EmuSession s = session;
                        int p;
                        try { p = Integer.parseInt(port.getText().toString().trim()); } catch (NumberFormatException e) { Toast.makeText(EmulatorActivity.this, "Enter a port number", Toast.LENGTH_SHORT).show(); return; }
                        int n = s == null ? 0 : s.injectSms(from.getText().toString().trim(), p, text.getText().toString(), null);
                        Toast.makeText(EmulatorActivity.this, n > 0 ? "Delivered to the MIDlet" : "No MIDlet listens on port " + p + " (see the console)", Toast.LENGTH_LONG).show();
                    }
                }).setNegativeButton("Cancel", null).show();
    }

    private void micDialog() {
        final String[] items = {"Phone microphone", "Test tone (no permission)"};
        new Ui.Dlg(this).setTitle("Microphone for MIDlets").setItems(items, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface d, int which) {
                prefs.edit().putBoolean("mic_test", which == 1).apply();
                EmuSession s = session;
                if (s != null) s.setMic(makeMic());
                Toast.makeText(EmulatorActivity.this, "Microphone: " + items[which], Toast.LENGTH_SHORT).show();
            }
        }).setNegativeButton("Close", null).show();
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, android.content.Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_PICK_IMAGE || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        try {
            java.io.InputStream in = getContentResolver().openInputStream(data.getData());
            Bitmap b;
            try { b = android.graphics.BitmapFactory.decodeStream(in); } finally { if (in != null) in.close(); }
            if (b == null) throw new IOException("not a picture");
            int max = Math.max(b.getWidth(), b.getHeight());
            if (max > 640) {
                Bitmap sc = Bitmap.createScaledBitmap(b, Math.max(1, b.getWidth() * 640 / max), Math.max(1, b.getHeight() * 640 / max), true);
                b.recycle();
                b = sc;
            }
            FileOutputStream out = new FileOutputStream(new File(getFilesDir(), "cam_still.png"));
            try { b.compress(Bitmap.CompressFormat.PNG, 100, out); } finally { out.close(); }
            b.recycle();
            prefs.edit().putString("cam", "image").apply();
            applyCameraChoice();
        } catch (Exception e) {
            Toast.makeText(this, "Cannot use that picture: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        Permissions.onResult(requestCode);
    }

    private void toggleNetwork() {
        boolean on = !prefs.getBoolean("net", true);
        prefs.edit().putBoolean("net", on).apply();
        EmuSession s = session;
        if (s != null) s.setNetworkEnabled(on);
        Toast.makeText(this, on ? "Network ON: MIDlets can now reach the internet" : "Network OFF", Toast.LENGTH_SHORT).show();
    }

    private void locationDialog() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        final EditText la = new EditText(this), lo = new EditText(this);
        la.setHint("latitude, e.g. 48.8566"); lo.setHint("longitude, e.g. 2.3522");
        la.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
        lo.setInputType(la.getInputType());
        la.setText(prefs.getString("lat", "")); lo.setText(prefs.getString("lon", ""));
        l.addView(la); l.addView(lo);
        new Ui.Dlg(this).setTitle("Simulated location (no real GPS)").setView(l)
                .setPositiveButton("Set", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) {
                        try {
                            double a = Double.parseDouble(la.getText().toString().trim()), b = Double.parseDouble(lo.getText().toString().trim());
                            if (a < -90 || a > 90 || b < -180 || b >= 180) throw new NumberFormatException();
                            prefs.edit().putString("lat", String.valueOf(a)).putString("lon", String.valueOf(b)).putBoolean("hasloc", true).apply();
                            if (session != null) session.setSimulatedLocation(a, b, 0, 25);
                        } catch (NumberFormatException e) { Toast.makeText(EmulatorActivity.this, "Invalid coordinates", Toast.LENGTH_SHORT).show(); }
                    }
                })
                .setNegativeButton("Clear", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) { prefs.edit().putBoolean("hasloc", false).apply(); if (session != null) session.clearSimulatedLocation(); }
                }).show();
    }

    private void applySize() {
        SharedPreferences.Editor ed = prefs.edit().putInt("w", screenW).putInt("h", screenH).putBoolean("landscape", landscape);
        if (session != null) ed.putString(SIZE_KEY + session.suiteId(), screenW + "x" + screenH + (landscape ? "L" : "P"));
        ed.apply();
        EmuSession s = session;
        if (s != null) { s.resize(curW(), curH()); showState(s, s.state()); }
    }

    private void pickSize() {
        final EmuSession cs = session;
        final boolean hasOwn = cs != null && cs.profile().suggestedW > 0;
        String[] n = new String[PROFILES.length + (hasOwn ? 2 : 1)];
        for (int i = 0; i < PROFILES.length; i++) n[i] = PROFILES[i][0] + " × " + PROFILES[i][1];
        n[PROFILES.length] = "Custom…";
        if (hasOwn) n[PROFILES.length + 1] = "App's own size (" + cs.profile().suggestedW + " × " + cs.profile().suggestedH + ")";
        new Ui.Dlg(this).setTitle("Screen size (" + screenW + "×" + screenH + ")").setItems(n, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface d, int which) {
                if (which < PROFILES.length) { screenW = PROFILES[which][0]; screenH = PROFILES[which][1]; applySize(); }
                else if (which == PROFILES.length) customSize();
                else { screenW = cs.profile().suggestedW; screenH = cs.profile().suggestedH; landscape = screenW > screenH; applySize(); }
            }
        }).show();
    }

    private void customSize() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setPadding(dp(16), dp(8), dp(16), 0);
        final EditText w = new EditText(this), h = new EditText(this);
        w.setInputType(InputType.TYPE_CLASS_NUMBER); h.setInputType(InputType.TYPE_CLASS_NUMBER);
        w.setHint("width"); h.setHint("height");
        w.setText(String.valueOf(screenW)); h.setText(String.valueOf(screenH));
        l.addView(w, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        l.addView(h, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        new Ui.Dlg(this).setTitle("Custom size (16 – 1024)").setView(l)
                .setPositiveButton("Apply", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int x) {
                        try {
                            int a = Integer.parseInt(w.getText().toString().trim()), b = Integer.parseInt(h.getText().toString().trim());
                            if (a < 16 || b < 16 || a > 1024 || b > 1024) { Toast.makeText(EmulatorActivity.this, "Size must be 16–1024", Toast.LENGTH_SHORT).show(); return; }
                            screenW = a; screenH = b; applySize();
                        } catch (NumberFormatException e) { Toast.makeText(EmulatorActivity.this, "Not a number", Toast.LENGTH_SHORT).show(); }
                    }
                }).setNegativeButton("Cancel", null).show();
    }

    private void keyMapDialog() {
        final int[] codes = {KeyMap.UP, KeyMap.DOWN, KeyMap.LEFT, KeyMap.RIGHT, KeyMap.SELECT, KeyMap.SOFT1, KeyMap.SOFT2, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 42, 35};
        String[] n = new String[codes.length + 1];
        for (int i = 0; i < codes.length; i++) n[i] = KeyMap.nameOf(codes[i]);
        n[codes.length] = "Reset to defaults";
        new Ui.Dlg(this).setTitle("Pick the emulator key, then press a keyboard key").setItems(n, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface d, int which) {
                if (which == codes.length) {
                    keyMap.reset();
                    prefs.edit().remove("keymap").apply();
                    Toast.makeText(EmulatorActivity.this, "Key map reset", Toast.LENGTH_SHORT).show();
                } else {
                    capturingFor = codes[which];
                    Toast.makeText(EmulatorActivity.this, "Press a key for \"" + KeyMap.nameOf(codes[which]) + "\" (Back cancels)", Toast.LENGTH_LONG).show();
                }
            }
        }).show();
    }

    private void screenshot() {
        EmuSession s = session;
        int[] wh = new int[2];
        int[] px = s == null ? null : s.frame(wh);
        if (px == null) { Toast.makeText(this, "Nothing on screen yet", Toast.LENGTH_SHORT).show(); return; }
        try {
            Bitmap b = Bitmap.createBitmap(wh[0], wh[1], Bitmap.Config.ARGB_8888);
            b.setPixels(px, 0, wh[0], 0, 0, wh[0], wh[1]);
            File dir = getExternalFilesDir("emulator_screenshots");
            if (dir == null) dir = new File(getFilesDir(), "emulator_screenshots");
            dir.mkdirs();
            File f = new File(dir, "shot_" + System.currentTimeMillis() + ".png");
            FileOutputStream o = new FileOutputStream(f);
            try { b.compress(Bitmap.CompressFormat.PNG, 100, o); } finally { o.close(); }
            b.recycle();
            Toast.makeText(this, "Saved " + f.getAbsolutePath(), Toast.LENGTH_LONG).show();
        } catch (IOException e) {
            Toast.makeText(this, "Screenshot failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void dataDialog() {
        final EmuSession s = session;
        if (s == null) return;
        List<String> r = s.rmsReport();
        StringBuilder sb = new StringBuilder();
        for (String x : r) sb.append(x).append('\n');
        new Ui.Dlg(this).setTitle("Saved data of this MIDlet suite")
                .setMessage(r.isEmpty() ? "No record stores saved." : sb.toString())
                .setPositiveButton("Close", null)
                .setNegativeButton("Clear data", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) {
                        try {
                            int n = s.clearData();
                            Toast.makeText(EmulatorActivity.this, "Deleted " + n + " file(s)", Toast.LENGTH_SHORT).show();
                        } catch (IllegalStateException e) {
                            Toast.makeText(EmulatorActivity.this, "Stop the MIDlet first", Toast.LENGTH_SHORT).show();
                        }
                    }
                }).show();
    }

    private void copyReport() {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null && session != null) {
            cm.setPrimaryClip(ClipData.newPlainText("emulator report", session.crashReport()));
            Toast.makeText(this, "Report copied", Toast.LENGTH_SHORT).show();
        }
    }

    // ---- lifecycle

    @Override protected void onPause() {
        super.onPause();
        EmuSession s = session;
        if (s != null && s.state() == EmuSession.State.ACTIVE) { autoPaused = true; s.pause(); }
    }

    @Override protected void onResume() {
        super.onResume();
        EmuSession s = session;
        if (autoPaused && s != null) { autoPaused = false; s.resume(); }
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        if (realSensors != null) { realSensors.close(); realSensors = null; }
        ui.removeCallbacksAndMessages(null);
        final EmuSession s = session;
        session = null;
        if (s != null) {
            s.setListener(null);
            s.console().setListener(null);
            final boolean nat = s.isNative();
            new Thread(new Runnable() {
                public void run() {
                    try { s.stop(); } catch (Throwable t) { /* ignore */ }
                    // natively running code cannot be halted from outside (busy loops, threads): the emulator lives in its own process, end it
                    if (nat) android.os.Process.killProcess(android.os.Process.myPid());
                }
            }, "emu-stop").start();
        }
    }
}
