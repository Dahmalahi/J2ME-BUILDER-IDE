package com.dashers.j2mebuilderide.emu;

import java.util.ArrayList;
import java.util.List;

/** Thread-safe ring buffer of runtime log lines, kept separate from the IDE's compiler output. */
public final class ConsoleLog {
    public static final int DEBUG = 0, INFO = 1, WARN = 2, ERROR = 3;

    public static final class Entry {
        public final long time; public final int level; public final String text;
        Entry(int level, String text) { time = System.currentTimeMillis(); this.level = level; this.text = text; }
        public String levelName() { return level == ERROR ? "E" : level == WARN ? "W" : level == DEBUG ? "D" : "I"; }
        @Override public String toString() { return levelName() + " " + text; }
    }

    public interface Listener { void onEntry(Entry e); }

    private final int max;
    private final ArrayList<Entry> entries = new ArrayList<Entry>();
    private volatile Listener listener;
    private volatile Listener tap;

    public ConsoleLog(int max) { this.max = max; }

    public void setListener(Listener l) { listener = l; }
    /** Internal observer (the analyser) that sees every entry before the UI listener. */
    public void setTap(Listener l) { tap = l; }

    public void add(int level, String text) {
        Entry e = new Entry(level, text);
        synchronized (this) {
            entries.add(e);
            if (entries.size() > max) entries.remove(0);
        }
        Listener t = tap;
        if (t != null) { try { t.onEntry(e); } catch (RuntimeException ex) { /* analysis must never break logging */ } }
        Listener l = listener;
        if (l != null) l.onEntry(e);
    }

    public synchronized List<Entry> snapshot() { return new ArrayList<Entry>(entries); }

    public synchronized int errorCount() {
        int n = 0;
        for (Entry e : entries) if (e.level == ERROR) n++;
        return n;
    }

    public synchronized String text() {
        StringBuilder sb = new StringBuilder();
        for (Entry e : entries) sb.append(e).append('\n');
        return sb.toString();
    }
}
