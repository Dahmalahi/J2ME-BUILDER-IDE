package com.dashers.j2mebuilderide.emu.midp;

public interface ContentConnection extends StreamConnection {
    String getType();
    String getEncoding();
    long getLength();
}
