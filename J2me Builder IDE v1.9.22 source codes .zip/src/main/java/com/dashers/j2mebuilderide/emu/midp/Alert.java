package com.dashers.j2mebuilderide.emu.midp;

import com.dashers.j2mebuilderide.emu.gfx.Frame;

public class Alert extends Screen {
    public static final int FOREVER = -2;
    private String text;
    private int timeout = 2500;
    private AlertType type;
    private Image image;
    Displayable next;

    public Alert(String title) { this(title, null, null, null); }
    public Alert(String title, String text, Image img, AlertType type) { setTitle(title); this.text = text; image = img; this.type = type; }

    public String getString() { return text; }
    public void setString(String s) { text = s; refresh(); }
    public int getDefaultTimeout() { return 2500; }
    public int getTimeout() { return timeout; }
    public void setTimeout(int t) { if (t <= 0 && t != FOREVER) throw new IllegalArgumentException(); timeout = t; }
    public AlertType getType() { return type; }
    public void setType(AlertType t) { type = t; }
    public Image getImage() { return image; }
    public void setImage(Image i) { image = i; refresh(); }
    public Gauge getIndicator() { return null; }

    @Override void render(Device d, Frame f) {
        if (next != null) next.render(d, f);
        int w = d.width() - 16;
        int th = Draw.wrapped(d, null, getTitle() == null ? "" : getTitle(), 0, 0, w - 8, 0, true);
        int bh = Draw.wrapped(d, null, text == null ? "" : text, 0, 0, w - 8, 0, false);
        int h = Math.min(d.height() - 20, th + bh + 16 + (image == null ? 0 : image.getHeight()));
        int x = 8, y = (d.height() - h) / 2;
        int band = type == AlertType.ERROR ? 0xC62828 : type == AlertType.WARNING ? 0xEF6C00 : type == AlertType.CONFIRMATION ? 0x2E7D32 : 0x1F4E8C;
        f.fillRect(x, y, w, h, 0xFFFFF0);
        f.fillRect(x, y, w, 3, band);
        f.drawRect(x, y, w - 1, h - 1, 0x000000);
        int ty = Draw.wrapped(d, f, getTitle() == null ? "" : getTitle(), x + 4, y + 6, w - 8, 0x000000, true);
        if (image != null) { Draw.image(f, image, x + 4, ty); ty += image.getHeight(); }
        Draw.wrapped(d, f, text == null ? "" : text, x + 4, ty + 2, w - 8, 0x000000, false);
        if (!visibleCommands().isEmpty()) drawSoftKeys(d, f);
    }

    @Override void keyEvent(Device d, int type, int code) {
        if (type != 0) return;
        if ((code == Canvas.CODE_SELECT || code == Canvas.KEY_NUM5) && visibleCommands().isEmpty()) d.display.dismissAlert(this);
    }
    @Override void pointerEvent(Device d, int type, int x, int y) {
        if (type != 0) return;
        int k = softKeyAt(d, x, y);
        if (k >= 0) { d.display.fireCommand(k); return; }
        if (visibleCommands().isEmpty()) d.display.dismissAlert(this);
    }
}
