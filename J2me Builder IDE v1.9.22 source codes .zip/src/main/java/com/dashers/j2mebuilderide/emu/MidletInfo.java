package com.dashers.j2mebuilderide.emu;

/** One MIDlet-n entry. */
public final class MidletInfo {
    public final int index;
    public final String name, icon, className;
    public final boolean classInJar;
    MidletInfo(int index, String name, String icon, String className, boolean inJar) {
        this.index = index; this.name = name; this.icon = icon; this.className = className; this.classInJar = inJar;
    }
    @Override public String toString() { return name + " (" + className + ")"; }
}
