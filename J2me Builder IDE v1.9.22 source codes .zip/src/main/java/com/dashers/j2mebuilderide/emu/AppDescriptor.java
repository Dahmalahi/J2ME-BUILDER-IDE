package com.dashers.j2mebuilderide.emu;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** Reads the jar, its manifest and an optional JAD. JAD attributes override manifest ones, as on a phone. */
public final class AppDescriptor {
    public final Map<String, byte[]> files = new HashMap<String, byte[]>();
    public final Map<String, String> props = new LinkedHashMap<String, String>();
    public final List<MidletInfo> midlets = new ArrayList<MidletInfo>();
    public final List<String> warnings = new ArrayList<String>();

    public static AppDescriptor parse(byte[] jar, String jadText) throws EmuException {
        if (jar == null || jar.length == 0) throw new EmuException("the jar is empty");
        AppDescriptor d = new AppDescriptor();
        try {
            ZipInputStream z = new ZipInputStream(new ByteArrayInputStream(jar));
            ZipEntry e;
            long total = 0;
            while ((e = z.getNextEntry()) != null) {
                if (e.isDirectory()) continue;
                ByteArrayOutputStream o = new ByteArrayOutputStream();
                byte[] b = new byte[8192];
                int n;
                while ((n = z.read(b)) > 0) {
                    o.write(b, 0, n);
                    total += n;
                    if (total > 64L * 1024 * 1024) throw new EmuException("jar expands to more than 64 MB");
                }
                d.files.put(e.getName(), o.toByteArray());
            }
        } catch (IOException ex) {
            throw new EmuException("not a readable jar/zip file: " + ex.getMessage());
        }
        if (d.files.isEmpty()) throw new EmuException("the jar contains no files");
        byte[] mf = d.files.get("META-INF/MANIFEST.MF");
        if (mf == null) d.warnings.add("jar has no META-INF/MANIFEST.MF");
        else parseAttrs(new String(mf, utf8()), d.props);
        if (jadText != null && jadText.trim().length() > 0) {
            Map<String, String> jad = new LinkedHashMap<String, String>();
            parseAttrs(jadText, jad);
            for (Map.Entry<String, String> en : jad.entrySet()) {
                String old = d.props.get(en.getKey());
                if (old != null && !old.equals(en.getValue()) && en.getKey().startsWith("MIDlet-") && !en.getKey().startsWith("MIDlet-Jar") && !en.getKey().equals("MIDlet-Name") && !en.getKey().equals("MIDlet-Version") && !en.getKey().equals("MIDlet-Vendor")) {
                    d.warnings.add("JAD value for " + en.getKey() + " differs from the manifest; the JAD value is used");
                }
                d.props.put(en.getKey(), en.getValue());
            }
        }
        for (int i = 1; i < 100; i++) {
            String v = d.props.get("MIDlet-" + i);
            if (v == null) { if (i > 1) break; else continue; }
            String[] p = v.split(",", -1);
            if (p.length < 3) { d.warnings.add("MIDlet-" + i + " is malformed (expected name, icon, class): " + v); continue; }
            String cls = p[2].trim().replace('.', '/');
            d.midlets.add(new MidletInfo(d.midlets.size(), p[0].trim(), p[1].trim(), p[2].trim(), d.files.containsKey(cls + ".class")));
        }
        if (d.midlets.isEmpty()) throw new EmuException("no MIDlet-1 entry in the manifest or JAD: the runtime cannot tell which class to start");
        String conf = d.props.get("MicroEdition-Configuration");
        if (conf != null && !conf.startsWith("CLDC-1")) d.warnings.add("MicroEdition-Configuration is " + conf + " (the runtime targets CLDC 1.x)");
        String prof = d.props.get("MicroEdition-Profile");
        if (prof != null && !prof.startsWith("MIDP-")) d.warnings.add("MicroEdition-Profile is " + prof + " (the runtime targets MIDP 1.0/2.0 basics)");
        return d;
    }

    private static java.nio.charset.Charset utf8() { return java.nio.charset.Charset.forName("UTF-8"); }

    /** Manifest/JAD syntax: "Key: value", continuation lines start with one space. */
    static void parseAttrs(String text, Map<String, String> out) {
        String[] lines = text.replace("\r\n", "\n").replace('\r', '\n').split("\n");
        String key = null;
        StringBuilder val = new StringBuilder();
        for (String ln : lines) {
            if (ln.startsWith(" ") && key != null) { val.append(ln.substring(1)); continue; }
            if (key != null) out.put(key, val.toString().trim());
            key = null;
            val.setLength(0);
            int c = ln.indexOf(':');
            if (c <= 0) continue;
            key = ln.substring(0, c).trim();
            val.append(ln.substring(c + 1));
        }
        if (key != null) out.put(key, val.toString().trim());
    }
}
