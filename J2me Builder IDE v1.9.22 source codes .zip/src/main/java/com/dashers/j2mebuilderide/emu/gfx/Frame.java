package com.dashers.j2mebuilderide.emu.gfx;

/** An ARGB pixel surface with a clip rectangle and the primitive drawing operations. Not thread-safe by itself. */
public final class Frame {
    public final int w, h;
    public final int[] px;
    public int cx, cy, cw, ch;   // clip, absolute coordinates, always inside the frame

    public Frame(int w, int h) {
        this.w = Math.max(1, w);
        this.h = Math.max(1, h);
        px = new int[this.w * this.h];
        resetClip();
    }

    public void resetClip() { cx = 0; cy = 0; cw = w; ch = h; }

    public void setClip(int x, int y, int ww, int hh) {
        int x0 = Math.max(0, x), y0 = Math.max(0, y);
        int x1 = Math.min(w, x + ww), y1 = Math.min(h, y + hh);
        cx = x0; cy = y0; cw = Math.max(0, x1 - x0); ch = Math.max(0, y1 - y0);
    }

    public void intersectClip(int x, int y, int ww, int hh) {
        int x0 = Math.max(cx, x), y0 = Math.max(cy, y);
        int x1 = Math.min(cx + cw, x + ww), y1 = Math.min(cy + ch, y + hh);
        cx = x0; cy = y0; cw = Math.max(0, x1 - x0); ch = Math.max(0, y1 - y0);
    }

    private boolean inClip(int x, int y) { return x >= cx && y >= cy && x < cx + cw && y < cy + ch; }

    public void plot(int x, int y, int rgb) { if (inClip(x, y)) px[y * w + x] = 0xFF000000 | rgb; }

    public void fillRect(int x, int y, int ww, int hh, int rgb) {
        int x0 = Math.max(cx, x), y0 = Math.max(cy, y), x1 = Math.min(cx + cw, x + ww), y1 = Math.min(cy + ch, y + hh);
        int c = 0xFF000000 | rgb;
        for (int j = y0; j < y1; j++) for (int i = x0; i < x1; i++) px[j * w + i] = c;
    }

    public void drawRect(int x, int y, int ww, int hh, int rgb) {
        if (ww < 0 || hh < 0) return;
        drawLine(x, y, x + ww, y, rgb); drawLine(x, y + hh, x + ww, y + hh, rgb);
        drawLine(x, y, x, y + hh, rgb); drawLine(x + ww, y, x + ww, y + hh, rgb);
    }

    public void drawLine(int x0, int y0, int x1, int y1, int rgb) {
        int dx = Math.abs(x1 - x0), dy = -Math.abs(y1 - y0), sx = x0 < x1 ? 1 : -1, sy = y0 < y1 ? 1 : -1, err = dx + dy;
        while (true) {
            plot(x0, y0, rgb);
            if (x0 == x1 && y0 == y1) break;
            int e2 = 2 * err;
            if (e2 >= dy) { err += dy; x0 += sx; }
            if (e2 <= dx) { err += dx; y0 += sy; }
        }
    }

    /** Ellipse inscribed in the box; fill or outline. Full ellipse only (arc angles are handled by the caller). */
    public void ellipse(int x, int y, int ww, int hh, int rgb, boolean fill, int startDeg, int arcDeg) {
        if (ww < 0 || hh < 0) return;
        double rx = ww / 2.0, ry = hh / 2.0, ccx = x + rx, ccy = y + ry;
        boolean full = arcDeg >= 360 || arcDeg <= -360;
        for (int j = y; j <= y + hh; j++) {
            for (int i = x; i <= x + ww; i++) {
                double dx = (i + 0.0 - ccx) / (rx == 0 ? 1 : rx), dy = (j + 0.0 - ccy) / (ry == 0 ? 1 : ry);
                double d = dx * dx + dy * dy;
                boolean on = fill ? d <= 1.0 : (d <= 1.0 && d >= 1.0 - 2.2 / Math.max(1.0, Math.min(rx, ry)));
                if (!on) continue;
                if (!full) {
                    double ang = Math.toDegrees(Math.atan2(-(j - ccy) / (ry == 0 ? 1 : ry), (i - ccx) / (rx == 0 ? 1 : rx)));
                    if (ang < 0) ang += 360;
                    double rel = arcDeg >= 0 ? ang - startDeg : startDeg - ang;
                    while (rel < 0) rel += 360;
                    if (rel > Math.abs(arcDeg)) continue;
                }
                plot(i, j, rgb);
            }
        }
    }

    /** Rounded rectangle; aw/ah are the corner arc diameters (MIDP semantics). */
    public void roundRect(int x, int y, int ww, int hh, int aw, int ah, int rgb, boolean fill) {
        if (ww < 0 || hh < 0) return;
        double rx = Math.min(Math.max(aw, 0), ww) / 2.0, ry = Math.min(Math.max(ah, 0), hh) / 2.0;
        for (int j = 0; j <= hh; j++) for (int i = 0; i <= ww; i++) {
            double dx = 0, dy = 0;
            if (i < rx) dx = (rx - i) / rx; else if (i > ww - rx) dx = (i - (ww - rx)) / rx;
            if (j < ry) dy = (ry - j) / ry; else if (j > hh - ry) dy = (j - (hh - ry)) / ry;
            double d = dx * dx + dy * dy;
            if (d > 1.0) continue;
            boolean edge = i == 0 || j == 0 || i == ww || j == hh || d > 1.0 - 2.0 / Math.max(1.0, Math.min(rx == 0 ? 99 : rx, ry == 0 ? 99 : ry));
            if (fill || edge) plot(x + i, y + j, rgb);
        }
    }

    public void fillTriangle(int x1, int y1, int x2, int y2, int x3, int y3, int rgb) {
        int minX = Math.min(x1, Math.min(x2, x3)), maxX = Math.max(x1, Math.max(x2, x3));
        int minY = Math.min(y1, Math.min(y2, y3)), maxY = Math.max(y1, Math.max(y2, y3));
        for (int y = minY; y <= maxY; y++) for (int x = minX; x <= maxX; x++) {
            long d1 = (long) (x - x2) * (y1 - y2) - (long) (x1 - x2) * (y - y2);
            long d2 = (long) (x - x3) * (y2 - y3) - (long) (x2 - x3) * (y - y3);
            long d3 = (long) (x - x1) * (y3 - y1) - (long) (x3 - x1) * (y - y1);
            boolean neg = d1 < 0 || d2 < 0 || d3 < 0, pos = d1 > 0 || d2 > 0 || d3 > 0;
            if (!(neg && pos)) plot(x, y, rgb);
        }
    }

    /** Source-over blend of an ARGB region. alpha=false treats source as opaque. */
    public void blit(int[] src, int sw, int sx, int sy, int rw, int rh, int dx, int dy, boolean alpha) {
        for (int j = 0; j < rh; j++) {
            int y = dy + j;
            if (y < cy || y >= cy + ch) continue;
            for (int i = 0; i < rw; i++) {
                int x = dx + i;
                if (x < cx || x >= cx + cw) continue;
                int s = src[(sy + j) * sw + sx + i];
                int a = alpha ? s >>> 24 : 255;
                if (a == 0) continue;
                if (a == 255) { px[y * w + x] = 0xFF000000 | s; continue; }
                int d = px[y * w + x];
                int r = ((s >> 16 & 255) * a + (d >> 16 & 255) * (255 - a)) / 255;
                int g = ((s >> 8 & 255) * a + (d >> 8 & 255) * (255 - a)) / 255;
                int b = ((s & 255) * a + (d & 255) * (255 - a)) / 255;
                px[y * w + x] = 0xFF000000 | r << 16 | g << 8 | b;
            }
        }
    }

    /** Draws a coverage mask in a colour (text). */
    public void blitMask(Platform.Mask m, int dx, int dy, int rgb) {
        int cr = rgb >> 16 & 255, cg = rgb >> 8 & 255, cb = rgb & 255;
        for (int j = 0; j < m.h; j++) {
            int y = dy + j;
            if (y < cy || y >= cy + ch) continue;
            for (int i = 0; i < m.w; i++) {
                int x = dx + i;
                if (x < cx || x >= cx + cw) continue;
                int a = m.alpha[j * m.w + i];
                if (a <= 0) continue;
                if (a >= 255) { px[y * w + x] = 0xFF000000 | rgb; continue; }
                int d = px[y * w + x];
                int r = (cr * a + (d >> 16 & 255) * (255 - a)) / 255;
                int g = (cg * a + (d >> 8 & 255) * (255 - a)) / 255;
                int b = (cb * a + (d & 255) * (255 - a)) / 255;
                px[y * w + x] = 0xFF000000 | r << 16 | g << 8 | b;
            }
        }
    }
}
