package com.dashers.j2mebuilderide.emu.midp;

import java.util.Enumeration;
import java.util.Vector;

public class FileSystemRegistry {
    private FileSystemRegistry() { }
    public static Enumeration listRoots() {
        Vector v = new Vector();
        if (Device.current().fileRoot != null) v.addElement("root1/");
        return v.elements();
    }
    public static boolean addFileSystemListener(Object l) { return false; }
    public static boolean removeFileSystemListener(Object l) { return false; }
}
