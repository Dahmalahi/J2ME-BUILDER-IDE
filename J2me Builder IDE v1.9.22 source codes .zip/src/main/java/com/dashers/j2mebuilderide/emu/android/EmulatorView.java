package com.dashers.j2mebuilderide.emu.android;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.view.View;

/** The in-app emulator surface: the last frame scaled to fit (aspect ratio kept) on a plain screen, no frame. */
public final class EmulatorView extends View {
    private Bitmap bmp;
    private final Paint paint = new Paint();
    private final Paint border = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint hint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Rect dst = new Rect();
    private final RectF rf = new RectF();
    private final Path clip = new Path();
    private boolean smooth;
    /** 0 = fill: as big as the area allows, shape kept (default); 1 = whole-number scales (crisp pixels, smaller); 2 = stretch to the whole area. */
    private int scaleMode;
    // look: rounded corners, accent glow border, LCD pixel grid, brightness
    private int cornerPx;
    private boolean glow, lcd;
    private int glowColor = 0xFFFF6FA8;
    private final Paint gridPaint = new Paint();
    private final Paint framePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private String message = "Starting\u2026";

    public EmulatorView(Context c) {
        super(c);
        paint.setFilterBitmap(false);
        border.setColor(0xFF3A4152);
        border.setStyle(Paint.Style.STROKE);
        border.setStrokeWidth(2f * c.getResources().getDisplayMetrics().density);
        hint.setColor(0xFF6B7385);
        hint.setTextAlign(Paint.Align.CENTER);
        hint.setTextSize(14f * c.getResources().getDisplayMetrics().scaledDensity);
        setBackgroundColor(Color.TRANSPARENT);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);     // clipPath with anti-aliased corners is reliable on software layers
    }

    /** Bilinear scaling instead of crisp pixels (nicer for photos, softer for pixel art). */
    public void setSmooth(boolean on) { smooth = on; paint.setFilterBitmap(on); invalidate(); }

    public void setScaleMode(int mode) { scaleMode = mode; invalidate(); }

    /** cornerDp 0 = square; glow draws an accent border; lcd draws the pixel grid when pixels are big enough; brightPct 100 = unchanged. */
    public void setLook(int cornerDp, boolean glowBorder, int glowArgb, boolean lcdGrid, int brightPct) {
        cornerPx = Math.round(cornerDp * getResources().getDisplayMetrics().density);
        glow = glowBorder;
        glowColor = glowArgb;
        lcd = lcdGrid;
        float b = Math.max(0.3f, brightPct / 100f);
        if (brightPct == 100) {
            paint.setColorFilter(null);
        } else {
            paint.setColorFilter(new android.graphics.ColorMatrixColorFilter(new float[]{
                    b, 0, 0, 0, 0,
                    0, b, 0, 0, 0,
                    0, 0, b, 0, 0,
                    0, 0, 0, 1, 0}));
        }
        invalidate();
    }

    /** Text shown on the empty screen ("Starting...", "Not started", ...). */
    public void setMessage(String m) { message = m; invalidate(); }

    /** Call on the UI thread. */
    public void setFrame(int[] argb, int w, int h) {
        if (argb == null) return;
        if (bmp == null || bmp.getWidth() != w || bmp.getHeight() != h) {
            if (bmp != null) bmp.recycle();
            bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        }
        bmp.setPixels(argb, 0, w, 0, 0, w, h);
        invalidate();
    }

    public void clear() {
        if (bmp != null) { bmp.recycle(); bmp = null; }
        invalidate();
    }

    /** View coordinates -> emulated screen pixels, or null when outside the picture (aspect ratio preserved). */
    public int[] toScreen(float vx, float vy) {
        if (bmp == null || dst.width() == 0) return null;
        if (vx < dst.left || vx >= dst.right || vy < dst.top || vy >= dst.bottom) return null;
        int x = (int) ((vx - dst.left) * bmp.getWidth() / dst.width());
        int y = (int) ((vy - dst.top) * bmp.getHeight() / dst.height());
        return new int[]{Math.max(0, Math.min(bmp.getWidth() - 1, x)), Math.max(0, Math.min(bmp.getHeight() - 1, y))};
    }

    @Override protected void onDraw(Canvas c) {
        if (bmp == null) {
            c.drawText(message, getWidth() / 2f, getHeight() / 2f, hint);
            return;
        }
        float s = Math.min(getWidth() / (float) bmp.getWidth(), getHeight() / (float) bmp.getHeight());
        int w, h;
        if (scaleMode == 2) {
            w = Math.max(1, getWidth());
            h = Math.max(1, getHeight());
        } else {
            // whole-number scales keep pixel art crisp but can leave a big margin (3.75x becomes 3x): only on request
            if (scaleMode == 1 && !smooth && s >= 1f) s = (float) Math.floor(s);
            w = Math.max(1, Math.round(bmp.getWidth() * s));
            h = Math.max(1, Math.round(bmp.getHeight() * s));
        }
        int x = (getWidth() - w) / 2, y = (getHeight() - h) / 2;
        dst.set(x, y, x + w, y + h);
        c.save();
        if (cornerPx > 0) {
            clip.reset();
            clip.addRoundRect(new android.graphics.RectF(dst), cornerPx, cornerPx, android.graphics.Path.Direction.CW);
            c.clipPath(clip);
        }
        c.drawBitmap(bmp, null, dst, paint);
        if (lcd) {
            float sx = w / (float) bmp.getWidth(), sy = h / (float) bmp.getHeight();
            if (sx >= 3f && sy >= 3f) {
                gridPaint.setColor(0x38000000);
                gridPaint.setStrokeWidth(1f);
                for (int i = 1; i < bmp.getWidth(); i++) c.drawLine(x + i * sx, y, x + i * sx, y + h, gridPaint);
                for (int j = 1; j < bmp.getHeight(); j++) c.drawLine(x, y + j * sy, x + w, y + j * sy, gridPaint);
            }
        }
        c.restore();
        if (glow || cornerPx > 0) {
            framePaint.setStyle(Paint.Style.STROKE);
            framePaint.setStrokeWidth(glow ? 3f : 1.5f);
            framePaint.setColor(glow ? glowColor : 0x55FFFFFF);
            c.drawRoundRect(new android.graphics.RectF(dst), cornerPx, cornerPx, framePaint);
        }
    }
}
