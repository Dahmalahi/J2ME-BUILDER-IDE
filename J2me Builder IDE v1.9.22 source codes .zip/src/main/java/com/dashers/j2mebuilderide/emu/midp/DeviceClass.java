package com.dashers.j2mebuilderide.emu.midp;

public class DeviceClass {
    private final int record;

    public DeviceClass(int record) {
        if ((record & 0xFF000000) != 0 || (record & 0x3) != 0) throw new IllegalArgumentException("not a valid class-of-device record");
        this.record = record;
    }

    public int getServiceClasses() { return record & 0xFFE000; }
    public int getMajorDeviceClass() { return record & 0x1F00; }
    public int getMinorDeviceClass() { return record & 0xFC; }
}
