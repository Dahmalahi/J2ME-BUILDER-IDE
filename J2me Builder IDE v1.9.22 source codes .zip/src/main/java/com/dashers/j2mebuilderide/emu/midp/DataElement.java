package com.dashers.j2mebuilderide.emu.midp;

import java.util.Enumeration;
import java.util.Vector;

/** SDP data element (the subset a MIDlet needs to read service records). */
public class DataElement {
    public static final int NULL = 0, U_INT_1 = 8, U_INT_2 = 9, U_INT_4 = 10, U_INT_8 = 11, U_INT_16 = 12, INT_1 = 16, INT_2 = 17, INT_4 = 18,
            INT_8 = 19, INT_16 = 20, URL = 64, UUID = 24, BOOL = 40, STRING = 32, DATSEQ = 48, DATALT = 56;

    private final int type;
    private long num;
    private boolean bool;
    private Object value;
    private final Vector children = new Vector();

    public DataElement(int valueType) {
        if (valueType != NULL && valueType != DATSEQ && valueType != DATALT) throw new IllegalArgumentException("this type needs a value");
        type = valueType;
    }

    public DataElement(boolean bool) { type = BOOL; this.bool = bool; }

    private static boolean longType(int t) { return t == U_INT_1 || t == U_INT_2 || t == U_INT_4 || t == INT_1 || t == INT_2 || t == INT_4 || t == INT_8; }

    public DataElement(int valueType, long value) {
        if (!longType(valueType)) throw new IllegalArgumentException("bad integer type " + valueType);
        type = valueType; num = value;
    }

    public DataElement(int valueType, Object value) {
        if (value == null) throw new IllegalArgumentException("value is null");
        if (valueType == STRING && value instanceof String) { }
        else if (valueType == URL && value instanceof String) { }
        else if (valueType == UUID && value instanceof com.dashers.j2mebuilderide.emu.midp.UUID) { }
        else if ((valueType == U_INT_16 || valueType == INT_16) && value instanceof byte[] && ((byte[]) value).length == 16) { }
        else throw new IllegalArgumentException("value does not fit the type " + valueType);
        type = valueType; this.value = value;
    }

    public void addElement(DataElement e) {
        if (type != DATSEQ && type != DATALT) throw new ClassCastException("only DATSEQ and DATALT hold elements");
        if (e == null) throw new NullPointerException("elem");
        children.addElement(e);
    }

    public void insertElementAt(DataElement e, int index) {
        if (type != DATSEQ && type != DATALT) throw new ClassCastException("only DATSEQ and DATALT hold elements");
        if (e == null) throw new NullPointerException("elem");
        children.insertElementAt(e, index);
    }

    public int getSize() {
        if (type != DATSEQ && type != DATALT) throw new ClassCastException("only DATSEQ and DATALT have a size");
        return children.size();
    }

    public boolean removeElement(DataElement e) {
        if (type != DATSEQ && type != DATALT) throw new ClassCastException("only DATSEQ and DATALT hold elements");
        if (e == null) throw new NullPointerException("elem");
        return children.removeElement(e);
    }

    public int getDataType() { return type; }

    public long getLong() {
        if (!longType(type)) throw new ClassCastException("not an integer element");
        return num;
    }

    public boolean getBoolean() {
        if (type != BOOL) throw new ClassCastException("not a BOOL element");
        return bool;
    }

    public Object getValue() {
        if (type == DATSEQ || type == DATALT) return children.elements();
        if (type == STRING || type == URL || type == UUID || type == U_INT_16 || type == INT_16) return value;
        throw new ClassCastException("this element has no object value");
    }
}
