package com.dashers.j2mebuilderide.emu;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Reads what the emulated app does (uncaught exceptions, stack traces it prints itself, missing resources, system
 * properties it asks for, how and when it quits, a screen that never appears or stays blank) and writes plain
 * explanations with a suggested fix into the console, each line starting with "[analysis]". Every finding is
 * printed once; repeats are only counted. Pure Java: unit-testable on a desktop JVM.
 */
public final class Diagnostics {
    public static final String TAG = "[analysis] ";
    public static final int INFO = 0, WARN = 1, ERROR = 2;

    public static final class Finding {
        public final int severity;
        public final String key, title, advice;
        public int count = 1;
        Finding(int severity, String key, String title, String advice) { this.severity = severity; this.key = key; this.title = title; this.advice = advice; }
    }

    private static final Pattern EXC_LINE = Pattern.compile("^(?:Exception in thread \"[^\"]*\"\\s+)?([A-Za-z_$][\\w$]*(?:\\.[A-Za-z_$][\\w$]*)*(?:Exception|Error|Throwable))(?::\\s*(.*))?$");
    private static final Pattern AT_LINE = Pattern.compile("^\\s*at\\s+(\\S+)");

    private final ConsoleLog console;
    private final AppDescriptor app;
    private final CompatScan compat;
    private ResourceIndex res;
    private final LinkedHashMap<String, Finding> findings = new LinkedHashMap<String, Finding>();
    private final TreeSet<String> unknownProps = new TreeSet<String>();
    private long t0 = System.currentTimeMillis();
    private boolean exitReported;
    private int resourceMisses;
    // exception line printed by the app itself, waiting for its stack trace to find the app frame
    private String pendKind, pendMsg;
    private int pendAt;

    public Diagnostics(ConsoleLog console, AppDescriptor app, CompatScan compat) {
        this.console = console;
        this.app = app;
        this.compat = compat;
    }

    public synchronized void setResources(ResourceIndex r) { res = r; }
    public synchronized void markStart() { t0 = System.currentTimeMillis(); }

    // ---- findings

    private Finding note(int sev, String key, String title, String advice) {
        Finding f;
        synchronized (this) {
            f = findings.get(key);
            if (f != null) { f.count++; return f; }
            f = new Finding(sev, key, title, advice);
            findings.put(key, f);
        }
        console.add(sev == INFO ? ConsoleLog.INFO : ConsoleLog.WARN, TAG + title);
        if (advice != null) for (String l : advice.split("\n")) console.add(sev == INFO ? ConsoleLog.INFO : ConsoleLog.WARN, TAG + "   -> " + l);
        return f;
    }

    public synchronized boolean hasProblems() {
        for (Finding f : findings.values()) if (f.severity >= WARN) return true;
        return false;
    }

    public synchronized List<Finding> findings() { return new ArrayList<Finding>(findings.values()); }

    // ---- events

    public void noteProfile(AppProfile p) {
        for (String pr : p.problems) note(WARN, "api:" + pr, "This app uses something the emulator does not have: " + pr + ".",
                "Code paths that need it will fail. If the app starts normally and only that feature breaks, ignore it; if the app quits or shows nothing, this is the likely reason.");
    }

    public void noteResourceMiss(String requested, String suggestion) {
        synchronized (this) { resourceMisses++; }
        note(WARN, "res:" + requested, "Resource not found in the jar: " + requested,
                (suggestion != null ? suggestion + "\n" : "") + "Paths are relative to the jar root and case-sensitive: getResourceAsStream(\"/img/a.png\") needs the file img/a.png inside the jar.\nA missing image usually means a blank or partly empty screen, or the app quitting.");
    }

    public void noteProperty(String key, boolean known) {
        if (known) return;
        boolean first;
        synchronized (this) { first = unknownProps.add(key); }
        if (first) console.add(ConsoleLog.INFO, "App asked for system property \"" + key + "\": not defined by the emulator (null returned)");
    }

    public void noScreen() {
        note(WARN, "no-screen", "The app has not shown any screen yet.",
                "It never called Display.setCurrent(...) (or does it from a thread that is still waiting).\nIf it loads data first, look for the Resource / network / record store warnings above.");
    }

    public void blankScreen() {
        String why = resourceMisses > 0 ? "Images or data it tried to load were missing (see the 'Resource not found' lines)." : "Nothing was drawn: its paint code may depend on an image, font or API that failed, or it waits for a key press.";
        note(WARN, "blank", "The screen is a single flat colour.", why);
    }

    public void startStuck() {
        note(WARN, "stuck", "startApp() has not returned after several seconds.",
                "The app is busy on the event thread (loading assets, waiting for the network, or an endless loop).\nWell-behaved MIDlets do slow work in their own Thread.");
    }

    /** Called when the app ends itself with notifyDestroyed() or System.exit(). */
    public void noteExit(String how) {
        long dt;
        List<Finding> bad = new ArrayList<Finding>();
        synchronized (this) {
            if (exitReported) return;
            exitReported = true;
            dt = System.currentTimeMillis() - t0;
            for (Finding f : findings.values()) if (f.severity >= WARN && !f.key.startsWith("exit")) bad.add(f);
            if (bad.size() > 3) bad = bad.subList(bad.size() - 3, bad.size());
        }
        String secs = (dt / 100) / 10.0 + " s";
        if (!bad.isEmpty()) {
            StringBuilder sb = new StringBuilder("The last problems before it quit:");
            for (Finding f : bad) sb.append("\n  - ").append(f.title);
            sb.append("\nApps often quit (or look like they restart) when a file, record store, network call or API fails. Fix the first problem and it should stay open.");
            note(WARN, "exit", "The app ended itself with " + how + " " + secs + " after starting.", sb.toString());
        } else if (dt < 4000) {
            String props;
            synchronized (this) { props = unknownProps.isEmpty() ? "" : "\nIt asked for these system properties that the emulator does not define: " + unknownProps; }
            note(WARN, "exit", "The app ended itself with " + how + " only " + secs + " after starting, with no error.",
                    "It most likely tested something (phone model, screen size, a required API, a licence/date check) and decided to quit." + props);
        }
    }

    // ---- stack traces

    /** Called with every console line (see ConsoleLog.setTap). */
    public void observe(ConsoleLog.Entry e) {
        String t = e.text;
        if (t == null || t.startsWith(TAG)) return;
        if (t.startsWith("MIDlet called notifyDestroyed()")) { flushPending(null); noteExit("notifyDestroyed()"); return; }
        if (t.startsWith("MIDlet called System.exit(")) { flushPending(null); noteExit("System.exit()"); return; }
        if (e.level < ConsoleLog.INFO || t.indexOf('\n') >= 0) return;      // multi-line entries come from analyze() itself
        Matcher at = AT_LINE.matcher(t);
        if (at.find()) {
            String frame = at.group(1);
            synchronized (this) {
                if (pendKind == null) return;
                pendAt++;
                if (isAppFrame(frame) || pendAt >= 25) { String k = pendKind, m = pendMsg; pendKind = null; flushLocked(k, m, isAppFrame(frame) ? frame : null); }
            }
            return;
        }
        if (t.startsWith("Caused by:")) return;
        flushPending(null);
        Matcher m = EXC_LINE.matcher(t.trim());
        if (m.find()) { synchronized (this) { pendKind = m.group(1); pendMsg = m.group(2); pendAt = 0; } }
    }

    private void flushPending(String loc) {
        String k, m;
        synchronized (this) { k = pendKind; m = pendMsg; pendKind = null; }
        if (k != null) flushLocked(k, m, loc);
    }

    private void flushLocked(String kind, String msg, String loc) { classify(kind, msg == null ? "" : msg, loc, "printed by the app"); }

    private boolean isAppFrame(String f) {
        return !(f.startsWith("java.") || f.startsWith("javax.") || f.startsWith("android.") || f.startsWith("com.android.") || f.startsWith("com.dashers.") || f.startsWith("dalvik.") || f.startsWith("libcore.") || f.startsWith("sun.") || f.startsWith("kotlin."));
    }

    /** An exception the runtime caught (uncaught in a callback, thread or startApp). */
    public void analyze(String where, Throwable t, String trace) {
        Throwable root = t;
        for (int i = 0; i < 8 && root.getCause() != null && root.getCause() != root; i++) root = root.getCause();
        String kind = root.getClass().getName();
        String msg = String.valueOf(root.getMessage());
        if (trace != null) {
            for (String ln : trace.split("\n")) {
                Matcher m = EXC_LINE.matcher(ln.trim());
                if (m.find()) { kind = m.group(1); msg = m.group(2) == null ? "" : m.group(2); }
                if (ln.indexOf("Caused by") < 0) break;
            }
        }
        String loc = null;
        if (trace != null) {
            for (String ln : trace.split("\n")) {
                Matcher at = AT_LINE.matcher(ln);
                if (at.find() && isAppFrame(at.group(1))) { loc = at.group(1); break; }
            }
        }
        classify(kind, "null".equals(msg) ? "" : msg, loc, where);
    }

    private boolean inJar(String dotted) { return app.files.containsKey(dotted.replace('.', '/') + ".class"); }

    private String caseMatch(String dotted) {
        String want = (dotted.replace('.', '/') + ".class").toLowerCase();
        for (String k : app.files.keySet()) if (k.toLowerCase().equals(want)) return k.substring(0, k.length() - 6).replace('/', '.');
        return null;
    }

    private void classify(String kind, String msg, String loc, String where) {
        String simple = kind.substring(kind.lastIndexOf('.') + 1);
        String at = loc == null ? "" : " in " + loc;
        String head = simple + (msg.length() > 0 ? ": " + msg : "") + at;
        String key = "ex:" + kind + ":" + msg + ":" + loc;
        String m = msg.replace('/', '.');

        if (simple.equals("NoClassDefFoundError") || simple.equals("ClassNotFoundException")) {
            String cls = m.trim();
            String how;
            if (cls.startsWith("javax.microedition.") || cls.startsWith("javax.bluetooth.") || cls.startsWith("javax.wireless.") || cls.startsWith("javax.obex.")) {
                Capabilities.Row r = Capabilities.forClass(cls);
                how = "The optional API " + cls + " is not provided by the built-in runtime" + (r != null ? " (" + r.status + ")" : "") + ".\nThe app needs a fallback (try/catch around it) or this feature stays unavailable.";
            } else if (cls.startsWith("com.nokia.") || cls.startsWith("com.siemens.") || cls.startsWith("com.samsung.") || cls.startsWith("com.motorola.") || cls.startsWith("com.sonyericsson.") || cls.startsWith("com.mascotcapsule.") || cls.startsWith("com.vodafone.")) {
                how = "Phone-maker extension " + cls + " is not provided by the built-in runtime.\nThe app only works if it catches this and continues without it.";
            } else if (inJar(cls)) {
                how = "The class IS in the jar but could not be loaded: look for a VerifyError / conversion warning earlier in this log.";
            } else if (caseMatch(cls) != null) {
                how = "The jar has \"" + caseMatch(cls) + "\" - the letter case of the class name differs from the code that uses it.";
            } else {
                how = "The class is not in the jar: a library was not packaged, or the class file was excluded by the build.";
            }
            note(ERROR, key, "Missing class" + (cls.length() > 0 ? " " + cls : "") + at + " (" + where + ")", how);
        } else if (simple.equals("NoSuchMethodError") || simple.equals("NoSuchFieldError") || simple.equals("AbstractMethodError") || simple.equals("IncompatibleClassChangeError") || simple.equals("UnsupportedApi")) {
            note(ERROR, key, "The app uses something the runtime does not implement: " + head + " (" + where + ")",
                    "Check Supported APIs in More. A MIDP method the runtime lacks has to be added to the emulator (send the report), or the app must avoid it.");
        } else if (simple.equals("VerifyError") || simple.equals("ClassFormatError") || simple.equals("UnsupportedClassVersionError") || simple.equals("ClassCircularityError")) {
            note(ERROR, key, "A class was rejected: " + head + " (" + where + ")",
                    "The bytecode is not accepted by the phone's runtime. Compile with -source 1.3/1.5 and -target 1.3/1.5, then preverify if needed, or switch Engine to Interpreter in More.");
        } else if (simple.equals("OutOfMemoryError")) {
            note(ERROR, key, "Out of memory" + at + " (" + where + ")", "The app loads more than the emulator's heap holds: big images or sound files, or arrays that are never released. Use smaller images or free them with null.");
        } else if (simple.equals("StackOverflowError")) {
            note(ERROR, key, "Stack overflow" + at + " (" + where + ")", "A method calls itself endlessly (or too deeply). Check recursion near " + (loc == null ? "the end of the trace" : loc) + ".");
        } else if (simple.equals("NullPointerException")) {
            int rm;
            synchronized (this) { rm = resourceMisses; }
            note(ERROR, key, "NullPointerException" + at + " (" + where + ")",
                    (rm > 0 ? "Likely cause: " + rm + " resource(s) were not found (see 'Resource not found' lines): code then uses a null image/stream.\n" : "")
                            + "Something is null when it is used" + (loc == null ? "." : " at " + loc + ".") + " Typical: an Image that failed to load, a record that does not exist yet, a Connector that returned null.");
        } else if (simple.equals("IOException") && m.startsWith("image resource not found")) {
            note(ERROR, key, "Image not found: " + msg.substring(msg.indexOf(':') + 1).trim() + at + " (" + where + ")", "Image.createImage(\"/name.png\") needs that exact path inside the jar (case-sensitive). See the 'Resource not found' line for a suggestion.");
        } else if (msg.startsWith("cannot decode image")) {
            note(ERROR, key, "An image could not be decoded" + at + " (" + where + ")", msg + "\nThe file is damaged, truncated, or not an image (a text/placeholder file renamed .png is common).");
        } else if (simple.equals("ConnectionNotFoundException") || (simple.equals("IOException") && (m.contains("network access is switched off") || m.contains("is not supported by the built-in emulator")))) {
            note(ERROR, key, "Connection problem: " + head + " (" + where + ")",
                    m.contains("switched off") ? "Network is off: More > Network access." : "Supported schemes: http, https, socket, ssl, serversocket, datagram and file:///root1/. Others (sms, btspp, comm, ...) are not available.");
        } else if (simple.startsWith("RecordStore")) {
            note(ERROR, key, "Record store problem: " + head + " (" + where + ")",
                    simple.equals("RecordStoreNotFoundException") ? "openRecordStore(name, false) was used before the store exists (normal on the very first run: the app should catch this and create it with true)." :
                    simple.equals("RecordStoreFullException") ? "The emulator's 1 MB quota per suite is full: More > Saved data (RMS) > Clear data." : "Check the store name and that it was opened before use and not closed twice.");
        } else if (simple.equals("SecurityException")) {
            note(ERROR, key, "Permission refused: " + head + " (" + where + ")", "Only file:///root1/ is reachable through FileConnection; other roots and protected APIs are refused.");
        } else if (simple.equals("InterruptedIOException") || simple.equals("SocketTimeoutException") || m.contains("timed out")) {
            note(ERROR, key, "Timeout: " + head + " (" + where + ")", "The server did not answer in 30 s. Check the address, that the phone is online, and Network access in More.");
        } else if (m.contains("unknown host") || m.contains("refused or unreachable") || m.contains("TLS/SSL")) {
            note(ERROR, key, "Network failure: " + head + " (" + where + ")", "Check the URL, the phone's internet connection and that the server accepts TLS 1.2+.");
        } else if (simple.equals("ArrayIndexOutOfBoundsException") || simple.equals("StringIndexOutOfBoundsException") || simple.equals("IndexOutOfBoundsException")) {
            note(ERROR, key, "Index out of range: " + head + " (" + where + ")", "An array/string/Vector index is wrong" + (loc == null ? "." : " at " + loc + ".") + " If it appears only at another screen size, the app may assume a fixed width/height: try More > Screen size with the size it was designed for.");
        } else if (simple.equals("ClassCastException")) {
            note(ERROR, key, "Wrong cast: " + head + " (" + where + ")", "An object is not of the type the code expects. If it involves a javax.microedition class, send the report: the runtime may return a different class than a real phone.");
        } else if (simple.equals("IllegalArgumentException") || simple.equals("IllegalStateException") || simple.equals("NumberFormatException") || simple.equals("ArithmeticException")) {
            note(ERROR, key, simple + (msg.length() > 0 ? ": " + msg : "") + at + " (" + where + ")", "The app passed a bad value to a method" + (loc == null ? "." : " at " + loc + "."));
        } else {
            note(ERROR, key, head + " (" + where + ")", loc == null ? "No app frame in the trace: the failure is inside the runtime or a library." : "First app frame: " + loc);
        }
    }

    // ---- report

    public synchronized String report() {
        StringBuilder sb = new StringBuilder();
        if (findings.isEmpty()) sb.append("No problems detected so far.\n");
        for (Finding f : findings.values()) {
            sb.append(f.severity == ERROR ? "[ERROR] " : f.severity == WARN ? "[WARN]  " : "[info]  ").append(f.title);
            if (f.count > 1) sb.append("  (x").append(f.count).append(')');
            sb.append('\n');
            if (f.advice != null) for (String l : f.advice.split("\n")) sb.append("    ").append(l).append('\n');
        }
        if (res != null) sb.append("Resources: ").append(res.hits()).append(" loaded, ").append(res.misses()).append(" missing, ").append(res.fuzzy()).append(" found only by ignoring case/folder\n");
        if (!unknownProps.isEmpty()) sb.append("System properties asked for but not defined: ").append(unknownProps).append('\n');
        return sb.toString();
    }
}
