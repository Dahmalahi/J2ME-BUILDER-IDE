package com.dashers.j2mebuilderide.emu.android;

import android.app.Activity;
import android.database.Cursor;
import android.provider.CalendarContract;
import android.provider.ContactsContract;

import com.dashers.j2mebuilderide.emu.midp.Contact;
import com.dashers.j2mebuilderide.emu.midp.Event;
import com.dashers.j2mebuilderide.emu.midp.PIM;
import com.dashers.j2mebuilderide.emu.midp.PimHost;
import com.dashers.j2mebuilderide.emu.midp.PimRecord;
import com.dashers.j2mebuilderide.emu.midp.PimStore;
import com.dashers.j2mebuilderide.emu.midp.RepeatRule;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

/**
 * Contacts and events for MIDlets. Default: the emulator's own sandbox (returns null, the runtime keeps its internal address
 * book). "Real" mode shows the phone's contacts and calendar READ-ONLY: READ_CONTACTS / READ_CALENDAR are asked at run time and
 * a dialog asks before anything is shared with the MIDlet; writes are refused. To-do lists are always sandbox. Needs a phone test.
 */
public final class AndroidPimHost implements PimHost {
    private static final int LIMIT = 3000;
    private final Activity act;
    private volatile boolean real;

    public AndroidPimHost(Activity a, boolean realMode) { act = a; real = realMode; }
    public void setReal(boolean on) { real = on; }
    public boolean real() { return real; }

    public PimStore store(int type) {
        if (!real || type == PIM.TODO_LIST) return null;
        return type == PIM.CONTACT_LIST ? new ContactsStore() : new CalendarStore();
    }

    private abstract class ReadOnly implements PimStore {
        public boolean readOnly() { return true; }
        public void save(List<PimRecord> items, LinkedHashSet<String> categories) throws IOException { throw new IOException("real phone data is read-only"); }

        final void allow(String perm, String what) {
            if (!Permissions.ensure(act, perm, 60000))
                throw new SecurityException("the " + perm.substring(perm.lastIndexOf('.') + 1) + " permission was refused - allow it in the phone's app settings, or use More > Contacts and calendar > Sandbox");
            if (!Ask.confirm(act, "Share " + what + "?", "A MIDlet wants to read your " + what + ". It can only read them, never change them.", "Share", "Don't share"))
                throw new SecurityException("the user refused to share the " + what + " with the MIDlet");
        }

        final String text(Cursor c, int i) {
            String s = c.isNull(i) ? null : c.getString(i);
            return s == null || s.length() == 0 ? null : s;
        }
    }

    private final class ContactsStore extends ReadOnly {
        public String name() { return "real phone contacts (read-only)"; }

        private int phoneAttr(int t) {
            switch (t) {
                case 1: return Contact.ATTR_HOME;
                case 2: return Contact.ATTR_MOBILE;
                case 3: return Contact.ATTR_WORK;
                case 4: return Contact.ATTR_WORK | Contact.ATTR_FAX;
                case 5: return Contact.ATTR_HOME | Contact.ATTR_FAX;
                case 6: return Contact.ATTR_PAGER;
                case 7: return Contact.ATTR_OTHER;
                case 12: return Contact.ATTR_PREFERRED;
                default: return 0;
            }
        }

        private int placeAttr(int t) { return t == 1 ? Contact.ATTR_HOME : t == 2 ? Contact.ATTR_WORK : t == 3 ? Contact.ATTR_OTHER : 0; }

        private void once(PimRecord r, int field, String v) {
            if (v != null && !r.fields.containsKey(Integer.valueOf(field))) r.add(field, v, 0);
        }

        public Snapshot load() throws IOException {
            allow("android.permission.READ_CONTACTS", "contacts");
            LinkedHashMap<Long, PimRecord> map = new LinkedHashMap<Long, PimRecord>();
            String D = ContactsContract.Data.CONTACT_ID;
            Cursor c = act.getContentResolver().query(ContactsContract.Data.CONTENT_URI,
                    new String[]{D, ContactsContract.Data.MIMETYPE, ContactsContract.Data.DATA1, ContactsContract.Data.DATA2, ContactsContract.Data.DATA3,
                        ContactsContract.Data.DATA4, ContactsContract.Data.DATA5, ContactsContract.Data.DATA6, ContactsContract.Data.DATA7,
                        ContactsContract.Data.DATA8, ContactsContract.Data.DATA9, ContactsContract.Data.DATA10},
                    null, null, D + " ASC");
            if (c == null) throw new IOException("the phone gave no access to the contacts");
            try {
                while (c.moveToNext()) {
                    long id = c.getLong(0);
                    PimRecord r = map.get(Long.valueOf(id));
                    if (r == null) {
                        if (map.size() >= LIMIT) break;
                        r = new PimRecord();
                        r.uid = String.valueOf(id);
                        map.put(Long.valueOf(id), r);
                    }
                    String mime = c.getString(1);
                    if (mime == null) continue;
                    if (mime.equals(ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE)) {
                        if (!r.fields.containsKey(Integer.valueOf(Contact.NAME)))
                            r.add(Contact.NAME, new String[]{text(c, 4), text(c, 3), text(c, 6), text(c, 5), text(c, 7)}, 0);   // family, given, middle, prefix, suffix
                        once(r, Contact.FORMATTED_NAME, text(c, 2));
                    } else if (mime.equals(ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE)) {
                        String n = text(c, 2);
                        if (n != null) r.add(Contact.TEL, n, phoneAttr(c.getInt(3)));
                    } else if (mime.equals(ContactsContract.CommonDataKinds.Email.CONTENT_ITEM_TYPE)) {
                        String n = text(c, 2);
                        int t = c.getInt(3);
                        if (n != null) r.add(Contact.EMAIL, n, t == 1 ? Contact.ATTR_HOME : t == 2 ? Contact.ATTR_WORK : Contact.ATTR_OTHER);
                    } else if (mime.equals(ContactsContract.CommonDataKinds.StructuredPostal.CONTENT_ITEM_TYPE)) {
                        r.add(Contact.ADDR, new String[]{text(c, 6), text(c, 7), text(c, 5), text(c, 8), text(c, 9), text(c, 10), text(c, 11)}, placeAttr(c.getInt(3)));
                    } else if (mime.equals(ContactsContract.CommonDataKinds.Organization.CONTENT_ITEM_TYPE)) {
                        once(r, Contact.ORG, text(c, 2));
                        once(r, Contact.TITLE, text(c, 5));
                    } else if (mime.equals(ContactsContract.CommonDataKinds.Note.CONTENT_ITEM_TYPE)) {
                        once(r, Contact.NOTE, text(c, 2));
                    } else if (mime.equals(ContactsContract.CommonDataKinds.Website.CONTENT_ITEM_TYPE)) {
                        String u = text(c, 2);
                        if (u != null) r.add(Contact.URL, u, 0);
                    } else if (mime.equals(ContactsContract.CommonDataKinds.Nickname.CONTENT_ITEM_TYPE)) {
                        once(r, Contact.NICKNAME, text(c, 2));
                    } else if (mime.equals(ContactsContract.CommonDataKinds.Event.CONTENT_ITEM_TYPE) && c.getInt(3) == ContactsContract.CommonDataKinds.Event.TYPE_BIRTHDAY) {
                        String d = text(c, 2);
                        if (d != null && !r.fields.containsKey(Integer.valueOf(Contact.BIRTHDAY))) {
                            try {
                                SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
                                f.setTimeZone(TimeZone.getTimeZone("UTC"));
                                r.add(Contact.BIRTHDAY, Long.valueOf(f.parse(d).getTime()), 0);
                            } catch (java.text.ParseException e) { /* birthday without a year */ }
                        }
                    }
                }
            } finally { c.close(); }
            return new Snapshot(new ArrayList<PimRecord>(map.values()), new LinkedHashSet<String>());
        }
    }

    private final class CalendarStore extends ReadOnly {
        public String name() { return "real phone calendar (read-only)"; }

        public Snapshot load() throws IOException {
            allow("android.permission.READ_CALENDAR", "calendar events");
            List<PimRecord> out = new ArrayList<PimRecord>();
            Cursor c = act.getContentResolver().query(CalendarContract.Events.CONTENT_URI,
                    new String[]{CalendarContract.Events._ID, CalendarContract.Events.TITLE, CalendarContract.Events.DTSTART, CalendarContract.Events.DTEND,
                        CalendarContract.Events.EVENT_LOCATION, CalendarContract.Events.DESCRIPTION, CalendarContract.Events.RRULE},
                    CalendarContract.Events.DELETED + " = 0", null, CalendarContract.Events.DTSTART + " DESC");
            if (c == null) throw new IOException("the phone gave no access to the calendar");
            try {
                while (c.moveToNext() && out.size() < LIMIT) {
                    PimRecord r = new PimRecord();
                    r.uid = String.valueOf(c.getLong(0));
                    String title = text(c, 1);
                    if (title != null) r.add(Event.SUMMARY, title, 0);
                    if (!c.isNull(2)) r.add(Event.START, Long.valueOf(c.getLong(2)), 0);
                    if (!c.isNull(3) && c.getLong(3) > 0) r.add(Event.END, Long.valueOf(c.getLong(3)), 0);
                    String loc = text(c, 4), note = text(c, 5);
                    if (loc != null) r.add(Event.LOCATION, loc, 0);
                    if (note != null) r.add(Event.NOTE, note, 0);
                    r.repeat = rule(text(c, 6));
                    out.add(r);
                }
            } finally { c.close(); }
            return new Snapshot(out, new LinkedHashSet<String>());
        }

        /** FREQ, INTERVAL and COUNT of an RFC 5545 rule; anything else is ignored. */
        private RepeatRule rule(String rrule) {
            if (rrule == null) return null;
            try {
                RepeatRule rr = new RepeatRule();
                boolean freq = false;
                for (String part : rrule.split(";")) {
                    int e = part.indexOf('=');
                    if (e < 0) continue;
                    String k = part.substring(0, e), v = part.substring(e + 1);
                    if (k.equals("FREQ")) {
                        int f = v.equals("DAILY") ? RepeatRule.DAILY : v.equals("WEEKLY") ? RepeatRule.WEEKLY : v.equals("MONTHLY") ? RepeatRule.MONTHLY : v.equals("YEARLY") ? RepeatRule.YEARLY : 0;
                        if (f != 0) { rr.setInt(RepeatRule.FREQUENCY, f); freq = true; }
                    } else if (k.equals("INTERVAL")) rr.setInt(RepeatRule.INTERVAL, Integer.parseInt(v));
                    else if (k.equals("COUNT")) rr.setInt(RepeatRule.COUNT, Integer.parseInt(v));
                }
                return freq ? rr : null;
            } catch (RuntimeException e) { return null; }
        }
    }
}
