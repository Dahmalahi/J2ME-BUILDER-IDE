package com.dashers.j2mebuilderide.emu.midp;

public interface ConditionListener {
    void conditionMet(SensorConnection a0, Data a1, Condition a2);
}
