package com.dashers.j2mebuilderide.emu;

/** A problem with the jar/JAD handed to the runtime (reported to the user, not a crash). */
public class EmuException extends Exception {
    public EmuException(String m) { super(m); }
}
