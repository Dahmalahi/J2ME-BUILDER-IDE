package com.dashers.j2mebuilderide.emu.midp;

public class FieldEmptyException extends RuntimeException {
    private final int field;
    public FieldEmptyException() { super(); field = -1; }
    public FieldEmptyException(String m) { super(m); field = -1; }
    public FieldEmptyException(String m, int field) { super(m); this.field = field; }
    public int getField() { return field; }
}
