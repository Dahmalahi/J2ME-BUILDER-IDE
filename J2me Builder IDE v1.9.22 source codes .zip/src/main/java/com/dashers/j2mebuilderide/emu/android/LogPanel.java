package com.dashers.j2mebuilderide.emu.android;

import android.content.Context;
import android.graphics.Typeface;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.dashers.j2mebuilderide.emu.ConsoleLog;
import com.dashers.j2mebuilderide.emu.Diagnostics;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** The emulator's log viewer: coloured lines with relative time, filter chips (All / Warnings / Errors / Analysis), copy, clear, enlarge. */
final class LogPanel {
    static final int F_ALL = 0, F_WARN = 1, F_ERR = 2, F_ANALYSIS = 3;

    interface Host { void copyText(String text); void sizeChanged(boolean big); void countsChanged(int errors, int warnings); }

    private static final class Row {
        final long time; final int level; final String text;
        Row(long time, int level, String text) { this.time = time; this.level = level; this.text = text; }
        boolean analysis() { return text.startsWith(Diagnostics.TAG); }
    }

    private final Context ctx;
    private final Host host;
    private final LinearLayout root;
    private final TextView body;
    private final ScrollView scroll;
    private final TextView[] chips = new TextView[4];
    private final ArrayList<Row> rows = new ArrayList<Row>();
    private final SpannableStringBuilder shown = new SpannableStringBuilder();
    private int filter = F_ALL, errors, warnings;
    private long t0;
    private boolean big, refreshPending;
    private final android.os.Handler ui = new android.os.Handler(android.os.Looper.getMainLooper());

    LogPanel(Context c, Host h) {
        ctx = c;
        host = h;
        root = new LinearLayout(c);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(Ui.glassPanel(c, 22));
        root.setPadding(Ui.dp(c, 8), Ui.dp(c, 8), Ui.dp(c, 8), Ui.dp(c, 6));

        LinearLayout bar = new LinearLayout(c);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(android.view.Gravity.CENTER_VERTICAL);
        HorizontalScrollView hs = new HorizontalScrollView(c);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout chipRow = new LinearLayout(c);
        chipRow.setOrientation(LinearLayout.HORIZONTAL);
        String[] names = {"All", "Warnings", "Errors", "Analysis"};
        for (int i = 0; i < 4; i++) {
            final int f = i;
            chips[i] = Ui.chip(c, names[i], new View.OnClickListener() { public void onClick(View v) { setFilter(f); } });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.rightMargin = Ui.dp(c, 5);
            chipRow.addView(chips[i], lp);
        }
        chips[0].setSelected(true);
        hs.addView(chipRow);
        bar.addView(hs, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView copy = Ui.chip(c, "Copy", new View.OnClickListener() { public void onClick(View v) { host.copyText(visibleText()); } });
        TextView clear = Ui.chip(c, "Clear", new View.OnClickListener() { public void onClick(View v) { clear(); } });
        final TextView size = Ui.chip(c, "Expand", null);
        size.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { big = !big; size.setText(big ? "Shrink" : "Expand"); host.sizeChanged(big); } });
        for (TextView t : new TextView[]{copy, clear, size}) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.leftMargin = Ui.dp(c, 5);
            bar.addView(t, lp);
        }
        root.addView(bar);

        scroll = new ScrollView(c);
        body = new TextView(c);
        body.setTypeface(Typeface.MONOSPACE);
        body.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        body.setTextColor(Ui.TEXT);
        body.setLineSpacing(0, 1.12f);
        body.setPadding(Ui.dp(c, 6), Ui.dp(c, 6), Ui.dp(c, 6), Ui.dp(c, 6));
        body.setTextIsSelectable(true);
        scroll.addView(body);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        sp.topMargin = Ui.dp(c, 6);
        root.addView(scroll, sp);
    }

    View view() { return root; }

    void add(long time, int level, String text) {
        if (rows.isEmpty()) t0 = time;
        Row r = new Row(time, level, text);
        rows.add(r);
        if (rows.size() > 3000) { rows.remove(0); }
        if (level == ConsoleLog.ERROR) errors++;
        else if (level == ConsoleLog.WARN && !r.analysis()) warnings++;
        host.countsChanged(errors, warnings);
        if (passes(r)) { append(r); scheduleRefresh(); }
    }

    private boolean passes(Row r) {
        switch (filter) {
            case F_WARN: return r.level >= ConsoleLog.WARN && !r.analysis() || r.analysis();
            case F_ERR: return r.level == ConsoleLog.ERROR;
            case F_ANALYSIS: return r.analysis();
            default: return true;
        }
    }

    private void append(Row r) {
        int color;
        String tag;
        if (r.analysis()) { color = Ui.HINT; tag = ""; }
        else if (r.level == ConsoleLog.ERROR) { color = Ui.ERR; tag = "E "; }
        else if (r.level == ConsoleLog.WARN) { color = Ui.WARN; tag = "W "; }
        else if (r.level == ConsoleLog.DEBUG) { color = Ui.MUTED; tag = "D "; }
        else { color = Ui.TEXT; tag = "  "; }
        String time = String.format(Locale.US, "+%5.1fs ", Math.max(0, r.time - t0) / 1000.0);
        int start = shown.length();
        String text = r.analysis() ? "\u25B8 " + r.text.substring(Diagnostics.TAG.length()) : r.text;
        shown.append(time).append(tag).append(text).append('\n');
        shown.setSpan(new ForegroundColorSpan(Ui.MUTED), start, start + time.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        shown.setSpan(new ForegroundColorSpan(color), start + time.length(), shown.length() - 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        if (shown.length() > 90000) shown.delete(0, shown.length() - 60000);
    }

    private void scheduleRefresh() {
        if (refreshPending) return;
        refreshPending = true;
        ui.postDelayed(new Runnable() {
            public void run() {
                refreshPending = false;
                body.setText(shown);
                scroll.post(new Runnable() { public void run() { scroll.fullScroll(View.FOCUS_DOWN); } });
            }
        }, 80);
    }

    void setFilter(int f) {
        filter = f;
        for (int i = 0; i < chips.length; i++) chips[i].setSelected(i == f);
        shown.clear();
        for (Row r : rows) if (passes(r)) append(r);
        scheduleRefresh();
    }

    void clear() {
        rows.clear();
        shown.clear();
        errors = 0;
        warnings = 0;
        host.countsChanged(0, 0);
        body.setText("");
    }

    private String visibleText() {
        StringBuilder sb = new StringBuilder();
        for (Row r : rows) if (passes(r)) sb.append(r.analysis() ? r.text : (r.level == ConsoleLog.ERROR ? "E " : r.level == ConsoleLog.WARN ? "W " : "I ") + r.text).append('\n');
        return sb.toString();
    }

    void showAnalysis() { setFilter(F_ANALYSIS); }
}
