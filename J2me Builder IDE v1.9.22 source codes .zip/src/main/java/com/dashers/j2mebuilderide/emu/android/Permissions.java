package com.dashers.j2mebuilderide.emu.android;

import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Looper;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/** Asks for a dangerous permission the first time a MIDlet needs it, from a non-UI thread, and waits for the user's answer. */
final class Permissions {
    private static final int REQ = 4217;
    private static final Object LOCK = new Object();
    private static CountDownLatch pending;

    private Permissions() { }

    static boolean has(Context c, String perm) {
        return Build.VERSION.SDK_INT < 23 || c.checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED;
    }

    /** True when the permission is granted (asking if needed). Never blocks the UI thread: there it only reports the current state. */
    static boolean ensure(final Activity a, final String perm, long timeoutMs) {
        if (has(a, perm)) return true;
        if (Looper.myLooper() == Looper.getMainLooper()) return false;
        final CountDownLatch latch;
        boolean request = false;
        synchronized (LOCK) {
            if (pending == null || pending.getCount() == 0) { pending = new CountDownLatch(1); request = true; }
            latch = pending;
        }
        if (request) a.runOnUiThread(new Runnable() { public void run() { a.requestPermissions(new String[]{perm}, REQ); } });
        try { latch.await(timeoutMs, TimeUnit.MILLISECONDS); } catch (InterruptedException e) { return false; }
        return has(a, perm);
    }

    /** Call from Activity.onRequestPermissionsResult. */
    static void onResult(int requestCode) {
        if (requestCode != REQ) return;
        synchronized (LOCK) { if (pending != null) pending.countDown(); }
    }
}
