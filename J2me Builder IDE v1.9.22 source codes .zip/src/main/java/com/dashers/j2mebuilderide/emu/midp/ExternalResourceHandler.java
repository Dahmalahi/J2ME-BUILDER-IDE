package com.dashers.j2mebuilderide.emu.midp;

public interface ExternalResourceHandler {
    void requestResource(ScalableImage image, String uri);
}
