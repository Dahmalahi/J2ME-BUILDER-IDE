package com.dashers.j2mebuilderide.emu;

import com.dashers.j2mebuilderide.emu.midp.Device;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/** Record stores as files in one directory (one directory per MIDlet suite, so suites cannot touch each other). */
public final class FileStorage implements Device.Storage {
    private final File dir;

    public FileStorage(File dir) { this.dir = dir; }

    private static String hex(String s) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length(); i++) sb.append(String.format("%04x", (int) s.charAt(i)));
        return sb.toString();
    }
    private static String unhex(String h) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i + 4 <= h.length(); i += 4) sb.append((char) Integer.parseInt(h.substring(i, i + 4), 16));
        return sb.toString();
    }
    private File file(String name) { return new File(dir, hex(name) + ".rms"); }

    public synchronized byte[] read(String name) {
        File f = file(name);
        if (!f.isFile()) return null;
        try {
            FileInputStream in = new FileInputStream(f);
            try {
                byte[] b = new byte[(int) f.length()];
                int n = 0, r;
                while (n < b.length && (r = in.read(b, n, b.length - n)) > 0) n += r;
                return b;
            } finally { in.close(); }
        } catch (IOException e) { return null; }
    }

    public synchronized void write(String name, byte[] data) {
        dir.mkdirs();
        File tmp = new File(dir, hex(name) + ".tmp"), f = file(name);
        try {
            FileOutputStream o = new FileOutputStream(tmp);
            try { o.write(data); o.getFD().sync(); } finally { o.close(); }
            if (!tmp.renameTo(f)) { f.delete(); if (!tmp.renameTo(f)) throw new IOException("rename failed"); }
        } catch (IOException e) {
            tmp.delete();
            throw new RuntimeException("cannot write record store " + name + ": " + e.getMessage());
        }
    }

    public synchronized boolean delete(String name) { return file(name).delete(); }

    public synchronized String[] list() {
        List<String> r = new ArrayList<String>();
        File[] fs = dir.listFiles();
        if (fs != null) for (File f : fs) if (f.getName().endsWith(".rms")) r.add(unhex(f.getName().substring(0, f.getName().length() - 4)));
        java.util.Collections.sort(r);
        return r.toArray(new String[0]);
    }

    /** Deletes every record store of this suite (development "clear application data"). */
    public synchronized int clear() {
        int n = 0;
        File[] fs = dir.listFiles();
        if (fs != null) for (File f : fs) if (f.delete()) n++;
        return n;
    }
}
