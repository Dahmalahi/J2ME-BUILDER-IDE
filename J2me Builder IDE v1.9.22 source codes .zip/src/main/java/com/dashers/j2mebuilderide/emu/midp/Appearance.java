package com.dashers.j2mebuilderide.emu.midp;

/** Generated from the JSR-184 class list (tools in docs); properties are stored, rendering lives in Graphics3D. */
public class Appearance extends Object3D {

    CompositingMode compositingMode;
    Fog fog;
    PolygonMode polygonMode;
    int layer;
    Material material;
    public Appearance() { }

    private final Texture2D[] textures = new Texture2D[8];
    public void setTexture(int unit, Texture2D t) { if (unit < 0 || unit >= 8) throw new IndexOutOfBoundsException("texture unit " + unit); textures[unit] = t; }
    public Texture2D getTexture(int unit) { if (unit < 0 || unit >= 8) throw new IndexOutOfBoundsException("texture unit " + unit); return textures[unit]; }
    public void setCompositingMode(CompositingMode v) { compositingMode = v; }
    public CompositingMode getCompositingMode() { return compositingMode; }
    public void setFog(Fog v) { fog = v; }
    public Fog getFog() { return fog; }
    public void setPolygonMode(PolygonMode v) { polygonMode = v; }
    public PolygonMode getPolygonMode() { return polygonMode; }
    public void setLayer(int v) { layer = v; }
    public int getLayer() { return layer; }
    public void setMaterial(Material v) { material = v; }
    public Material getMaterial() { return material; }
}
