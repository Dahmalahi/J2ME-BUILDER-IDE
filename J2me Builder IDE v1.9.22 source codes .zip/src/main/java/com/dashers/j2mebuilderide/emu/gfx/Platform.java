package com.dashers.j2mebuilderide.emu.gfx;

import java.io.IOException;

/**
 * The only places where the runtime needs the host OS: text rasterisation and image decoding.
 * Android supplies an implementation backed by Paint / BitmapFactory; tests use a deterministic one.
 */
public interface Platform {

    /** Coverage mask (0..255 per pixel, row-major) of a rendered string. */
    final class Mask {
        public final int w, h;
        public final int[] alpha;
        public Mask(int w, int h, int[] alpha) { this.w = w; this.h = h; this.alpha = alpha; }
    }

    /** Decoded image pixels (non-premultiplied ARGB). */
    final class Pixels {
        public final int w, h;
        public final int[] argb;
        public Pixels(int w, int h, int[] argb) { this.w = w; this.h = h; this.argb = argb; }
    }

    int stringWidth(String s, int face, int style, int size);
    int fontHeight(int face, int style, int size);
    int fontBaseline(int face, int style, int size);
    /** Renders s; the mask is stringWidth x fontHeight, baseline at fontBaseline. */
    Mask renderString(String s, int face, int style, int size);
    Pixels decodeImage(byte[] data) throws IOException;
}
