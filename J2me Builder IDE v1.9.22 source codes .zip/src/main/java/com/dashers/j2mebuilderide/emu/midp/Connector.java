package com.dashers.j2mebuilderide.emu.midp;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class Connector {
    public static final int READ = 1, WRITE = 2, READ_WRITE = 3;
    private Connector() { }

    public static Connection open(String name) throws IOException { return open(name, READ_WRITE, false); }
    public static Connection open(String name, int mode) throws IOException { return open(name, mode, false); }

    /** Operator / device parameters old MIDlets append to URLs (BlackBerry, Nokia, SonyEricsson ...); meaningless here. */
    private static final String[] JUNK = {"deviceside", "interface", "apn", "connectionuid", "connectiontype", "wapgatewayip",
            "wapgatewayapn", "tunnelauthusername", "tunnelauthpassword", "tunnelauthtype", "ppp_username", "ppp_password",
            "bearer", "wapsource", "dnsa", "dnsb", "ratio"};

    static String cleanUrl(String url) {
        int i = url.indexOf(';');
        if (i < 0) return url;
        StringBuilder sb = new StringBuilder(url.substring(0, i));
        String[] parts = url.substring(i + 1).split(";");
        for (String p : parts) {
            int e = p.indexOf('=');
            String k = (e < 0 ? p : p.substring(0, e)).trim().toLowerCase();
            boolean junk = false;
            for (String j : JUNK) if (k.equals(j)) { junk = true; break; }
            if (!junk && p.length() > 0) sb.append(';').append(p);
        }
        return sb.toString();
    }

    public static Connection open(String name, int mode, boolean timeouts) throws IOException {
        if (name == null) throw new IllegalArgumentException("null URL");
        name = name.trim();
        int c = name.indexOf(':');
        if (c <= 0) throw new IllegalArgumentException("not a URL: " + name);
        String scheme = name.substring(0, c).toLowerCase();
        Device d = Device.current();
        if (scheme.equals("file")) return new FileImpl(d, name, mode);
        if (scheme.equals("sms")) return new SmsConn(d, name);
        if (scheme.equals("sensor")) return d.sensorHub().open(name);
        if (scheme.equals("btspp")) return BtConnect.open(d, name);
        if (scheme.equals("sip") || scheme.equals("sips")) throw new ConnectionNotFoundException("SIP (JSR-180, " + scheme + ":) is not supported by the built-in emulator");
        if (scheme.equals("btl2cap")) throw new ConnectionNotFoundException("L2CAP (btl2cap://) is not supported by the built-in emulator, only btspp:// (RFCOMM serial port)");
        if (scheme.equals("btgoep") || scheme.equals("irdaobex") || scheme.equals("tcpobex")) throw new ConnectionNotFoundException("OBEX (" + scheme + "://) is not supported by the built-in emulator");
        if (scheme.equals("mms")) throw new ConnectionNotFoundException("MMS (mms://) is not supported by the built-in emulator, only sms://");
        boolean net = scheme.equals("http") || scheme.equals("https") || scheme.equals("socket") || scheme.equals("ssl")
                || scheme.equals("serversocket") || scheme.equals("datagram");
        if (!net) throw new ConnectionNotFoundException("protocol \"" + scheme + "\" is not supported by the built-in emulator");
        if (!d.networkAllowed) {
            d.log(2, "Blocked " + scheme + " connection to " + name + ": network access is switched off (More > Network access)");
            throw new ConnectionNotFoundException("network access is switched off for the built-in emulator");
        }
        String url = cleanUrl(name);
        d.log(0, "open " + url);
        try {
            if (scheme.equals("http") || scheme.equals("https")) return new HttpImpl(d, url);
            String rest = url.substring(c + 3);
            boolean server = scheme.equals("serversocket") || (scheme.equals("socket") && rest.startsWith(":"));
            if (server) return new ServerSocketImpl(url);
            if (scheme.equals("datagram")) return new UdpImpl(url);
            return new SocketImpl(url);
        } catch (IOException e) {
            d.log(2, "Cannot open " + url + ": " + e.getMessage());
            throw e;
        }
    }

    public static InputStream openInputStream(String name) throws IOException {
        Connection c = open(name, READ);
        try { return ((InputConnection) c).openInputStream(); } finally { /* the stream keeps the connection alive */ }
    }
    public static DataInputStream openDataInputStream(String name) throws IOException { return new DataInputStream(openInputStream(name)); }
    public static OutputStream openOutputStream(String name) throws IOException { return ((OutputConnection) open(name, WRITE)).openOutputStream(); }
    public static DataOutputStream openDataOutputStream(String name) throws IOException { return new DataOutputStream(openOutputStream(name)); }
}
