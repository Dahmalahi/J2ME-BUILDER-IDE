package com.dashers.j2mebuilderide.emu.midp;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

public interface Datagram extends DataInput, DataOutput {
    String getAddress();
    byte[] getData();
    int getLength();
    int getOffset();
    void reset();
    void setAddress(String addr) throws IOException;
    void setAddress(Datagram reference);
    void setData(byte[] buffer, int offset, int len);
    void setLength(int len);
}
