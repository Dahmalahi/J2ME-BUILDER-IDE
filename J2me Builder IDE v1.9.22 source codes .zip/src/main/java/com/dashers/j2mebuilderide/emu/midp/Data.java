package com.dashers.j2mebuilderide.emu.midp;

public interface Data {
    ChannelInfo getChannelInfo();
    double[] getDoubleValues();
    int[] getIntValues();
    java.lang.Object[] getObjectValues();
    long getTimestamp(int a0);
    float getUncertainty(int a0);
    boolean isValid(int a0);
}
