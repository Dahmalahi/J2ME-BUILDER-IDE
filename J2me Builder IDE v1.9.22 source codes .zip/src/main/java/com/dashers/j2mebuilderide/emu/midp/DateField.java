package com.dashers.j2mebuilderide.emu.midp;

import com.dashers.j2mebuilderide.emu.gfx.Frame;

import java.text.SimpleDateFormat;
import java.util.Date;

public class DateField extends Item {
    public static final int DATE = 1, TIME = 2, DATE_TIME = 3;
    private int mode;
    private Date date;
    private final java.util.TimeZone zone;

    public DateField(String label, int mode) { this(label, mode, null); }
    public DateField(String label, int mode, java.util.TimeZone tz) {
        super(label);
        if (mode < DATE || mode > DATE_TIME) throw new IllegalArgumentException("mode");
        this.mode = mode; zone = tz == null ? java.util.TimeZone.getDefault() : tz;
    }
    public Date getDate() { return date == null ? null : new Date(date.getTime()); }
    public void setDate(Date d) { date = d == null ? null : new Date(d.getTime()); changed(); }
    public int getInputMode() { return mode; }
    public void setInputMode(int m) { if (m < DATE || m > DATE_TIME) throw new IllegalArgumentException("mode"); mode = m; changed(); }

    private String pattern() { return mode == DATE ? "yyyy-MM-dd" : mode == TIME ? "HH:mm" : "yyyy-MM-dd HH:mm"; }
    private SimpleDateFormat fmt() { SimpleDateFormat f = new SimpleDateFormat(pattern()); f.setTimeZone(zone); f.setLenient(false); return f; }

    @Override boolean focusable() { return true; }
    @Override void activate(Device d) {
        d.requestText(getLabel(), date == null ? "" : fmt().format(date), 16, TextField.ANY, new Device.TextResult() {
            public void accept(String s) {
                try { date = fmt().parse(s.trim()); changed(); notifyStateChanged(); }
                catch (java.text.ParseException e) { Device.current().log(2, "DateField: \"" + s + "\" does not match " + pattern()); }
            }
        });
    }
    @Override int paint(Device d, Frame f, int x, int y, int w, boolean focused) {
        int y0 = y;
        y = paintLabel(d, f, x, y, w);
        int h = Draw.lineHeight(d, false) + 4;
        f.fillRect(x, y, w, h, 0xFFFFFF);
        f.drawRect(x, y, w - 1, h - 1, focused ? 0x1F4E8C : 0x888888);
        Draw.text(d, f, date == null ? "(not set)" : fmt().format(date), x + 3, y + 2, date == null ? 0x888888 : 0, false);
        return y + h - y0;
    }
}
