package com.dashers.j2mebuilderide.emu.midp;

public interface CommandListener {
    void commandAction(Command c, Displayable d);
}
