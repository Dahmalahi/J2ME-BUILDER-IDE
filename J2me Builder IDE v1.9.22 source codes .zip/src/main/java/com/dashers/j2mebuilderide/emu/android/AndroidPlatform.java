package com.dashers.j2mebuilderide.emu.android;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;

import com.dashers.j2mebuilderide.emu.gfx.Platform;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/** Text rendering and image decoding for the built-in emulator, backed by android.graphics. */
public final class AndroidPlatform implements Platform {
    private final Map<Integer, Paint> paints = new HashMap<Integer, Paint>();

    private synchronized Paint paint(int face, int style, int size) {
        int key = face * 100000 + style * 1000 + size;
        Paint p = paints.get(key);
        if (p == null) {
            p = new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setColor(0xFFFFFFFF);
            Typeface base = face == 32 ? Typeface.MONOSPACE : face == 64 ? Typeface.SERIF : Typeface.SANS_SERIF;
            int st = ((style & 1) != 0 ? Typeface.BOLD : 0) | ((style & 2) != 0 ? Typeface.ITALIC : 0);
            p.setTypeface(Typeface.create(base, st));
            p.setTextSize(size == 8 ? 10 : size == 16 ? 17 : 13);
            p.setUnderlineText((style & 4) != 0);
            paints.put(key, p);
        }
        return p;
    }

    public int stringWidth(String s, int face, int style, int size) {
        return (int) Math.ceil(paint(face, style, size).measureText(s));
    }

    public int fontHeight(int face, int style, int size) {
        Paint.FontMetrics m = paint(face, style, size).getFontMetrics();
        return (int) Math.ceil(m.descent - m.ascent);
    }

    public int fontBaseline(int face, int style, int size) {
        return (int) Math.ceil(-paint(face, style, size).getFontMetrics().ascent);
    }

    public Mask renderString(String s, int face, int style, int size) {
        Paint p = paint(face, style, size);
        int w = Math.max(1, stringWidth(s, face, style, size)), h = Math.max(1, fontHeight(face, style, size));
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        try {
            new Canvas(b).drawText(s, 0, fontBaseline(face, style, size), p);
            int[] px = new int[w * h];
            b.getPixels(px, 0, w, 0, 0, w, h);
            for (int i = 0; i < px.length; i++) px[i] = px[i] >>> 24;
            return new Mask(w, h, px);
        } finally {
            b.recycle();
        }
    }

    public Pixels decodeImage(byte[] data) throws IOException {
        Bitmap b = BitmapFactory.decodeByteArray(data, 0, data.length);
        if (b == null) throw new IOException("unsupported or corrupt image data");
        try {
            int w = b.getWidth(), h = b.getHeight();
            int[] px = new int[w * h];
            b.getPixels(px, 0, w, 0, 0, w, h);
            return new Pixels(w, h, px);
        } finally {
            b.recycle();
        }
    }
}
