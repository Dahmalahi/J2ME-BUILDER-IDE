package com.dashers.j2mebuilderide.emu.midp;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.LinkedList;

/** A one-way byte channel with blocking reads: what the simulated device echoes back. */
final class BtLoop {
    private final LinkedList<byte[]> chunks = new LinkedList<byte[]>();
    private int off;
    private boolean closed;

    final InputStream in = new InputStream() {
        public int read() throws IOException {
            byte[] b = new byte[1];
            return read(b, 0, 1) < 0 ? -1 : b[0] & 0xFF;
        }

        public int read(byte[] b, int o, int len) throws IOException {
            if (len == 0) return 0;
            synchronized (BtLoop.this) {
                while (chunks.isEmpty()) {
                    if (closed) return -1;
                    try { BtLoop.this.wait(); } catch (InterruptedException e) { throw new java.io.InterruptedIOException("interrupted"); }
                }
                byte[] c = chunks.getFirst();
                int n = Math.min(len, c.length - off);
                System.arraycopy(c, off, b, o, n);
                off += n;
                if (off >= c.length) { chunks.removeFirst(); off = 0; }
                return n;
            }
        }

        public int available() { synchronized (BtLoop.this) { return chunks.isEmpty() ? 0 : chunks.getFirst().length - off; } }
        public void close() { BtLoop.this.close(); }
    };

    final OutputStream out = new OutputStream() {
        public void write(int v) throws IOException { write(new byte[]{(byte) v}, 0, 1); }

        public void write(byte[] b, int o, int len) throws IOException {
            synchronized (BtLoop.this) {
                if (closed) throw new IOException("the Bluetooth link is closed");
                if (len > 0) { byte[] c = new byte[len]; System.arraycopy(b, o, c, 0, len); chunks.addLast(c); BtLoop.this.notifyAll(); }
            }
        }

        public void close() { BtLoop.this.close(); }
    };

    synchronized void close() { closed = true; notifyAll(); }
}
