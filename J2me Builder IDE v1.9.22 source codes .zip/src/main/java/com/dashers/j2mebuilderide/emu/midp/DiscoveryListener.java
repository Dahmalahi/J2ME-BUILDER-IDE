package com.dashers.j2mebuilderide.emu.midp;

public interface DiscoveryListener {
    int INQUIRY_COMPLETED = 0;
    int INQUIRY_TERMINATED = 5;
    int INQUIRY_ERROR = 7;
    int SERVICE_SEARCH_COMPLETED = 1;
    int SERVICE_SEARCH_TERMINATED = 2;
    int SERVICE_SEARCH_ERROR = 3;
    int SERVICE_SEARCH_NO_RECORDS = 4;
    int SERVICE_SEARCH_DEVICE_NOT_REACHABLE = 6;
    void deviceDiscovered(RemoteDevice a0, DeviceClass a1);
    void servicesDiscovered(int a0, ServiceRecord[] a1);
    void serviceSearchCompleted(int a0, int a1);
    void inquiryCompleted(int a0);
}
