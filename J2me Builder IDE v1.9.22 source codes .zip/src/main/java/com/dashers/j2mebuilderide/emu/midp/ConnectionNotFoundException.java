package com.dashers.j2mebuilderide.emu.midp;

public class ConnectionNotFoundException extends java.io.IOException {
    public ConnectionNotFoundException() { super(); }
    public ConnectionNotFoundException(String m) { super(m); }
}
