package com.dashers.j2mebuilderide.emu.midp;

import java.io.IOException;

/** btspp://localhost:UUID service: waits for a device to connect. */
final class BtServerConn implements StreamConnectionNotifier {
    private final BtState st;
    private final BluetoothProvider.Server server;
    final ServiceRecordImpl record;
    private boolean closed;

    BtServerConn(BtState st, BluetoothProvider.Server server, ServiceRecordImpl record) { this.st = st; this.server = server; this.record = record; st.add(this); }

    public StreamConnection acceptAndOpen() throws IOException {
        synchronized (this) { if (closed) throw new IOException("the service is closed"); }
        st.device.log(0, "Bluetooth service " + record.uuid + " waits for a device");
        BluetoothProvider.Link l = server.accept();
        st.device.log(0, "Bluetooth device " + l.remoteAddress() + " connected to service " + record.uuid);
        return new BtStream(st, l);
    }

    public void close() throws IOException {
        synchronized (this) { if (closed) return; closed = true; }
        st.remove(this);
        server.close();
    }
}
