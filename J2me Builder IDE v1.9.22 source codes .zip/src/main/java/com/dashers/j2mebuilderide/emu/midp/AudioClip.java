package com.dashers.j2mebuilderide.emu.midp;

import java.io.ByteArrayInputStream;
import java.io.IOException;

/** Samsung com.samsung.util.AudioClip: MP3 and MIDI are played; MMF (Yamaha) is not supported. volume 0..5, loop 0 = until stopped. */
public class AudioClip {
    public static final int TYPE_MMF = 1, TYPE_MP3 = 2, TYPE_MIDI = 3;
    private Player player;
    private final Device device = Device.current();

    public AudioClip(int type, byte[] audioData, int audioOffset, int audioLength) {
        if (audioData == null) throw new NullPointerException("audioData");
        if (audioOffset < 0 || audioLength < 0 || audioOffset + audioLength > audioData.length) throw new IllegalArgumentException("bad offset/length");
        open(type, new ByteArrayInputStream(audioData, audioOffset, audioLength));
    }

    public AudioClip(int type, String filename) throws IOException {
        if (filename == null) throw new NullPointerException("filename");
        byte[] b = device.resource(filename);
        if (b == null) throw new IOException("audio file not found: " + filename);
        open(type, new ByteArrayInputStream(b));
    }

    private void open(int type, java.io.InputStream in) {
        String mime = type == TYPE_MP3 ? "audio/mpeg" : type == TYPE_MIDI ? "audio/midi" : null;
        if (mime == null) {
            if (type == TYPE_MMF) device.log(1, "Samsung MMF audio is not supported: this clip stays silent");
            else throw new IllegalArgumentException("unknown audio type " + type);
            return;
        }
        try {
            player = Manager.createPlayer(in, mime);
            player.realize();
        } catch (IOException e) { throw new IllegalArgumentException("cannot read the audio data: " + e.getMessage()); }
        catch (MediaException e) { throw new IllegalArgumentException("cannot use the audio data: " + e.getMessage()); }
    }

    public static boolean isSupported() { return true; }

    public synchronized void play(int loop, int volume) {
        if (loop < 0) throw new IllegalArgumentException("negative loop");
        if (volume < 0 || volume > 5) throw new IllegalArgumentException("volume must be 0..5");
        if (player == null) return;
        try {
            player.setLoopCount(loop == 0 ? -1 : loop);
            Control c = player.getControl("VolumeControl");
            if (c instanceof VolumeControl) ((VolumeControl) c).setLevel(volume * 20);
            player.start();
        } catch (MediaException e) { device.log(2, "AudioClip.play failed: " + e.getMessage()); }
    }

    public synchronized void pause() { try { if (player != null) player.stop(); } catch (MediaException e) { /* already stopped */ } }
    public synchronized void resume() { try { if (player != null) player.start(); } catch (MediaException e) { device.log(2, "AudioClip.resume failed: " + e.getMessage()); } }
    public synchronized void stop() {
        try { if (player != null) { player.stop(); player.setMediaTime(0); } } catch (MediaException e) { /* already stopped */ }
    }
}
