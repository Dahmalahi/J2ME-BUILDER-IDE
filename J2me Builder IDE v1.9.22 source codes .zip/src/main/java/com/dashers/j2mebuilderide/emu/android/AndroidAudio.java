package com.dashers.j2mebuilderide.emu.android;

import android.content.Context;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.graphics.PixelFormat;
import android.media.Image;
import android.media.ImageReader;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.os.HandlerThread;
import android.os.Handler;
import android.os.Looper;

import com.dashers.j2mebuilderide.emu.midp.Audio;
import com.dashers.j2mebuilderide.emu.midp.FrameSource;
import com.dashers.j2mebuilderide.emu.midp.VideoHost;
import com.dashers.j2mebuilderide.emu.midp.VideoSeek;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

/** Sound output for the built-in emulator: PCM (tones, WAV) through AudioTrack, MIDI/MP3/AMR/AAC through MediaPlayer. Needs a device test. */
public class AndroidAudio implements Audio, VideoHost {
    private final Context ctx;
    private final Handler main = new Handler(Looper.getMainLooper());

    public AndroidAudio(Context c) { ctx = c.getApplicationContext(); }

    public Handle openPcm(final short[] mono, final int rate) throws IOException {
        final AudioTrack track;
        try {
            track = new AudioTrack(AudioManager.STREAM_MUSIC, rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT,
                    Math.max(2, mono.length * 2), AudioTrack.MODE_STATIC);
            track.write(mono, 0, mono.length);
        } catch (RuntimeException e) { throw new IOException("AudioTrack: " + e.getMessage()); }
        return new Handle() {
            private Runnable pending;
            public void start(int loops, int volume, final Runnable onEnd) {
                cancel();
                try {
                    track.stop(); track.reloadStaticData();
                    track.setLoopPoints(0, mono.length, loops < 0 ? -1 : Math.max(0, loops - 1));
                    setVolume(volume);
                    track.play();
                } catch (RuntimeException e) { return; }
                if (loops > 0) {
                    pending = new Runnable() { public void run() { pending = null; if (onEnd != null) onEnd.run(); } };
                    main.postDelayed(pending, durationMs() * loops + 30);
                }
            }
            private void cancel() { if (pending != null) { main.removeCallbacks(pending); pending = null; } }
            public void stop() { cancel(); try { track.stop(); } catch (RuntimeException e) { } }
            public void setVolume(int v) { try { track.setStereoVolume(v / 100f, v / 100f); } catch (RuntimeException e) { } }
            public long durationMs() { return mono.length * 1000L / rate; }
            public long positionMs() { try { return track.getPlaybackHeadPosition() * 1000L / rate; } catch (RuntimeException e) { return 0; } }
            public void close() { cancel(); try { track.release(); } catch (RuntimeException e) { } }
        };
    }

    public Handle openEncoded(byte[] data, String mimeType) throws IOException {
        final File f = File.createTempFile("emu_snd", ".bin", ctx.getCacheDir());
        FileOutputStream o = new FileOutputStream(f);
        try { o.write(data); } finally { o.close(); }
        final MediaPlayer mp = new MediaPlayer();
        try {
            mp.setDataSource(f.getPath());
            mp.prepare();
        } catch (Exception e) { mp.release(); f.delete(); throw new IOException("cannot decode " + mimeType + ": " + e.getMessage()); }
        return new Handle() {
            public void start(int loops, final int volume, final Runnable onEnd) {
                try {
                    mp.setLooping(loops < 0);
                    setVolume(volume);
                    mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() { public void onCompletion(MediaPlayer m) { if (onEnd != null) onEnd.run(); } });
                    mp.seekTo(0); mp.start();
                } catch (RuntimeException e) { }
            }
            public void stop() { try { if (mp.isPlaying()) mp.pause(); } catch (RuntimeException e) { } }
            public void setVolume(int v) { try { mp.setVolume(v / 100f, v / 100f); } catch (RuntimeException e) { } }
            public long durationMs() { try { return mp.getDuration(); } catch (RuntimeException e) { return -1; } }
            public long positionMs() { try { return mp.getCurrentPosition(); } catch (RuntimeException e) { return 0; } }
            public void close() { try { mp.release(); } catch (RuntimeException e) { } f.delete(); }
        };
    }

    /**
     * 3GP/MP4 playback: MediaPlayer renders into an off-screen ImageReader (RGBA_8888); the newest picture is exposed as a
     * FrameSource that VideoControl draws. Needs a phone test; a phone whose decoder refuses this surface gives sound only.
     */
    public Handle openVideo(byte[] data, String mimeType) throws IOException {
        final File f = File.createTempFile("emu_vid", ".bin", ctx.getCacheDir());
        FileOutputStream o = new FileOutputStream(f);
        try { o.write(data); } finally { o.close(); }
        int vw = 0, vh = 0, vrot = 0;
        double vfps = 15;
        MediaMetadataRetriever r = new MediaMetadataRetriever();
        try {
            r.setDataSource(f.getPath());
            String a = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH), b = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT);
            if (a != null && b != null) { vw = Integer.parseInt(a); vh = Integer.parseInt(b); }
            String ro = r.extractMetadata(24);   // METADATA_KEY_VIDEO_ROTATION
            if (ro != null) vrot = Integer.parseInt(ro) % 360;
            String fr = r.extractMetadata(25);   // METADATA_KEY_CAPTURE_FRAMERATE (API 23)
            if (fr != null) { double fv = Double.parseDouble(fr); if (fv > 1 && fv < 120) vfps = fv; }
        } catch (RuntimeException e) { vw = 0; }
        finally { try { r.release(); } catch (RuntimeException e) { /* ignore */ } }
        if (vw <= 0 || vh <= 0) { f.delete(); throw new IOException("no video track found"); }
        final int w = vw, h = vh, step = Math.max(1, Math.max(vw, vh) / 480), rot = vrot;
        final double fps = vfps;
        final boolean swap = rot == 90 || rot == 270;
        final HandlerThread ht = new HandlerThread("emu-video");
        ht.start();
        final ImageReader ir;
        final MediaPlayer mp = new MediaPlayer();
        try {
            ir = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2);
            mp.setDataSource(f.getPath());
            mp.setSurface(ir.getSurface());
            mp.prepare();
        } catch (Exception e) {
            mp.release(); ht.quitSafely(); f.delete();
            throw new IOException("cannot decode video: " + e.getMessage());
        }
        final int[][] box = new int[1][];
        final int[] size = new int[2];
        final Object lock = new Object();
        ir.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() {
            public void onImageAvailable(ImageReader rd) {
                Image im = null;
                try {
                    im = rd.acquireLatestImage();
                    if (im == null) return;
                    Image.Plane pl = im.getPlanes()[0];
                    java.nio.ByteBuffer bb = pl.getBuffer();
                    int rs = pl.getRowStride(), ps = pl.getPixelStride(), iw = im.getWidth(), ih = im.getHeight();
                    int ow = (swap ? ih : iw) / step, oh = (swap ? iw : ih) / step;
                    int[] out = new int[ow * oh];
                    for (int y = 0; y < oh; y++) {
                        int uy = y * step;
                        for (int x = 0; x < ow; x++) {
                            int ux = x * step, sx, sy;
                            switch (rot) {
                                case 90: sx = uy; sy = ih - 1 - ux; break;
                                case 180: sx = iw - 1 - ux; sy = ih - 1 - uy; break;
                                case 270: sx = iw - 1 - uy; sy = ux; break;
                                default: sx = ux; sy = uy;
                            }
                            if (sx < 0) sx = 0; else if (sx >= iw) sx = iw - 1;
                            if (sy < 0) sy = 0; else if (sy >= ih) sy = ih - 1;
                            int p = sy * rs + sx * ps;
                            out[y * ow + x] = 0xFF000000 | ((bb.get(p) & 0xFF) << 16) | ((bb.get(p + 1) & 0xFF) << 8) | (bb.get(p + 2) & 0xFF);
                        }
                    }
                    synchronized (lock) { box[0] = out; size[0] = ow; size[1] = oh; }
                } catch (RuntimeException e) { /* skip a bad picture */ }
                finally { if (im != null) im.close(); }
            }
        }, new android.os.Handler(ht.getLooper()));
        class VideoHandle implements Handle, FrameSource, VideoSeek {
            public void start(int loops, int volume, final Runnable onEnd) {
                try {
                    mp.setLooping(loops < 0);
                    setVolume(volume);
                    mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() { public void onCompletion(MediaPlayer m) { if (onEnd != null) onEnd.run(); } });
                    mp.seekTo(0); mp.start();
                } catch (RuntimeException e) { }
            }
            public void stop() { try { if (mp.isPlaying()) mp.pause(); } catch (RuntimeException e) { } }
            public void setVolume(int v) { try { mp.setVolume(v / 100f, v / 100f); } catch (RuntimeException e) { } }
            public long durationMs() { try { return mp.getDuration(); } catch (RuntimeException e) { return -1; } }
            public long positionMs() { try { return mp.getCurrentPosition(); } catch (RuntimeException e) { return 0; } }
            public void close() {
                try { mp.release(); } catch (RuntimeException e) { }
                try { ir.close(); } catch (RuntimeException e) { }
                ht.quitSafely();
                f.delete();
            }
            public int[] frame(int[] wh) {
                synchronized (lock) { if (box[0] == null) return null; wh[0] = size[0]; wh[1] = size[1]; return box[0]; }
            }
            public int width() { return (swap ? h : w) / step; }
            public int height() { return (swap ? w : h) / step; }
            public byte[] jpeg(int[] argb, int pw, int ph, int q) { return null; }
            public void seekMs(long ms) { try { mp.seekTo((int) ms); } catch (RuntimeException e) { } }
            public double fps() { return fps; }
        }
        return new VideoHandle();
    }
}
