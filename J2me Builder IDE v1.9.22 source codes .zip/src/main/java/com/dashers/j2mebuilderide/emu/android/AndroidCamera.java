package com.dashers.j2mebuilderide.emu.android;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.ImageFormat;
import android.graphics.SurfaceTexture;
import android.hardware.Camera;
import android.media.CamcorderProfile;
import android.media.MediaRecorder;
import android.os.Handler;
import android.os.HandlerThread;
import android.view.Surface;

import com.dashers.j2mebuilderide.emu.midp.CameraProvider;
import com.dashers.j2mebuilderide.emu.midp.Recordable;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/**
 * Phone camera for capture://video. Uses the classic android.hardware.Camera preview callback (works on every phone from
 * Android 5, no extra library): NV21 frames are rotated/mirrored upright and converted to ARGB for the emulator screen.
 * The CAMERA permission is requested at run time on first use. Needs a phone test.
 */
@SuppressWarnings("deprecation")
public final class AndroidCamera implements CameraProvider {
    private final Activity act;
    private volatile int zoomPct;
    private volatile boolean torch;
    private volatile Live current;

    public AndroidCamera(Activity a) { this(a, 100, false); }
    public AndroidCamera(Activity a, int zoomPercent, boolean torchOn) { act = a; zoomPct = zoomPercent; torch = torchOn; }

    /** Zoom (100 = none) and torch of the open camera; also used for the next opening. Safe from the UI thread. */
    public void setTuning(int zoomPercent, boolean torchOn) {
        zoomPct = zoomPercent;
        torch = torchOn;
        final Live l = current;
        if (l != null) l.h.post(new Runnable() { public void run() { l.tune(zoomPct, torch); } });
    }

    public String name() { return "phone camera"; }

    public Session open(final boolean front, final int wantW, final int wantH) throws IOException {
        if (!Permissions.ensure(act, "android.permission.CAMERA", 60000))
            throw new SecurityException("the CAMERA permission was refused - allow it for J2ME Builder IDE in the phone's app settings, or choose More > Camera > Test pattern");
        final HandlerThread ht = new HandlerThread("emu-camera");
        ht.start();
        final Live live = new Live(new Handler(ht.getLooper()), ht, act);
        live.zoom = zoomPct;
        live.torchOn = torch;
        final CountDownLatch latch = new CountDownLatch(1);
        final Throwable[] err = new Throwable[1];
        live.h.post(new Runnable() {
            public void run() {
                try { live.start(front, wantW, wantH); } catch (Throwable t) { err[0] = t; } finally { latch.countDown(); }
            }
        });
        boolean ok;
        try { ok = latch.await(8, TimeUnit.SECONDS); } catch (InterruptedException e) { ok = false; }
        if (!ok) { live.close(); throw new IOException("the camera did not open in time (is another app using it?)"); }
        if (err[0] != null) { live.close(); throw new IOException(String.valueOf(err[0].getMessage())); }
        current = live;
        return live;
    }

    private static final class Pic { final int[] px; final int w, h; Pic(int[] p, int w, int h) { px = p; this.w = w; this.h = h; } }

    private static final class Live implements Session, Recordable {
        final Handler h;
        private final HandlerThread ht;
        private final Activity act;
        private Camera cam;
        private SurfaceTexture tex;
        private int srcW, srcH, rot, step = 1;
        private boolean mirror, closed;
        volatile int zoom = 100;
        volatile boolean torchOn;
        private int camId;
        private int hint;
        private MediaRecorder recorder;
        private volatile Pic latest;

        Live(Handler h, HandlerThread ht, Activity a) { this.h = h; this.ht = ht; act = a; }

        void start(boolean front, int wantW, int wantH) throws IOException {
            int n = Camera.getNumberOfCameras();
            if (n == 0) throw new IOException("this phone has no camera");
            Camera.CameraInfo info = new Camera.CameraInfo();
            int id = -1;
            for (int i = 0; i < n; i++) {
                Camera.getCameraInfo(i, info);
                if ((info.facing == Camera.CameraInfo.CAMERA_FACING_FRONT) == front) { id = i; break; }
            }
            if (id < 0) { id = 0; Camera.getCameraInfo(0, info); }
            camId = id;
            try { cam = Camera.open(id); } catch (RuntimeException e) { throw new IOException("cannot open camera " + id + ": " + e.getMessage()); }
            Camera.Parameters p = cam.getParameters();
            int tw = wantW > 0 ? wantW : 320, th = wantH > 0 ? wantH : 240;
            List<Camera.Size> sizes = p.getSupportedPreviewSizes();
            Camera.Size best = null;
            long bestScore = Long.MAX_VALUE;
            if (sizes != null) {
                for (Camera.Size s : sizes) {
                    if (s.width > 1280) continue;
                    long sc = Math.abs(Math.max(s.width, s.height) - Math.max(tw, th)) + Math.abs(Math.min(s.width, s.height) - Math.min(tw, th));
                    if (sc < bestScore) { bestScore = sc; best = s; }
                }
            }
            if (best != null) p.setPreviewSize(best.width, best.height);
            p.setPreviewFormat(ImageFormat.NV21);
            List<String> fm = p.getSupportedFocusModes();
            if (fm != null && fm.contains(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE)) p.setFocusMode(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE);
            applyTuning(p);
            try { cam.setParameters(p); } catch (RuntimeException e) { /* keep the camera's own settings */ }
            Camera.Size ps = cam.getParameters().getPreviewSize();
            srcW = ps.width; srcH = ps.height;
            int disp;
            switch (act.getWindowManager().getDefaultDisplay().getRotation()) {
                case Surface.ROTATION_90: disp = 90; break;
                case Surface.ROTATION_180: disp = 180; break;
                case Surface.ROTATION_270: disp = 270; break;
                default: disp = 0;
            }
            rot = front ? (info.orientation + disp) % 360 : (info.orientation - disp + 360) % 360;
            mirror = front;
            hint = rot;
            step = Math.max(srcW, srcH) > 640 ? 2 : 1;
            armCallbacks();
            try {
                tex = new SurfaceTexture(42);
                cam.setPreviewTexture(tex);
                cam.startPreview();
            } catch (RuntimeException e) { throw new IOException("cannot start the preview: " + e.getMessage()); }
        }

        private void armCallbacks() {
            int size = srcW * srcH * 3 / 2;
            for (int i = 0; i < 3; i++) cam.addCallbackBuffer(new byte[size]);
            cam.setPreviewCallbackWithBuffer(new Camera.PreviewCallback() {
                public void onPreviewFrame(byte[] d, Camera c) {
                    try { convert(d); } catch (RuntimeException e) { /* skip a bad frame */ }
                    c.addCallbackBuffer(d);
                }
            });
        }

        private void applyTuning(Camera.Parameters p) {
            try {
                if (p.isZoomSupported()) {
                    List<Integer> ratios = p.getZoomRatios();
                    int best = 0;
                    for (int i = 0; i < ratios.size(); i++) if (ratios.get(i) <= zoom) best = i;
                    p.setZoom(best);
                }
                List<String> fl = p.getSupportedFlashModes();
                if (fl != null && fl.contains(Camera.Parameters.FLASH_MODE_TORCH))
                    p.setFlashMode(torchOn ? Camera.Parameters.FLASH_MODE_TORCH : Camera.Parameters.FLASH_MODE_OFF);
            } catch (RuntimeException e) { /* this camera has no zoom/torch */ }
        }

        /** Camera thread. */
        void tune(int zoomPct, boolean torch) {
            zoom = zoomPct;
            torchOn = torch;
            if (cam == null) return;
            try { Camera.Parameters p = cam.getParameters(); applyTuning(p); cam.setParameters(p); } catch (RuntimeException e) { /* busy or unsupported */ }
        }

        private interface Job { void run() throws Exception; }

        private void onCameraThread(final Job job) throws IOException {
            final CountDownLatch done = new CountDownLatch(1);
            final Throwable[] err = new Throwable[1];
            h.post(new Runnable() { public void run() { try { job.run(); } catch (Throwable t) { err[0] = t; } finally { done.countDown(); } } });
            boolean ok;
            try { ok = done.await(10, TimeUnit.SECONDS); } catch (InterruptedException e) { ok = false; }
            if (!ok) throw new IOException("the camera did not answer in time");
            if (err[0] != null) throw new IOException(String.valueOf(err[0].getMessage()));
        }

        /** Picture and, when RECORD_AUDIO is granted, sound into an MP4 file (MediaRecorder takes the camera over; the preview may freeze meanwhile). */
        public void startRecording(final File out) throws IOException {
            final boolean audio = Permissions.ensure(act, "android.permission.RECORD_AUDIO", 60000);
            onCameraThread(new Job() {
                public void run() throws Exception {
                    if (recorder != null) throw new IllegalStateException("already recording");
                    cam.unlock();
                    MediaRecorder r = new MediaRecorder();
                    try {
                        r.setCamera(cam);
                        if (audio) r.setAudioSource(MediaRecorder.AudioSource.CAMCORDER);
                        r.setVideoSource(MediaRecorder.VideoSource.CAMERA);
                        CamcorderProfile pr = CamcorderProfile.hasProfile(camId, CamcorderProfile.QUALITY_480P) ? CamcorderProfile.get(camId, CamcorderProfile.QUALITY_480P) : CamcorderProfile.get(camId, CamcorderProfile.QUALITY_LOW);
                        if (audio) r.setProfile(pr);
                        else {
                            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
                            r.setVideoEncoder(MediaRecorder.VideoEncoder.H264);
                            r.setVideoSize(pr.videoFrameWidth, pr.videoFrameHeight);
                            r.setVideoFrameRate(pr.videoFrameRate);
                            r.setVideoEncodingBitRate(pr.videoBitRate);
                        }
                        r.setOrientationHint(hint);
                        r.setOutputFile(out.getPath());
                        if (tex != null) r.setPreviewDisplay(new Surface(tex));
                        r.prepare();
                        r.start();
                        recorder = r;
                    } catch (Exception e) {
                        try { r.release(); } catch (RuntimeException e2) { /* ignore */ }
                        try { cam.lock(); } catch (RuntimeException e2) { /* ignore */ }
                        throw e;
                    }
                }
            });
        }

        public void stopRecording() throws IOException {
            onCameraThread(new Job() { public void run() { finishRecording(); } });
        }

        /** Camera thread. */
        private void finishRecording() {
            MediaRecorder r = recorder;
            if (r == null) return;
            recorder = null;
            try { r.stop(); } catch (RuntimeException e) { /* nothing recorded */ }
            try { r.reset(); r.release(); } catch (RuntimeException e) { /* ignore */ }
            try {
                cam.lock();
                cam.startPreview();
                armCallbacks();
            } catch (RuntimeException e) { /* preview stays frozen */ }
        }

        private void convert(byte[] d) {
            final int W = srcW, H = srcH, s = step;
            boolean swap = rot % 180 != 0;
            int ow = (swap ? H : W) / s, oh = (swap ? W : H) / s;
            int[] out = new int[ow * oh];
            int fs = W * H;
            for (int oy = 0; oy < oh; oy++) {
                int uy = oy * s;
                for (int ox = 0; ox < ow; ox++) {
                    int ux = (mirror ? ow - 1 - ox : ox) * s;
                    int sx, sy;
                    switch (rot) {
                        case 90: sx = uy; sy = H - 1 - ux; break;
                        case 180: sx = W - 1 - ux; sy = H - 1 - uy; break;
                        case 270: sx = W - 1 - uy; sy = ux; break;
                        default: sx = ux; sy = uy;
                    }
                    if (sx < 0) sx = 0; else if (sx >= W) sx = W - 1;
                    if (sy < 0) sy = 0; else if (sy >= H) sy = H - 1;
                    int ci = fs + (sy >> 1) * W + (sx & ~1);
                    int v = (d[ci] & 0xFF) - 128, u = (d[ci + 1] & 0xFF) - 128;
                    int c = ((d[sy * W + sx] & 0xFF) - 16);
                    if (c < 0) c = 0;
                    c *= 1192;
                    int r = (c + 1634 * v) >> 10, g = (c - 833 * v - 400 * u) >> 10, b = (c + 2066 * u) >> 10;
                    r = r < 0 ? 0 : r > 255 ? 255 : r;
                    g = g < 0 ? 0 : g > 255 ? 255 : g;
                    b = b < 0 ? 0 : b > 255 ? 255 : b;
                    out[oy * ow + ox] = 0xFF000000 | (r << 16) | (g << 8) | b;
                }
            }
            latest = new Pic(out, ow, oh);
        }

        public int[] frame(int[] wh) {
            Pic p = latest;
            if (p == null) return null;
            wh[0] = p.w; wh[1] = p.h;
            return p.px;
        }
        public int width() { Pic p = latest; return p != null ? p.w : (rot % 180 != 0 ? srcH : srcW) / step; }
        public int height() { Pic p = latest; return p != null ? p.h : (rot % 180 != 0 ? srcW : srcH) / step; }

        public byte[] jpeg(int[] argb, int w, int hh, int quality) {
            Bitmap b = null;
            try {
                b = Bitmap.createBitmap(argb, w, hh, Bitmap.Config.ARGB_8888);
                ByteArrayOutputStream o = new ByteArrayOutputStream();
                return b.compress(Bitmap.CompressFormat.JPEG, quality, o) ? o.toByteArray() : null;
            } catch (RuntimeException e) { return null; }
            finally { if (b != null) b.recycle(); }
        }

        public void close() {
            synchronized (this) { if (closed) return; closed = true; }
            h.post(new Runnable() {
                public void run() {
                    finishRecording();
                    if (cam != null) {
                        try { cam.setPreviewCallbackWithBuffer(null); cam.stopPreview(); } catch (RuntimeException e) { /* already stopped */ }
                        try { cam.release(); } catch (RuntimeException e) { /* already released */ }
                        cam = null;
                    }
                    if (tex != null) { try { tex.release(); } catch (RuntimeException e) { /* ignore */ } tex = null; }
                    ht.quitSafely();
                }
            });
        }
    }
}
