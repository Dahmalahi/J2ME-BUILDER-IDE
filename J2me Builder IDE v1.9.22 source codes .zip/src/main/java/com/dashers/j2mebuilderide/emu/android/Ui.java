package com.dashers.j2mebuilderide.emu.android;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/**
 * Look of the emulator screen: glassmorphism on a night-to-sunset backdrop (the emulator runs in its own process,
 * so it draws its own glass instead of sharing the IDE's), fully rounded (pill) controls.
 */
final class Ui {
    static final int BG = 0xFF120B2E, BG_BOTTOM = 0xFF4A1D4F, SURFACE = 0xFF1C1736, SURFACE2 = 0x26FFFFFF, SURFACE3 = 0x44FFFFFF,
            STROKE = 0x38FFFFFF,
            TEXT = 0xFFF6F0FB, MUTED = 0xFFBBAED4,
            OK = 0xFF6FD6A0, WARN = 0xFFFFC266, ERR = 0xFFFF7A7A, HINT = 0xFF7FE0F0, DANGER_BG = 0xFF4A2326;
    static final int NORMAL = 0, PRIMARY = 1, DANGER = 2, GHOST = 3;

    // ---- user customisation (read from the emulator's preferences by configure()) ----
    static int ACCENT = 0xFFFF6FA8, ON_ACCENT = 0xFF2A0A1A;
    /** Alpha of the frosted panels' white fill: 0x14 light, 0x22 medium, 0x38 strong. */
    static int glassAlpha = 0x22;
    /** 0 = wallpaper if there is one else sunset, 1 sunset, 2 night, 3 black. */
    static int backdropStyle = 0;

    static void setAccent(int c) {
        ACCENT = 0xFF000000 | c;
        double lum = (0.299 * ((c >> 16) & 255) + 0.587 * ((c >> 8) & 255) + 0.114 * (c & 255)) / 255.0;
        ON_ACCENT = lum > 0.55 ? 0xFF1A0A12 : 0xFFFFFFFF;
    }

    static int lighten(int c, float f) {
        int r = (c >> 16) & 255, g = (c >> 8) & 255, b = c & 255;
        r += (int) ((255 - r) * f);
        g += (int) ((255 - g) * f);
        b += (int) ((255 - b) * f);
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    static void configure(android.content.SharedPreferences p) {
        setAccent(p.getInt("emu_accent", 0xFFFF6FA8));
        int g = p.getInt("emu_glass", 1);
        glassAlpha = g == 0 ? 0x14 : g == 2 ? 0x38 : 0x22;
        backdropStyle = Math.max(0, Math.min(3, p.getInt("emu_backdrop", 0)));
    }

    private Ui() { }

    /** Frosted panel: translucent white with a light edge and a soft sheen on the upper half. */
    static android.graphics.drawable.Drawable glassPanel(Context c, int radiusDp) {
        float r = radiusDp >= 100 ? 4000f : dp(c, radiusDp);
        GradientDrawable base = shape((glassAlpha << 24) | 0x00FFFFFF, r, 0x40FFFFFF, Math.max(1, dp(c, 1)));
        GradientDrawable sheen = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0x2EFFFFFF, 0x00FFFFFF});
        sheen.setCornerRadius(r);
        return new android.graphics.drawable.LayerDrawable(new android.graphics.drawable.Drawable[]{base, sheen});
    }

    /** Night sky into a warm sunset: vertical gradient plus a cyan glow (top left) and an orange glow (bottom right). */
    static android.graphics.drawable.Drawable backdrop() {
        final int style = backdropStyle;
        if (style == 3) return new ColorDrawable(0xFF05050A);
        final int top = style == 2 ? 0xFF050B1E : BG, mid = style == 2 ? 0xFF0E2352 : 0xFF2B1450, bottom = style == 2 ? 0xFF1A1F4D : BG_BOTTOM;
        final int glowA = style == 2 ? 0x556E5CFF : 0x5540C8E0, glowB = style == 2 ? 0x6640C8E0 : 0x80FFA24C;
        return new android.graphics.drawable.Drawable() {
            private final android.graphics.Paint p = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
            @Override public void draw(android.graphics.Canvas c) {
                android.graphics.Rect b = getBounds();
                if (b.width() <= 0 || b.height() <= 0) return;
                p.setShader(new android.graphics.LinearGradient(0, b.top, 0, b.bottom,
                        new int[]{top, mid, bottom}, new float[]{0f, 0.55f, 1f}, android.graphics.Shader.TileMode.CLAMP));
                c.drawRect(b, p);
                float m = Math.max(b.width(), b.height());
                p.setShader(new android.graphics.RadialGradient(b.left + b.width() * 0.05f, b.top + b.height() * 0.10f, m * 0.6f,
                        glowA, glowA & 0x00FFFFFF, android.graphics.Shader.TileMode.CLAMP));
                c.drawRect(b, p);
                p.setShader(new android.graphics.RadialGradient(b.left + b.width() * 0.95f, b.top + b.height() * 0.98f, m * 0.7f,
                        glowB, glowB & 0x00FFFFFF, android.graphics.Shader.TileMode.CLAMP));
                c.drawRect(b, p);
                p.setShader(null);
            }
            @Override public void setAlpha(int a) { }
            @Override public void setColorFilter(android.graphics.ColorFilter f) { }
            @Override public int getOpacity() { return android.graphics.PixelFormat.OPAQUE; }
        };
    }

    /** The IDE's wallpaper (the user's own, else the GTA 6 theme's) read from the shared app data; null = none. */
    static android.graphics.Bitmap loadWallpaper(Context c) {
        try {
            android.content.SharedPreferences sp = c.getSharedPreferences("ide", Context.MODE_PRIVATE);
            java.io.File f = new java.io.File(c.getFilesDir(), "wallpaper_custom.jpg");
            if (sp.getBoolean("wallCustom", false) && f.exists()) return android.graphics.BitmapFactory.decodeFile(f.getPath());
            if ("gta6".equals(sp.getString("theme", ""))) {
                android.graphics.BitmapFactory.Options o = new android.graphics.BitmapFactory.Options();
                o.inScaled = false;
                return android.graphics.BitmapFactory.decodeResource(c.getResources(), com.dashers.j2mebuilderide.R.drawable.wallpaper_gta6, o);
            }
        } catch (Throwable ignore) {
            // no wallpaper: the emulator's own backdrop is used
        }
        return null;
    }

    /** A picture scaled to cover the whole area (centred, overflow cropped, so it fits any phone) under a soft dark shade. */
    static android.graphics.drawable.Drawable wallpaperDrawable(final android.graphics.Bitmap bmp) {
        return new android.graphics.drawable.Drawable() {
            private final android.graphics.Paint p = new android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG);
            private final android.graphics.Paint shade = new android.graphics.Paint();
            private final android.graphics.Matrix m = new android.graphics.Matrix();
            private final android.graphics.Rect last = new android.graphics.Rect();
            @Override public void draw(android.graphics.Canvas c) {
                android.graphics.Rect b = getBounds();
                if (b.width() <= 0 || b.height() <= 0 || bmp.isRecycled()) return;
                if (!b.equals(last)) {
                    last.set(b);
                    float s = Math.max(b.width() / (float) bmp.getWidth(), b.height() / (float) bmp.getHeight());
                    m.setScale(s, s);
                    m.postTranslate(b.left + (b.width() - bmp.getWidth() * s) / 2f, b.top + (b.height() - bmp.getHeight() * s) / 2f);
                    shade.setShader(new android.graphics.LinearGradient(0, b.top, 0, b.bottom, 0x44000000, 0x80000000,
                            android.graphics.Shader.TileMode.CLAMP));
                }
                c.drawBitmap(bmp, m, p);
                c.drawRect(b, shade);
            }
            @Override public void setAlpha(int a) { }
            @Override public void setColorFilter(android.graphics.ColorFilter f) { }
            @Override public int getOpacity() { return android.graphics.PixelFormat.OPAQUE; }
        };
    }

    /** Same pill alerts as the IDE (theme from res/values/styles.xml, recoloured here for the emulator's glass look). */
    static class Dlg extends android.app.AlertDialog.Builder {
        Dlg(Context c) { super(c, com.dashers.j2mebuilderide.R.style.AlertPillDark); }

        @Override public android.app.AlertDialog create() {
            final android.app.AlertDialog d = super.create();
            final Context c = getContext();
            Window w = d.getWindow();
            if (w != null) {
                w.setDimAmount(0.6f);
                w.getDecorView().addOnAttachStateChangeListener(new View.OnAttachStateChangeListener() {
                    public void onViewAttachedToWindow(View v) { polish(d, c); }
                    public void onViewDetachedFromWindow(View v) { }
                });
            }
            return d;
        }

        private static void polish(android.app.AlertDialog d, Context c) {
            try {
                Window w = d.getWindow();
                View decor = w.getDecorView();
                GradientDrawable g = shape(0xFF241A45, dp(c, 32), 0x40FFFFFF, Math.max(1, dp(c, 1)));
                decor.setBackground(new android.graphics.drawable.InsetDrawable(g, dp(c, 10)));
                final int in = dp(c, 10), rad = dp(c, 32);
                decor.setClipToOutline(true);
                decor.setOutlineProvider(new android.view.ViewOutlineProvider() {
                    public void getOutline(View v, android.graphics.Outline o) {
                        o.setRoundRect(in, in, Math.max(in + 1, v.getWidth() - in), Math.max(in + 1, v.getHeight() - in), rad);
                    }
                });
                int tid = c.getResources().getIdentifier("alertTitle", "id", "android");
                TextView title = tid != 0 ? (TextView) d.findViewById(tid) : null;
                if (title != null) { title.setTextColor(TEXT); title.setTextSize(22); title.setTypeface(Typeface.DEFAULT_BOLD); }
                TextView msg = (TextView) d.findViewById(android.R.id.message);
                if (msg != null) { msg.setTextColor(TEXT); msg.setTextSize(16); }
                int[] ids = {android.app.AlertDialog.BUTTON_POSITIVE, android.app.AlertDialog.BUTTON_NEGATIVE, android.app.AlertDialog.BUTTON_NEUTRAL};
                for (int i = 0; i < ids.length; i++) {
                    android.widget.Button b = d.getButton(ids[i]);
                    if (b == null) continue;
                    boolean main = ids[i] == android.app.AlertDialog.BUTTON_POSITIVE;
                    b.setAllCaps(false);
                    b.setTypeface(Typeface.DEFAULT_BOLD);
                    b.setMinHeight(dp(c, 44));
                    b.setPadding(dp(c, 20), 0, dp(c, 20), 0);
                    b.setTextColor(main ? ON_ACCENT : ACCENT);
                    b.setBackground(shape(main ? ACCENT : ((ACCENT & 0x00FFFFFF) | 0x33000000), 4000f, 0, 0));
                }
            } catch (Throwable ignore) {
                // cosmetic only
            }
        }
    }

    static int dp(Context c, int v) { return Math.round(v * c.getResources().getDisplayMetrics().density); }

    static GradientDrawable shape(int fill, float radiusPx, int stroke, int strokePx) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.RECTANGLE);
        g.setColor(fill);
        g.setCornerRadius(radiusPx);
        if (strokePx > 0) g.setStroke(strokePx, stroke);
        return g;
    }

    private static StateListDrawable states(int normal, int pressed, int selected, int stroke, int strokePx) {
        float r = 2000f;      // larger than half the height: the drawable clamps it, giving a perfect pill
        StateListDrawable sl = new StateListDrawable();
        sl.addState(new int[]{android.R.attr.state_pressed}, shape(pressed, r, stroke, strokePx));
        sl.addState(new int[]{android.R.attr.state_selected}, shape(selected, r, stroke, strokePx));
        sl.addState(new int[]{-android.R.attr.state_enabled}, shape(0x14FFFFFF, r, stroke, strokePx));
        sl.addState(new int[]{}, shape(normal, r, stroke, strokePx));
        return sl;
    }

    static void style(TextView t, int style) {
        t.setTag(Integer.valueOf(style));          // so the whole screen can be restyled live when the accent changes
        Context c = t.getContext();
        int sw = dp(c, 1);
        int fg = TEXT;
        if (style == PRIMARY) { t.setBackground(states(ACCENT, lighten(ACCENT, 0.3f), ACCENT, 0, 0)); fg = ON_ACCENT; }
        else if (style == DANGER) { t.setBackground(states(0x66FF4D6A, 0x99FF4D6A, 0x66FF4D6A, 0x66FF8A9C, sw)); fg = 0xFFFFD0D8; }
        else if (style == GHOST) { t.setBackground(states(0x00000000, SURFACE3, SURFACE3, STROKE, sw)); fg = MUTED; }
        else { t.setBackground(states(SURFACE2, SURFACE3, ACCENT, STROKE, sw)); }
        int sel = style == NORMAL || style == GHOST ? ON_ACCENT : fg;
        t.setTextColor(new ColorStateList(new int[][]{{android.R.attr.state_selected}, {-android.R.attr.state_enabled}, {}}, new int[]{sel, 0xFF7E7396, fg}));
    }

    /** A rounded pill button. Clickable TextView: no default Button elevation or padding surprises. */
    static TextView pill(Context c, String label, int style, View.OnClickListener l) {
        TextView t = new TextView(c);
        t.setText(label);
        t.setGravity(Gravity.CENTER);
        t.setSingleLine(true);
        t.setEllipsize(TextUtils.TruncateAt.END);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        t.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        t.setMinHeight(dp(c, 40));
        t.setPadding(dp(c, 12), 0, dp(c, 12), 0);
        style(t, style);
        t.setClickable(true);
        t.setFocusable(true);
        if (l != null) t.setOnClickListener(l);
        return t;
    }

    /** Small pill used for filters / state (can be selected). */
    static TextView chip(Context c, String label, View.OnClickListener l) {
        TextView t = pill(c, label, NORMAL, l);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        t.setMinHeight(dp(c, 30));
        t.setPadding(dp(c, 10), 0, dp(c, 10), 0);
        return t;
    }

    /** Round key (d-pad). */
    static TextView roundKey(Context c, String label, int sizeDp) {
        TextView t = pill(c, label, NORMAL, null);
        t.setPadding(0, 0, 0, 0);
        t.setMinHeight(dp(c, sizeDp));
        t.setMinWidth(dp(c, sizeDp));
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        return t;
    }

    static LinearLayout.LayoutParams weight(Context c, int heightDp, int marginDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, heightDp <= 0 ? ViewGroup.LayoutParams.WRAP_CONTENT : dp(c, heightDp), 1f);
        p.setMargins(dp(c, marginDp), dp(c, marginDp), dp(c, marginDp), dp(c, marginDp));
        return p;
    }

    interface Pick { void pick(int index); }

    /** Bottom sheet with rounded rows: label on the left, current value on the right. */
    static Dialog sheet(Activity a, String title, String[] labels, String[] values, final Pick cb) {
        final Dialog d = new Dialog(a);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        float r = dp(a, 24);
        GradientDrawable top = new GradientDrawable();
        top.setColor(0xF01E1740);
        top.setStroke(Math.max(1, dp(a, 1)), 0x33FFFFFF);
        top.setCornerRadii(new float[]{r, r, r, r, 0, 0, 0, 0});
        root.setBackground(top);
        root.setPadding(dp(a, 14), dp(a, 14), dp(a, 14), dp(a, 14));

        TextView h = new TextView(a);
        h.setText(title);
        h.setTextColor(TEXT);
        h.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        h.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        h.setPadding(dp(a, 8), dp(a, 2), dp(a, 8), dp(a, 10));
        root.addView(h);

        LinearLayout list = new LinearLayout(a);
        list.setOrientation(LinearLayout.VERTICAL);
        for (int i = 0; i < labels.length; i++) {
            final int idx = i;
            LinearLayout row = new LinearLayout(a);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setMinimumHeight(dp(a, 46));
            row.setPadding(dp(a, 16), 0, dp(a, 16), 0);
            row.setBackground(states(SURFACE2, SURFACE3, SURFACE3, 0, 0));
            row.setClickable(true);
            TextView l = new TextView(a);
            l.setText(labels[i]);
            l.setTextColor(TEXT);
            l.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            l.setSingleLine(true);
            l.setEllipsize(TextUtils.TruncateAt.END);
            row.addView(l, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            if (values != null && values[i] != null && values[i].length() > 0) {
                TextView v = new TextView(a);
                v.setText(values[i]);
                v.setTextColor(values[i].equals("ON") ? OK : MUTED);
                v.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
                v.setSingleLine(true);
                v.setPadding(dp(a, 8), 0, 0, 0);
                row.addView(v);
            }
            row.setOnClickListener(new View.OnClickListener() { public void onClick(View x) { d.dismiss(); cb.pick(idx); } });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.bottomMargin = dp(a, 6);
            list.addView(row, lp);
        }
        ScrollView sv = new ScrollView(a);
        sv.addView(list);
        root.addView(sv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        d.setContentView(root);
        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            w.setGravity(Gravity.BOTTOM);
            int maxH = (int) (a.getResources().getDisplayMetrics().heightPixels * 0.82f);
            w.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
            sv.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Math.min(maxH, dp(a, 52) * labels.length + dp(a, 20))));
        }
        return d;
    }

    /** Re-applies the pill look to every styled TextView under v (after the accent colour changed). */
    static void restyle(View v) {
        if (v instanceof TextView && v.getTag() instanceof Integer) {
            TextView t = (TextView) v;
            boolean sel = t.isSelected();
            style(t, ((Integer) t.getTag()).intValue());
            t.setSelected(sel);
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) restyle(g.getChildAt(i));
        }
    }
}
