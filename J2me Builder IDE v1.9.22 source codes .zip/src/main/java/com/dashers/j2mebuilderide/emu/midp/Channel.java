package com.dashers.j2mebuilderide.emu.midp;

public interface Channel {
    void addCondition(ConditionListener a0, Condition a1);
    ChannelInfo getChannelInfo();
    Condition[] getConditions(ConditionListener a0);
    java.lang.String getChannelUrl();
    void removeAllConditions();
    void removeCondition(ConditionListener a0, Condition a1);
    void removeConditionListener(ConditionListener a0);
}
