package com.dashers.j2mebuilderide.emu;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** What the emulator learned about the loaded app before running it: identity, design resolution, assets, APIs it uses. */
public final class AppProfile {
    public String name = "", vendor = "", version = "", profile = "", configuration = "";
    /** Screen size the app was designed for (0 = unknown) and where that came from. */
    public int suggestedW, suggestedH;
    public String suggestedFrom = "";
    public int classes, images, sounds, otherFiles;
    public long totalBytes;
    public final List<String> features = new ArrayList<String>();
    public final List<String> problems = new ArrayList<String>();

    private static final Pattern SIZE = Pattern.compile("(\\d{2,4})\\s*[,xX*]\\s*(\\d{2,4})");
    private static final Pattern DIR = Pattern.compile("(?:^|/)(\\d{2,4})[xX_](\\d{2,4})(?:/|$)");

    public static AppProfile analyze(AppDescriptor app, CompatScan compat) {
        AppProfile p = new AppProfile();
        Map<String, String> pr = app.props;
        p.name = nz(pr.get("MIDlet-Name"));
        p.vendor = nz(pr.get("MIDlet-Vendor"));
        p.version = nz(pr.get("MIDlet-Version"));
        p.profile = nz(pr.get("MicroEdition-Profile"));
        p.configuration = nz(pr.get("MicroEdition-Configuration"));

        for (Map.Entry<String, byte[]> e : app.files.entrySet()) {
            String k = e.getKey(), lk = k.toLowerCase();
            p.totalBytes += e.getValue().length;
            if (k.endsWith(".class")) p.classes++;
            else if (k.startsWith("META-INF/")) continue;
            else if (lk.endsWith(".png") || lk.endsWith(".gif") || lk.endsWith(".jpg") || lk.endsWith(".jpeg") || lk.endsWith(".bmp")) p.images++;
            else if (lk.endsWith(".mid") || lk.endsWith(".midi") || lk.endsWith(".wav") || lk.endsWith(".mp3") || lk.endsWith(".amr") || lk.endsWith(".aac") || lk.endsWith(".mmf") || lk.endsWith(".ogg") || lk.endsWith(".3gp")) p.sounds++;
            else p.otherFiles++;
        }

        // design resolution: explicit attribute first, then a folder such as "240x320/"
        for (Map.Entry<String, String> e : pr.entrySet()) {
            if (!e.getKey().toLowerCase().contains("display-size")) continue;
            Matcher m = SIZE.matcher(e.getValue());
            if (m.find() && p.setSize(Integer.parseInt(m.group(1)), Integer.parseInt(m.group(2)), e.getKey())) break;
        }
        if (p.suggestedW == 0) {
            for (String k : app.files.keySet()) {
                Matcher m = DIR.matcher(k);
                if (m.find() && p.setSize(Integer.parseInt(m.group(1)), Integer.parseInt(m.group(2)), "folder " + k.substring(0, Math.min(k.length(), m.end())))) break;
            }
        }

        boolean canvas = false, ui = false, rms = false, net = false, file = false, media = false, loc = false;
        for (String u : compat.used) {
            if (u.equals("javax.microedition.lcdui.Canvas") || u.equals("javax.microedition.lcdui.game.GameCanvas") || u.startsWith("javax.microedition.lcdui.game.")) canvas = true;
            else if (u.startsWith("javax.microedition.lcdui.")) ui = ui || u.matches(".*\\.(Form|List|TextBox|Alert|ChoiceGroup|TextField|StringItem|Gauge|DateField|Ticker)");
            else if (u.startsWith("javax.microedition.rms.")) rms = true;
            else if (u.startsWith("javax.microedition.io.file.")) file = true;
            else if (u.startsWith("javax.microedition.io.")) net = net || !u.endsWith("Connection") || u.contains("Http") || u.contains("Socket") || u.contains("Datagram");
            else if (u.startsWith("javax.microedition.media.")) media = true;
            else if (u.startsWith("javax.microedition.location.")) loc = true;
            else if (u.startsWith("javax.microedition.m3g.")) p.problems.add("3D graphics (M3G) is only partly available: no .m3g files, sprites, skinning or animation yet");
            else if (u.startsWith("javax.microedition.sip.")) p.problems.add("SIP is not available");
            else if (u.startsWith("javax.obex.") || u.startsWith("javax.bluetooth.L2CAP")) p.problems.add("Bluetooth OBEX / L2CAP is not available (only the serial port, btspp://)");
            else if (u.startsWith("javax.wireless.messaging.MultipartMessage") || u.startsWith("javax.wireless.messaging.MessagePart")) p.problems.add("MMS (multipart messages) is not available");
            else if (compat.unsupportedClasses.contains(u) && (u.startsWith("com.nokia.") || u.startsWith("com.siemens.") || u.startsWith("com.samsung.") || u.startsWith("com.motorola.") || u.startsWith("com.sonyericsson.") || u.startsWith("com.mascotcapsule.") || u.startsWith("com.vodafone."))) {
                String vendor = u.substring(0, u.indexOf('.', 4) < 0 ? u.length() : u.indexOf('.', 4));
                String msg = "vendor extension " + vendor + ".* is not available";
                if (!p.problems.contains(msg)) p.problems.add(msg);
            }
        }
        if (canvas) p.features.add("custom drawing (Canvas / game API)");
        if (ui) p.features.add("standard screens (Form / List / TextBox)");
        if (rms) p.features.add("saved data (RecordStore)");
        if (net) p.features.add("network");
        if (file) p.features.add("files (FileConnection)");
        if (media) p.features.add("sound / video");
        if (loc) p.features.add("location");
        return p;
    }

    private boolean setSize(int w, int h, String from) {
        if (w < 64 || h < 64 || w > 1024 || h > 1024) return false;
        suggestedW = w;
        suggestedH = h;
        suggestedFrom = from;
        return true;
    }

    private static String nz(String s) { return s == null ? "" : s; }

    public List<String> lines() {
        List<String> l = new ArrayList<String>();
        l.add("App: " + (name.length() == 0 ? "(unnamed)" : name) + (version.length() > 0 ? " " + version : "") + (vendor.length() > 0 ? " by " + vendor : ""));
        if (profile.length() > 0 || configuration.length() > 0) l.add("Targets: " + profile + " " + configuration);
        l.add("Content: " + classes + " classes, " + images + " images, " + sounds + " sounds, " + otherFiles + " other files, " + (totalBytes / 1024) + " KB");
        if (suggestedW > 0) l.add("Designed for a " + suggestedW + "x" + suggestedH + " screen (" + suggestedFrom + ")");
        if (!features.isEmpty()) {
            StringBuilder sb = new StringBuilder("Uses: ");
            for (int i = 0; i < features.size(); i++) { if (i > 0) sb.append(", "); sb.append(features.get(i)); }
            l.add(sb.toString());
        }
        return l;
    }
}
