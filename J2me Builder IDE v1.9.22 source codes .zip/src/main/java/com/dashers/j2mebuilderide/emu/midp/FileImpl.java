package com.dashers.j2mebuilderide.emu.midp;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.util.Enumeration;
import java.util.Vector;

/**
 * JSR-75 FileConnection limited to the MIDlet suite's private folder: one root ("root1/"). Nothing outside it can be
 * reached, so no Android storage permission is needed (and shared storage is NOT offered).
 */
final class FileImpl implements FileConnection {
    private static final String ROOT = "root1";
    private final File root;
    private String vpath;           // "/" or "/root1/dir/file"
    private boolean closed;

    FileImpl(Device d, String url, int mode) throws IOException {
        root = d.fileRoot;
        if (root == null) throw new IOException("file access is not available in this host");
        root.mkdirs();
        if (!url.startsWith("file:///")) throw new IllegalArgumentException("file URL must start with file:///");
        vpath = norm("/" + url.substring("file:///".length()));
    }

    private static String norm(String p) throws IOException {
        String[] parts = p.split("/");
        java.util.ArrayList<String> out = new java.util.ArrayList<String>();
        for (String s : parts) {
            if (s.length() == 0 || s.equals(".")) continue;
            if (s.equals("..")) { if (out.isEmpty()) throw new IOException("path escapes the root"); out.remove(out.size() - 1); continue; }
            out.add(s);
        }
        StringBuilder sb = new StringBuilder("/");
        for (int i = 0; i < out.size(); i++) { sb.append(out.get(i)); if (i < out.size() - 1) sb.append('/'); }
        if (p.endsWith("/") && out.size() > 0) sb.append('/');
        return sb.toString();
    }

    private boolean atTop() { return vpath.equals("/"); }

    private File real() throws IOException {
        if (atTop()) return root;
        String rest = vpath.substring(1);
        int s = rest.indexOf('/');
        String first = s < 0 ? rest : rest.substring(0, s);
        if (!first.equals(ROOT)) throw new IOException("unknown root \"" + first + "\" (only root1/ exists)");
        File f = s < 0 ? root : new File(root, rest.substring(s + 1));
        String rc = root.getCanonicalPath(), fc = f.getCanonicalPath();
        if (!fc.equals(rc) && !fc.startsWith(rc + File.separator)) throw new IOException("path escapes the root");
        return f;
    }

    private void open() throws IOException { if (closed) throw new IOException("connection closed"); }
    private File rf() { try { return real(); } catch (IOException e) { return null; } }

    public boolean isOpen() { return !closed; }
    public void close() { closed = true; }
    public boolean exists() { File f = rf(); return atTop() || (f != null && f.exists()); }
    public boolean isDirectory() { File f = rf(); return atTop() || (f != null && f.isDirectory()); }
    public boolean canRead() { File f = rf(); return f != null && f.canRead(); }
    public boolean canWrite() { File f = rf(); return f != null && f.canWrite(); }
    public boolean isHidden() { File f = rf(); return f != null && f.isHidden(); }
    public void setReadable(boolean b) throws IOException { real().setReadable(b); }
    public void setWritable(boolean b) throws IOException { real().setWritable(b); }
    public void setHidden(boolean b) { }
    public long lastModified() { File f = rf(); return f == null ? 0 : f.lastModified(); }
    public long totalSize() { return root.getTotalSpace(); }
    public long availableSize() { return root.getUsableSpace(); }
    public long usedSize() { return size(root, true); }

    private static long size(File f, boolean sub) {
        if (f.isFile()) return f.length();
        long n = 0;
        File[] k = f.listFiles();
        if (k != null) for (File c : k) n += c.isFile() ? c.length() : (sub ? size(c, true) : 0);
        return n;
    }
    public long directorySize(boolean sub) throws IOException { open(); File f = real(); if (!f.isDirectory()) throw new IOException("not a directory"); return size(f, sub); }
    public long fileSize() throws IOException { open(); File f = real(); if (!f.isFile()) return -1; return f.length(); }

    public String getName() {
        if (atTop()) return "";
        String p = vpath.endsWith("/") ? vpath.substring(0, vpath.length() - 1) : vpath;
        String n = p.substring(p.lastIndexOf('/') + 1);
        return vpath.endsWith("/") ? n + "/" : n;
    }
    public String getPath() { int i = vpath.lastIndexOf('/', vpath.endsWith("/") ? vpath.length() - 2 : vpath.length() - 1); return i < 0 ? "/" : vpath.substring(0, i + 1); }
    public String getURL() { return "file://" + vpath; }

    public Enumeration list() throws IOException { return list("*", false); }
    public Enumeration list(String filter, boolean hidden) throws IOException {
        open();
        Vector v = new Vector();
        if (atTop()) { v.addElement(ROOT + "/"); return v.elements(); }
        File f = real();
        if (!f.isDirectory()) throw new IOException("not a directory");
        String re = filter == null ? ".*" : filter.replace(".", "\\.").replace("*", ".*").replace("?", ".");
        String[] names = f.list();
        if (names != null) {
            java.util.Arrays.sort(names);
            for (String n : names) {
                File c = new File(f, n);
                if (!hidden && c.isHidden()) continue;
                if (!n.matches(re)) continue;
                v.addElement(c.isDirectory() ? n + "/" : n);
            }
        }
        return v.elements();
    }

    public void create() throws IOException { open(); File f = real(); if (f.exists()) throw new IOException("already exists"); if (!f.createNewFile()) throw new IOException("cannot create file"); }
    public void mkdir() throws IOException { open(); File f = real(); if (f.exists()) throw new IOException("already exists"); if (!f.mkdir()) throw new IOException("cannot create directory"); }
    public void delete() throws IOException { open(); File f = real(); if (f.equals(root)) throw new SecurityException("cannot delete the root"); if (!f.delete()) throw new IOException("cannot delete"); }
    public void rename(String n) throws IOException {
        open();
        if (n == null || n.indexOf('/') >= 0 || n.length() == 0) throw new IllegalArgumentException("name");
        File f = real(), t = new File(f.getParentFile(), n);
        if (t.exists()) throw new IOException("target exists");
        if (!f.renameTo(t)) throw new IOException("rename failed");
        vpath = getPath() + n + (vpath.endsWith("/") ? "/" : "");
    }
    public void truncate(long off) throws IOException { open(); RandomAccessFile r = new RandomAccessFile(real(), "rw"); try { r.setLength(off); } finally { r.close(); } }
    public void setFileConnection(String name) throws IOException {
        open();
        String base = vpath.endsWith("/") ? vpath : vpath + "/";
        if (name.equals("..")) { vpath = norm(base + ".."); if (!vpath.endsWith("/")) vpath += "/"; }
        else { File cur = real(); if (!cur.isDirectory() && !atTop()) throw new IOException("current connection is not a directory"); vpath = norm(base + name); }
        real();
    }

    public InputStream openInputStream() throws IOException { open(); File f = real(); if (!f.isFile()) throw new IOException("no such file"); return new FileInputStream(f); }
    public DataInputStream openDataInputStream() throws IOException { return new DataInputStream(openInputStream()); }
    public OutputStream openOutputStream() throws IOException { return openOutputStream(0); }
    public DataOutputStream openDataOutputStream() throws IOException { return new DataOutputStream(openOutputStream()); }
    public OutputStream openOutputStream(long off) throws IOException {
        open();
        File f = real();
        if (!f.exists()) throw new IOException("file does not exist (call create() first)");
        final RandomAccessFile r = new RandomAccessFile(f, "rw");
        r.seek(off);
        return new OutputStream() {
            public void write(int b) throws IOException { r.write(b); }
            public void write(byte[] b, int o, int l) throws IOException { r.write(b, o, l); }
            public void close() throws IOException { r.close(); }
        };
    }
}
