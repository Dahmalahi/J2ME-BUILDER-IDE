package com.dashers.j2mebuilderide.emu.midp;

import com.dashers.j2mebuilderide.emu.vm.Vm;

import java.util.TimerTask;

/** Host-side halves of guest classes that extend runtime / JDK classes: they call back into the interpreter. */
public final class Delegates {
    private Delegates() { }

    private static final String GFX = "(Ljavax/microedition/lcdui/Graphics;)V";

    private static void rethrow(Throwable t) throws MIDletStateChangeException {
        if (t instanceof MIDletStateChangeException) throw (MIDletStateChangeException) t;
        if (t instanceof RuntimeException) throw (RuntimeException) t;
        if (t instanceof Error) throw (Error) t;
        throw new RuntimeException(t);
    }

    private static void rethrowUnchecked(Throwable t) {
        if (t instanceof RuntimeException) throw (RuntimeException) t;
        if (t instanceof Error) throw (Error) t;
        throw new RuntimeException(t);
    }

    public static void register(Vm vm) {
        vm.registerDelegate(MIDlet.class, new Vm.DelegateFactory() {
            public Object create(Vm v, Vm.GObject owner, Object[] a) { return new GuestMIDlet(v, owner); }
        });
        vm.registerDelegate(Canvas.class, new Vm.DelegateFactory() {
            public Object create(Vm v, Vm.GObject owner, Object[] a) { return new GuestCanvas(v, owner); }
        });
        vm.registerDelegate(GameCanvas.class, new Vm.DelegateFactory() {
            public Object create(Vm v, Vm.GObject owner, Object[] a) {
                return new GuestGameCanvas(v, owner, a.length > 0 && Boolean.TRUE.equals(a[0]));
            }
        });
        vm.registerDelegate(CustomItem.class, new Vm.DelegateFactory() {
            public Object create(Vm v, Vm.GObject owner, Object[] a) { return new GuestCustomItem(v, owner, a.length > 0 ? (String) a[0] : null); }
        });
        vm.registerDelegate(Thread.class, new Vm.DelegateFactory() {
            public Object create(Vm v, Vm.GObject owner, Object[] a) { return new GuestThread(v, owner, a); }
        });
        vm.registerDelegate(TimerTask.class, new Vm.DelegateFactory() {
            public Object create(Vm v, Vm.GObject owner, Object[] a) { return new GuestTimerTask(v, owner); }
        });
    }

    static final class GuestMIDlet extends MIDlet implements Vm.GuestBacked {
        final Vm vm; final Vm.GObject owner;
        GuestMIDlet(Vm vm, Vm.GObject o) { this.vm = vm; owner = o; }
        public Vm.GObject guestOwner() { return owner; }
        public void startApp() throws MIDletStateChangeException {
            try { vm.callVirtual(owner, "startApp", "()V"); } catch (Throwable t) { rethrow(t); }
        }
        public void pauseApp() {
            try { vm.callVirtual(owner, "pauseApp", "()V"); } catch (Throwable t) { rethrowUnchecked(t); }
        }
        public void destroyApp(boolean u) throws MIDletStateChangeException {
            try { vm.callVirtual(owner, "destroyApp", "(Z)V", Boolean.valueOf(u)); } catch (Throwable t) { rethrow(t); }
        }
    }

    static final class GuestCanvas extends Canvas implements Vm.GuestBacked {
        final Vm vm; final Vm.GObject owner;
        GuestCanvas(Vm vm, Vm.GObject o) { this.vm = vm; owner = o; }
        public Vm.GObject guestOwner() { return owner; }
        @Override protected void paint(Graphics g) {
            try { vm.callVirtual(owner, "paint", GFX, g); } catch (Throwable t) { rethrowUnchecked(t); }
        }
        private void fwd(String name, String desc, Object... args) {
            try { vm.callIfDefined(owner, name, desc, args); } catch (Throwable t) { rethrowUnchecked(t); }
        }
        @Override public void keyPressed(int k) { if (vm.takeSuperFlag()) return; fwd("keyPressed", "(I)V", Integer.valueOf(k)); }
        @Override public void keyReleased(int k) { if (vm.takeSuperFlag()) return; fwd("keyReleased", "(I)V", Integer.valueOf(k)); }
        @Override public void keyRepeated(int k) { if (vm.takeSuperFlag()) return; fwd("keyRepeated", "(I)V", Integer.valueOf(k)); }
        @Override public void pointerPressed(int x, int y) { if (vm.takeSuperFlag()) return; fwd("pointerPressed", "(II)V", Integer.valueOf(x), Integer.valueOf(y)); }
        @Override public void pointerReleased(int x, int y) { if (vm.takeSuperFlag()) return; fwd("pointerReleased", "(II)V", Integer.valueOf(x), Integer.valueOf(y)); }
        @Override public void pointerDragged(int x, int y) { if (vm.takeSuperFlag()) return; fwd("pointerDragged", "(II)V", Integer.valueOf(x), Integer.valueOf(y)); }
        @Override public void showNotify() { if (vm.takeSuperFlag()) return; fwd("showNotify", "()V"); }
        @Override public void hideNotify() { if (vm.takeSuperFlag()) return; fwd("hideNotify", "()V"); }
        @Override public void sizeChanged(int w, int h) { if (vm.takeSuperFlag()) return; fwd("sizeChanged", "(II)V", Integer.valueOf(w), Integer.valueOf(h)); }
    }

    static final class GuestCustomItem extends CustomItem implements Vm.GuestBacked {
        final Vm vm; final Vm.GObject owner;
        GuestCustomItem(Vm vm, Vm.GObject o, String label) { super(label); this.vm = vm; owner = o; }
        public Vm.GObject guestOwner() { return owner; }
        private int geti(String n, String d, Object... a) {
            try { return ((Number) vm.callVirtual(owner, n, d, a)).intValue(); } catch (Throwable t) { rethrowUnchecked(t); return 0; }
        }
        private void fwd(String name, String desc, Object... args) {
            try { vm.callIfDefined(owner, name, desc, args); } catch (Throwable t) { rethrowUnchecked(t); }
        }
        @Override protected int getMinContentWidth() { return geti("getMinContentWidth", "()I"); }
        @Override protected int getMinContentHeight() { return geti("getMinContentHeight", "()I"); }
        @Override protected int getPrefContentWidth(int h) { return geti("getPrefContentWidth", "(I)I", Integer.valueOf(h)); }
        @Override protected int getPrefContentHeight(int w) { return geti("getPrefContentHeight", "(I)I", Integer.valueOf(w)); }
        @Override protected void paint(Graphics g, int w, int h) {
            try { vm.callVirtual(owner, "paint", "(Ljavax/microedition/lcdui/Graphics;II)V", g, Integer.valueOf(w), Integer.valueOf(h)); } catch (Throwable t) { rethrowUnchecked(t); }
        }
        @Override protected void sizeChanged(int w, int h) { if (vm.takeSuperFlag()) return; fwd("sizeChanged", "(II)V", Integer.valueOf(w), Integer.valueOf(h)); }
        @Override protected boolean traverse(int dir, int vw, int vh, int[] vis) {
            if (vm.takeSuperFlag()) return false;
            try { Object r = vm.callVirtual(owner, "traverse", "(III[I)Z", Integer.valueOf(dir), Integer.valueOf(vw), Integer.valueOf(vh), vis);
                return r instanceof Boolean ? (Boolean) r : r instanceof Number && ((Number) r).intValue() != 0; } catch (Throwable t) { rethrowUnchecked(t); return false; }
        }
        @Override protected void traverseOut() { if (vm.takeSuperFlag()) return; fwd("traverseOut", "()V"); }
        @Override protected void keyPressed(int k) { if (vm.takeSuperFlag()) return; fwd("keyPressed", "(I)V", Integer.valueOf(k)); }
        @Override protected void keyReleased(int k) { if (vm.takeSuperFlag()) return; fwd("keyReleased", "(I)V", Integer.valueOf(k)); }
        @Override protected void keyRepeated(int k) { if (vm.takeSuperFlag()) return; fwd("keyRepeated", "(I)V", Integer.valueOf(k)); }
        @Override protected void pointerPressed(int x, int y) { if (vm.takeSuperFlag()) return; fwd("pointerPressed", "(II)V", Integer.valueOf(x), Integer.valueOf(y)); }
        @Override protected void pointerReleased(int x, int y) { if (vm.takeSuperFlag()) return; fwd("pointerReleased", "(II)V", Integer.valueOf(x), Integer.valueOf(y)); }
        @Override protected void pointerDragged(int x, int y) { if (vm.takeSuperFlag()) return; fwd("pointerDragged", "(II)V", Integer.valueOf(x), Integer.valueOf(y)); }
        @Override protected void showNotify() { if (vm.takeSuperFlag()) return; fwd("showNotify", "()V"); }
        @Override protected void hideNotify() { if (vm.takeSuperFlag()) return; fwd("hideNotify", "()V"); }
    }

    static final class GuestThread extends Thread implements Vm.GuestBacked {
        final Vm vm; final Vm.GObject owner;
        GuestThread(Vm vm, Vm.GObject o, Object[] a) {
            super(a.length > 0 && a[0] instanceof Runnable ? (Runnable) a[0] : null);
            this.vm = vm;
            owner = o;
            if (a.length > 0 && a[a.length - 1] instanceof String) setName((String) a[a.length - 1]);
        }
        public Vm.GObject guestOwner() { return owner; }
        @Override public void run() {
            if (vm.takeSuperFlag()) { super.run(); return; }
            try {
                if (!vm.callIfDefined(owner, "run", "()V")) super.run();
            } catch (Throwable t) { vm.reportUncaught("thread " + getName(), t); }
        }
    }

    static final class GuestTimerTask extends TimerTask implements Vm.GuestBacked {
        final Vm vm; final Vm.GObject owner;
        GuestTimerTask(Vm vm, Vm.GObject o) { this.vm = vm; owner = o; }
        public Vm.GObject guestOwner() { return owner; }
        @Override public void run() {
            try { vm.callVirtual(owner, "run", "()V"); } catch (Throwable t) { vm.reportUncaught("timer task", t); }
        }
    }

    static final class GuestGameCanvas extends GameCanvas implements Vm.GuestBacked {
        final Vm vm; final Vm.GObject owner;
        GuestGameCanvas(Vm vm, Vm.GObject o, boolean suppress) { super(suppress); this.vm = vm; owner = o; }
        public Vm.GObject guestOwner() { return owner; }
        @Override public void paint(Graphics g) {
            if (vm.takeSuperFlag()) { super.paint(g); return; }
            try { if (!vm.callIfDefined(owner, "paint", GFX, g)) super.paint(g); } catch (Throwable t) { rethrowUnchecked(t); }
        }
        private void fwd(String name, String desc, Object... args) {
            try { vm.callIfDefined(owner, name, desc, args); } catch (Throwable t) { rethrowUnchecked(t); }
        }
        @Override public void keyPressed(int k) { if (vm.takeSuperFlag()) return; fwd("keyPressed", "(I)V", Integer.valueOf(k)); }
        @Override public void keyReleased(int k) { if (vm.takeSuperFlag()) return; fwd("keyReleased", "(I)V", Integer.valueOf(k)); }
        @Override public void keyRepeated(int k) { if (vm.takeSuperFlag()) return; fwd("keyRepeated", "(I)V", Integer.valueOf(k)); }
        @Override public void pointerPressed(int x, int y) { if (vm.takeSuperFlag()) return; fwd("pointerPressed", "(II)V", Integer.valueOf(x), Integer.valueOf(y)); }
        @Override public void pointerReleased(int x, int y) { if (vm.takeSuperFlag()) return; fwd("pointerReleased", "(II)V", Integer.valueOf(x), Integer.valueOf(y)); }
        @Override public void pointerDragged(int x, int y) { if (vm.takeSuperFlag()) return; fwd("pointerDragged", "(II)V", Integer.valueOf(x), Integer.valueOf(y)); }
        @Override public void showNotify() { if (vm.takeSuperFlag()) return; fwd("showNotify", "()V"); }
        @Override public void hideNotify() { if (vm.takeSuperFlag()) return; fwd("hideNotify", "()V"); }
        @Override public void sizeChanged(int w, int h) { if (vm.takeSuperFlag()) return; fwd("sizeChanged", "(II)V", Integer.valueOf(w), Integer.valueOf(h)); }
    }
}
