package com.dashers.j2mebuilderide.emu.midp;

public interface DataAndErrorListener extends DataListener {
    void errorReceived(SensorConnection a0, int a1, long a2);
}
