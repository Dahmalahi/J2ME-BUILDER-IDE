package com.dashers.j2mebuilderide.emu;

import java.util.ArrayList;
import java.util.List;

/** What the built-in runtime really provides, with the labels the roadmap asks for. Shown in the emulator and docs. */
public final class Capabilities {
    public static final String IMPLEMENTED = "Implemented", PARTIAL = "Partially implemented", SIMULATED = "Simulated",
            STUB_ONLY = "Compile-time stub only", UNSUPPORTED = "Unsupported";

    public static final class Row {
        public final String api, status, note;
        final String[] prefixes;
        Row(String api, String status, String note, String... prefixes) { this.api = api; this.status = status; this.note = note; this.prefixes = prefixes; }
        @Override public String toString() { return api + " - " + status + ": " + note; }
    }

    private static final List<Row> ROWS = new ArrayList<Row>();
    static {
        ROWS.add(new Row("MIDP 2.0 core: lifecycle, Display, Canvas, Graphics, Image, Font, Command", IMPLEMENTED, "software renderer; fonts come from Android"));
        ROWS.add(new Row("LCDUI items: Form, List, TextBox, Alert, StringItem, TextField, ChoiceGroup, Gauge, DateField, Spacer, ImageItem", IMPLEMENTED, "single-column layout; text entry through a dialog"));
        ROWS.add(new Row("Game API: GameCanvas, Sprite, TiledLayer, LayerManager", IMPLEMENTED, "pixel-level collisions included"));
        ROWS.add(new Row("RMS record stores", IMPLEMENTED, "files per MIDlet suite; 1 MB quota"));
        ROWS.add(new Row("SVG / M2G (JSR-226): SVGImage.createImage, ScalableGraphics.bindTarget/render/releaseTarget, viewport, transparency", PARTIAL, "needs a phone test: static pictures only, drawn by the runtime from the DOM (shapes, paths with arcs, transforms, fill/stroke colours, opacity, fill-rule, viewBox/preserveAspectRatio, gradients as their first colour); no text, images, filters, masks, clipping, patterns, dashes; getDocument() gives a plain DOM, SVG-specific DOM interfaces, SVGAnimator, focusOn and dispatchMouseEvent are not provided", "javax.microedition.m2g", "org.w3c.dom.svg"));
        ROWS.add(new Row("3D (JSR-184 M3G, javax.microedition.m3g)", PARTIAL, "needs a phone test (speed above all: software renderer); written from the JSR-184 API and file format, no third-party code: full API surface, Loader for .m3g files (zlib sections, all object types, forward references) and PNG/JPEG as Image2D, scene graph, immediate and retained rendering, lighting, fog, textures, blending, Sprite3D, SkinnedMesh, MorphingMesh, keyframe animation (LINEAR, STEP, SLERP, SPLINE; SQUAD is played as SLERP) with track blending, picking (undeformed meshes); NOT yet: node alignment, mipmaps, antialiasing, depth offset, two-sided lighting, Object3D.duplicate, external references in .m3g files", "javax.microedition.m3g"));
        ROWS.add(new Row("SIP (JSR-180)", UNSUPPORTED, "not provided: Connector.open(\"sip:...\") gives a clear ConnectionNotFoundException; a SIP stack is too large for the built-in emulator", "javax.microedition.sip"));
        ROWS.add(new Row("Bluetooth (JSR-82 javax.bluetooth): LocalDevice, DiscoveryAgent (inquiry, service search, selectService), RemoteDevice, UUID, ServiceRecord, btspp:// client and server", PARTIAL, "needs a phone test for real Bluetooth: serial port (RFCOMM) only; simulated by default (a virtual echo device); real mode asks before listing paired devices, scanning, connecting and offering a service; pairing, authentication and making the phone discoverable are done in Android settings (authenticate/authorize/encrypt return false, setDiscoverable is ignored); service search reports the UUIDs the device advertises, SPP assumed when unknown", "javax.bluetooth"));
        ROWS.add(new Row("Bluetooth L2CAP (btl2cap://) and OBEX (javax.obex, btgoep://, irdaobex://)", UNSUPPORTED, "Connector.open gives a clear ConnectionNotFoundException; the L2CAP/OBEX classes are not provided", "javax.bluetooth.L2CAPConnection", "javax.bluetooth.L2CAPConnectionNotifier", "javax.obex"));
        ROWS.add(new Row("Sensors (JSR-256 javax.microedition.sensor): SensorManager.findSensors, SensorInfo, SensorConnection, getData, DataListener, conditions, Channel/ChannelInfo/Data", PARTIAL, "needs a phone test: acceleration (m/s2, int channels with scale -3), magnetic_field (T, scale -9), orientation (degrees), light (lux), proximity (m) from the phone or from simulated sensors (More > Sensors: sliders, arrow-key tilt); 50 Hz; Data is lenient between int and double; conditions fire when they turn true; no availability push, no error reporting", "javax.microedition.sensor"));
        ROWS.add(new Row("Sensor controls (javax.microedition.sensor.control) and vendor accelerometers (Nokia, Samsung, Sony Ericsson)", UNSUPPORTED, "SampleRateControl etc. are not provided; vendor accelerometer APIs stay unsupported until their licence terms are reviewed - they can be added later as an adapter on the same SensorProvider", "javax.microedition.sensor.control", "com.nokia.mid.sensor", "com.samsung.sensor", "com.sonyericsson.accelerometer"));
        ROWS.add(new Row("PIM (JSR-75 javax.microedition.pim): ContactList, EventList, ToDoList, items, fields, categories, RepeatRule", PARTIAL, "needs a phone test for real phone data: sandbox by default (internal address book, calendar and to-do list saved per MIDlet suite, MIDlets may write); More > Contacts & calendar shows the phone's real contacts/events READ-ONLY after you allow it (writes give a SecurityException; to-do stays sandbox); no vCard/vCalendar (fromSerialFormat/toSerialFormat), RepeatRule expands DAILY/WEEKLY/MONTHLY/YEARLY only, no extended fields or attributes", "javax.microedition.pim"));
        ROWS.add(new Row("WMA 1.1 (JSR-120): sms:// MessageConnection, TextMessage, BinaryMessage, MessageListener, numberOfSegments", PARTIAL, "needs a phone test for real SMS: simulated by default (sends are only logged, incoming messages come from More > SMS); real mode asks SEND_SMS and your confirmation before EVERY message; real receiving only for binary SMS on the listened port - the phone's text messages are never handed to a MIDlet; max 10 segments", "javax.wireless.messaging"));
        ROWS.add(new Row("WMA 2.0 (JSR-205): mms://, MultipartMessage, MessagePart", UNSUPPORTED, "mms:// gives a clear ConnectionNotFoundException, newMessage(\"multipart\") an IllegalArgumentException", "javax.wireless.messaging.MultipartMessage", "javax.wireless.messaging.MessagePart"));
        ROWS.add(new Row("MMAPI audio (JSR-135): Manager, Player, ToneControl, VolumeControl", PARTIAL, "tones and WAV are synthesised/decoded in the runtime; MIDI/MP3/AMR/AAC use Android MediaPlayer; media from file:///root1/ and http(s) URLs is downloaded fully, then played; no streaming, MIDI/tempo/rate controls", "javax.microedition.media"));
        ROWS.add(new Row("MMAPI camera (JSR-135): capture://video, capture://image, capture://devcamN, VideoControl, GUIControl", PARTIAL, "needs a phone test: preview is drawn by the runtime (direct video over a Canvas or a Form item), getSnapshot gives JPEG/PNG up to the preview size (about 640 px), CAMERA permission asked at first use; More > Camera selects the phone camera, a test pattern or a chosen picture; zoom and flash light are set from More > Camera (not from the MIDlet: JSR-234 camera controls are Unsupported)", "javax.microedition.media.control.VideoControl", "javax.microedition.media.control.GUIControl"));
        ROWS.add(new Row("MMAPI video recording: capture://video + RecordControl", PARTIAL, "needs a phone test: phone camera only (MediaRecorder, MP4 with sound when RECORD_AUDIO is allowed), committed to a stream or file:///root1/; the live preview may freeze while recording; the virtual camera cannot record", "javax.microedition.media.control.RecordControl"));
        ROWS.add(new Row("MMAPI microphone (JSR-135): capture://audio, RecordControl (audio)", PARTIAL, "needs a phone test: 8/16-bit mono PCM written as WAV (setRecordStream or file:///root1/ location) at commit(); RECORD_AUDIO asked at first use; AMR/other encodings are refused with a clear message", "javax.microedition.media.control.RecordControl"));
        ROWS.add(new Row("MMAPI video playback (3GP/MP4)", PARTIAL, "needs a phone test: Android MediaPlayer decodes into an off-screen reader, frames are shown through VideoControl (rotation metadata honoured); FramePositioningControl maps frames with an estimated frame rate; falls back to sound only if the phone's decoder gives no frames", "javax.microedition.media.control.FramePositioningControl"));
        ROWS.add(new Row("Networking: HttpConnection, SocketConnection, SecureConnection, ServerSocketConnection, DatagramConnection", PARTIAL, "HTTP/HTTPS, TCP socket://, TLS ssl://, server sockets (socket://:port, serversocket://:port) and UDP datagram://; ON by default, switch in More > Network access; GET/HEAD redirects (up to 5, including http to https) are followed automatically, POST redirects are left to the app; operator URL parameters (;deviceside=, ;apn= ...) are ignored; a warning is logged when network code runs on the UI event thread; no SMS or Bluetooth", "javax.microedition.io"));
        ROWS.add(new Row("FileConnection (JSR-75)", PARTIAL, "one root only: file:///root1/ = the phone's J2MEBuilder/root1 folder when the IDE has file access (private app folder otherwise); no other roots", "javax.microedition.io.file"));
        ROWS.add(new Row("Location API (JSR-179)", SIMULATED, "returns the position you set in More > Location; no GPS", "javax.microedition.location"));
        ROWS.add(new Row("Vibration, backlight, Ticker", SIMULATED, "accepted, no visible effect"));
        ROWS.add(new Row("PIM (JSR-75)", UNSUPPORTED, "no contact/calendar access", "javax.microedition.pim"));
        ROWS.add(new Row("Sensor API (JSR-256)", UNSUPPORTED, "", "javax.microedition.sensor"));
        ROWS.add(new Row("Bluetooth / OBEX (JSR-82)", UNSUPPORTED, "", "javax.bluetooth", "javax.obex"));
        ROWS.add(new Row("Wireless Messaging (JSR-120/205)", UNSUPPORTED, "", "javax.wireless.messaging"));
        ROWS.add(new Row("Content Handler (JSR-211)", UNSUPPORTED, "", "javax.microedition.content"));
        ROWS.add(new Row("Nokia UI API subset: FullCanvas, DeviceControl, DirectGraphics, DirectUtils", PARTIAL, "needs a phone test; written from the public API (no vendor SDK code): FullCanvas (soft key codes -6/-7/-5), DeviceControl (lights and vibration are accepted, no visible effect), DirectUtils.createImage/getFont, DirectGraphics fill/draw polygons and triangles with alpha, drawImage and drawPixels (int ARGB/RGB, short 4444/444/555/565, byte 8-bit gray and 3-3-2) with flips and counter-clockwise rotations, getPixels (int and short); packed 1/2/4-bit pixel formats and byte getPixels are not provided", "com.nokia.mid.ui.FullCanvas", "com.nokia.mid.ui.DeviceControl", "com.nokia.mid.ui.DirectGraphics", "com.nokia.mid.ui.DirectUtils"));
        ROWS.add(new Row("Nokia Sound API (com.nokia.mid.sound.Sound)", PARTIAL, "needs a phone test: WAV data and single tones (frequency, duration) play with listener events; the Nokia ringtone binary format (FORMAT_TONE with data) stays silent", "com.nokia.mid.sound.Sound", "com.nokia.mid.sound.SoundListener"));
        ROWS.add(new Row("Samsung util: Vibration, LCDLight, AudioClip", PARTIAL, "needs a phone test: vibration and light are accepted without a visible effect; AudioClip plays MP3 and MIDI (MMF stays silent)", "com.samsung.util.Vibration", "com.samsung.util.LCDLight", "com.samsung.util.AudioClip"));
        ROWS.add(new Row("Other phone-maker extensions (Nokia TextEditor/CanvasItem, Siemens, Motorola, Sony Ericsson, Samsung SMS, Mascot Capsule v3)", UNSUPPORTED, "not provided: not written yet; Mascot Capsule v3 needs its model file formats (MBAC/MTRA) and exact API semantics, which come either from the specification or from code with a compatible licence (for example the Apache-2.0 J2ME-Loader micro3d package, which can be ported with attribution if its source is supplied)", "com.nokia", "com.siemens", "com.samsung", "com.mascotcapsule", "com.motorola", "com.sonyericsson"));
    }

    private Capabilities() { }

    public static List<Row> rows() { return new ArrayList<Row>(ROWS); }

    /** The registry row covering a class (dotted name), or null. */
    public static Row forClass(String dotted) {
        Row best = null;
        int bestLen = -1;
        for (Row r : ROWS) for (String p : r.prefixes) if (dotted.startsWith(p) && p.length() > bestLen) { best = r; bestLen = p.length(); }
        return best;
    }

    public static String report() {
        StringBuilder sb = new StringBuilder();
        for (Row r : ROWS) sb.append(r.status).append("  |  ").append(r.api).append(r.note.length() > 0 ? "  -  " + r.note : "").append('\n');
        return sb.toString();
    }
}
