package com.dashers.j2mebuilderide.emu.midp;

public class FieldFullException extends RuntimeException {
    private final int field;
    public FieldFullException() { super(); field = -1; }
    public FieldFullException(String m) { super(m); field = -1; }
    public FieldFullException(String m, int field) { super(m); this.field = field; }
    public int getField() { return field; }
}
