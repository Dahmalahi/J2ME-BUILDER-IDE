package com.dashers.j2mebuilderide.emu.midp;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Display {
    private final Device device;
    private volatile Displayable current;

    Display(Device d) { device = d; }

    public static Display getDisplay(MIDlet m) {
        if (m == null) throw new NullPointerException();
        return m.device.display;
    }

    public Displayable getCurrent() { return current; }

    public void setCurrent(final Displayable d) {
        if (d == null) return;
        if (d instanceof Alert) { setCurrent((Alert) d, current); return; }
        switchTo(d);
    }

    public void setCurrent(Alert a, Displayable next) {
        if (a == null || next == null) throw new NullPointerException();
        if (next instanceof Alert) throw new IllegalArgumentException("next must not be an Alert");
        a.next = next;
        switchTo(a);
    }

    void dismissAlert(final Alert a) {
        if (current != a) return;
        Displayable n = a.next;
        if (n != null) switchTo(n);
    }

    private void switchTo(final Displayable d) {
        Displayable old = current;
        current = d;
        final Displayable prev = old;
        device.post(new Runnable() {
            public void run() {
                if (prev != null && prev != d) prev.hideNotifyInternal();
                d.showNotifyInternal();
                device.renderNow();
                if (d instanceof Alert && ((Alert) d).getTimeout() != Alert.FOREVER) {
                    final Alert a = (Alert) d;
                    device.postDelayed(new Runnable() { public void run() { dismissAlert(a); } }, a.getTimeout());
                }
            }
        });
    }

    public void callSerially(Runnable r) {
        if (r == null) throw new NullPointerException();
        device.post(r);
    }

    public boolean isColor() { return true; }
    public int numColors() { return 1 << 24; }
    public int numAlphaLevels() { return 256; }
    public boolean flashBacklight(int ms) { return false; }
    public boolean vibrate(int ms) { return false; }

    void requestRepaint() { device.scheduleRepaint(); }

    void serviceRepaints() {
        device.postAndWait(new Runnable() { public void run() { device.renderNow(); } }, 2000);
    }

    // ---- input from the host (called from any thread, delivered on the event thread)

    public void dispatchKey(final int type, final int code) {
        device.post(new Runnable() {
            public void run() {
                Displayable d = current;
                if (d == null) return;
                if (d instanceof Canvas) {
                    Canvas c = (Canvas) d;
                    c.trackKey(type, code);
                    boolean soft = code == Canvas.CODE_SOFT1 || code == Canvas.CODE_SOFT2;
                    if (soft && !c.fullScreen() && !c.commandsSnapshot().isEmpty()) {
                        if (type == 0) fireNow(code == Canvas.CODE_SOFT1 ? 0 : 1);
                        return;
                    }
                    if (c.suppressKeys()) return;
                    if (type == 0) c.keyPressed(code); else if (type == 1) c.keyReleased(code); else c.keyRepeated(code);
                    return;
                }
                if (code == Canvas.CODE_SOFT1 || code == Canvas.CODE_SOFT2) {
                    if (type == 0) fireNow(code == Canvas.CODE_SOFT1 ? 0 : 1);
                    return;
                }
                d.keyEvent(device, type, code);
            }
        });
    }

    /** Pointer input in screen coordinates: type 0 pressed, 1 released, 2 dragged. */
    public void dispatchPointer(final int type, final int x, final int y) {
        device.post(new Runnable() {
            public void run() {
                Displayable d = current;
                if (d == null) return;
                if (d instanceof Canvas) {
                    Canvas c = (Canvas) d;
                    if (type == 0) c.pointerPressed(x, y); else if (type == 1) c.pointerReleased(x, y); else c.pointerDragged(x, y);
                    return;
                }
                if (d instanceof Screen && type == 0) {
                    int k = ((Screen) d).softKeyAt(device, x, y);
                    if (k >= 0) { fireNow(k); return; }
                }
                d.pointerEvent(device, type, x, y);
            }
        });
    }

    /** Fires the n-th command (priority order) of the current screen to its listener. */
    public void fireCommand(final int index) {
        device.post(new Runnable() { public void run() { fireNow(index); } });
    }

    private void fireNow(int index) {
        Displayable d = current;
        if (d == null) return;
        List<Command> cs = d instanceof Screen ? ((Screen) d).visibleCommands() : sortedCommands(d);
        if (index < 0 || index >= cs.size()) {
            if (d instanceof Alert && cs.isEmpty() && index == 0) dismissAlert((Alert) d);
            return;
        }
        CommandListener l = d.listener();
        if (l != null) l.commandAction(cs.get(index), d);
        else device.log(1, "Command \"" + cs.get(index).getLabel() + "\" pressed but the screen has no CommandListener");
    }

    /** Labels of the commands on the current screen, in softkey order. */
    public List<String> commandLabels() {
        List<String> r = new ArrayList<String>();
        Displayable d = current;
        if (d == null) return r;
        List<Command> cs = d instanceof Screen ? ((Screen) d).visibleCommands() : sortedCommands(d);
        for (Command c : cs) r.add(c.getLabel());
        if (r.isEmpty() && d instanceof Alert) r.add("Done");
        return r;
    }

    static List<Command> sortedCommands(Displayable d) {
        List<Command> cs = d.commandsSnapshot();
        Collections.sort(cs, new Comparator<Command>() {
            public int compare(Command a, Command b) { return a.getPriority() - b.getPriority(); }
        });
        return cs;
    }

    void showFirstFrame() { device.post(new Runnable() { public void run() { device.renderNow(); } }); }
}
