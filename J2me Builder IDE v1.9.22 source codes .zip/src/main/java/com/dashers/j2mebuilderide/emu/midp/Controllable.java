package com.dashers.j2mebuilderide.emu.midp;

public interface Controllable {
    Control[] getControls();
    Control getControl(String type);
}
