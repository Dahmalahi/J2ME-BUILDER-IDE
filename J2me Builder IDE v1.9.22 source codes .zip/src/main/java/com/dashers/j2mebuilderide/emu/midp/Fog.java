package com.dashers.j2mebuilderide.emu.midp;

/** Generated from the JSR-184 class list (tools in docs); properties are stored, rendering lives in Graphics3D. */
public class Fog extends Object3D {
    public static final int EXPONENTIAL = 80;
    public static final int LINEAR = 81;
    int mode = 81;
    float nearDistance;
    float farDistance = 1f;
    float density = 1f;
    int color;
    public Fog() { }

    public void setMode(int v) { mode = v; }
    public int getMode() { return mode; }
    public void setLinear(float a0, float a1) { nearDistance = a0; farDistance = a1; }
    public float getNearDistance() { return nearDistance; }
    public float getFarDistance() { return farDistance; }
    public void setDensity(float v) { density = v; }
    public float getDensity() { return density; }
    public void setColor(int v) { color = v; }
    public int getColor() { return color; }
}
