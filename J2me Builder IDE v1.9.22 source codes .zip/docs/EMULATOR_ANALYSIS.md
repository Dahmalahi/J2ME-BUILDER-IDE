# Emulator analysis (v1.6.3)

Everything the emulator learns about the running app goes to the log, one line per finding, prefixed `[analysis]`.
Filter with the **Analysis** chip in the log panel, or open *More > Analysis report*; *More > Copy full report* includes it.

| Source | What is reported |
|---|---|
| App profile (`AppProfile`) | name/vendor/version, assets count, APIs used, the screen size the app was designed for (`*Display-Size` attribute or a `240x320/` folder) - the emulator starts at that size the first time |
| Resources (`ResourceIndex`) | every missing file once, with "did you mean"; paths found only by ignoring case or folder (a phone would not find them) |
| Exceptions (`Diagnostics.analyze`) | uncaught errors and stack traces printed by the app: plain explanation + suggested fix + the first app frame |
| Images | undecodable image data says what the bytes really are (empty, text, not PNG/JPEG/GIF/BMP) |
| System properties | every `System.getProperty` key the app asks for that the emulator does not define |
| Exit | `notifyDestroyed()` / `System.exit()` shortly after start: lists the problems that came just before (apps "restart" because they quit when a load fails) |
| Watchdog | no screen shown after 4 s, `startApp()` still running, flat blank screen after 9 s |

Verified on a desktop JVM: `DiagnosticsTest` (resource tolerance, once-per-kind reporting, quick-exit explanation).
Needs a phone test: the redesigned `EmulatorActivity` (pill controls, log panel, bottom sheet menu, rounded screen).
