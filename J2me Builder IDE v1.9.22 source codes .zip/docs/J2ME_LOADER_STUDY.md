# What J2ME-Loader does, and what it means for this emulator

Source studied: the J2ME-Loader zip you supplied (Apache-2.0, https://github.com/nikita36078/J2ME-Loader). Read for
architecture only; no code from it was copied into this project.

## The key difference

| | J2ME-Loader | This IDE's built-in emulator (V1.5) |
|---|---|---|
| How MIDlet code runs | The JAR's `.class` files are **converted to dex** (`dexlib` = a copy of Android's `dx` + ASM) and loaded by a `DexClassLoader`. The phone's ART runs the MIDlet **natively**. | Own **bytecode interpreter** in Java. |
| `javax.microedition.*` | Real classes in the app (`app/src/main/java/javax/microedition/...`: lcdui, game, media, io, rms, m3g, pim, sensor, location, bluetooth, ...). | Same API, but in `emu.midp.*` and name-mapped. |
| Class patching | ASM visitors rewrite a few JDK references (e.g. `java.util.Timer`) before dexing. | Name mapper only. |
| Stopping a MIDlet | Runs in its own process; the process is ended. | Cooperative halt flag. |
| Speed | Native. | Measured here on a desktop JVM: fib 6 ms native vs 140-530 ms interpreted; loop 7 ms vs 370-1400 ms (25-200x slower; ART numbers will differ but the gap stays large). |

Consequence: no interpreter tuning can make action games run like J2ME-Loader. The gap is structural.

## What a native mode would need here

1. A dexer on the phone: Android's `dx` (Apache-2.0) + ASM 9, as J2ME-Loader ships. About 14k lines of third-party code plus
   NOTICE/licence text; the APK grows by roughly 2-3 MB. D8 is not a drop-in for on-device use.
2. `javax.microedition.*` as real classes (or an ASM rename pass from `emu.midp.*` at conversion time). My classes already
   exist and are tested; the rename pass is small (constant-pool rewrite).
3. Run the MIDlet in a separate Android process (`android:process=":emu"`) so Stop really stops busy loops.
4. Keep the interpreter as the fallback / for desktop-JVM testing.

Cannot be verified in this workspace: there is no Android SDK and no device, so the dexing and process model could only be
tested on your phone.

## Other things worth borrowing (ideas, not code)

* Conversion result cached per JAR; re-converted only when the JAR changes.
* Per-app config profiles (screen size, key mapping, FPS limit, font size) - partly done (screen size, key map).
* On-screen virtual keyboard overlay with editable layout - done in simple form (keypad panel).
* FPS limit / frame skip option.
