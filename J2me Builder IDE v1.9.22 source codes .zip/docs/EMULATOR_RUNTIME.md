# Built-in emulator runtime (V1.2.5 proof of concept)

> **V1.6: two engines.** *Native* (default, like J2ME-Loader): the MIDlet jar is converted to dex once (Android `dx`
> bundled from J2ME-Loader's dexlib, Apache-2.0, see `docs/LICENSE-J2ME-Loader-Apache-2.0.txt`; each class is first
> rewritten with ASM by `emu/nat/Instrumenter`) and run by the phone's own runtime, so speed is that of a native app.
> *Interpreter* (fallback, and used by the desktop tests): the original bytecode interpreter. If conversion or class
> loading fails the emulator says so and falls back to the interpreter by itself. The emulator window runs in its own
> process (`:emu`) so ending it really ends a MIDlet stuck in a busy loop. More > Engine switches between them.
> **Verified here (desktop JVM):** the rewritten classes run the same MIDlets natively (features, game canvas, custom
> items, sound/file/location/date field) and `dx` converts the rewritten jar to a valid dex. **Not verified (needs your
> phone):** loading that dex with `DexClassLoader`, speed on the phone, the `:emu` process behaviour.
> **root1:** `file:///root1/` is the phone's `J2MEBuilder/root1/` folder (shared storage) when the IDE has file access.

**Status: experimental, default OFF** (Settings -> Experimental -> "Built-in emulator"). The external emulator
hand-off (`EmulatorLauncher`) and the MicroEmulator setting (`MicroEmuBridge`) are unchanged and remain the
supported way to run a MIDlet.

## Decision: own runtime, no third-party emulator code bundled

| Candidate | Licence | Why it was not embedded |
|---|---|---|
| MicroEmulator (r2206 trunk, supplied) | dual LGPL-2.1 / Apache-2.0 | Core and the Android port depend on Swing/AWT-style display code, ASM class instrumentation and build-time `dx`. The Android port is a separate app that cannot open a jar passed from the IDE. Embedding needs a port and a dex toolchain that this project does not have. No MicroEmulator source was copied. |
| J2ME Loader | Apache-2.0 | Large Android app, not a library; not reviewed for extraction. |
| Desktop Swing emulators | various | Explicitly out of scope (roadmap). |

Chosen: a small Java bytecode interpreter plus an own MIDP subset, written for this project (same licence as the
IDE). Reason: Android cannot load plain `.class` files at runtime, and no dexer is available on the device, so
interpreting the jar's classes is the only way to run an arbitrary built jar without a build-time dex step.

Provenance: all code under `emu/` was written for this project. Nothing from MicroEmulator, J2ME Loader or any
other emulator is included. If MicroEmulator game classes are bundled later they need a licence/attribution
review first (the Apache-2.0 option would apply).

## Layout (isolated module)

```
emu/vm       ClassFile parser, Vm (bytecode interpreter)          pure Java
emu/gfx      Frame (ARGB surface + primitives), Platform hooks    pure Java
emu/midp     LCDUI/MIDlet subset, Device (event thread), Names    pure Java
emu          EmuSession (public API), AppDescriptor, ConsoleLog   pure Java
emu/android  AndroidPlatform, EmulatorView, EmulatorActivity      Android adapter
```

`EmuSessionTest.runtimeIsIsolatedFromEditorCompilerAndPackager` fails if `emu/` (outside `emu/android`) imports
`android.*` or IDE `ide/ui/compiler` classes. The IDE only passes the built jar and JAD text:
`new EmuSession(jarBytes, jadText, platform, w, h)`, then `start / pause / resume / stop`.

## What is implemented (V1.2.5 - V1.2.9 core, built on the same runtime)

* Class files up to version 52, including old unpreverified code with `jsr/ret`; `invokedynamic` and
  constant-dynamic are rejected with a clear message.
* Manifest + JAD parsing (JAD wins), `MIDlet-n` entries, multi-MIDlet suites.
* **Compatibility scan before every run**: every class of the jar is inspected and the console lists MIDP classes
  and methods the runtime does not provide (for example `javax.microedition.media.Manager`).
* Lifecycle: start, pause (pauseApp once), resume (startApp once), stop (destroyApp(true)), `notifyDestroyed`,
  `notifyPaused`. Repeated calls are ignored, so callbacks never duplicate. Busy-loop MIDlets can still be stopped.
* LCDUI high level: `Form` (StringItem, ImageItem, TextField, ChoiceGroup, Gauge, Spacer, ItemStateListener),
  `List` (IMPLICIT / EXCLUSIVE / MULTIPLE, select command), `TextBox`, `Alert` (timeouts, types), `Ticker` (stored,
  not drawn), `Command`/`CommandListener` on soft keys, focus navigation and scrolling, touch.
* LCDUI low level: `Canvas`, `Graphics` (rects, rounded rects, lines, arcs, triangles, strings, images, regions with
  all 8 transforms, clip, translate, RGB), `Image`, `Font`.
* Game API: `GameCanvas` (off-screen buffer, `flushGraphics`, latched `getKeyStates`, suppressed key events),
  `Sprite` (frames, sequences, transforms, reference pixel, rectangle and pixel-level collisions against sprites,
  tiled layers and images), `TiledLayer` (static + animated tiles), `LayerManager` (view window).
* **RMS**: `RecordStore` (add/get/set/delete, listeners, enumerations with filter and comparator, quota),
  stored per MIDlet suite in files (`files/emu_rms/<vendor_name>/`), survives restarts, "Saved data" browser and
  "Clear data" only touch the selected suite.
* Device: profiles 128x160, 176x208, 240x320, 320x480 and custom 16..1024, portrait/landscape (the MIDlet gets
  `sizeChanged`), aspect ratio kept, touch coordinates mapped back to screen pixels, pointer events.
* Input: numeric keypad 0-9 * #, d-pad, select, soft keys, hold-to-repeat, external keyboard with an editable,
  persisted key map, text entry through an Android dialog (TextField / TextBox).
* Tools: screenshot (PNG in the app's external files folder), FPS in the status line, console with levels,
  copy-report for bug reports, separate emulator console.
* Runtime errors: uncaught exceptions with a guest stack trace go to the emulator console; `System.out/err` and
  `printStackTrace` of the MIDlet too. A MIDlet crash ends only its session.
* Anything not provided is named, never silently wrong.

## Known limits (do not read this as full MIDP 2.0 support)

Still missing: Item commands, `Graphics.copyArea`, `platformRequest`, vibration/backlight have no visible
effect (they return false/are accepted), `Ticker` text is not drawn. Fonts come from Android, so widths differ from
real phones. Layout of Form items is a single column. Guest reflection is limited to
`Class.forName/getName/newInstance/getResourceAsStream`.

**Speed.** The interpreter is still much slower than a real phone JVM. This build added a call-site inline cache, a
small boxed-Integer cache and removed a per-call thread-local lookup; on this server's micro-benchmarks that gave
roughly 1.2x-2x (noisy, depends on the program; no device figure exists). Heavy action games can still run slowly on
a weak phone. No bytecode compiler/JIT is planned: it would be a rewrite, not a tuning pass.

### Added in this build (V1.5)

* **Sound (MMAPI subset)**: `Manager.playTone`, `Manager.createPlayer` for `device://tone`, WAV (8/16-bit PCM, decoded
  in the runtime) and, through Android `MediaPlayer`, MIDI/MP3/AMR/AAC; `Player` lifecycle and `PlayerListener`
  events, `ToneControl` (tempo, resolution, blocks, volume, repeat - synthesised in the runtime), `VolumeControl`.
  Not provided: video, capture/recording, streaming locators, MIDIControl, RateControl, TempoControl.
* **Networking**: `Connector.open` with `http://`, `https://` (`HttpConnection`: GET/POST/HEAD, headers, response
  code, redirects) and `socket://host:port` (`SocketConnection`, TCP). **OFF by default**: a MIDlet gets
  `ConnectionNotFoundException` ("network access is switched off") until you tick *More > Network access*; the choice
  is remembered. Not provided: UDP, server sockets, SMS, Bluetooth, `comm:`.
* **FileConnection (JSR-75 files)**: restricted to one root `file:///root1/`, which is `J2MEBuilder/root1/` on shared
  storage when the IDE has file access (otherwise a private app folder, and the console says so); `..` escapes are refused. PIM (the other
  half of JSR-75) is Unsupported.
* **Location API (JSR-179)**: SIMULATED. Returns the position you enter in *More > Simulated location*; without one,
  `LocationException`. There is no real GPS.
* **DateField**: DATE / TIME / DATE_TIME, time zone, entry through a text dialog (`yyyy-MM-dd`, `HH:mm`).
* **Capability registry** (`Capabilities`, also shown in *More > Supported APIs*): every API row is labelled
  Implemented / Partially implemented / Simulated / Compile-time stub only / Unsupported, and the compatibility scan
  names the label for each missing class.

| API | Status |
|---|---|
| MIDlet lifecycle, Display, Canvas, Graphics, Image, Font, Command | Implemented |
| Form / List / TextBox / Alert and items incl. DateField, CustomItem | Implemented (single-column layout) |
| GameCanvas, Sprite, TiledLayer, LayerManager | Implemented |
| RMS | Implemented (per-suite files) |
| MMAPI audio (tone, WAV; encoded via Android) | Partially implemented |
| HttpConnection, SocketConnection | Partially implemented (opt-in) |
| FileConnection | Partially implemented (root1 = J2MEBuilder/root1 only) |
| Location API | Simulated |
| Ticker, vibrate, flashBacklight | Simulated (no visible effect) |
| PIM, Sensor, SIP, SVG/M2G, M3G, Bluetooth/OBEX, SMS/MMS, Content Handler | Unsupported |
| Nokia / Siemens / Samsung / Mascot extensions | Unsupported (only after a licence review) |
| copyArea | Unsupported |

## Verification status

Verified on a desktop JVM (JUnit, `src/test/java/.../emu`, 16 emulator tests; test MIDlets are compiled with javac
against stubs generated from the runtime by `tools/gen_midp_stubs.py`):
* Interpreter output identical to the real JVM on a 30-feature program.
* Hello MIDlet pixels, key delivery, command -> `notifyDestroyed`; pause/resume/stop without duplicate callbacks;
  crash contained with trace; busy-loop MIDlet stopped; JAD overrides manifest.
* Sprites, collisions, transforms, TiledLayer + animated tiles, LayerManager pixels, RMS (add/set/delete, enumeration
  with filter and comparator, closed/missing store errors, persistence on disk, per-suite scoping, clear), List
  select command, Form focus/ChoiceGroup/Gauge events, GameCanvas key states and flush, resize, compatibility scan,
  key map round trip.

Also verified on the desktop JVM (V1.5): tone sequences and WAV reach the audio hook with the right sample count;
Player state machine (realize/prefetch/start/close); HTTP and TCP socket against loopback servers, both blocked
when the network switch is off and working when on; FileConnection create/write/size and refusal of `..` escapes;
Location returns the simulated position and fails cleanly without one; DateField set/get; capability registry.

NOT verified (needs a device): real sound output (`AndroidAudio`: AudioTrack/MediaPlayer), real internet access,
Android permissions at run time, the new menu entries, everything in `emu/android` (compiled only for syntax, no android.jar here): the
activity, buttons, touch mapping, dialogs, screenshots, text input, real font metrics, performance on a low-end
phone, activity pause/resume with the screen off, and the Settings toggle / menu entry in `MainActivity`.

## Acceptance checklist for the device test

1. Settings -> Experimental -> switch "Built-in emulator" ON (a warning appears).
2. Build a Hello MIDlet, menu -> "Run in built-in emulator": the screen appears, console shows `startApp`.
3. Press Home and return: the console shows pause then resume exactly once each.
4. Stop, then Restart. Run a MIDlet that throws: the error and stack appear in the emulator console only.
5. Switch the toggle OFF: the menu entry disappears; "Open JAR in emulator" still opens your external emulator.


## Camera, microphone and video (V1.6.6, mission 2)

NOT verified on a phone: nothing in this step was compiled or run (no javac/JUnit in the build sandbox).

| API | How it works |
|---|---|
| `Manager.createPlayer("capture://video")` (also `capture://image`, `capture://devcamN`; `devcam1` = front camera) | `CameraPlayer`; the camera opens at `prefetch()`/`start()`; query parameters `width`/`height` are preview hints, unknown ones are ignored |
| `VideoControl` / `GUIControl` | `USE_DIRECT_VIDEO` is drawn over the Canvas after its `paint()` (hidden until `setVisible(true)`, as in the spec); `USE_GUI_PRIMITIVE` returns an `Item` for a Form; `setDisplayLocation/Size/FullScreen`, `getSourceWidth/Height` |
| `getSnapshot(null or "encoding=jpeg&width=320&height=240&quality=80")` | JPEG on the phone camera, PNG on the virtual camera or when the host cannot encode JPEG (`Image.createImage` reads both); size = preview size (about 640 px max) or the requested size (scaled) |
| `capture://audio?encoding=pcm&rate=8000&bits=16` + `RecordControl` | `MicPlayer`; PCM is buffered and written as a WAV file at `commit()` (`setRecordStream` or a `file:///root1/...` location); AMR and other encodings are refused with a message |
| Video files / URLs (3GP, MP4) | `Manager.createPlayer(InputStream, "video/3gpp")` or a `file:`/`http(s):` locator (downloaded fully first, max 24 MB); Android `MediaPlayer` decodes into an `ImageReader`, frames are shown through `VideoControl` |

Host side: `CameraProvider`, `MicProvider` and `VideoHost` (in `emu/midp`) are implemented by `AndroidCamera`, `AndroidMic` and
`AndroidAudio` (in `emu/android`); `VirtualCamera` (test pattern or a chosen picture) and `TestToneMic` need no hardware and are
what the tests use. `CAMERA` and `RECORD_AUDIO` are requested at run time by `Permissions` on first use; a refusal reaches the
MIDlet as a `SecurityException` and the console says how to fix it. Camera, microphone and players are closed when the session stops.
Choose the source in *More > Camera* / *More > Microphone*.

Added after the first camera step (V1.6.7):

- `capture://video` + `RecordControl`: phone camera only; `MediaRecorder` writes an MP4 (with sound when `RECORD_AUDIO` is
  allowed) into a temporary file, `commit()` copies it to `setRecordStream` or a `file:///root1/...` location. The preview may
  freeze while recording. The virtual camera cannot record (clear `IllegalStateException`). No size limit.
- `FramePositioningControl` on video files (`seek`, `skip`, `mapFrameToTime`, `mapTimeToFrame`) using an estimated frame rate
  (metadata when the phone gives it, else 15 fps); video rotation metadata is applied to the picture.
- *More > Camera*: flash light (torch) and zoom 100-400 %, applied to the phone camera now and at every opening.

Not implemented: JSR-234 camera controls (`ZoomControl`, `FlashControl`, `FocusControl`, ...) called by the MIDlet itself,
full-resolution still capture (snapshots stay at the preview size), recording with the virtual camera, streaming playback.

Phone test checklist: (1) run a MIDlet that opens `capture://video` and accept the permission dialog: preview appears and
follows the phone orientation; (2) `getSnapshot` result decodes with `Image.createImage`; (3) More > Camera > Test pattern works
without permission; (4) refuse the permission: the MIDlet gets an exception and the console explains; (5) `capture://audio` +
`RecordControl`, then play the WAV; (6) play a small 3GP/MP4 from `file:///root1/` (also a portrait phone video: it must be upright);
(7) record with `capture://video` + `RecordControl` and open the MP4; (8) More > Camera: torch and zoom change the picture.


## SMS / WMA (V1.6.8, mission 3)

NOT verified on a phone or on a desktop JVM: nothing was compiled or run in the build sandbox.

| API | How it works |
|---|---|
| `Connector.open("sms://+15551234567[:port]")` | client connection (send only): `SmsConn`; phone number characters `+ * # 0-9` (spaces, `-`, `.`, `()` are ignored) |
| `Connector.open("sms://:5000")` | server connection: receives through `receive()` (blocks; `InterruptedIOException` when closed) or `setMessageListener` (`notifyIncomingMessage` runs on its own thread, then call `receive()`) |
| `newMessage(TEXT_MESSAGE / BINARY_MESSAGE [, address])`, `TextMessage`, `BinaryMessage`, `getTimestamp` | client connections pre-fill the address; server connections do not |
| `numberOfSegments` | GSM 7-bit 160/153 (extension characters count 2), UCS-2 70/67, binary 140/134; 0 and `SizeExceededException` above 10 segments |
| `mms://`, `MultipartMessage`, `newMessage("multipart")` | Unsupported: `ConnectionNotFoundException` / `IllegalArgumentException` with a clear message |

Safety: `SmsProvider` is simulated by default (`SimulatedSms`): a send is only written to the console ("SIMULATED, nothing was
sent"). *More > SMS > Real SMS* uses `AndroidSms`: `SEND_SMS` is requested at run time and a dialog shows the number and text; the
message leaves the phone only if you tap *Send*, for EVERY message (a refusal is a `SecurityException` in the MIDlet and a line
in the console). Incoming messages: *More > SMS > Simulate an incoming SMS* delivers text to the MIDlet's server connection on a
port (0 listeners = dropped, with a console line). In real mode only binary (data) SMS addressed to the listened port are
forwarded (`RECEIVE_SMS`, run time); the phone's ordinary text messages are never given to a MIDlet (Android gives no port for
them and it would expose private messages). Play-store note: apps declaring `SEND_SMS`/`RECEIVE_SMS` need a Play policy
declaration; remove the two permissions and `AndroidSms` real mode if you publish there.

Host side: `SmsProvider`, `SmsBus`, `SmsUtil` in `emu/midp`; `AndroidSms` in `emu/android`; `EmuSession.setSms` /
`injectSms`; the tests use a fake provider.

Phone test checklist: (1) run a MIDlet that sends an SMS in simulated mode: the console says nothing was sent; (2) More > SMS >
Real, send again: permission dialog, then the confirmation dialog; tap *Don't send* and see the exception in the MIDlet; (3) send
to your own number and tap *Send*: the message arrives once; (4) a MIDlet listening on `sms://:5000` + More > Simulate an
incoming SMS (port 5000): the listener fires and `receive()` returns the text; (5) real binary SMS to the port (needs a second
phone/app that sends data SMS); (6) `mms://` gives the clear refusal.


## PIM / JSR-75 contacts, calendar and to-do (V1.6.9, mission 4)

NOT verified on a phone or on a desktop JVM: nothing was compiled or run in the build sandbox. The interfaces and constants were
generated from the bundled `jsr75.jar` so they match the real API exactly.

| Area | How it works |
|---|---|
| `PIM.getInstance().openPIMList(CONTACT_LIST / EVENT_LIST / TODO_LIST, mode[, name])` | one list per kind: "Contacts", "Events", "To Do"; other names give `PIMException(LIST_NOT_ACCESSIBLE)`; `listPIMLists` |
| `ContactList` / `EventList` / `ToDoList` | `createX`, `importX`, `removeX`, `items()`, `items(PIMItem)` (substring, case-insensitive, per field), `items(String)`, `itemsByCategory`, `EventList.items(STARTING/ENDING/OCCURRING, ...)` (repeat rules included unless `initialEventOnly`), `ToDoList.items(DUE/COMPLETION_DATE, start, end)` |
| Items | all JSR-75 field types (string, string array, int, date, boolean, binary), attributes on TEL/EMAIL/ADDR, `getPreferredIndex`, `FieldFullException`, `FieldEmptyException`, `UnsupportedFieldException`, `commit()` assigns UID and REVISION, categories (unlimited) |
| `RepeatRule` | `FREQUENCY`, `INTERVAL`, `COUNT`, `END`, `DAY_IN_WEEK` (weekly), `DAY_IN_MONTH`, `MONTH_IN_YEAR`, except dates; `dates()` expands DAILY/WEEKLY/MONTHLY/YEARLY. `WEEK_IN_MONTH` and `DAY_IN_YEAR` are stored but not expanded |
| Modes | `READ_ONLY` lists refuse `commit`/`remove`, `WRITE_ONLY` lists refuse reading: `SecurityException` |
| `fromSerialFormat` / `toSerialFormat` | not supported: `PIMException(FEATURE_NOT_SUPPORTED)`; `supportedSerialFormats` is empty |

Data and safety: by default MIDlets get a **sandbox** (an address book, calendar and to-do list of their own, saved in the MIDlet
suite's storage as `~pim.*`, not listed as record stores); your real contacts are never touched. *More > Contacts & calendar*
switches contacts and calendar events to **real phone data, read-only**: `READ_CONTACTS` / `READ_CALENDAR` are requested at run
time, a dialog asks before anything is shared with the MIDlet, and writes give a `SecurityException` (so the phone's data cannot
be damaged by an untested MIDlet). To-do lists stay in the sandbox (Android has no standard to-do store). Real contacts show name,
phones, emails, addresses, organization, title, note, website, nickname and birthday; events show title, start, end, location,
note and a simple repeat rule (FREQ / INTERVAL / COUNT). Photos and other fields are not read.

Host side: `PimStore`, `PimHost`, `PimData`, `PimSchema`, `PimRecord`, `PimCodec`, `SandboxStore` and the list/item classes in
`emu/midp`; `AndroidPimHost` in `emu/android`; `EmuSession.setPimHost`.

Phone test checklist: (1) a MIDlet that adds a contact in the sandbox, restarts, and finds it again; (2) More > Contacts &
calendar > Real: permission dialog, then the sharing dialog, then the MIDlet lists your real contacts (names, numbers); (3)
refuse the dialog: the MIDlet gets a `SecurityException`; (4) a MIDlet that writes in real mode gets a `SecurityException`, your
contacts are unchanged; (5) calendar events appear with start/end; (6) switch back to the sandbox.


## Sensors / JSR-256 (V1.7.0, mission 5)

NOT verified on a phone or on a desktop JVM: nothing was compiled or run in the build sandbox. The interfaces and constants were
generated from the JSR-256 classes bundled in `assets/j2me/api` so they match the real API.

| Area | How it works |
|---|---|
| `SensorManager.findSensors(quantity, contextType)` / `findSensors("sensor:acceleration;contextType=user;model=EmuSensor")` | empty array when nothing matches (also when the host has no sensors); `addSensorListener` is accepted and never called (all sensors are always available) |
| `Connector.open(sensorInfo.getUrl())` | `SensorConnectionImpl`; `ConnectionNotFoundException` lists the available quantities when nothing matches |
| Quantities | `acceleration` (axis_x/y/z, m/s2, gravity included, int channels with scale -3), `magnetic_field` (axis_x/y/z, T, scale -9), `orientation` (azimuth, pitch, roll in degrees), `light` (lux), `proximity` (m). Light and proximity are extras; the other names follow the usual JSR-256 names but should be checked against the spec |
| `getData(n)` / `getData(n, period, timestamps, uncertainty, validity)` | blocks while n samples are taken at 50 Hz; `IllegalStateException` while a listener is set; timestamps/validity only when requested |
| `setDataListener(listener, bufferSize[, period, ...])` / `removeDataListener` | own thread, calls `dataReceived(conn, Data[], false)` every bufferSize samples (or period); state `STATE_LISTENING` |
| `Channel.addCondition(listener, LimitCondition / RangeCondition / ObjectCondition)` | checked at 50 Hz, `conditionMet` fires when a condition turns from false to true |
| `Data` | lenient on purpose: `getIntValues()` on a double channel and `getDoubleValues()` on an int channel convert with the channel scale instead of throwing |

Host side: `SensorProvider` (pure Java), `SimulatedSensors` (values set by sliders / keys / tests) and `AndroidSensors`
(accelerometer, magnetometer, rotation vector or accelerometer+magnetometer for orientation, light, proximity; 50 Hz; no
permission). `Device.sensors`, `EmuSession.setSensors`. *More > Sensors*: phone sensors, simulated with sliders, or simulated
with the arrow keys of an external keyboard tilting the phone (the on-screen pad is not used for tilt).

Vendor accelerometer APIs (Nokia, Samsung, Sony Ericsson) and `javax.microedition.sensor.control` are Unsupported; the vendor
ones are left out until their licence terms are reviewed. `SensorProvider` is the common adapter to add them to later.

Phone test checklist: (1) a MIDlet that lists `findSensors("acceleration", null)` and prints a value: lying flat gives z about
9.8 m/s2 (9807 as int); (2) tilt the phone: x/y change, a `DataListener` receives buffers; (3) a `LimitCondition` fires when you
shake past the limit; (4) More > Sensors > Simulated: the sliders change what the MIDlet reads; (5) orientation turns with the
phone (azimuth 0-360); (6) a phone without a given sensor: `findSensors` returns an empty array.


## Bluetooth / JSR-82 (V1.7.1, mission 6)

NOT verified on a phone or on a desktop JVM: nothing was compiled or run in the build sandbox. The API classes were generated from
the JSR-82 classes bundled in `assets/j2me/api` (the sources in the TK 10.2 and MicroEmulator zips only contain empty API stubs).

| Area | How it works |
|---|---|
| `LocalDevice.getLocalDevice()` | `BluetoothStateException` when the host has no Bluetooth; name, address (12 hex digits; Android hides the real one), `getProperty("bluetooth.api.version")` = 1.1, `isPowerOn`; `setDiscoverable` is ignored (Android asks the user), `getRecord` for a service notifier |
| `DiscoveryAgent` | `startInquiry` / `cancelInquiry` (callbacks on a thread of their own), `retrieveDevices(PREKNOWN)` = paired devices and `CACHED` = found in this run, `searchServices` (UUIDs advertised by the device; SPP assumed when the phone does not know them), `selectService` |
| `RemoteDevice`, `DeviceClass`, `UUID`, `ServiceRecord`, `DataElement` | complete for what MIDlets use; `authenticate`/`authorize`/`encrypt` return false (pair in Android settings) |
| `Connector.open("btspp://ADDRESS:1[;uuid=HEX]")` | RFCOMM client (SPP UUID 1101 unless a `uuid=` parameter or a 32-digit UUID is given); `getConnectionURL` of a found record carries the `uuid=` |
| `Connector.open("btspp://localhost:UUID;name=...")` | RFCOMM server: `acceptAndOpen()` returns a `StreamConnection` |
| `btl2cap://`, `btgoep://`, `irdaobex://` | Unsupported: `ConnectionNotFoundException` with a clear message |

Safety: Bluetooth is **simulated by default** (`SimulatedBluetooth`: one paired virtual device "Emulator BT Echo", address
001122334455, that sends back what the MIDlet writes; servers wait for More > Bluetooth > "a device connects to the MIDlet's
service"). *More > Bluetooth > Real* uses `AndroidBluetooth`: `BLUETOOTH_CONNECT` / `BLUETOOTH_SCAN` (Android 12+) and location
(Android needs it for scanning) are asked at run time, and a dialog asks before the MIDlet lists paired devices, scans, connects
to a device (once per device and run) or offers a service. Every action is written to the console. The phone's Bluetooth is never
switched on or paired by the emulator.

Phone test checklist: (1) simulated mode: a MIDlet that does inquiry, service search and `btspp://` echo works without any
permission; (2) More > Bluetooth > Real with Bluetooth off: clear error; with Bluetooth on: permission dialogs, then the
"search" dialog, then the devices found; (3) connect to a paired serial-port device (for example an HC-05 module or a PC SPP
service): the dialog names the device and data flows both ways; (4) refuse a dialog: the MIDlet gets a `SecurityException`;
(5) offer a service with `btspp://localhost:UUID` and connect from a paired phone.


## Mission 7 - SVG/M2G, SIP, M3G (V1.7.2, first part)

NOT verified on a phone or on a desktop JVM: nothing was compiled or run in the build sandbox.

**SVG / M2G (JSR-226), static pictures**: `SVGImage.createImage(InputStream | resource | file:///..., handler)`, `getViewportWidth/Height`
and the setters (the picture is scaled to the viewport), `ScalableGraphics.createInstance / bindTarget(Graphics) / render(x, y, image) /
releaseTarget / setTransparency / setRenderingQuality`. The document is parsed with the platform XML parser (external DTDs are never
fetched) and drawn from its DOM at every `render` with a small anti-aliased rasterizer (`SvgDoc`, `SvgPath`, `SvgRaster`, pure Java):
svg/g/a/switch/use, rect (rounded), circle, ellipse, line, polyline, polygon, path (all commands, arcs), transforms, fill/stroke with
names, `#rgb`, `rgb()`, opacity, fill-rule, stroke-width (round joins and caps), `style=""`, viewBox + preserveAspectRatio, gradients as
their first stop colour. Not drawn: text, images, filters, masks, clipping, patterns, dashes, real gradients. `getDocument()` returns a
plain DOM (the SVG-specific `org.w3c.dom.svg` interfaces, `focusOn`, `dispatchMouseEvent`, `createEmptyImage` and `SVGAnimator` are not
provided; `createAnimator` throws a clear `UnsupportedOperationException`).

**SIP (JSR-180)**: Unsupported. `Connector.open("sip:...")` gives a `ConnectionNotFoundException` with an explanation.

**M3G (JSR-184)**: Unsupported for now. The 3D engine inside the TK 10.2 zip was NOT reused: it is JADX-decompiled code (about 9,700 lines,
with damaged spots: wrong constants such as `androidx...ViewCompat` and `proguard.ConfigurationConstants` in the middle of the maths, and
26 decompiler warnings), it depends on microemu classes of that app, and the zip carries no licence statement. Copying it would break the
rule of this project (only code with a compatible licence, with attribution). Ways forward: (a) TK provides the original source with a
licence (for example Apache-2.0), then it can be integrated in `emu/midp` behind the same `Graphics3D` API; (b) write it in sub-steps from the
J2ME-Loader (Apache-2.0) design: `Loader` for `.m3g` files first, then immediate-mode rendering, then retained mode (World/Group/Mesh/
Camera/Light), drawing into the emulator `Frame` (software) before any GLES.

Phone test checklist (SVG): (1) a MIDlet that loads a small SVG from its jar and renders it at 1x and 2x: shapes and colours match a
browser; (2) a path with curves/arcs looks smooth; (3) `setTransparency(0.5f)` blends with the Canvas behind; (4) an SVG with text shows
without text (nothing crashes); (5) `Connector.open("sip:...")` refuses clearly.


## Mission 8 - phone-maker extensions (V1.7.3)

NOT verified on a phone or on a desktop JVM: nothing was compiled or run in the build sandbox.

Two fixes found while preparing this step (both affected earlier missions): (1) the class mapping (`Names`, `Instrumenter`, `Vm`,
`Diagnostics`) only knew `javax.microedition.*`, so `javax.bluetooth.*` (mission 6) would never have been mapped to the runtime; it now
knows every package this runtime provides (`Names.isApi`: `javax.microedition`, `javax.bluetooth`, `javax.obex`, `javax.wireless`,
`com.nokia`, `com.samsung`, ...). (2) The SMS API of mission 3 was declared in the wrong package (`javax.microedition.wireless.messaging`);
the real JSR-120 package is `javax.wireless.messaging` and the classes, test stubs and capability rows now use it. The "compatibility"
summary no longer lists PIM, sensors, Bluetooth serial or SMS as "not available".

What is provided (written from the public API, no vendor SDK code, no code from any decompiled app):

| Package | Classes |
|---|---|
| `com.nokia.mid.ui` | `FullCanvas` (key constants -1..-4 arrows, -6/-7/-5 soft keys, -10/-11 send/end; commands throw `IllegalStateException`), `DeviceControl` (`setLights`, `flashLights`, `startVibra`, `stopVibra`; accepted, no visible effect), `DirectUtils` (`getDirectGraphics`, `createImage` mutable from colour or data, `getFont`), `DirectGraphics` (`setARGBColor`, `fill/drawPolygon`, `fill/drawTriangle` with alpha, `drawImage` and `drawPixels` for int ARGB/RGB, short 4444/444/555/565 and byte 8-bit gray / 3-3-2 with `FLIP_*` and counter-clockwise `ROTATE_*`, `getPixels` for int and short) |
| `com.nokia.mid.sound` | `Sound` (WAV data and single tones; `play(loop)` with 0 = until stopped, gain 0..255, listener events `SOUND_PLAYING` / `SOUND_STOPPED`; Nokia ringtone binary data stays silent with a console line), `SoundListener` |
| `com.samsung.util` | `Vibration` (strength 0..5), `LCDLight`, `AudioClip` (MP3 and MIDI; MMF stays silent; volume 0..5) |

Not provided (still "Unsupported" in the compatibility list, with a clear missing-class message): Nokia `TextEditor`, `CanvasItem`,
`UIStyle`, Series 40 sensors; `com.siemens.mp.*`; `com.motorola.*`; `com.sonyericsson.*`; Samsung SMS/other classes; packed 1/2/4-bit
`DirectGraphics` formats; and `com.mascotcapsule.micro3d.v3`, which needs a 3D engine (see M3G above) - it can only be added through code
with a compatible licence. The constants and semantics here (rotation direction, `loop 0`, Samsung ranges) come from the public
documentation as remembered and must be checked against a real game: treat them as "needs a phone test".

Phone test checklist: (1) a Series 40 game extending `FullCanvas` starts and the soft keys arrive as -6/-7; (2) its `DirectGraphics`
alpha sprites, flipped and rotated frames look right (if a rotation turns the wrong way, the mapping in `DirectGraphicsImpl.drawArgb`
is the single place to change); (3) `Sound` plays a WAV and the listener fires; (4) a Samsung game's `Vibration`/`AudioClip` do not crash.


## M3G (JSR-184), step 1 of 3 (V1.8.0)

NOT verified on a phone or on a desktop JVM: nothing was compiled or run in the build sandbox. Written from the JSR-184 API (the class
list, constants and signatures were generated from the JSR-184 classes bundled in `assets/j2me/api`); no code was taken from the TK 10.2
zip, from J2ME-Loader or from any other project.

| Area | State |
|---|---|
| API surface | all 30 classes with exact signatures and constants (`Names`); unimplemented methods throw `UnsupportedOperationException` with the method name |
| Maths and scene graph | `Transform` (4x4, invert, rotate, quaternion, transform arrays/vertices), `Transformable` (T*R*S*M composite), `Node` (alpha, scope, `getTransformTo`), `Group`, `World`, `Camera` (perspective / parallel / generic), `Object3D` (user id/object, tracks, `find`) |
| Geometry | `VertexArray` (byte/short), `VertexBuffer` (positions, normals, colours, 8 texture units, scale/bias, default colour), `IndexBuffer` / `TriangleStripArray`, `Mesh` (submeshes, appearances) |
| Appearance | `Appearance`, `Material`, `Light` (ambient, directional, omni, spot), `Fog`, `PolygonMode`, `CompositingMode`, `Texture2D` + `Image2D` (all formats), `Background` (colour, depth, image, crop, repeat) |
| Rendering | `Graphics3D` bound to a `Graphics`: `setViewport`, `clear`, `setCamera`, lights, `render(World)`, `render(Node, Transform)`, `render(VertexBuffer, IndexBuffer, Appearance, Transform[, scope])`; software rasterizer with near-plane clipping, perspective-correct interpolation, depth buffer, back-face culling, per-vertex lighting (diffuse, specular, attenuation, spot), fog, texture filtering and wrapping, texture functions, alpha threshold and the five blending modes; appearance layers sort the draw order |
| Not yet | `Loader` for `.m3g` files (throws a clear `IOException`; step 2), `Sprite3D` drawing, skinning (`SkinnedMesh` draws its bind pose) and morphing (base mesh only), keyframe animation playback (`animate` does nothing; step 3), picking (`pick` returns false), alignment, mipmaps, antialiasing, depth offset, two-sided lighting, `Object3D.duplicate` |

Plan: step 2 = `Loader` (the `.m3g` container, zlib sections and the object types), step 3 = animation (`KeyframeSequence`,
`AnimationController`, `animate`), `Sprite3D`, skinning, morphing and picking, then speed work (the rasterizer is plain Java; a GLES back end
could replace `Graphics3D.raster` later without changing the API classes). Mascot Capsule v3 (`com.mascotcapsule.micro3d.v3`) can reuse the
same rasterizer, but its API is a separate job that needs a compatible licence for its data formats.

Phone test checklist: (1) a MIDlet that builds a coloured triangle and renders it with a perspective camera shows it centred, with the same
winding rule as a real phone (back faces hidden); (2) lights change the colour as the surface turns; (3) a textured quad shows its picture;
(4) a `World` with a camera and several meshes renders in the right order; (5) frame rate on a 240x320 screen with a few hundred triangles
(note it in the report: it is a software renderer).


## M3G steps 2 and 3: Loader, animation, sprites, skinning, morphing, picking, speed (V1.9.0)

NOT verified on a phone or on a desktop JVM: nothing was compiled or run in the build sandbox. Written from the JSR-184 API and file
format; no code from the TK 10.2 zip, J2ME-Loader or any other project. The object type numbers and field orders of the file format
come from memory of the specification: if a real `.m3g` file is rejected, `M3gReader.create` is the one place to compare.

| Area | State |
|---|---|
| `Loader.load(name)` / `load(bytes, offset)` | identifier check, sections (stored or zlib), every object type (header, animation controller / track, appearance, background, camera, compositing mode, fog, polygon mode, group, image 2D, triangle strips, light, material, mesh, morphing mesh, skinned mesh, texture 2D, sprite 3D, keyframe sequence, vertex array incl. delta encoding, vertex buffer, world), forward references, returns the objects nothing else refers to; PNG/JPEG data gives one `Image2D`; external references load as null |
| Animation | `Object3D.animate(time)` plays the tracks of the object and everything it refers to: keyframes LINEAR / STEP / SLERP / SPLINE (SQUAD as SLERP), repeat CONSTANT / LOOP, valid range, controller speed / position / weight / active interval, tracks driving the same property are blended by weight; properties: alpha, colours, crop, density, near/far, field of view, intensity, morph weights, orientation, pickability, scale, shininess, spot angle/exponent, translation, visibility; returns 0 when something moved |
| `Sprite3D` | scaled (units of the node scale) and unscaled (screen pixels) sprites with crop, drawn through the same pipeline (appearance compositing mode decides transparency) |
| `SkinnedMesh` | the skeleton becomes a child of the mesh; the bone pose at `addTransform` (or at load, after the tree is assembled) is the bind pose; weights are normalised per vertex; normals follow the bones; `getBoneTransform`, `getBoneVertices` |
| `MorphingMesh` | weights blend positions, normals and colours of the targets |
| Picking | `Group.pick(scope, ray)` and `pick(scope, x, y, camera)`: closest Mesh, distance, submesh, texture coordinates, normal, ray; respects back-face culling and picking/scope flags; uses the undeformed mesh |
| Speed | the rasterizer steps every attribute and the depth with one addition per pixel, solves the covered span of each row from the edge equations (no per-pixel inside test) and needs one division per pixel; near-plane clipping only when a triangle crosses it; no per-triangle allocation on the common path. It is still a Java software renderer: report the frame rate of a real game |

Not yet: node alignment, mipmaps, antialiasing, depth offset, two-sided lighting, `Object3D.duplicate`, SQUAD interpolation, picking of
skinned/morphed shapes in their deformed pose.

**Mascot Capsule v3 (`com.mascotcapsule.micro3d.v3`)** is NOT done. The API classes are bundled for compiling, but the runtime needs the model
and motion file formats (MBAC / MTRA) and exact rendering rules, and neither the specification nor a licensed implementation is in the
project. The honest options: supply the source of the Apache-2.0 J2ME-Loader `micro3d` package (it can then be ported with attribution),
or a written format description. The rasterizer above is ready to be reused for it.

Phone test checklist (3D): (1) a game that ships `.m3g` files loads its world and shows it; (2) animated characters play (set `animate`
time from `System.currentTimeMillis()`); (3) skinned/morphed models deform; (4) picking returns the object under the touch point;
(5) note the frame rate on a 240x320 screen: if it is too low, the next lever is a fixed-point inner loop, then GLES.
